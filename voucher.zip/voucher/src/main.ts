import { NestFactory } from '@nestjs/core';
import {
  FastifyAdapter,
  NestFastifyApplication,
} from '@nestjs/platform-fastify';
import FastifyCaching from '@fastify/caching';
import { join } from 'path';
import fastifyCookie from '@fastify/cookie';
import createServer from 'next';

import { AppModule } from './app.module';
import { VersioningType } from '@nestjs/common';
import { ValidationPipe } from './core/pipes/validation.pipe';
import { ErrorFilter } from './core/filters/error.filter';
import setUpSwagger from './common/config/setup-swagger';
import { ViewModule } from './common/view/view.module';
import { ViewService } from './common/view/view.service';
import { sslCa, sslCrt, sslKey } from './common/config/secret';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function startServer() {
  const httpsOptions = {
    key: sslKey,
    cert: sslCrt,
    ca: sslCa,
  };

  const app = await NestFactory.create<NestFastifyApplication>(
    AppModule.initialize(),
    new FastifyAdapter({
      logger: process.env.APP_ENV === 'dev',
      trustProxy: true,
    }),
  );

  const appView = await NestFactory.create<NestFastifyApplication>(
    ViewModule,
    new FastifyAdapter({
      logger: process.env.APP_ENV === 'dev',
      https: httpsOptions,
    }),
  );

  // app.register(require('fastify-https-redirect'));
  // appView.register(require('fastify-https-redirect'));
  // app.enableCors();

  const origin = [
    'https://niagapay.click',
    'https://portal.niagapay.click',
    'https://primevoucher.store',
  ];
  app.register(require('@fastify/cors'), {
    origin,
  });
  appView.register(require('@fastify/cors'), {
    origin: origin,
  });

  app.register(FastifyCaching, {
    privacy: FastifyCaching.privacy.NOCACHE,
  });
  appView.register(FastifyCaching, {
    privacy: FastifyCaching.privacy.NOCACHE,
  });

  // appView.register(fastifyCookie, {
  //   secret: process.env.SWAGGER_KEY,
  // });

  appView.register(require('@fastify/static'), {
    root: join(__dirname, '..', 'images'),
    prefix: '/images/',
    // exclude: ['/api*'],
  });

  appView.register(require('@fastify/http-proxy'), {
    upstream: 'http://localhost:3000',
    constraints: { host: /.*\.niagapay\.click/ },
    proxyPayloads: false,
    preHandler(request: any, _reply: any, next: any) {
      request.headers['hostname'] = request.hostname;
      request.headers['x-forwarded-for'] = request.ip;
      next();
    },
  });

  const nextServer = createServer({
    dev: false,
    dir: join(__dirname, '..'),
    conf: {
      reactStrictMode: false,
      images: {
        domains: ['niagapay.click'],
      },
      target: 'server',
      outputFileTracing: false,
      productionBrowserSourceMaps: false,
      optimizeFonts: true,
      swcMinify: true,
    },
  });
  const viewService = appView.select(ViewModule).get(ViewService);
  await viewService.setNextServer(nextServer, true);
  viewService.setNextHandler();

  // app.setGlobalPrefix('api');
  app.enableVersioning({
    type: VersioningType.URI,
  });

  // app.useGlobalFilters(new ErrorFilter(viewService));
  // appView.useGlobalFilters(new ErrorFilter(viewService));
  app.useGlobalPipes(new ValidationPipe());

  // setUpSwagger(app, app.getHttpAdapter().getInstance(), app);

  // await app.listen(parseInt(process.env.PORT_HTTP), '0.0.0.0');
  // console.log('HTTP Server running on port ' + process.env.PORT_HTTP);
  try {
    if (process.env.APP_ENV === 'dev') {
      app.register(fastifyCookie, {
        secret: process.env.SWAGGER_KEY,
      });
      setUpSwagger(app, app.getHttpAdapter().getInstance(), app);
      await app.listen(parseInt(process.env.PORT_HTTP), '0.0.0.0');
      console.log('DEV Server running on port ' + process.env.PORT_HTTP);
    } else {
      await app.listen(parseInt(process.env.PORT_API), '0.0.0.0');
      console.log('API Server running on port ' + process.env.PORT_API);
      await appView.listen(parseInt(process.env.PORT_HTTPS), '0.0.0.0');
      console.log('HTTPS Server running on port ' + process.env.PORT_HTTPS);
    }
  } catch (err) {
    console.log(err);
  }
}

startServer();
