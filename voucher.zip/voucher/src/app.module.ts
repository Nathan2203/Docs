import { DynamicModule, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_FILTER, APP_GUARD } from '@nestjs/core';
import { MongooseModule } from '@nestjs/mongoose';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { ScheduleModule } from '@nestjs/schedule';
import { V1Module } from './api/v1/v1.module';
import { TaskModule } from './core/task/task.module';
import { ErrorFilter } from './core/filters/error.filter';

@Module({})
export class AppModule {
  public static async initialize(): Promise<DynamicModule> {
    return {
      module: AppModule,
      imports: [
        ConfigModule.forRoot({
          expandVariables: true,
        }),
        ThrottlerModule.forRoot({
          ttl: 5,
          limit: 10,
        }),
        MongooseModule.forRoot(
          process.env.APP_ENV === 'prod'
            ? process.env.MONGODB_URL_PROD
            : process.env.MONGODB_URL_DEV,
        ),
        ScheduleModule.forRoot(),
        process.env.APP_ENV === 'prod' ? TaskModule : null,
        V1Module,
      ],
      providers: [
        {
          provide: APP_GUARD,
          useClass: ThrottlerGuard,
        },
        {
          provide: APP_FILTER,
          useClass: ErrorFilter,
        },
      ],
    };
  }
}
