import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import { UserService } from './user.service';
import {
  ApiBearerAuth,
  ApiHeader,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { FastifyReply } from 'fastify';

import { FastifyUserRequest } from 'src/common/interface/fastify-user.interface';
import { UserGuard } from 'src/common/middleware/user/user.guard';
import { Roles } from 'src/core/decorators/role.decorator';
import { Role } from 'src/common/config/enum';
import { ValidationPipe } from 'src/core/pipes/validation.pipe';

import { UpdateProfileDto } from './dto/update-profile.dto';
import { ProcessDto } from './dto/process.dto';
import { QueryDto } from '../admin/dto/query.dto';
import { ChangePassDto } from './dto/change-pass.dto';

@ApiTags('User')
@Controller({ path: 'user', version: '1' })
@ApiBearerAuth()
@ApiHeader({
  name: 'x-browser-id',
  description: 'Browser ID',
  required: true,
})
@ApiHeader({ name: 'session' })
@Roles(Role.User)
@UseGuards(UserGuard)
export class UserController {
  constructor(private userService: UserService) {}

  @Get('/profile')
  getProfile(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.userService.getProfile(req, res);
  }

  @Patch('/profile')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  getData(
    @Body(new ValidationPipe()) updateProfileDto: UpdateProfileDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.userService.updateProfile(updateProfileDto, req, res);
  }

  @Post('/profile/pass')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  changePass(
    @Body(new ValidationPipe()) data: ChangePassDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.userService.changePass(data, req, res);
  }

  @Get('/history')
  getHistory(
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.userService.getHistory(query, req, res);
  }

  @Get('/history/:id')
  getHistoryDetail(
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.userService.getHistoryDetail(id, req, res);
  }

  @Post('/process')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, productId + '|' + data + '|' + methodId + '|' + browserId) encoding hex",
  })
  process(
    @Body(new ValidationPipe()) processDto: ProcessDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.userService.process(processDto, req, res);
  }

  @Get('/invoice/:id')
  getInvoice(@Param('id') id: string, @Res() res: FastifyReply) {
    this.userService.getInvoice(id, res);
  }

  @Get('/invoice/s/:id')
  checkInvoiceStatus(@Param('id') id: string, @Res() res: FastifyReply) {
    this.userService.checkInvoiceStatus(id, res);
  }
}
