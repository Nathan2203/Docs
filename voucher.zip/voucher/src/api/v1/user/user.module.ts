import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { User, UserSchema } from 'src/api/v1/user/entities/user.entity';
import { UserGuard } from 'src/common/middleware/user/user.guard';
import { Session, SessionSchema } from './entities/session.entity';
import { UserController } from './user.controller';
import { UserService } from './user.service';
import { UserStrategy } from 'src/common/middleware/user/user.strategy';
import { Balance, BalanceSchema } from './entities/balance.entity';
import { Browser, BrowserSchema } from './entities/browser.entity';
import { Product, ProductSchema } from '../public/entities/product.entity';
import { Transaction, TransactionSchema } from './entities/transaction.entity';
import { Method, MethodSchema } from '../public/entities/method.entity';
import { BalanceLog, BalanceLogSchema } from './entities/balance-log.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      {
        name: Session.name,
        schema: SessionSchema,
      },
      { name: Browser.name, schema: BrowserSchema },
      { name: Balance.name, schema: BalanceSchema },
      { name: BalanceLog.name, schema: BalanceLogSchema },
      { name: Product.name, schema: ProductSchema },
      { name: Transaction.name, schema: TransactionSchema },
      { name: Method.name, schema: MethodSchema },
    ]),
  ],
  controllers: [UserController],
  providers: [UserService, UserStrategy, UserGuard],
})
export class UserModule {}
