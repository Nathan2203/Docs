import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';

export type BalanceDocument = HydratedDocument<Balance>;

@Schema({ timestamps: true })
export class Balance {
  @Prop({ default: 0 })
  balance: number;

  @Prop({ default: 0 })
  pending: number;

  @Prop({ default: 0 })
  freeze: number;

  @Prop({ default: 0 })
  debt: number;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;
}

export const BalanceSchema = SchemaFactory.createForClass(Balance);
