import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';
import { BalanceLogType } from 'src/common/config/enum';

export type BalanceLogDocument = HydratedDocument<BalanceLog>;

@Schema({ timestamps: true })
export class BalanceLog {
  @Prop()
  name: string;

  @Prop()
  balanceAmount: number;

  @Prop()
  balanceCredit: number;

  @Prop()
  pgAmount: number;

  @Prop()
  pgCredit: number;

  @Prop()
  dfAmount: number;

  @Prop()
  msg: string;

  @Prop({ enum: BalanceLogType })
  type: BalanceLogType;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Balance' })
  balance: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Transaction' })
  transaction: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Withdraw' })
  withdraw: Types.ObjectId;
}

export const BalanceLogSchema = SchemaFactory.createForClass(BalanceLog);
