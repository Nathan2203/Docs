import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';
import {
  AccessFrom,
  TransactionStatusType,
  TransactionType,
} from 'src/common/config/enum';

export type TransactionDocument = HydratedDocument<Transaction>;

@Schema({ timestamps: true })
export class Transaction {
  @Prop()
  form: string;

  @Prop()
  email: string;

  @Prop()
  transactionId: string;

  @Prop()
  orderId: string;

  @Prop()
  refId: string;

  @Prop()
  amount: number;

  @Prop()
  fee: number;

  @Prop()
  feeAdmin: number;

  @Prop()
  debt: number;

  @Prop()
  usedBalance: number;

  @Prop()
  phone: string;

  @Prop()
  payment: string;

  @Prop()
  url: string;

  @Prop({ type: Date })
  exp: Date;

  @Prop({ enum: TransactionType, default: TransactionType.Transaction })
  transactionType: string;

  @Prop({ enum: TransactionStatusType, default: TransactionStatusType.Pending })
  status: string;

  @Prop({ enum: AccessFrom, default: AccessFrom.Dashboard })
  accessFrom: string;

  @Prop({ default: false })
  pgSettled: boolean;

  @Prop()
  paidRef: string;

  @Prop({ type: Date })
  paidTime: Date;

  @Prop()
  serialNumber: string;

  @Prop()
  clientRef: string;

  @Prop()
  clientCustName: string;

  @Prop({ default: false })
  clientSettled: boolean;

  @Prop({ type: Date })
  clientSettleDate: Date;

  @Prop()
  error: string;

  @Prop()
  dfTrxId: string;

  @Prop()
  dfSn: string;

  @Prop([
    {
      _id: false,
      id: { type: Number },
      commission: { type: SchemaTypes.ObjectId, ref: 'Commission' },
      amount: { type: Number },
    },
  ])
  uplineFee: Record<string, any>[];

  @Prop()
  ip: string;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Method' })
  method: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Product' })
  product: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Provider' })
  provider: Types.ObjectId;
}

export const TransactionSchema = SchemaFactory.createForClass(Transaction);
TransactionSchema.index(
  { user: 1, clientRef: 1 },
  { unique: true, partialFilterExpression: { clientRef: { $exists: true } } },
);
