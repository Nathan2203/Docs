import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';

export type BrowserDocument = HydratedDocument<Browser>;

@Schema({ timestamps: true })
export class Browser {
  @Prop()
  browserId: string;

  @Prop()
  userAgent: string;

  @Prop()
  ip: Types.Array<string>;

  @Prop()
  csrf: string;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;
}

export const BrowserSchema = SchemaFactory.createForClass(Browser);
