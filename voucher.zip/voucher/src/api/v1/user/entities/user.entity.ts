import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';
import { SignJWT, importPKCS8 } from 'jose';
import { privKey } from 'src/common/config/secret';
import * as bcrypt from 'bcrypt';
import { JWT_ALG } from 'src/common/config/constants';
import { Role } from 'src/common/config/enum';

export type UserDocument = HydratedDocument<User>;

@Schema({ timestamps: true })
export class User {
  @Prop()
  email: string;

  @Prop()
  username: string;

  @Prop()
  company: string;

  @Prop()
  phone: string;

  @Prop()
  pass: string;

  @Prop()
  secret2Fa: string;

  @Prop({ default: Role.User, enum: Role })
  role: string;

  @Prop({ default: false })
  isVerified: boolean;

  @Prop({ default: false })
  isBlocked: boolean;

  @Prop({ default: false })
  isDeleted: boolean;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  upline: Types.ObjectId;

  generateJWT: Function;

  comparePass: Function;
}

export const UserSchema = SchemaFactory.createForClass(User);

UserSchema.pre('save', function (next) {
  if (this.isNew) {
    next();
  } else if (this.isModified('role')) {
    throw new Error('This field is read only');
  } else {
    next();
  }
});

UserSchema.methods.generateJWT = async function () {
  const payload = {
    id: this._id,
    role: this.role,
  };

  var privateKEY = await importPKCS8(privKey, process.env.USER_JWT_ALG);
  const jwt = await new SignJWT(payload)
    .setProtectedHeader({ alg: JWT_ALG })
    .setExpirationTime('1d')
    .setIssuer('NiagaPay')
    .sign(privateKEY);

  return `Bearer ${jwt}`;
};

UserSchema.methods.comparePass = function (pass: string) {
  return bcrypt.compareSync(pass, this.pass);
};
