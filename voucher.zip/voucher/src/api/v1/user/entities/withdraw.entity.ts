import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';
import {
  AccessFrom,
  WithdrawProcess,
  WithdrawStatus,
  WithdrawType,
} from 'src/common/config/enum';

export type WithdrawDocument = HydratedDocument<Withdraw>;

@Schema({ timestamps: true })
export class Withdraw {
  @Prop()
  withdrawId: string;

  @Prop()
  orderId: string;

  @Prop()
  amount: number;

  @Prop()
  fee: number;

  @Prop()
  feeAdmin: number;

  @Prop()
  name: string;

  @Prop()
  accNumber: string;

  @Prop()
  email: string;

  @Prop()
  phone: string;

  @Prop()
  remark: string;

  @Prop()
  inquiryReff: string;

  @Prop({ type: Date })
  exp: Date;

  @Prop({ enum: WithdrawProcess, default: WithdrawProcess.Inquiry })
  process: string;

  @Prop({ enum: WithdrawStatus })
  status: string;

  @Prop({ enum: WithdrawType })
  withdrawType: string;

  @Prop({ enum: AccessFrom, default: AccessFrom.Dashboard })
  accessFrom: string;

  @Prop()
  clientRef: string;

  @Prop({ default: false })
  callbackSent: boolean;

  @Prop()
  errorCallback: string;

  @Prop()
  resCallback: string;

  @Prop({ type: Date })
  lastCallback: Date;

  @Prop()
  error: string;

  @Prop()
  note: string;

  @Prop({ type: Date })
  processedDate: Date;

  @Prop({ type: Date })
  paidDate: Date;

  @Prop()
  serialNumber: string;

  @Prop()
  paidReff: string;

  @Prop([
    {
      _id: false,
      id: { type: Number },
      commission: { type: SchemaTypes.ObjectId, ref: 'Commission' },
      amount: { type: Number },
    },
  ])
  uplineFee: Record<string, any>[];

  @Prop()
  ip: string;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  inquiryBy: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  processedBy: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Bank' })
  bank: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'BankAccount' })
  bankAccount: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Provider' })
  provider: Types.ObjectId;
}

export const WithdrawSchema = SchemaFactory.createForClass(Withdraw);
WithdrawSchema.index(
  { user: 1, clientRef: 1 },
  { unique: true, partialFilterExpression: { clientRef: { $exists: true } } },
);
