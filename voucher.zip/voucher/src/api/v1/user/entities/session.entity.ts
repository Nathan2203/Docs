import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';

export type SessionDocument = HydratedDocument<Session>;

@Schema({ timestamps: true })
export class Session {
  @Prop()
  sessionToken: string;

  @Prop({ type: Date })
  sessionExpires: Date;

  @Prop()
  refreshToken: string;

  @Prop({ type: Date })
  refreshExpires: Date;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;

  @Prop({ type: Date })
  lastActivityDate: Date;
}

export const SessionSchema = SchemaFactory.createForClass(Session);
