import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class ProcessDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsString()
  @IsNotEmpty({ message: 'Product ID must not be empty' })
  productId: string;

  @IsString()
  @IsNotEmpty({ message: 'Data must not be empty' })
  data: string;

  @IsString()
  @IsNotEmpty({ message: 'Method ID must not be empty' })
  method: string;

  @IsString()
  @IsOptional()
  phone: string;
}
