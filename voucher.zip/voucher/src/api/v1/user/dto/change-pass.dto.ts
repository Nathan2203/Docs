import { IsNotEmpty, IsString } from 'class-validator';

export class ChangePassDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsString()
  @IsNotEmpty({ message: 'Current Password must not be empty' })
  old: string;

  @IsString()
  @IsNotEmpty({ message: 'New Password must not be empty' })
  new: string;
}
