import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { FastifyReply } from 'fastify';
import fetch from 'node-fetch';

import { FastifyUserRequest } from 'src/common/interface/fastify-user.interface';
import {
  BalanceLogType,
  FeeType,
  MethodType,
  PgType,
  Role,
  TransactionStatusType,
  TransactionType,
  ValueType,
} from 'src/common/config/enum';
import { encryptHmac } from 'src/common/helper/encryptKey';
import { hash } from 'src/common/helper/hash';
import { minifyJson } from 'src/common/helper/minifyJson';
import { generateRandomNumber } from 'src/common/helper/generateRandomNumber';
import { CT_APP_JSON, EMAIL_NOT_PROVIDED } from 'src/common/config/constants';
import { encryptPass } from 'src/common/helper/encryptPass';

import { UpdateProfileDto } from './dto/update-profile.dto';
import { ProcessDto } from './dto/process.dto';
import { QueryDto } from '../admin/dto/query.dto';
import { ChangePassDto } from './dto/change-pass.dto';

import { User, UserDocument } from 'src/api/v1/user/entities/user.entity';
import { Balance, BalanceDocument } from './entities/balance.entity';
import {
  Transaction,
  TransactionDocument,
} from './entities/transaction.entity';
import { Product, ProductDocument } from '../public/entities/product.entity';
import { Method, MethodDocument } from '../public/entities/method.entity';
import { BalanceLog, BalanceLogDocument } from './entities/balance-log.entity';
import { Browser, BrowserDocument } from './entities/browser.entity';

import { SOPResponse, SOPErrorMessage as ErrorMessage } from 'src/common/api';
import { toCurrency } from 'src/common/helper/cast.helper';
import { decrypt } from 'src/common/helper/decryptKeyIv';
const response = new SOPResponse();

@Injectable()
export class UserService {
  constructor(
    @InjectModel(Browser.name) private readonly Browser: Model<BrowserDocument>,
    @InjectModel(User.name) private readonly User: Model<UserDocument>,
    @InjectModel(Balance.name) private readonly Balance: Model<BalanceDocument>,
    @InjectModel(BalanceLog.name)
    private readonly BalanceLog: Model<BalanceLogDocument>,
    @InjectModel(Transaction.name)
    private readonly Transaction: Model<TransactionDocument>,
    @InjectModel(Product.name) private readonly Product: Model<ProductDocument>,
    @InjectModel(Method.name) private readonly Method: Model<MethodDocument>,
  ) {}

  async getProfile(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      await this.Balance.findOne({
        user: user.id,
      }).then((balance) => {
        const success = response.initSuccess(200, true, {
          email: user.email,
          username: user.username,
          credit: balance.balance,
        });
        return res.send(success);
      });
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateProfile(
    data: UpdateProfileDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      payload.userId = user.id;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        const updateUser = {
          username: data.username,
        };

        await this.User.findByIdAndUpdate(user.id, updateUser);

        const success = response.initSuccess(
          200,
          true,
          'Success update username',
        );
        return res.send(success);
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async changePass(
    data: ChangePassDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      payload.userId = user.id;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        if (user.comparePass(data.old)) {
          await this.User.findByIdAndUpdate(user.id, {
            pass: await encryptPass(data.new),
          });

          const success = response.initSuccess(200, true, true);
          return res.send(success);
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Current Password invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getHistory(
    query: QueryDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;

      await this.Transaction.aggregate([
        {
          $match: {
            $expr: {
              $eq: ['$user', { $toObjectId: user.id }],
            },
            transactionType: TransactionType.Transaction,
          },
        },
        {
          $facet: {
            results: [
              {
                $sort: { createdAt: -1 },
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $lookup: {
                  from: 'products',
                  let: { productId: '$product' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $eq: ['$_id', '$$productId'],
                        },
                      },
                    },
                    {
                      $lookup: {
                        from: 'brandtypes',
                        let: { brandTypeId: '$brandType' },
                        pipeline: [
                          {
                            $match: {
                              $expr: {
                                $eq: ['$_id', '$$brandTypeId'],
                              },
                            },
                          },
                          {
                            $lookup: {
                              from: 'brands',
                              let: { brandId: '$brand' },
                              pipeline: [
                                {
                                  $match: {
                                    $expr: {
                                      $eq: ['$_id', '$$brandId'],
                                    },
                                  },
                                },
                                {
                                  $project: {
                                    _id: 0,
                                    brandName: 1,
                                    brandImg: 1,
                                  },
                                },
                              ],
                              as: 'brand',
                            },
                          },
                        ],
                        as: 'brandType',
                      },
                    },
                    {
                      $project: { name: 1, price: 1, brandType: 1 },
                    },
                  ],
                  as: 'product',
                },
              },
              {
                $unwind: '$product',
              },
              {
                $match: query.search
                  ? {
                      $or: [
                        {
                          transactionId: {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                        {
                          'product.name': {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                      ],
                    }
                  : {},
              },
              {
                $unwind: '$product.brandType',
              },
              {
                $unwind: '$product.brandType.brand',
              },
              {
                $addFields: {
                  brand: '$product.brandType.brand',
                },
              },
              {
                $project: {
                  id: '$_id',
                  _id: 0,
                  transactionId: 1,
                  name: '$product.name',
                  amount: '$product.price',
                  img: '$brand.brandImg',
                  status: 1,
                  createdAt: 1,
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            count: {
              $ifNull: [{ $arrayElemAt: ['$count', 0] }, { total: 0 }],
            },
          },
        },
        {
          $project: {
            results: 1,
            total: '$count.total',
          },
        },
      ]).then((transactions) => {
        if (transactions.length) {
          const success = response.initSuccess(200, true, transactions[0]);
          return res.send(success);
        } else {
          const success = response.initSuccess(200, true, {
            results: [],
            total: 0,
          });
          return res.send(success);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getHistoryDetail(
    id: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      await this.Transaction.aggregate([
        {
          $match: {
            $expr: {
              $and: [
                {
                  $eq: ['$_id', { $toObjectId: id }],
                },
                { $eq: ['$user', { $toObjectId: user.id }] },
              ],
            },
          },
        },
        {
          $lookup: {
            from: 'methods',
            let: { methodId: '$method' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $eq: ['$_id', { $toObjectId: '$$methodId' }],
                  },
                },
              },
              { $project: { _id: 0, name: 1, img: 1, type: 1 } },
            ],
            as: 'method',
          },
        },
        {
          $unwind: '$method',
        },
        {
          $lookup: {
            from: 'products',
            let: { productId: '$product' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $eq: ['$_id', '$$productId'],
                  },
                },
              },
              {
                $lookup: {
                  from: 'brandtypes',
                  let: { brandTypeId: '$brandType' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $eq: ['$_id', '$$brandTypeId'],
                        },
                      },
                    },
                    {
                      $lookup: {
                        from: 'brands',
                        let: { brandId: '$brand' },
                        pipeline: [
                          {
                            $match: {
                              $expr: {
                                $eq: ['$_id', '$$brandId'],
                              },
                            },
                          },
                          { $project: { _id: 0, brandName: 1, brandImg: 1 } },
                        ],
                        as: 'brand',
                      },
                    },
                  ],
                  as: 'brandType',
                },
              },
              {
                $project: { name: 1, price: 1, brandType: 1 },
              },
            ],
            as: 'product',
          },
        },
        {
          $unwind: '$product',
        },
        {
          $unwind: '$product.brandType',
        },
        {
          $unwind: '$product.brandType.brand',
        },
        {
          $addFields: {
            brand: '$product.brandType.brand',
          },
        },
        {
          $lookup: {
            from: 'balancelogs',
            let: { transactionId: '$_id' },
            pipeline: [
              {
                $lookup: {
                  from: 'balances',
                  let: { userId: { $toObjectId: user.id } },
                  pipeline: [
                    {
                      $match: {
                        $expr: { $eq: ['$user', '$$userId'] },
                      },
                    },
                  ],
                  as: 'balanceUser',
                },
              },
              {
                $unwind: '$balanceUser',
              },
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$transaction', '$$transactionId'] },
                      {
                        $eq: ['$balance', { $toObjectId: '$balanceUser._id' }],
                      },
                    ],
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  balance: 0,
                  transaction: 0,
                  updatedAt: 0,
                  balanceUser: 0,
                  __v: 0,
                },
              },
              {
                $sort: { createdAt: -1 },
              },
            ],
            as: 'logs',
          },
        },
        {
          $project: {
            _id: 0,
            form: 1,
            email: 1,
            transactionId: 1,
            amount: 1,
            fee: 1,
            usedBalance: 1,
            phone: 1,
            payment: 1,
            url: 1,
            exp: 1,
            status: 1,
            paidTime: 1,
            createdAt: 1,
            method: 1,
            brand: 1,
            logs: 1,
            serialNumber: '$dfSn',
            product: { name: 1, price: 1 },
          },
        },
      ]).then((transactions) => {
        if (transactions.length) {
          const success = response.initSuccess(200, true, transactions[0]);
          return res.send(success);
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Transaction not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async process(data: ProcessDto, req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      payload.userId = user.id;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        this.Product.findById(data.productId).then(async (product) => {
          if (product) {
            this.Method.aggregate([
              {
                $match: {
                  $expr: {
                    $eq: ['$_id', { $toObjectId: data.method }],
                  },
                  isActive: true,
                },
              },
              {
                $lookup: {
                  from: 'fees',
                  let: { methodId: '$_id' },
                  pipeline: [
                    {
                      $lookup: {
                        from: 'users',
                        localField: 'user',
                        foreignField: '_id',
                        as: 'user',
                      },
                    },
                    {
                      $unwind: '$user',
                    },
                    {
                      $match: {
                        $expr: {
                          $and: [
                            { $eq: ['$method', '$$methodId'] },
                            { $eq: ['$feeType', FeeType.Transaction] },
                            { $eq: ['$user.role', Role.Root] },
                            { isActive: true },
                          ],
                        },
                      },
                    },
                    {
                      $lookup: {
                        from: 'providers',
                        let: { providerId: '$provider' },
                        pipeline: [
                          {
                            $match: {
                              $expr: { $eq: ['$_id', '$$providerId'] },
                            },
                          },
                          {
                            $lookup: {
                              from: 'providers',
                              localField: 'providerRoot',
                              foreignField: '_id',
                              as: 'providerRoot',
                            },
                          },
                          {
                            $unwind: {
                              path: '$providerRoot',
                              preserveNullAndEmptyArrays: true,
                            },
                          },
                        ],
                        as: 'provider',
                      },
                    },
                    {
                      $unwind: '$provider',
                    },
                  ],
                  as: 'fee',
                },
              },
              {
                $unwind: '$fee',
              },
              {
                $lookup: {
                  from: 'valuetypes',
                  localField: 'fee.type',
                  foreignField: '_id',
                  as: 'fee.type',
                },
              },
              {
                $unwind: '$fee.type',
              },
            ]).then(async (methods) => {
              if (methods.length) {
                await this.Balance.findOne({
                  user: user.id,
                }).then(async (balance) => {
                  if (balance) {
                    const method = methods[0];
                    if (
                      method.fee.isActive &&
                      method.fee.provider &&
                      method.fee.provider.key
                    ) {
                      if (product.price < method.min) {
                        const error = response.initError(
                          403,
                          false,
                          new ErrorMessage(
                            'Product price must greater than ' +
                              toCurrency(method.min),
                          ),
                        );
                        return res.send(error);
                      } else if (product.price > method.max) {
                        const error = response.initError(
                          403,
                          false,
                          new ErrorMessage(
                            'Product price must smaller than ' +
                              toCurrency(method.max),
                          ),
                        );
                        return res.send(error);
                      } else {
                        const exp = new Date();
                        exp.setDate(exp.getDate() + 1);
                        exp.setHours(exp.getHours() + 7);
                        const dateString = exp
                          .toLocaleString('en-US', {
                            year: 'numeric',
                            month: '2-digit',
                            day: '2-digit',
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                          })
                          .replace(/\/|,|:| /g, '');
                        const formattedDate = `${dateString.slice(
                          4,
                          8,
                        )}${dateString.slice(0, 2)}${dateString.slice(
                          2,
                          4,
                        )}${dateString.slice(8, 14)}`;
                        const orderId = generateRandomNumber(50);
                        const email = user.email;
                        const customerId = exp.getTime();

                        if (balance.balance >= product.price) {
                          const transactionId =
                            'UT' +
                            browser.browserId
                              .replace(/[^a-zA-Z0-9]/g, '')
                              .substring(0, 5) +
                            generateRandomNumber(5) +
                            customerId;
                          const newTransaction = new this.Transaction({
                            form: data.data,
                            email,
                            transactionId,
                            orderId,
                            refId: 'balance',
                            amount: product.price,
                            fee: 0,
                            feeAdmin: 0,
                            usedBalance: product.price,
                            phone: data.phone,
                            payment: 'balance',
                            status: TransactionStatusType.Processing,
                            method: new Types.ObjectId(data.method),
                            user: user.id,
                            product: new Types.ObjectId(data.productId),
                          });
                          const saved = await newTransaction.save();

                          await this.Balance.findByIdAndUpdate(balance.id, {
                            $inc: {
                              balance: -Number(product.price),
                            },
                          });

                          const newBalanceLog = new this.BalanceLog({
                            name: 'Buy' + product.name,
                            balanceAmount: balance.balance,
                            balanceCredit: product.price,
                            type: BalanceLogType.Out,
                            balance: balance.id,
                            transaction: saved.id,
                          });

                          await newBalanceLog.save();

                          const payload = {
                            username: process.env.DF_USERNAME,
                            buyer_sku_code: product.code,
                            customer_no: data.data,
                            ref_id: saved.transactionId,
                            sign: hash(
                              'md5',
                              `${process.env.DF_USERNAME}${process.env.DF_PROD_KEY}${saved.transactionId}`,
                            ),
                          };
                          const header = {
                            'Content-Type': CT_APP_JSON,
                          };
                          await fetch(process.env.DF_BASE_URL + 'transaction', {
                            method: 'POST',
                            body: JSON.stringify(payload),
                            headers: header,
                          }).then(async (responseFetch) => {
                            const responseData = await responseFetch.json();
                            const updateTransaction: any = {
                              paidRef: 'balance',
                              paidTime: new Date(),
                              serialNumber: 'b' + generateRandomNumber(10),
                            };

                            if (
                              responseData.data.status === 'Sukses' &&
                              responseData.data.rc === '00'
                            ) {
                              updateTransaction.status =
                                TransactionStatusType.Paid;
                              updateTransaction.dfTrxId =
                                responseData.data.trx_id;
                              updateTransaction.dfSn = responseData.data.sn;
                            } else if (responseData.data.status === 'Gagal') {
                              if (
                                responseData.data.rc === '01' ||
                                responseData.data.rc === '44' ||
                                responseData.data.rc === '53' ||
                                responseData.data.rc === '55' ||
                                responseData.data.rc === '56' ||
                                responseData.data.rc === '58' ||
                                responseData.data.rc === '62' ||
                                responseData.data.rc === '63' ||
                                responseData.data.rc === '64' ||
                                responseData.data.rc === '65' ||
                                responseData.data.rc === '66' ||
                                responseData.data.rc === '67' ||
                                responseData.data.rc === '68' ||
                                responseData.data.rc === '70' ||
                                responseData.data.rc === '71' ||
                                responseData.data.rc === '80' ||
                                responseData.data.rc === '99'
                              ) {
                                updateTransaction.status =
                                  TransactionStatusType.Assist;
                              } else {
                                updateTransaction.status =
                                  TransactionStatusType.Failed;
                                await this.Balance.findByIdAndUpdate(
                                  balance.id,
                                  {
                                    $inc: {
                                      balance: Number(product.price),
                                    },
                                  },
                                );

                                const newBalanceLog = new this.BalanceLog({
                                  name: 'Refund used balance: ' + product.name,
                                  balanceAmount:
                                    balance.balance - product.price,
                                  balanceCredit: product.price,
                                  type: BalanceLogType.Refund,
                                  balance: balance.id,
                                  transaction: saved.id,
                                });

                                await newBalanceLog.save();
                              }
                              updateTransaction.error =
                                responseData.data.message;
                            }
                            await this.Transaction.findByIdAndUpdate(
                              saved.id,
                              updateTransaction,
                            );

                            const success = response.initSuccess(
                              200,
                              true,
                              saved.transactionId,
                            );
                            return res.send(success);
                          });
                        } else {
                          var usedBalance = 0;
                          if (product.price - 10000 < balance.balance) {
                            usedBalance = product.price - 10000;
                          } else {
                            usedBalance = balance.balance;
                          }
                          const price = product.price - usedBalance;
                          let feeAmount: number;
                          switch (method.fee.type.name) {
                            case ValueType.Percentage:
                              feeAmount = Math.floor(
                                (price * method.fee.percentage) / 100,
                              );
                              break;
                            case ValueType.Fixed:
                              feeAmount = method.fee.fixed;
                              break;
                            default:
                              feeAmount = Math.floor(
                                (price * method.fee.percentage) / 100 +
                                  method.fee.fixed,
                              );
                              break;
                          }

                          var keyDec: string;
                          if (method.fee.provider.key === 'root') {
                            keyDec = decrypt(
                              process.env.ENCRYPT_ALG,
                              hash(
                                'sha256',
                                method.fee.provider.providerRoot._id.valueOf(),
                              ).substring(0, 32),
                              hash(
                                'sha256',
                                method.fee.provider.providerRoot.user.valueOf() +
                                  method.fee.provider.providerRoot.code,
                              ).substring(0, 16),
                              method.fee.provider.providerRoot.key,
                            );
                          } else {
                            keyDec = decrypt(
                              process.env.ENCRYPT_ALG,
                              hash(
                                'sha256',
                                method.fee.provider._id.valueOf(),
                              ).substring(0, 32),
                              hash(
                                'sha256',
                                method.fee.provider.user.valueOf() +
                                  method.fee.provider.code,
                              ).substring(0, 16),
                              method.fee.provider.key,
                            );
                          }
                          const key = JSON.parse(keyDec);
                          const amount = price + feeAmount;
                          const appName = 'PrimeVoucher';
                          const reqMethod = 'POST';
                          const paramX = `${method.path}${reqMethod}`;
                          var paramY: string;
                          if (
                            method.type === MethodType.Va ||
                            method.type === MethodType.Retail
                          ) {
                            paramY = `${amount}${formattedDate}${method.code}${orderId}${customerId}${appName}${EMAIL_NOT_PROVIDED}${key.clientId}`;
                          } else if (method.type === MethodType.Qris) {
                            paramY = `${amount}${formattedDate}${orderId}${customerId}${appName}${EMAIL_NOT_PROVIDED}${key.clientId}`;
                          } else if (method.type === MethodType.Ewallet) {
                            if (data.phone) {
                              paramY = `${amount}${formattedDate}${method.code}${orderId}${customerId}${appName}${EMAIL_NOT_PROVIDED}${data.phone}${key.clientId}`;
                            } else {
                              const error = response.initError(
                                400,
                                false,
                                new ErrorMessage('Phone is required'),
                              );
                              return res.send(error);
                            }
                          } else {
                            const error = response.initError(
                              404,
                              false,
                              new ErrorMessage('Method type not found'),
                            );
                            return res.send(error);
                          }
                          const sig = encryptHmac(
                            'sha256',
                            key.sigKey,
                            paramX +
                              paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
                            'hex',
                          );
                          const payload: any = {
                            expired: formattedDate,
                            amount: Number(amount),
                            customer_id: Number(customerId),
                            partner_reff: orderId,
                            customer_email: EMAIL_NOT_PROVIDED,
                            username: key.username,
                            pin: key.pin,
                            customer_name: appName,
                            signature: sig,
                          };
                          if (method.type === MethodType.Va) {
                            payload.bank_code = method.code;
                          } else if (
                            method.type === MethodType.Ewallet ||
                            method.type === MethodType.Retail
                          ) {
                            payload.retail_code = method.code;
                            if (method.type === MethodType.Ewallet) {
                              payload.ewallet_phone = data.phone;
                              payload.bill_title = 'NiagaPay';
                              payload.customer_phone = data.phone;
                            } else {
                              payload.customer_phone = '081234567890';
                            }
                          }
                          const header = {
                            'Content-Type': CT_APP_JSON,
                            'client-id': key.clientId,
                            'client-secret': key.clientSecret,
                          };
                          await fetch(
                            process.env.PG_BASE_URL + method.path.substring(1),
                            {
                              method: reqMethod,
                              body: JSON.stringify(payload),
                              headers: header,
                            },
                          ).then(async (responseFetch) => {
                            const responseData = await responseFetch.json();

                            if (
                              responseData.status === PgType.Success &&
                              responseData.response_code === PgType.SuccessCode
                            ) {
                              const transactionId =
                                'UT' +
                                browser.browserId
                                  .replace(/[^a-zA-Z0-9]/g, '')
                                  .substring(0, 5) +
                                generateRandomNumber(5) +
                                new Date().getTime();
                              const newTransaction = new this.Transaction({
                                form: data.data,
                                email,
                                transactionId,
                                orderId,
                                refId: responseData.partner_reff2,
                                amount,
                                fee: feeAmount,
                                feeAdmin: responseData.feeadmin,
                                usedBalance,
                                phone: data.phone,
                                payment:
                                  responseData.virtual_account ??
                                  responseData.payment_code ??
                                  responseData.qris_text,
                                url: responseData.url_payment,
                                exp,
                                method: new Types.ObjectId(data.method),
                                user: user.id,
                                product: new Types.ObjectId(data.productId),
                              });
                              const saved = await newTransaction.save();

                              if (usedBalance > 0) {
                                await this.Balance.findByIdAndUpdate(
                                  balance.id,
                                  {
                                    $inc: {
                                      balance: -Number(usedBalance),
                                    },
                                  },
                                );

                                const newBalanceLog = new this.BalanceLog({
                                  name: 'Buy ' + product.name,
                                  balanceAmount: balance.balance,
                                  balanceCredit: usedBalance,
                                  type: BalanceLogType.Out,
                                  balance: balance.id,
                                  transaction: saved.id,
                                });

                                await newBalanceLog.save();
                              }

                              const success = response.initSuccess(
                                200,
                                true,
                                saved.transactionId,
                              );
                              return res.send(success);
                            } else {
                              const error = response.initError(
                                200,
                                false,
                                new ErrorMessage(
                                  'Failed to create your transaction, please try again later',
                                ),
                              );
                              return res.send(error);
                            }
                          });
                        }
                      }
                    } else {
                      const error = response.initError(
                        404,
                        false,
                        new ErrorMessage('Payment method not allowed'),
                      );
                      return res.status(200).send(error);
                    }
                  } else {
                    const error = response.initError(
                      404,
                      false,
                      new ErrorMessage('Balance data not found'),
                    );
                    return res.send(error);
                  }
                });
              } else {
                const error = response.initError(
                  404,
                  false,
                  new ErrorMessage('Payment method not found'),
                );
                return res.send(error);
              }
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Product not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getInvoice(id: string, res: FastifyReply) {
    try {
      this.Transaction.aggregate([
        {
          $match: {
            $expr: {
              $eq: ['$transactionId', id],
            },
          },
        },
        {
          $lookup: {
            from: 'methods',
            let: { methodId: '$method' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $eq: ['$_id', { $toObjectId: '$$methodId' }],
                  },
                },
              },
              { $project: { _id: 0, name: 1, img: 1, type: 1 } },
            ],
            as: 'method',
          },
        },
        {
          $unwind: '$method',
        },
        {
          $lookup: {
            from: 'products',
            let: { productId: '$product' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $eq: ['$_id', '$$productId'],
                  },
                },
              },
              {
                $lookup: {
                  from: 'brandtypes',
                  let: { brandTypeId: '$brandType' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $eq: ['$_id', '$$brandTypeId'],
                        },
                      },
                    },
                    {
                      $lookup: {
                        from: 'brands',
                        let: { brandId: '$brand' },
                        pipeline: [
                          {
                            $match: {
                              $expr: {
                                $eq: ['$_id', '$$brandId'],
                              },
                            },
                          },
                          { $project: { _id: 0, brandName: 1, brandImg: 1 } },
                        ],
                        as: 'brand',
                      },
                    },
                  ],
                  as: 'brandType',
                },
              },
              {
                $project: { name: 1, price: 1, brandType: 1 },
              },
            ],
            as: 'product',
          },
        },
        {
          $unwind: '$product',
        },
        {
          $unwind: '$product.brandType',
        },
        {
          $unwind: '$product.brandType.brand',
        },
        {
          $addFields: {
            brand: '$product.brandType.brand',
          },
        },
        {
          $project: {
            _id: 0,
            form: 1,
            email: 1,
            transactionId: 1,
            amount: 1,
            fee: 1,
            usedBalance: 1,
            phone: 1,
            payment: 1,
            url: 1,
            exp: 1,
            status: 1,
            paidTime: 1,
            createdAt: 1,
            method: 1,
            brand: 1,
            serialNumber: '$dfSn',
            product: { name: 1, price: 1 },
          },
        },
      ]).then((transaction) => {
        if (transaction.length) {
          const success = response.initSuccess(200, true, transaction[0]);
          return res.send(success);
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Transaction not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async checkInvoiceStatus(id: string, res: FastifyReply) {
    try {
      this.Transaction.findOne({
        transactionId: id,
      })
        .select('status')
        .then((transaction) => {
          if (transaction) {
            const success = response.initSuccess(200, true, transaction.status);
            return res.send(success);
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Transaction not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }
}
