import { Module } from '@nestjs/common';
import { OpenModule } from './open/open.module';
import { AdminModule } from './admin/admin.module';
import { PublicModule } from './public/public.module';
import { AuthModule } from './auth/auth.module';
import { PortalModule } from './portal/portal.module';
import { CallbackModule } from './callback/callback.module';
import { UserModule } from './user/user.module';
import { PartnerModule } from './partner/partner.module';

@Module({
  imports: [
    OpenModule,
    AdminModule,
    PublicModule,
    AuthModule,
    PortalModule,
    UserModule,
    CallbackModule,
    PartnerModule,
  ],
})
export class V1Module {}
