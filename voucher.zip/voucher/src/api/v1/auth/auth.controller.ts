import {
  Controller,
  Get,
  Post,
  Body,
  UseGuards,
  Req,
  Res,
} from '@nestjs/common';
import { ApiHeader, ApiOperation, ApiTags } from '@nestjs/swagger';
import { FastifyReply } from 'fastify';

import { FastifyBrowserRequest } from 'src/common/interface/fastify-browser.interface';
import { BrowserGuard } from 'src/common/middleware/public/browser.guard';
import { ValidationPipe } from 'src/core/pipes/validation.pipe';

import { AuthService } from './auth.service';
import { LoginPortalDto } from './dto/login-portal.dto';
import { LoginUserDto } from './dto/login-user.dto';
import { CheckUserDto } from './dto/check-user.dto';

@ApiTags('Auth')
@Controller({ path: 'auth', version: '1' })
@ApiHeader({
  name: 'x-browser-id',
  description: 'Browser ID',
  required: true,
})
@UseGuards(BrowserGuard)
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('/check/user')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  checkUser(
    @Body(new ValidationPipe()) check: CheckUserDto,
    @Req() req: FastifyBrowserRequest,
    @Res() res: FastifyReply,
  ) {
    return this.authService.checkUser(check, req, res);
  }

  @Post('/login/user')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, password + '|' + email + '|' + browserId) encoding hex",
  })
  loginUser(
    @Body(new ValidationPipe()) login: LoginUserDto,
    @Req() req: FastifyBrowserRequest,
    @Res() res: FastifyReply,
  ) {
    return this.authService.loginUser(login, req, res);
  }

  @Post('/login/portal')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, password + '|' + username + '|' + browserId) encoding hex",
  })
  loginPortal(
    @Body(new ValidationPipe()) login: LoginPortalDto,
    @Req() req: FastifyBrowserRequest,
    @Res() res: FastifyReply,
  ) {
    return this.authService.loginPortal(login, req, res);
  }

  @Get('/refresh/token')
  refresh(@Req() req: FastifyBrowserRequest, @Res() res: FastifyReply) {
    return this.authService.refreshToken(req, res);
  }
}
