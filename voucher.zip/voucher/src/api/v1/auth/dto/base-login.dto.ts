import { IsNotEmpty, IsString } from 'class-validator';

export class BaseLoginDto {
  @IsNotEmpty({ message: 'Signature must not be empty' })
  @IsString()
  signature: string;

  @IsNotEmpty({ message: 'Password must not be empty' })
  @IsString()
  password: string;
}
