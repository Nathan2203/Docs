import { IsNotEmpty, IsString } from 'class-validator';

export class CheckUserDto {
  @IsNotEmpty({ message: 'Signature must not be empty' })
  @IsString()
  signature: string;

  @IsNotEmpty({ message: 'email must not be empty' })
  @IsString()
  email: string;
}
