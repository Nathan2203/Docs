import { IsNotEmpty, IsString } from 'class-validator';
import { BaseLoginDto } from './base-login.dto';

export class LoginPortalDto extends BaseLoginDto {
  @IsNotEmpty({ message: 'Username must not be empty' })
  @IsString()
  username: string;
}
