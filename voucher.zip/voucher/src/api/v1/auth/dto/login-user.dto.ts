import { IsNotEmpty, IsString } from 'class-validator';
import { BaseLoginDto } from './base-login.dto';

export class LoginUserDto extends BaseLoginDto {
  @IsNotEmpty({ message: 'Email must not be empty' })
  @IsString()
  email: string;
}
