import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { User, UserSchema } from '../user/entities/user.entity';
import { Session, SessionSchema } from '../user/entities/session.entity';
import { Browser, BrowserSchema } from '../user/entities/browser.entity';
import { BrowserStrategy } from 'src/common/middleware/public/browser.strategy';
import { BrowserGuard } from 'src/common/middleware/public/browser.guard';
import { LogType, LogTypeSchema } from '../admin/entities/log-type.entity';
import { Log, LogSchema } from '../admin/entities/log.entity';
import { Balance, BalanceSchema } from '../user/entities/balance.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Balance.name, schema: BalanceSchema },
      { name: Session.name, schema: SessionSchema },
      { name: Browser.name, schema: BrowserSchema },
      { name: Log.name, schema: LogSchema },
      { name: LogType.name, schema: LogTypeSchema },
    ]),
  ],
  controllers: [AuthController],
  providers: [AuthService, BrowserStrategy, BrowserGuard],
})
export class AuthModule {}
