import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { FastifyReply } from 'fastify';
import { Model } from 'mongoose';
import * as bcrypt from 'bcrypt';

import { FastifyBrowserRequest } from 'src/common/interface/fastify-browser.interface';
import { encryptHmac } from 'src/common/helper/encryptKey';
import { LogType as LogTypes, Role } from 'src/common/config/enum';
import { encryptPass } from 'src/common/helper/encryptPass';
import { minifyJson } from 'src/common/helper/minifyJson';
import { hash } from 'src/common/helper/hash';

import { LoginPortalDto } from './dto/login-portal.dto';
import { LoginUserDto } from './dto/login-user.dto';
import { CheckUserDto } from './dto/check-user.dto';

import { User, UserDocument } from '../user/entities/user.entity';
import { Session, SessionDocument } from '../user/entities/session.entity';
import { Browser, BrowserDocument } from '../user/entities/browser.entity';
import { LogType, LogTypeDocument } from '../admin/entities/log-type.entity';
import { Log, LogDocument } from '../admin/entities/log.entity';
import { Balance, BalanceDocument } from '../user/entities/balance.entity';

import { SOPResponse, SOPErrorMessage as ErrorMessage } from 'src/common/api';
const response = new SOPResponse();

@Injectable()
export class AuthService {
  constructor(
    @InjectModel(User.name) private readonly User: Model<UserDocument>,
    @InjectModel(Balance.name) private readonly Balance: Model<BalanceDocument>,
    @InjectModel(Session.name) private readonly Session: Model<SessionDocument>,
    @InjectModel(Browser.name) private readonly Browser: Model<BrowserDocument>,
    @InjectModel(LogType.name)
    private readonly LogType: Model<LogTypeDocument>,
    @InjectModel(Log.name)
    private readonly Log: Model<LogDocument>,
  ) {}

  async checkUser(
    data: CheckUserDto,
    req: FastifyBrowserRequest,
    res: FastifyReply,
  ) {
    try {
      const browser = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      if (data.signature === signatureVerify) {
        this.User.findOne({
          email: {
            $regex: new RegExp(data.email, 'i'),
          },
        }).then(async (user) => {
          return res.send(response.initSuccess(200, true, !!user));
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async loginUser(
    data: LoginUserDto,
    req: FastifyBrowserRequest,
    res: FastifyReply,
  ) {
    try {
      const browser = req.user;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        data.password + '|' + data.email + '|' + browser.browserId,
        'hex',
      );

      if (data.signature === signatureVerify) {
        this.User.findOne({
          email: {
            $regex: new RegExp(data.email, 'i'),
          },
        }).then(async (user) => {
          var userDoc: UserDocument;
          if (!user) {
            const newUser = new this.User({
              email: data.email,
              pass: await encryptPass(data.password),
            });

            const savedUser = await newUser.save();

            const newBalance = new this.Balance({
              user: savedUser.id,
            });

            await newBalance.save();
            userDoc = savedUser;
          } else if (user.role === Role.User) {
            userDoc = user;
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('User not found'),
            );
            return res.send(error);
          }
          await this.login(browser.id, data.password, userDoc, req, res);
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async loginPortal(
    data: LoginPortalDto,
    req: FastifyBrowserRequest,
    res: FastifyReply,
  ) {
    try {
      const browser = req.user;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        data.password + '|' + data.username + '|' + browser.browserId,
        'hex',
      );

      if (data.signature === signatureVerify) {
        this.User.findOne({
          username: { $regex: new RegExp(data.username, 'i') },
          role: { $nin: [Role.User, Role.Root] },
        }).then(async (user) => {
          if (user) {
            await this.login(browser.id, data.password, user, req, res);
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('User not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async login(
    browserId: string,
    pass: string,
    user: UserDocument,
    req: FastifyBrowserRequest,
    res: FastifyReply,
  ) {
    const updateBrowser = {
      user: user.id,
      $addToSet: { ip: req.ip },
    };

    await this.Browser.findByIdAndUpdate(
      browserId,
      {
        $set: updateBrowser,
        $unset: {
          csrf: undefined,
        },
      },
      { new: true, upsert: true },
    );

    if (user.isBlocked) {
      const error = response.initError(
        400,
        false,
        new ErrorMessage('Sorry, Your account is blocked'),
      );
      return res.send(error);
    } else if (user.isDeleted) {
      const error = response.initError(
        400,
        false,
        new ErrorMessage('Sorry, Your account is deleted'),
      );
      return res.send(error);
    } else {
      if (user.comparePass(pass)) {
        let sessionToken: string, refreshToken: string;
        const jwt = await user.generateJWT();

        await this.Session.findOne({ user: user.id })
          .then(async (sessionFind) => {
            const sessionExp = new Date();
            sessionExp.setMonth(sessionExp.getMonth() + 1);
            const sessionSalt = await bcrypt.genSalt(10);
            sessionToken = await bcrypt.hash(user.id, sessionSalt);

            const refreshExp = new Date();
            refreshExp.setDate(refreshExp.getDate() + 1);
            const refreshSalt = await bcrypt.genSalt(10);
            refreshToken = await bcrypt.hash(user.id, refreshSalt);

            if (sessionFind) {
              const updateSession = {
                sessionToken: sessionToken,
                sessionExpires: sessionExp,
                refreshToken: refreshToken,
                refreshExpires: refreshExp,
                lastActivityDate: new Date(),
              };

              await this.Session.findByIdAndUpdate(
                sessionFind.id,
                { $set: updateSession },
                { new: true, upsert: true },
              );
            } else {
              const newSession = new this.Session({
                sessionToken: sessionToken,
                sessionExpires: sessionExp,
                refreshToken: refreshToken,
                refreshExpires: refreshExp,
                user: user.id,
                lastActivityDate: new Date(),
              });
              await newSession.save();
            }

            await this.LogType.findOne({ type: LogTypes.Login }).then(
              async (logType) => {
                if (logType) {
                  const newLog = new this.Log({
                    message: `${user.username || user.email} login`,
                    ip: req.ip,
                    type: logType.id,
                  });
                  if (user.role === Role.Admin || user.role === Role.Super) {
                    newLog.admin = user.id;
                  } else {
                    newLog.user = user.id;
                  }

                  await newLog.save();
                }

                const success = response.initSuccess(200, true, {
                  token: jwt,
                });

                return res
                  .headers({
                    'X-SESSION': sessionToken,
                    'X-REFRESH': refreshToken,
                    'Access-Control-Expose-Headers': 'X-SESSION, X-REFRESH',
                  })
                  .send(success);
              },
            );
          })
          .catch((_err) => {
            const error = response.initError(
              500,
              false,
              new ErrorMessage("Can't create your session"),
            );
            return res.send(error);
          });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Wrong Password'),
        );
        return res.send(error);
      }
    }
  }

  async refreshToken(req: FastifyBrowserRequest, res: FastifyReply) {
    try {
      const browser = req.user;
      const jwt = req.headers.authorization;
      const session = req.headers.session;
      const refresh = req.headers['refresh'];

      await this.Session.findOne({
        sessionToken: session,
        refreshToken: refresh,
      }).then(async (session) => {
        if (session) {
          const sessionExp = new Date();
          if (session.sessionExpires > sessionExp) {
            await this.User.findById(browser.user).then(async (user) => {
              if (user) {
                if (session.user.equals(browser.user)) {
                  var base64Payload = jwt.split('.')[1];
                  var payload = Buffer.from(base64Payload, 'base64');
                  if (JSON.parse(payload.toString()).id == browser.user) {
                    const jwt = await user.generateJWT();
                    const sessionExp = new Date();
                    sessionExp.setMonth(sessionExp.getMonth() + 1);
                    const sessionSalt = await bcrypt.genSalt(10);
                    const sessionToken = await bcrypt.hash(
                      browser.user.toString(),
                      sessionSalt,
                    );

                    const refreshExp = new Date();
                    refreshExp.setDate(refreshExp.getDate() + 1);
                    const refreshSalt = await bcrypt.genSalt(10);
                    const refreshToken = await bcrypt.hash(
                      browser.user.toString(),
                      refreshSalt,
                    );

                    const updateSession = {
                      sessionToken: sessionToken,
                      sessionExpires: sessionExp,
                      refreshToken: refreshToken,
                      refreshExpires: refreshExp,
                      lastActivityDate: new Date(),
                    };

                    await this.Session.findByIdAndUpdate(
                      session.id,
                      { $set: updateSession },
                      { new: true, upsert: true },
                    );

                    const updateBrowser = {
                      user: user.id,
                      $addToSet: { ip: req.ip },
                    };

                    await this.Browser.findByIdAndUpdate(
                      browser.id,
                      {
                        $set: updateBrowser,
                        $unset: {
                          csrf: undefined,
                        },
                      },
                      { new: true, upsert: true },
                    );

                    const success = response.initSuccess(200, true, {
                      token: jwt,
                    });

                    return res
                      .headers({
                        'X-SESSION': sessionToken,
                        'X-REFRESH': refreshToken,
                        'Access-Control-Expose-Headers': 'X-SESSION, X-REFRESH',
                      })
                      .send(success);
                  } else {
                    const error = response.initError(
                      403,
                      false,
                      new ErrorMessage('Unauthorized Access - Invalid Token'),
                    );
                    return res.send(error);
                  }
                } else {
                  const error = response.initError(
                    403,
                    false,
                    new ErrorMessage(
                      'Unauthorized Access - Invalid Browser ID',
                    ),
                  );
                  return res.send(error);
                }
              } else {
                const error = response.initError(
                  404,
                  false,
                  new ErrorMessage('User not found'),
                );
                return res.send(error);
              }
            });
          } else {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Session Expired'),
            );
            return res.send(error);
          }
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Unauthorized Access - Invalid Session'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }
}
