import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { FastifyReply, FastifyRequest } from 'fastify';
import { Model, Types } from 'mongoose';
import fetch from 'node-fetch';

import {
  Transaction,
  TransactionDocument,
} from '../user/entities/transaction.entity';
import { Client, ClientDocument } from '../open/entities/client.entity';
import { Balance, BalanceDocument } from '../user/entities/balance.entity';
import { Fee, FeeDocument } from '../admin/entities/fee.entity';
import {
  BalanceLog,
  BalanceLogDocument,
} from '../user/entities/balance-log.entity';
import { User, UserDocument } from '../user/entities/user.entity';
import {
  Commission,
  CommissionDocument,
} from '../partner/entities/commission.entity';
import {
  ValueType,
  ValueTypeDocument,
} from '../admin/entities/value-type.entity';
import { Provider, ProviderDocument } from '../admin/entities/provider.entity';
import { Callback, CallbackDocument } from './entities/callback.entity';
import { Withdraw, WithdrawDocument } from '../user/entities/withdraw.entity';

import { LinkquTDto } from './dto/linkqu-t.dto';
import { DigiflazzDto } from './dto/digiflazz.dto';
import { LinkquWdDto } from './dto/linkqu-wd.dto';
import { BncQrisDto } from './dto/bnc-qris.dto';

import {
  AccessFrom,
  BalanceLogType,
  BankType,
  CallbackType,
  FeeType,
  MethodType,
  PgType,
  Role,
  TransactionStatusType,
  TransactionType,
  ValueType as VType,
  WithdrawProcess,
  WithdrawStatus,
  WithdrawType,
} from 'src/common/config/enum';
import { hash } from 'src/common/helper/hash';
import { CT_APP_JSON } from 'src/common/config/constants';
import { encryptHmac } from 'src/common/helper/encryptKey';
import { minifyJson } from 'src/common/helper/minifyJson';
import { searchArray } from 'src/common/helper/searchArray';
import { toCurrency } from 'src/common/helper/cast.helper';
import { decrypt } from 'src/common/helper/decryptKeyIv';
import { bncPubKey, primePrivKey } from 'src/common/config/secret';
import { encryptRsa, verifyRsa } from 'src/common/helper/rsa';
import sendCallback from 'src/common/util/sendCallback';

import { SOPResponse, SOPErrorMessage as ErrorMessage } from 'src/common/api';
import { MpiBcaDto } from './dto/mpi-bca.dto';
const response = new SOPResponse();

@Injectable()
export class CallbackService {
  constructor(
    @InjectModel(User.name)
    private readonly User: Model<UserDocument>,
    @InjectModel(Transaction.name)
    private readonly Transaction: Model<TransactionDocument>,
    @InjectModel(Withdraw.name)
    private readonly Withdraw: Model<WithdrawDocument>,
    @InjectModel(Balance.name)
    private readonly Balance: Model<BalanceDocument>,
    @InjectModel(BalanceLog.name)
    private readonly BalanceLog: Model<BalanceLogDocument>,
    @InjectModel(Client.name)
    private readonly Client: Model<ClientDocument>,
    @InjectModel(Fee.name)
    private readonly Fee: Model<FeeDocument>,
    @InjectModel(Commission.name)
    private readonly Commission: Model<CommissionDocument>,
    @InjectModel(ValueType.name)
    private readonly ValueType: Model<ValueTypeDocument>,
    @InjectModel(Callback.name)
    private readonly Callback: Model<CallbackDocument>,
    @InjectModel(Provider.name)
    private readonly Provider: Model<ProviderDocument>,
  ) {}

  async linkquTransaction(
    data: LinkquTDto,
    req: FastifyRequest,
    res: FastifyReply,
  ) {
    try {
      console.log(req.body);
      if (req.ip === '34.101.73.158') {
        await this.Transaction.findOne({
          orderId: data.partner_reff,
        })
          .populate('method')
          .populate('user')
          .populate('product')
          .then(async (transaction: any) => {
            if (
              transaction &&
              transaction.amount === data.amount &&
              transaction.feeAdmin === data.additionalfee
            ) {
              await this.Balance.findOne({
                user: transaction.user.id,
              }).then(async (balance) => {
                if (balance) {
                  if (data.status === PgType.Success) {
                    await this.User.aggregate([
                      {
                        $match: {
                          role: Role.Root,
                        },
                      },
                      {
                        $lookup: {
                          from: 'balances',
                          localField: '_id',
                          foreignField: 'user',
                          as: 'balance',
                        },
                      },
                      { $unwind: '$balance' },
                    ]).then(async (rootData: any) => {
                      if (transaction.user.role === Role.Client) {
                        await this.Fee.findOne({
                          user: transaction.user.id,
                          method: transaction.method.id,
                          feeType: FeeType.Transaction,
                        }).then(async (fee) => {
                          if (fee) {
                            await this.Client.findOne({
                              user: transaction.user.id,
                            }).then(async (client) => {
                              if (client) {
                                const amountCredit =
                                  transaction.amount - transaction.fee;
                                var rootCredit =
                                  transaction.fee - transaction.feeAdmin;
                                const updateTransaction: any = {
                                  paidRef: data.payment_reff,
                                  paidTime: new Date(data.transaction_time),
                                  serialNumber: data.serialnumber.replace(
                                    new RegExp('linkqu', 'ig'),
                                    '',
                                  ),
                                };

                                if (data.type === PgType.Pay) {
                                  if (
                                    transaction.status ===
                                    TransactionStatusType.Pending
                                  ) {
                                    updateTransaction.uplineFee = [];

                                    if (
                                      transaction.transactionType ===
                                        TransactionType.Transaction ||
                                      (transaction.transactionType ===
                                        TransactionType.Topup &&
                                        transaction.accessFrom ===
                                          AccessFrom.Api)
                                    ) {
                                      const resObj: any = {
                                        amount: transaction.amount,
                                        fee: transaction.fee,
                                        expired: new Date(
                                          transaction.exp,
                                        ).getTime(),
                                        method: transaction.method.code,
                                        methodName: transaction.method.name,
                                        customerName:
                                          transaction.clientCustName,
                                        ref1: transaction.clientRef,
                                        ref2: transaction.transactionId,
                                        status: TransactionStatusType.Paid,
                                        desc: `Your ${
                                          transaction.method.type ===
                                          MethodType.Va
                                            ? 'Virtual Account'
                                            : transaction.method.type ===
                                              MethodType.Retail
                                            ? 'Retail'
                                            : transaction.method.type ===
                                              MethodType.Qris
                                            ? 'QRIS'
                                            : transaction.method.type ===
                                              MethodType.Ewallet
                                            ? 'Ewallet'
                                            : ''
                                        } ${
                                          transaction.transactionType ===
                                          TransactionType.Transaction
                                            ? 'Transaction'
                                            : 'Topup'
                                        } is Paid`,
                                        paidTime: new Date(
                                          data.transaction_time,
                                        ).getTime(),
                                        serialNumber: data.serialnumber.replace(
                                          new RegExp('linkqu', 'ig'),
                                          '',
                                        ),
                                      };

                                      if (
                                        transaction.method.type ===
                                        MethodType.Ewallet
                                      ) {
                                        resObj.phone = transaction.phone;
                                      }

                                      const callbackKey = decrypt(
                                        process.env.ENCRYPT_ALG,
                                        hash('sha256', client.id).substring(
                                          0,
                                          32,
                                        ),
                                        hash(
                                          'sha256',
                                          transaction.user.id + client.clientId,
                                        ).substring(0, 16),
                                        client.callbackKey,
                                      );

                                      const sig = encryptHmac(
                                        'sha512',
                                        callbackKey,
                                        minifyJson(resObj).toLowerCase(),
                                        'hex',
                                      );

                                      const cbQuery: any = {
                                        user: transaction.user.id,
                                      };

                                      if (
                                        transaction.transactionType ===
                                        TransactionType.Transaction
                                      ) {
                                        cbQuery.transaction = transaction.id;
                                      } else {
                                        cbQuery.topup = transaction.id;
                                      }
                                      await this.Callback.findOne(cbQuery).then(
                                        async (transactionCb) => {
                                          var res: string, sent: boolean;
                                          await sendCallback(
                                            transaction.transactionType ===
                                              TransactionType.Transaction
                                              ? client.callbackTrx
                                              : client.callbackTopup,
                                            resObj,
                                            sig,
                                          )
                                            .then((responseData) => {
                                              res = responseData;
                                              sent = true;
                                            })
                                            .catch((error) => {
                                              res = error;
                                              sent = false;
                                            });

                                          if (transactionCb) {
                                            transactionCb.isSent = sent;
                                            transactionCb.payload =
                                              JSON.stringify(resObj);
                                            transactionCb.callbackUrl =
                                              transaction.transactionType ===
                                              TransactionType.Transaction
                                                ? client.callbackTrx
                                                : client.callbackTopup;
                                            if (sent) {
                                              transactionCb.res = res;
                                            } else {
                                              transactionCb.error = res;
                                            }
                                            transactionCb.attempt =
                                              transactionCb.attempt + 1;
                                            transactionCb.last = new Date();

                                            await transactionCb.save();
                                          } else {
                                            const newCallback =
                                              new this.Callback({
                                                isSent: sent,
                                                payload: JSON.stringify(resObj),
                                                callbackUrl:
                                                  transaction.transactionType ===
                                                  TransactionType.Transaction
                                                    ? client.callbackTrx
                                                    : client.callbackTopup,
                                                last: new Date(),
                                                type:
                                                  transaction.transactionType ===
                                                  TransactionType.Transaction
                                                    ? CallbackType.Transaction
                                                    : CallbackType.Topup,
                                                user: transaction.user.id,
                                              });

                                            if (
                                              transaction.transactionType ===
                                              TransactionType.Transaction
                                            ) {
                                              newCallback.transaction =
                                                transaction.id;
                                            } else {
                                              newCallback.topup =
                                                transaction.id;
                                            }

                                            if (sent) {
                                              newCallback.res = res;
                                            } else {
                                              newCallback.error = res;
                                            }

                                            await newCallback.save();
                                          }
                                        },
                                      );
                                    }

                                    const debtCredit = Math.min(
                                      balance.debt ?? 0,
                                      amountCredit,
                                    );
                                    const balanceCredit =
                                      amountCredit - debtCredit;

                                    if (debtCredit > 0) {
                                      await this.Balance.findByIdAndUpdate(
                                        balance.id,
                                        {
                                          $inc: {
                                            debt: -Number(debtCredit),
                                          },
                                        },
                                      );

                                      const newBalanceLog = new this.BalanceLog(
                                        {
                                          name: `Paying debt from ${
                                            transaction.clientRef
                                          } ${
                                            transaction.transactionType ===
                                            TransactionType.Topup
                                              ? "'s Topup"
                                              : ''
                                          } with amount ${toCurrency(
                                            debtCredit,
                                          )}`,
                                          balanceAmount: balance.debt,
                                          balanceCredit: Number(debtCredit),
                                          type: BalanceLogType.Pay,
                                          balance: balance.id,
                                          transaction: transaction.id,
                                        },
                                      );

                                      await newBalanceLog.save();

                                      updateTransaction.debt = debtCredit;
                                    }

                                    const feeMethodRoot =
                                      await this.Fee.findOne({
                                        user: rootData[0]._id,
                                        method: transaction.method.id,
                                        feeType: FeeType.Transaction,
                                      });

                                    if (
                                      transaction.method.type ===
                                        MethodType.Va &&
                                      feeMethodRoot.delay === 0
                                    ) {
                                      updateTransaction.pgSettled = true;
                                      if (fee.delay > 0) {
                                        updateTransaction.status =
                                          TransactionStatusType.Paid;

                                        if (balanceCredit > 0) {
                                          await this.Balance.findByIdAndUpdate(
                                            balance.id,
                                            {
                                              $inc: {
                                                pending: Number(balanceCredit),
                                              },
                                            },
                                          );
                                          const settleDate = new Date();
                                          settleDate.setDate(
                                            settleDate.getDate() + fee.delay,
                                          );
                                          settleDate.setHours(4, 0, 0, 0);
                                          updateTransaction.clientSettleDate =
                                            settleDate;
                                        }
                                      } else {
                                        if (
                                          transaction.transactionType ===
                                            TransactionType.Transaction ||
                                          (transaction.transactionType ===
                                            TransactionType.Topup &&
                                            transaction.accessFrom ===
                                              AccessFrom.Api)
                                        ) {
                                          const resObj: any = {
                                            amount: transaction.amount,
                                            fee: transaction.fee,
                                            expired: new Date(
                                              transaction.exp,
                                            ).getTime(),
                                            method: transaction.method.code,
                                            methodName: transaction.method.name,
                                            customerName:
                                              transaction.clientCustName,
                                            ref1: transaction.clientRef,
                                            ref2: transaction.transactionId,
                                            status:
                                              TransactionStatusType.Settled,
                                            desc: `Your ${
                                              transaction.method.type ===
                                              MethodType.Va
                                                ? 'Virtual Account'
                                                : transaction.method.type ===
                                                  MethodType.Retail
                                                ? 'Retail'
                                                : transaction.method.type ===
                                                  MethodType.Qris
                                                ? 'QRIS'
                                                : transaction.method.type ===
                                                  MethodType.Ewallet
                                                ? 'Ewallet'
                                                : ''
                                            } ${
                                              transaction.transactionType ===
                                              TransactionType.Transaction
                                                ? 'Transaction'
                                                : 'Topup'
                                            } is Settled to your balance`,
                                            paidTime: new Date(
                                              data.transaction_time,
                                            ).getTime(),
                                            serialNumber:
                                              data.serialnumber.replace(
                                                new RegExp('linkqu', 'ig'),
                                                '',
                                              ),
                                            settleTime: new Date().getTime(),
                                          };

                                          if (
                                            transaction.method.type ===
                                            MethodType.Ewallet
                                          ) {
                                            resObj.phone = transaction.phone;
                                          }

                                          const callbackKey = decrypt(
                                            process.env.ENCRYPT_ALG,
                                            hash('sha256', client.id).substring(
                                              0,
                                              32,
                                            ),
                                            hash(
                                              'sha256',
                                              transaction.user.id +
                                                client.clientId,
                                            ).substring(0, 16),
                                            client.callbackKey,
                                          );

                                          const sig = encryptHmac(
                                            'sha512',
                                            callbackKey,
                                            minifyJson(resObj).toLowerCase(),
                                            'hex',
                                          );

                                          const cbQuery: any = {
                                            user: transaction.user.id,
                                          };

                                          if (
                                            transaction.transactionType ===
                                            TransactionType.Transaction
                                          ) {
                                            cbQuery.transaction =
                                              transaction.id;
                                          } else {
                                            cbQuery.topup = transaction.id;
                                          }
                                          await this.Callback.findOne(
                                            cbQuery,
                                          ).then(async (transactionCb) => {
                                            var res: string, sent: boolean;
                                            await sendCallback(
                                              transaction.transactionType ===
                                                TransactionType.Transaction
                                                ? client.callbackTrx
                                                : client.callbackTopup,
                                              resObj,
                                              sig,
                                            )
                                              .then((responseData) => {
                                                res = responseData;
                                                sent = true;
                                              })
                                              .catch((error) => {
                                                res = error;
                                                sent = false;
                                              });

                                            if (transactionCb) {
                                              transactionCb.isSent = sent;
                                              transactionCb.payload =
                                                JSON.stringify(resObj);
                                              transactionCb.callbackUrl =
                                                transaction.transactionType ===
                                                TransactionType.Transaction
                                                  ? client.callbackTrx
                                                  : client.callbackTopup;
                                              if (sent) {
                                                transactionCb.res = res;
                                              } else {
                                                transactionCb.error = res;
                                              }
                                              transactionCb.attempt =
                                                transactionCb.attempt + 1;
                                              transactionCb.last = new Date();

                                              await transactionCb.save();
                                            } else {
                                              const newCallback =
                                                new this.Callback({
                                                  isSent: sent,
                                                  payload:
                                                    JSON.stringify(resObj),
                                                  callbackUrl:
                                                    transaction.transactionType ===
                                                    TransactionType.Transaction
                                                      ? client.callbackTrx
                                                      : client.callbackTopup,
                                                  last: new Date(),
                                                  type:
                                                    transaction.transactionType ===
                                                    TransactionType.Transaction
                                                      ? CallbackType.Transaction
                                                      : CallbackType.Topup,
                                                  user: transaction.user.id,
                                                });

                                              if (
                                                transaction.transactionType ===
                                                TransactionType.Transaction
                                              ) {
                                                newCallback.transaction =
                                                  transaction.id;
                                              } else {
                                                newCallback.topup =
                                                  transaction.id;
                                              }

                                              if (sent) {
                                                newCallback.res = res;
                                              } else {
                                                newCallback.error = res;
                                              }

                                              await newCallback.save();
                                            }
                                          });
                                        }

                                        updateTransaction.status =
                                          TransactionStatusType.Settled;
                                        updateTransaction.clientSettled = true;
                                        const settleDate = new Date();
                                        updateTransaction.clientSettleDate =
                                          settleDate;

                                        if (balanceCredit > 0) {
                                          await this.Balance.findByIdAndUpdate(
                                            balance.id,
                                            {
                                              $inc: {
                                                balance: Number(balanceCredit),
                                              },
                                            },
                                          );

                                          const newBalanceLog =
                                            new this.BalanceLog({
                                              name: `${
                                                transaction.clientRef
                                                  ? `${transaction.clientRef}'s `
                                                  : ''
                                              }${
                                                transaction.transactionType ===
                                                TransactionType.Topup
                                                  ? 'Topup'
                                                  : 'Transaction'
                                              }`,
                                              balanceAmount: balance.balance,
                                              balanceCredit:
                                                Number(balanceCredit),
                                              type: BalanceLogType.In,
                                              balance: balance.id,
                                              transaction: transaction.id,
                                            });

                                          await newBalanceLog.save();
                                        }
                                      }
                                    } else {
                                      updateTransaction.status =
                                        TransactionStatusType.Paid;

                                      if (balanceCredit > 0) {
                                        await this.Balance.findByIdAndUpdate(
                                          balance.id,
                                          {
                                            $inc: {
                                              pending: Number(balanceCredit),
                                            },
                                          },
                                        );
                                      }
                                    }

                                    var feeUpline1: number = 0,
                                      feeUpline2: number = 0,
                                      feeUpline3: number = 0;
                                    if (
                                      transaction.accessFrom === AccessFrom.Api
                                    ) {
                                      if (
                                        fee.uplineFee &&
                                        fee.uplineFee.length
                                      ) {
                                        await this.User.findById(
                                          transaction.user.id,
                                        )
                                          .populate({
                                            path: 'upline',
                                            populate: {
                                              path: 'upline',
                                              populate: {
                                                path: 'upline',
                                              },
                                            },
                                          })
                                          .then(async (userUpline: any) => {
                                            await this.ValueType.find().then(
                                              async (valueType) => {
                                                for (const uplineFee of fee.uplineFee) {
                                                  const typeFound = searchArray(
                                                    valueType,
                                                    null,
                                                    null,
                                                    'id',
                                                    uplineFee.type,
                                                  );
                                                  if (typeFound.length) {
                                                    let feeAmount: number;
                                                    switch (typeFound[0].name) {
                                                      case VType.Percentage:
                                                        feeAmount = Math.floor(
                                                          (amountCredit *
                                                            uplineFee.percentage) /
                                                            100,
                                                        );
                                                        break;
                                                      case VType.Fixed:
                                                        feeAmount =
                                                          uplineFee.fixed;
                                                        break;
                                                      default:
                                                        feeAmount = Math.floor(
                                                          (amountCredit *
                                                            uplineFee.percentage) /
                                                            100 +
                                                            uplineFee.fixed,
                                                        );
                                                        break;
                                                    }
                                                    if (
                                                      uplineFee.id === 1 &&
                                                      userUpline.upline &&
                                                      !userUpline.upline
                                                        .isBlocked &&
                                                      !userUpline.upline
                                                        .isDeleted
                                                    ) {
                                                      if (
                                                        transaction.method
                                                          .type ===
                                                          MethodType.Va &&
                                                        feeMethodRoot.delay ===
                                                          0
                                                      ) {
                                                        await this.Balance.findOne(
                                                          {
                                                            user: userUpline
                                                              .upline.id,
                                                          },
                                                        ).then(
                                                          async (
                                                            balanceUpline,
                                                          ) => {
                                                            let debDec =
                                                              Math.min(
                                                                balanceUpline.debt ??
                                                                  0,
                                                                feeAmount,
                                                              );
                                                            let feeFinal =
                                                              feeAmount -
                                                              debDec;

                                                            if (feeFinal > 0) {
                                                              const commission =
                                                                await this.Commission.findOneAndUpdate(
                                                                  {
                                                                    isActive:
                                                                      true,
                                                                    user: userUpline
                                                                      .upline
                                                                      .id,
                                                                  },
                                                                  {
                                                                    $inc: {
                                                                      clientTrx:
                                                                        feeFinal,
                                                                      clientTrxQty: 1,
                                                                    },
                                                                  },
                                                                  { new: true },
                                                                );

                                                              await this.Commission.findOneAndUpdate(
                                                                {
                                                                  isActive:
                                                                    true,
                                                                  upline:
                                                                    userUpline
                                                                      .upline
                                                                      .id,
                                                                  downline:
                                                                    userUpline.id,
                                                                },
                                                                {
                                                                  $inc: {
                                                                    amountTrx:
                                                                      feeFinal,
                                                                    amountTrxQty: 1,
                                                                  },
                                                                },
                                                              );

                                                              await this.Balance.findByIdAndUpdate(
                                                                balanceUpline.id,
                                                                {
                                                                  $inc: {
                                                                    balance:
                                                                      Number(
                                                                        feeFinal,
                                                                      ),
                                                                  },
                                                                },
                                                              );

                                                              const newBalanceLog =
                                                                new this.BalanceLog(
                                                                  {
                                                                    name: userUpline.username,
                                                                    balanceAmount:
                                                                      balanceUpline.balance,
                                                                    balanceCredit:
                                                                      Number(
                                                                        feeFinal,
                                                                      ),
                                                                    type: BalanceLogType.In,
                                                                    balance:
                                                                      balanceUpline.id,
                                                                    transaction:
                                                                      transaction.id,
                                                                  },
                                                                );

                                                              await newBalanceLog.save();

                                                              const newUplineFee =
                                                                {
                                                                  id: 1,
                                                                  commission:
                                                                    commission.id,
                                                                  amount:
                                                                    feeFinal,
                                                                };
                                                              updateTransaction.uplineFee.push(
                                                                newUplineFee,
                                                              );

                                                              feeUpline1 =
                                                                feeFinal;
                                                            }

                                                            if (debDec > 0) {
                                                              await this.Balance.findByIdAndUpdate(
                                                                balanceUpline.id,
                                                                {
                                                                  $inc: {
                                                                    debt: -Number(
                                                                      debDec,
                                                                    ),
                                                                  },
                                                                },
                                                              );

                                                              const newBalanceLog =
                                                                new this.BalanceLog(
                                                                  {
                                                                    name: `Paying debt from ${
                                                                      userUpline.username
                                                                    } with amount ${toCurrency(
                                                                      debDec,
                                                                    )}`,
                                                                    balanceAmount:
                                                                      balanceUpline.debt,
                                                                    balanceCredit:
                                                                      Number(
                                                                        debDec,
                                                                      ),
                                                                    type: BalanceLogType.Pay,
                                                                    balance:
                                                                      balanceUpline.id,
                                                                    transaction:
                                                                      transaction.id,
                                                                  },
                                                                );

                                                              await newBalanceLog.save();
                                                            }
                                                          },
                                                        );
                                                      } else {
                                                        const commission =
                                                          await this.Commission.findOne(
                                                            {
                                                              isActive: true,
                                                              user: userUpline
                                                                .upline.id,
                                                            },
                                                          );

                                                        const newUplineFee = {
                                                          id: 1,
                                                          commission:
                                                            commission.id,
                                                          amount: feeAmount,
                                                        };
                                                        updateTransaction.uplineFee.push(
                                                          newUplineFee,
                                                        );

                                                        feeUpline1 = feeAmount;
                                                      }
                                                    } else if (
                                                      uplineFee.id === 2 &&
                                                      userUpline.upline &&
                                                      userUpline.upline
                                                        .upline &&
                                                      !userUpline.upline.upline
                                                        .isBlocked &&
                                                      !userUpline.upline.upline
                                                        .isDeleted
                                                    ) {
                                                      if (
                                                        transaction.method
                                                          .type ===
                                                          MethodType.Va &&
                                                        feeMethodRoot.delay ===
                                                          0
                                                      ) {
                                                        await this.Balance.findOne(
                                                          {
                                                            user: userUpline
                                                              .upline.upline.id,
                                                          },
                                                        ).then(
                                                          async (
                                                            balanceUpline,
                                                          ) => {
                                                            let debDec =
                                                              Math.min(
                                                                balanceUpline.debt ??
                                                                  0,
                                                                feeAmount,
                                                              );
                                                            let feeFinal =
                                                              feeAmount -
                                                              debDec;

                                                            if (feeFinal > 0) {
                                                              const commission =
                                                                await this.Commission.findOneAndUpdate(
                                                                  {
                                                                    isActive:
                                                                      true,
                                                                    user: userUpline
                                                                      .upline
                                                                      .upline
                                                                      .id,
                                                                  },
                                                                  {
                                                                    $inc: {
                                                                      partnerTrx:
                                                                        feeFinal,
                                                                      partnerTrxQty: 1,
                                                                    },
                                                                  },
                                                                  { new: true },
                                                                );

                                                              await this.Commission.findOneAndUpdate(
                                                                {
                                                                  isActive:
                                                                    true,
                                                                  upline:
                                                                    userUpline
                                                                      .upline
                                                                      .upline
                                                                      .id,
                                                                  downline:
                                                                    userUpline
                                                                      .upline
                                                                      .id,
                                                                },
                                                                {
                                                                  $inc: {
                                                                    amountTrx:
                                                                      feeFinal,
                                                                    amountTrxQty: 1,
                                                                  },
                                                                },
                                                              );

                                                              await this.Balance.findByIdAndUpdate(
                                                                balanceUpline.id,
                                                                {
                                                                  $inc: {
                                                                    balance:
                                                                      Number(
                                                                        feeFinal,
                                                                      ),
                                                                  },
                                                                },
                                                              );

                                                              const newBalanceLog =
                                                                new this.BalanceLog(
                                                                  {
                                                                    name: userUpline
                                                                      .upline
                                                                      .username,
                                                                    balanceAmount:
                                                                      balanceUpline.balance,
                                                                    balanceCredit:
                                                                      Number(
                                                                        feeFinal,
                                                                      ),
                                                                    type: BalanceLogType.In,
                                                                    balance:
                                                                      balanceUpline.id,
                                                                    transaction:
                                                                      transaction.id,
                                                                  },
                                                                );

                                                              await newBalanceLog.save();

                                                              const newUplineFee =
                                                                {
                                                                  id: 2,
                                                                  commission:
                                                                    commission.id,
                                                                  amount:
                                                                    feeFinal,
                                                                };
                                                              updateTransaction.uplineFee.push(
                                                                newUplineFee,
                                                              );

                                                              feeUpline2 =
                                                                feeFinal;
                                                            }

                                                            if (debDec > 0) {
                                                              await this.Balance.findByIdAndUpdate(
                                                                balanceUpline.id,
                                                                {
                                                                  $inc: {
                                                                    debt: -Number(
                                                                      debDec,
                                                                    ),
                                                                  },
                                                                },
                                                              );

                                                              const newBalanceLog =
                                                                new this.BalanceLog(
                                                                  {
                                                                    name: `Paying debt from ${
                                                                      userUpline
                                                                        .upline
                                                                        .username
                                                                    } with amount ${toCurrency(
                                                                      debDec,
                                                                    )}`,
                                                                    balanceAmount:
                                                                      balanceUpline.debt,
                                                                    balanceCredit:
                                                                      Number(
                                                                        debDec,
                                                                      ),
                                                                    type: BalanceLogType.Pay,
                                                                    balance:
                                                                      balanceUpline.id,
                                                                    transaction:
                                                                      transaction.id,
                                                                  },
                                                                );

                                                              await newBalanceLog.save();
                                                            }
                                                          },
                                                        );
                                                      } else {
                                                        const commission =
                                                          await this.Commission.findOne(
                                                            {
                                                              isActive: true,
                                                              user: userUpline
                                                                .upline.upline
                                                                .id,
                                                            },
                                                          );

                                                        const newUplineFee = {
                                                          id: 2,
                                                          commission:
                                                            commission.id,
                                                          amount: feeAmount,
                                                        };
                                                        updateTransaction.uplineFee.push(
                                                          newUplineFee,
                                                        );

                                                        feeUpline2 = feeAmount;
                                                      }
                                                    } else if (
                                                      uplineFee.id === 3 &&
                                                      userUpline.upline &&
                                                      userUpline.upline
                                                        .upline &&
                                                      userUpline.upline.upline
                                                        .upline &&
                                                      !userUpline.upline.upline
                                                        .upline.isBlocked &&
                                                      !userUpline.upline.upline
                                                        .upline.isDeleted
                                                    ) {
                                                      if (
                                                        transaction.method
                                                          .type ===
                                                          MethodType.Va &&
                                                        feeMethodRoot.delay ===
                                                          0
                                                      ) {
                                                        await this.Balance.findOne(
                                                          {
                                                            user: userUpline
                                                              .upline.upline
                                                              .upline.id,
                                                          },
                                                        ).then(
                                                          async (
                                                            balanceUpline,
                                                          ) => {
                                                            let debDec =
                                                              Math.min(
                                                                balanceUpline.debt ??
                                                                  0,
                                                                feeAmount,
                                                              );
                                                            let feeFinal =
                                                              feeAmount -
                                                              debDec;

                                                            if (feeFinal > 0) {
                                                              const commission =
                                                                await this.Commission.findOneAndUpdate(
                                                                  {
                                                                    isActive:
                                                                      true,
                                                                    user: userUpline
                                                                      .upline
                                                                      .upline
                                                                      .upline
                                                                      .id,
                                                                  },
                                                                  {
                                                                    $inc: {
                                                                      partnerTrx:
                                                                        feeFinal,
                                                                      partnerTrxQty: 1,
                                                                    },
                                                                  },
                                                                  { new: true },
                                                                );

                                                              await this.Commission.findOneAndUpdate(
                                                                {
                                                                  isActive:
                                                                    true,
                                                                  upline:
                                                                    userUpline
                                                                      .upline
                                                                      .upline
                                                                      .upline
                                                                      .id,
                                                                  downline:
                                                                    userUpline
                                                                      .upline
                                                                      .upline
                                                                      .id,
                                                                },
                                                                {
                                                                  $inc: {
                                                                    amountTrx:
                                                                      feeFinal,
                                                                    amountTrxQty: 1,
                                                                  },
                                                                },
                                                              );

                                                              await this.Balance.findByIdAndUpdate(
                                                                balanceUpline.id,
                                                                {
                                                                  $inc: {
                                                                    balance:
                                                                      Number(
                                                                        feeFinal,
                                                                      ),
                                                                  },
                                                                },
                                                              );

                                                              const newBalanceLog =
                                                                new this.BalanceLog(
                                                                  {
                                                                    name: userUpline
                                                                      .upline
                                                                      .upline
                                                                      .username,
                                                                    balanceAmount:
                                                                      balanceUpline.balance,
                                                                    balanceCredit:
                                                                      Number(
                                                                        feeFinal,
                                                                      ),
                                                                    type: BalanceLogType.In,
                                                                    balance:
                                                                      balanceUpline.id,
                                                                    transaction:
                                                                      transaction.id,
                                                                  },
                                                                );

                                                              await newBalanceLog.save();

                                                              const newUplineFee =
                                                                {
                                                                  id: 3,
                                                                  commission:
                                                                    commission.id,
                                                                  amount:
                                                                    feeFinal,
                                                                };
                                                              updateTransaction.uplineFee.push(
                                                                newUplineFee,
                                                              );

                                                              feeUpline3 =
                                                                feeFinal;
                                                            }

                                                            if (debDec > 0) {
                                                              await this.Balance.findByIdAndUpdate(
                                                                balanceUpline.id,
                                                                {
                                                                  $inc: {
                                                                    debt: -Number(
                                                                      debDec,
                                                                    ),
                                                                  },
                                                                },
                                                              );

                                                              const newBalanceLog =
                                                                new this.BalanceLog(
                                                                  {
                                                                    name: `Paying debt from ${
                                                                      userUpline
                                                                        .upline
                                                                        .upline
                                                                        .username
                                                                    } with amount ${toCurrency(
                                                                      debDec,
                                                                    )}`,
                                                                    balanceAmount:
                                                                      balanceUpline.debt,
                                                                    balanceCredit:
                                                                      Number(
                                                                        debDec,
                                                                      ),
                                                                    type: BalanceLogType.Pay,
                                                                    balance:
                                                                      balanceUpline.id,
                                                                    transaction:
                                                                      transaction.id,
                                                                  },
                                                                );

                                                              await newBalanceLog.save();
                                                            }
                                                          },
                                                        );
                                                      } else {
                                                        const commission =
                                                          await this.Commission.findOne(
                                                            {
                                                              isActive: true,
                                                              user: userUpline
                                                                .upline.upline
                                                                .upline.id,
                                                            },
                                                          );

                                                        const newUplineFee = {
                                                          id: 3,
                                                          commission:
                                                            commission.id,
                                                          amount: feeAmount,
                                                        };
                                                        updateTransaction.uplineFee.push(
                                                          newUplineFee,
                                                        );

                                                        feeUpline3 = feeAmount;
                                                      }
                                                    }
                                                  }
                                                }
                                              },
                                            );
                                          });
                                      }
                                    }

                                    rootCredit -=
                                      feeUpline1 + feeUpline2 + feeUpline3;

                                    if (
                                      transaction.method.type ===
                                        MethodType.Va &&
                                      feeMethodRoot.delay === 0
                                    ) {
                                      await this.Balance.findByIdAndUpdate(
                                        rootData[0].balance._id,
                                        {
                                          $inc: {
                                            balance: Number(rootCredit),
                                          },
                                        },
                                      );

                                      const newBalanceLog = new this.BalanceLog(
                                        {
                                          name: `${client.clientName}'s ${
                                            transaction.transactionType ===
                                            TransactionType.Topup
                                              ? 'Topup'
                                              : 'Transaction'
                                          }`,
                                          balanceAmount:
                                            rootData[0].balance.balance,
                                          balanceCredit: Number(rootCredit),
                                          pgAmount: data.balance,
                                          pgCredit: data.credit_balance,
                                          type: BalanceLogType.In,
                                          balance: rootData[0].balance._id,
                                          transaction: transaction.id,
                                        },
                                      );

                                      await newBalanceLog.save();
                                    } else {
                                      await this.Balance.findByIdAndUpdate(
                                        rootData[0].balance._id,
                                        {
                                          $inc: {
                                            pending: Number(rootCredit),
                                          },
                                        },
                                      );
                                    }

                                    if (updateTransaction.uplineFee.length) {
                                      updateTransaction.uplineFee.sort(
                                        (a: any, b: any) => {
                                          if (a.id < b.id) return -1;
                                          if (a.id > b.id) return 1;
                                          return 0;
                                        },
                                      );
                                    }

                                    await this.Transaction.findByIdAndUpdate(
                                      transaction.id,
                                      updateTransaction,
                                    );
                                  }
                                } else {
                                  if (!transaction.pgSettled) {
                                    updateTransaction.uplineFee =
                                      transaction.uplineFee;
                                    const balanceCredit =
                                      amountCredit - (transaction.debt ?? 0);

                                    updateTransaction.pgSettled = true;
                                    if (fee.delay > 0) {
                                      const settleDate = new Date();
                                      settleDate.setDate(
                                        settleDate.getDate() + fee.delay,
                                      );
                                      settleDate.setHours(4, 0, 0, 0);
                                      updateTransaction.clientSettleDate =
                                        settleDate;
                                    } else {
                                      if (
                                        transaction.transactionType ===
                                          TransactionType.Transaction ||
                                        (transaction.transactionType ===
                                          TransactionType.Topup &&
                                          transaction.accessFrom ===
                                            AccessFrom.Api)
                                      ) {
                                        const resObj: any = {
                                          amount: transaction.amount,
                                          fee: transaction.fee,
                                          expired: new Date(
                                            transaction.exp,
                                          ).getTime(),
                                          method: transaction.method.code,
                                          methodName: transaction.method.name,
                                          customerName:
                                            transaction.clientCustName,
                                          ref1: transaction.clientRef,
                                          ref2: transaction.transactionId,
                                          status: TransactionStatusType.Settled,
                                          desc: `Your ${
                                            transaction.method.type ===
                                            MethodType.Va
                                              ? 'Virtual Account'
                                              : transaction.method.type ===
                                                MethodType.Retail
                                              ? 'Retail'
                                              : transaction.method.type ===
                                                MethodType.Qris
                                              ? 'QRIS'
                                              : transaction.method.type ===
                                                MethodType.Ewallet
                                              ? 'Ewallet'
                                              : ''
                                          } ${
                                            transaction.transactionType ===
                                            TransactionType.Transaction
                                              ? 'Transaction'
                                              : 'Topup'
                                          } is Settled to your balance`,
                                          paidTime: new Date(
                                            data.transaction_time,
                                          ).getTime(),
                                          serialNumber:
                                            data.serialnumber.replace(
                                              new RegExp('linkqu', 'ig'),
                                              '',
                                            ),
                                          settleTime: new Date().getTime(),
                                        };

                                        if (
                                          transaction.method.type ===
                                          MethodType.Ewallet
                                        ) {
                                          resObj.phone = transaction.phone;
                                        }

                                        const callbackKey = decrypt(
                                          process.env.ENCRYPT_ALG,
                                          hash('sha256', client.id).substring(
                                            0,
                                            32,
                                          ),
                                          hash(
                                            'sha256',
                                            transaction.user.id +
                                              client.clientId,
                                          ).substring(0, 16),
                                          client.callbackKey,
                                        );

                                        const sig = encryptHmac(
                                          'sha512',
                                          callbackKey,
                                          minifyJson(resObj).toLowerCase(),
                                          'hex',
                                        );

                                        const cbQuery: any = {
                                          user: transaction.user.id,
                                        };

                                        if (
                                          transaction.transactionType ===
                                          TransactionType.Transaction
                                        ) {
                                          cbQuery.transaction = transaction.id;
                                        } else {
                                          cbQuery.topup = transaction.id;
                                        }
                                        await this.Callback.findOne(
                                          cbQuery,
                                        ).then(async (transactionCb) => {
                                          var res: string, sent: boolean;
                                          await sendCallback(
                                            transaction.transactionType ===
                                              TransactionType.Transaction
                                              ? client.callbackTrx
                                              : client.callbackTopup,
                                            resObj,
                                            sig,
                                          )
                                            .then((responseData) => {
                                              res = responseData;
                                              sent = true;
                                            })
                                            .catch((error) => {
                                              res = error;
                                              sent = false;
                                            });

                                          if (transactionCb) {
                                            transactionCb.isSent = sent;
                                            transactionCb.payload =
                                              JSON.stringify(resObj);
                                            transactionCb.callbackUrl =
                                              transaction.transactionType ===
                                              TransactionType.Transaction
                                                ? client.callbackTrx
                                                : client.callbackTopup;
                                            if (sent) {
                                              transactionCb.res = res;
                                            } else {
                                              transactionCb.error = res;
                                            }
                                            transactionCb.attempt =
                                              transactionCb.attempt + 1;
                                            transactionCb.last = new Date();

                                            await transactionCb.save();
                                          } else {
                                            const newCallback =
                                              new this.Callback({
                                                isSent: sent,
                                                payload: JSON.stringify(resObj),
                                                callbackUrl:
                                                  transaction.transactionType ===
                                                  TransactionType.Transaction
                                                    ? client.callbackTrx
                                                    : client.callbackTopup,
                                                last: new Date(),
                                                type:
                                                  transaction.transactionType ===
                                                  TransactionType.Transaction
                                                    ? CallbackType.Transaction
                                                    : CallbackType.Topup,
                                                user: transaction.user.id,
                                              });

                                            if (
                                              transaction.transactionType ===
                                              TransactionType.Transaction
                                            ) {
                                              newCallback.transaction =
                                                transaction.id;
                                            } else {
                                              newCallback.topup =
                                                transaction.id;
                                            }

                                            if (sent) {
                                              newCallback.res = res;
                                            } else {
                                              newCallback.error = res;
                                            }

                                            await newCallback.save();
                                          }
                                        });
                                      }
                                      updateTransaction.status =
                                        TransactionStatusType.Settled;
                                      updateTransaction.clientSettled = true;
                                      const settleDate = new Date();
                                      updateTransaction.clientSettleDate =
                                        settleDate;

                                      await this.Balance.findByIdAndUpdate(
                                        balance.id,
                                        {
                                          $inc: {
                                            balance: Number(balanceCredit),
                                            pending: -Number(balanceCredit),
                                          },
                                        },
                                      );

                                      const newBalanceLog = new this.BalanceLog(
                                        {
                                          name: `${
                                            transaction.clientRef
                                              ? `${transaction.clientRef}'s `
                                              : ''
                                          } ${
                                            transaction.transactionType ===
                                            TransactionType.Topup
                                              ? 'Topup'
                                              : 'Transaction'
                                          }`,
                                          balanceAmount: balance.balance,
                                          balanceCredit: Number(balanceCredit),
                                          type: BalanceLogType.In,
                                          balance: balance.id,
                                          transaction: transaction.id,
                                        },
                                      );

                                      await newBalanceLog.save();
                                    }

                                    var feeUpline1: number = 0,
                                      feeUpline2: number = 0,
                                      feeUpline3: number = 0;
                                    if (
                                      transaction.accessFrom === AccessFrom.Api
                                    ) {
                                      if (
                                        fee.uplineFee &&
                                        fee.uplineFee.length
                                      ) {
                                        await this.User.findById(
                                          transaction.user.id,
                                        )
                                          .populate({
                                            path: 'upline',
                                            populate: {
                                              path: 'upline',
                                              populate: {
                                                path: 'upline',
                                              },
                                            },
                                          })
                                          .then(async (userUpline: any) => {
                                            for (const uplineFee of fee.uplineFee) {
                                              if (uplineFee.id === 1) {
                                                const uplineFeeFound =
                                                  searchArray(
                                                    transaction.uplineFee,
                                                    null,
                                                    null,
                                                    'id',
                                                    '1',
                                                  );
                                                if (uplineFeeFound.length) {
                                                  await this.Commission.findById(
                                                    uplineFeeFound[0]
                                                      .commission,
                                                  ).then(async (commission) => {
                                                    if (
                                                      userUpline.upline &&
                                                      commission.user ==
                                                        userUpline.upline.id &&
                                                      !userUpline.upline
                                                        .isBlocked &&
                                                      !userUpline.upline
                                                        .isDeleted
                                                    ) {
                                                      await this.Balance.findOne(
                                                        {
                                                          user: commission.user,
                                                        },
                                                      ).then(
                                                        async (
                                                          balanceUpline,
                                                        ) => {
                                                          let debDec = Math.min(
                                                            balanceUpline.debt ??
                                                              0,
                                                            uplineFeeFound[0]
                                                              .amount,
                                                          );
                                                          let feeFinal =
                                                            uplineFeeFound[0]
                                                              .amount - debDec;

                                                          if (feeFinal > 0) {
                                                            await this.Commission.findByIdAndUpdate(
                                                              commission.id,
                                                              {
                                                                $inc: {
                                                                  clientTrx:
                                                                    feeFinal,
                                                                  clientTrxQty: 1,
                                                                },
                                                              },
                                                              { new: true },
                                                            );

                                                            await this.Commission.findOneAndUpdate(
                                                              {
                                                                isActive: true,
                                                                upline:
                                                                  userUpline
                                                                    .upline.id,
                                                                downline:
                                                                  userUpline.id,
                                                              },
                                                              {
                                                                $inc: {
                                                                  amountTrx:
                                                                    feeFinal,
                                                                  amountTrxQty: 1,
                                                                },
                                                              },
                                                            );

                                                            await this.Balance.findByIdAndUpdate(
                                                              balanceUpline.id,
                                                              {
                                                                $inc: {
                                                                  balance:
                                                                    Number(
                                                                      feeFinal,
                                                                    ),
                                                                },
                                                              },
                                                            );

                                                            const newBalanceLog =
                                                              new this.BalanceLog(
                                                                {
                                                                  name: userUpline.username,
                                                                  balanceAmount:
                                                                    balanceUpline.balance,
                                                                  balanceCredit:
                                                                    Number(
                                                                      feeFinal,
                                                                    ),
                                                                  type: BalanceLogType.In,
                                                                  balance:
                                                                    balanceUpline.id,
                                                                  transaction:
                                                                    transaction.id,
                                                                },
                                                              );

                                                            await newBalanceLog.save();

                                                            feeUpline1 =
                                                              feeFinal;
                                                          }

                                                          const newUplineFee = {
                                                            id: 1,
                                                            commission:
                                                              commission.id,
                                                            amount: feeFinal,
                                                          };
                                                          updateTransaction.uplineFee.splice(
                                                            updateTransaction.uplineFee.findIndex(
                                                              (fee: any) =>
                                                                fee.id === 1,
                                                            ),
                                                            1,
                                                            newUplineFee,
                                                          );

                                                          if (debDec > 0) {
                                                            await this.Balance.findByIdAndUpdate(
                                                              balanceUpline.id,
                                                              {
                                                                $inc: {
                                                                  debt: -Number(
                                                                    debDec,
                                                                  ),
                                                                },
                                                              },
                                                            );

                                                            const newBalanceLog =
                                                              new this.BalanceLog(
                                                                {
                                                                  name: `Paying debt from ${
                                                                    userUpline.username
                                                                  } with amount ${toCurrency(
                                                                    debDec,
                                                                  )}`,
                                                                  balanceAmount:
                                                                    balanceUpline.debt,
                                                                  balanceCredit:
                                                                    Number(
                                                                      debDec,
                                                                    ),
                                                                  type: BalanceLogType.Pay,
                                                                  balance:
                                                                    balanceUpline.id,
                                                                  transaction:
                                                                    transaction.id,
                                                                },
                                                              );

                                                            await newBalanceLog.save();
                                                          }
                                                        },
                                                      );
                                                    } else {
                                                      const newUplineFee = {
                                                        id: 1,
                                                        commission:
                                                          commission.id,
                                                        amount: 0,
                                                      };

                                                      updateTransaction.uplineFee.splice(
                                                        updateTransaction.uplineFee.findIndex(
                                                          (fee: any) =>
                                                            fee.id === 1,
                                                        ),
                                                        1,
                                                        newUplineFee,
                                                      );
                                                    }
                                                  });
                                                }
                                              } else if (uplineFee.id === 2) {
                                                const uplineFeeFound =
                                                  searchArray(
                                                    transaction.uplineFee,
                                                    null,
                                                    null,
                                                    'id',
                                                    '2',
                                                  );
                                                if (uplineFeeFound.length) {
                                                  await this.Commission.findById(
                                                    uplineFeeFound[0]
                                                      .commission,
                                                  ).then(async (commission) => {
                                                    if (
                                                      userUpline.upline &&
                                                      userUpline.upline
                                                        .upline &&
                                                      commission.user ==
                                                        userUpline.upline.upline
                                                          .id &&
                                                      !userUpline.upline.upline
                                                        .isBlocked &&
                                                      !userUpline.upline.upline
                                                        .isDeleted
                                                    ) {
                                                      await this.Balance.findOne(
                                                        {
                                                          user: commission.user,
                                                        },
                                                      ).then(
                                                        async (
                                                          balanceUpline,
                                                        ) => {
                                                          let debDec = Math.min(
                                                            balanceUpline.debt ??
                                                              0,
                                                            uplineFeeFound[0]
                                                              .amount,
                                                          );
                                                          let feeFinal =
                                                            uplineFeeFound[0]
                                                              .amount - debDec;

                                                          if (feeFinal > 0) {
                                                            await this.Commission.findByIdAndUpdate(
                                                              commission.id,
                                                              {
                                                                $inc: {
                                                                  partnerTrx:
                                                                    feeFinal,
                                                                  partnerTrxQty: 1,
                                                                },
                                                              },
                                                            );

                                                            await this.Commission.findOneAndUpdate(
                                                              {
                                                                isActive: true,
                                                                upline:
                                                                  userUpline
                                                                    .upline
                                                                    .upline.id,
                                                                downline:
                                                                  userUpline
                                                                    .upline.id,
                                                              },
                                                              {
                                                                $inc: {
                                                                  amountTrx:
                                                                    feeFinal,
                                                                  amountTrxQty: 1,
                                                                },
                                                              },
                                                            );

                                                            await this.Balance.findByIdAndUpdate(
                                                              balanceUpline.id,
                                                              {
                                                                $inc: {
                                                                  balance:
                                                                    Number(
                                                                      feeFinal,
                                                                    ),
                                                                },
                                                              },
                                                            );

                                                            const newBalanceLog =
                                                              new this.BalanceLog(
                                                                {
                                                                  name: userUpline
                                                                    .upline
                                                                    .username,
                                                                  balanceAmount:
                                                                    balanceUpline.balance,
                                                                  balanceCredit:
                                                                    Number(
                                                                      feeFinal,
                                                                    ),
                                                                  type: BalanceLogType.In,
                                                                  balance:
                                                                    balanceUpline.id,
                                                                  transaction:
                                                                    transaction.id,
                                                                },
                                                              );

                                                            await newBalanceLog.save();

                                                            feeUpline2 =
                                                              feeFinal;
                                                          }

                                                          const newUplineFee = {
                                                            id: 2,
                                                            commission:
                                                              commission.id,
                                                            amount: feeFinal,
                                                          };
                                                          updateTransaction.uplineFee.splice(
                                                            updateTransaction.uplineFee.findIndex(
                                                              (fee: any) =>
                                                                fee.id === 2,
                                                            ),
                                                            1,
                                                            newUplineFee,
                                                          );

                                                          if (debDec > 0) {
                                                            await this.Balance.findByIdAndUpdate(
                                                              balanceUpline.id,
                                                              {
                                                                $inc: {
                                                                  debt: -Number(
                                                                    debDec,
                                                                  ),
                                                                },
                                                              },
                                                            );

                                                            const newBalanceLog =
                                                              new this.BalanceLog(
                                                                {
                                                                  name: `Paying debt from ${
                                                                    userUpline
                                                                      .upline
                                                                      .username
                                                                  } with amount ${toCurrency(
                                                                    debDec,
                                                                  )}`,
                                                                  balanceAmount:
                                                                    balanceUpline.debt,
                                                                  balanceCredit:
                                                                    Number(
                                                                      debDec,
                                                                    ),
                                                                  type: BalanceLogType.Pay,
                                                                  balance:
                                                                    balanceUpline.id,
                                                                  transaction:
                                                                    transaction.id,
                                                                },
                                                              );

                                                            await newBalanceLog.save();
                                                          }
                                                        },
                                                      );
                                                    } else {
                                                      const newUplineFee = {
                                                        id: 2,
                                                        commission:
                                                          commission.id,
                                                        amount: 0,
                                                      };

                                                      updateTransaction.uplineFee.splice(
                                                        updateTransaction.uplineFee.findIndex(
                                                          (fee: any) =>
                                                            fee.id === 2,
                                                        ),
                                                        1,
                                                        newUplineFee,
                                                      );
                                                    }
                                                  });
                                                }
                                              } else if (uplineFee.id === 3) {
                                                const uplineFeeFound =
                                                  searchArray(
                                                    transaction.uplineFee,
                                                    null,
                                                    null,
                                                    'id',
                                                    '3',
                                                  );
                                                if (uplineFeeFound.length) {
                                                  await this.Commission.findById(
                                                    uplineFeeFound[0]
                                                      .commission,
                                                  ).then(async (commission) => {
                                                    if (
                                                      userUpline.upline &&
                                                      userUpline.upline
                                                        .upline &&
                                                      userUpline.upline.upline
                                                        .upline &&
                                                      commission.user ==
                                                        userUpline.upline.upline
                                                          .upline.id &&
                                                      !userUpline.upline.upline
                                                        .upline.isBlocked &&
                                                      !userUpline.upline.upline
                                                        .upline.isDeleted
                                                    ) {
                                                      await this.Balance.findOne(
                                                        {
                                                          user: commission.user,
                                                        },
                                                      ).then(
                                                        async (
                                                          balanceUpline,
                                                        ) => {
                                                          let debDec = Math.min(
                                                            balanceUpline.debt ??
                                                              0,
                                                            uplineFeeFound[0]
                                                              .amount,
                                                          );
                                                          let feeFinal =
                                                            uplineFeeFound[0]
                                                              .amount - debDec;

                                                          if (feeFinal > 0) {
                                                            await this.Commission.findByIdAndUpdate(
                                                              commission.id,
                                                              {
                                                                $inc: {
                                                                  partnerTrx:
                                                                    feeFinal,
                                                                  partnerTrxQty: 1,
                                                                },
                                                              },
                                                            );

                                                            await this.Commission.findOneAndUpdate(
                                                              {
                                                                isActive: true,
                                                                upline:
                                                                  userUpline
                                                                    .upline
                                                                    .upline
                                                                    .upline.id,
                                                                downline:
                                                                  userUpline
                                                                    .upline
                                                                    .upline.id,
                                                              },
                                                              {
                                                                $inc: {
                                                                  amountTrx:
                                                                    feeFinal,
                                                                  amountTrxQty: 1,
                                                                },
                                                              },
                                                            );

                                                            await this.Balance.findByIdAndUpdate(
                                                              balanceUpline.id,
                                                              {
                                                                $inc: {
                                                                  balance:
                                                                    Number(
                                                                      feeFinal,
                                                                    ),
                                                                },
                                                              },
                                                            );

                                                            const newBalanceLog =
                                                              new this.BalanceLog(
                                                                {
                                                                  name: userUpline
                                                                    .upline
                                                                    .upline
                                                                    .username,
                                                                  balanceAmount:
                                                                    balanceUpline.balance,
                                                                  balanceCredit:
                                                                    Number(
                                                                      feeFinal,
                                                                    ),
                                                                  type: BalanceLogType.In,
                                                                  balance:
                                                                    balanceUpline.id,
                                                                  transaction:
                                                                    transaction.id,
                                                                },
                                                              );

                                                            await newBalanceLog.save();

                                                            feeUpline3 =
                                                              feeFinal;
                                                          }

                                                          const newUplineFee = {
                                                            id: 3,
                                                            commission:
                                                              commission.id,
                                                            amount: feeFinal,
                                                          };
                                                          updateTransaction.uplineFee.splice(
                                                            updateTransaction.uplineFee.findIndex(
                                                              (fee: any) =>
                                                                fee.id === 3,
                                                            ),
                                                            1,
                                                            newUplineFee,
                                                          );

                                                          if (debDec > 0) {
                                                            await this.Balance.findByIdAndUpdate(
                                                              balanceUpline.id,
                                                              {
                                                                $inc: {
                                                                  debt: -Number(
                                                                    debDec,
                                                                  ),
                                                                },
                                                              },
                                                            );

                                                            const newBalanceLog =
                                                              new this.BalanceLog(
                                                                {
                                                                  name: `Paying debt from ${
                                                                    userUpline
                                                                      .upline
                                                                      .upline
                                                                      .username
                                                                  } with amount ${toCurrency(
                                                                    debDec,
                                                                  )}`,
                                                                  balanceAmount:
                                                                    balanceUpline.debt,
                                                                  balanceCredit:
                                                                    Number(
                                                                      debDec,
                                                                    ),
                                                                  type: BalanceLogType.Pay,
                                                                  balance:
                                                                    balanceUpline.id,
                                                                  transaction:
                                                                    transaction.id,
                                                                },
                                                              );

                                                            await newBalanceLog.save();
                                                          }
                                                        },
                                                      );
                                                    } else {
                                                      const newUplineFee = {
                                                        id: 3,
                                                        commission:
                                                          commission.id,
                                                        amount: 0,
                                                      };

                                                      updateTransaction.uplineFee.splice(
                                                        updateTransaction.uplineFee.findIndex(
                                                          (fee: any) =>
                                                            fee.id === 3,
                                                        ),
                                                        1,
                                                        newUplineFee,
                                                      );
                                                    }
                                                  });
                                                }
                                              }
                                            }
                                          });
                                      }
                                    }

                                    rootCredit -=
                                      feeUpline1 + feeUpline2 + feeUpline3;

                                    await this.Balance.findByIdAndUpdate(
                                      rootData[0].balance._id,
                                      {
                                        $inc: {
                                          balance: Number(rootCredit),
                                          pending: -Number(rootCredit),
                                        },
                                      },
                                    );

                                    const newBalanceLog = new this.BalanceLog({
                                      name: `${client.clientName}'s ${
                                        transaction.transactionType ===
                                        TransactionType.Topup
                                          ? 'Topup'
                                          : 'Transaction'
                                      }`,
                                      balanceAmount:
                                        rootData[0].balance.balance,
                                      balanceCredit: Number(rootCredit),
                                      pgAmount: data.balance,
                                      pgCredit: data.credit_balance,
                                      type: BalanceLogType.In,
                                      balance: rootData[0].balance._id,
                                      transaction: transaction.id,
                                    });

                                    await newBalanceLog.save();

                                    if (updateTransaction.uplineFee.length) {
                                      updateTransaction.uplineFee.sort(
                                        (a: any, b: any) => {
                                          if (a.id < b.id) return -1;
                                          if (a.id > b.id) return 1;
                                          return 0;
                                        },
                                      );
                                    }

                                    await this.Transaction.findByIdAndUpdate(
                                      transaction.id,
                                      updateTransaction,
                                    );
                                  }
                                }
                              }
                            });
                          } else {
                            const error = response.initError(
                              404,
                              false,
                              new ErrorMessage('3 not found'),
                            );
                            return res.send(error);
                          }
                        });
                      } else {
                        if (transaction.product) {
                          await this.Fee.findOne({
                            user: rootData[0]._id,
                            method: transaction.method.id,
                            feeType: FeeType.Transaction,
                          }).then(async (fee) => {
                            if (fee) {
                              if (data.type === PgType.Pay) {
                                if (
                                  transaction.status ===
                                  TransactionStatusType.Pending
                                ) {
                                  const payload = {
                                    username: process.env.DF_USERNAME,
                                    buyer_sku_code: transaction.product.code,
                                    customer_no: transaction.form,
                                    ref_id: transaction.transactionId,
                                    sign: hash(
                                      'md5',
                                      `${process.env.DF_USERNAME}${process.env.DF_PROD_KEY}${transaction.transactionId}`,
                                    ),
                                  };
                                  const header = {
                                    'Content-Type': CT_APP_JSON,
                                  };
                                  await fetch(
                                    process.env.DF_BASE_URL + 'transaction',
                                    {
                                      method: 'POST',
                                      body: JSON.stringify(payload),
                                      headers: header,
                                    },
                                  ).then(async (responseFetch) => {
                                    const responseData =
                                      await responseFetch.json();

                                    const updateTransaction: any = {
                                      paidRef: data.payment_reff,
                                      paidTime: new Date(data.transaction_time),
                                      serialNumber: data.serialnumber.replace(
                                        new RegExp('linkqu', 'ig'),
                                        '',
                                      ),
                                    };
                                    if (
                                      responseData.data.status === 'Sukses' &&
                                      responseData.data.rc === '00'
                                    ) {
                                      updateTransaction.status =
                                        TransactionStatusType.Paid;
                                      updateTransaction.dfTrxId =
                                        responseData.data.trx_id;
                                      updateTransaction.dfSn =
                                        responseData.data.sn;
                                    } else if (
                                      responseData.data.status === 'Pending'
                                    ) {
                                      updateTransaction.status =
                                        TransactionStatusType.Processing;
                                    } else {
                                      if (
                                        responseData.data.rc === '01' ||
                                        responseData.data.rc === '44' ||
                                        responseData.data.rc === '53' ||
                                        responseData.data.rc === '55' ||
                                        responseData.data.rc === '56' ||
                                        responseData.data.rc === '58' ||
                                        responseData.data.rc === '62' ||
                                        responseData.data.rc === '63' ||
                                        responseData.data.rc === '64' ||
                                        responseData.data.rc === '65' ||
                                        responseData.data.rc === '66' ||
                                        responseData.data.rc === '67' ||
                                        responseData.data.rc === '68' ||
                                        responseData.data.rc === '70' ||
                                        responseData.data.rc === '71' ||
                                        responseData.data.rc === '80' ||
                                        responseData.data.rc === '99'
                                      ) {
                                        updateTransaction.status =
                                          TransactionStatusType.Assist;
                                      } else {
                                        updateTransaction.status =
                                          TransactionStatusType.Failed;

                                        await this.Balance.findByIdAndUpdate(
                                          balance.id,
                                          {
                                            $inc: {
                                              balance: Number(
                                                transaction.amount -
                                                  transaction.fee,
                                              ),
                                            },
                                          },
                                        );
                                        const newBalanceLog =
                                          new this.BalanceLog({
                                            name:
                                              'Refund failed transaction: ' +
                                              transaction.product.name,
                                            balanceAmount: balance.balance,
                                            balanceCredit: Number(
                                              transaction.amount,
                                            ),
                                            type: BalanceLogType.Refund,
                                            balance: balance.id,
                                            transaction: transaction.id,
                                          });

                                        await newBalanceLog.save();

                                        const newBalanceLog2 =
                                          new this.BalanceLog({
                                            name:
                                              'Fee: ' +
                                              transaction.product.name,
                                            balanceAmount:
                                              balance.balance +
                                              transaction.amount,
                                            balanceCredit: Number(
                                              transaction.fee,
                                            ),
                                            type: BalanceLogType.Out,
                                            balance: balance.id,
                                            transaction: transaction.id,
                                          });

                                        await newBalanceLog2.save();

                                        if (transaction.usedBalance > 0) {
                                          await this.Balance.findByIdAndUpdate(
                                            balance.id,
                                            {
                                              $inc: {
                                                balance: Number(
                                                  transaction.usedBalance,
                                                ),
                                              },
                                            },
                                          );

                                          const newBalanceLog3 =
                                            new this.BalanceLog({
                                              name:
                                                'Refund used balance: ' +
                                                transaction.product.name,
                                              balanceAmount: balance.balance,
                                              balanceCredit: Number(
                                                transaction.usedBalance,
                                              ),
                                              type: BalanceLogType.Refund,
                                              balance: balance.id,
                                              transaction: transaction.id,
                                            });

                                          await newBalanceLog3.save();
                                        }
                                      }
                                      updateTransaction.error =
                                        responseData.data.message;
                                    }

                                    const rootCredit =
                                      transaction.fee - transaction.feeAdmin;

                                    await this.Balance.findByIdAndUpdate(
                                      rootData[0].balance._id,
                                      {
                                        $inc: {
                                          balance: Number(rootCredit),
                                        },
                                      },
                                    );
                                    const newBalanceLog = new this.BalanceLog({
                                      name: transaction.user.email,
                                      balanceAmount:
                                        rootData[0].balance.balance,
                                      balanceCredit: Number(rootCredit),
                                      pgAmount: data.balance,
                                      pgCredit: data.credit_balance,
                                      dfAmount:
                                        responseData.data.buyer_last_saldo,
                                      type: BalanceLogType.In,
                                      balance: rootData[0].balance._id,
                                      transaction: transaction.id,
                                    });

                                    await newBalanceLog.save();

                                    await this.Transaction.findByIdAndUpdate(
                                      transaction.id,
                                      updateTransaction,
                                    );
                                  });
                                }
                              } else {
                                if (!transaction.pgSettled) {
                                  const updateTransaction = {
                                    pgSettled: true,
                                  };

                                  await this.Transaction.findByIdAndUpdate(
                                    transaction.id,
                                    updateTransaction,
                                  );
                                }
                              }
                            } else {
                              const error = response.initError(
                                404,
                                false,
                                new ErrorMessage('6 not found!'),
                              );
                              return res.send(error);
                            }
                          });
                        } else {
                          const error = response.initError(
                            404,
                            false,
                            new ErrorMessage('5 not found!'),
                          );
                          return res.send(error);
                        }
                      }
                    });
                  } else if (data.status === PgType.Failed) {
                    const updateTransaction: any = {
                      paidRef: data.payment_reff,
                      paidTime: new Date(data.transaction_time),
                      status: TransactionStatusType.Failed,
                    };
                    await this.Transaction.findByIdAndUpdate(
                      transaction.id,
                      updateTransaction,
                    );
                    if (transaction.user.role === Role.Client) {
                      await this.Client.findOne({
                        user: transaction.user.id,
                      }).then(async (client) => {
                        if (client) {
                          if (
                            transaction.transactionType ===
                              TransactionType.Transaction ||
                            (transaction.transactionType ===
                              TransactionType.Topup &&
                              transaction.accessFrom === AccessFrom.Api)
                          ) {
                            const resObj: any = {
                              amount: transaction.amount,
                              fee: transaction.fee,
                              expired: new Date(transaction.exp).getTime(),
                              method: transaction.method.code,
                              methodName: transaction.method.name,
                              customerName: transaction.clientCustName,
                              ref1: transaction.clientRef,
                              ref2: transaction.transactionId,
                              status: TransactionStatusType.Failed,
                              desc: `Your ${
                                transaction.method.type === MethodType.Va
                                  ? 'Virtual Account'
                                  : transaction.method.type ===
                                    MethodType.Retail
                                  ? 'Retail'
                                  : transaction.method.type === MethodType.Qris
                                  ? 'QRIS'
                                  : transaction.method.type ===
                                    MethodType.Ewallet
                                  ? 'Ewallet'
                                  : ''
                              } ${
                                transaction.transactionType ===
                                TransactionType.Transaction
                                  ? 'Transaction'
                                  : 'Topup'
                              } is Failed`,
                            };

                            if (
                              transaction.method.type === MethodType.Ewallet
                            ) {
                              resObj.phone = transaction.phone;
                            }

                            const callbackKey = decrypt(
                              process.env.ENCRYPT_ALG,
                              hash('sha256', client.id).substring(0, 32),
                              hash(
                                'sha256',
                                transaction.user.id + client.clientId,
                              ).substring(0, 16),
                              client.callbackKey,
                            );

                            const sig = encryptHmac(
                              'sha512',
                              callbackKey,
                              minifyJson(resObj).toLowerCase(),
                              'hex',
                            );

                            const cbQuery: any = {
                              user: transaction.user.id,
                            };

                            if (
                              transaction.transactionType ===
                              TransactionType.Transaction
                            ) {
                              cbQuery.transaction = transaction.id;
                            } else {
                              cbQuery.topup = transaction.id;
                            }
                            await this.Callback.findOne(cbQuery).then(
                              async (transactionCb) => {
                                var res: string, sent: boolean;
                                await sendCallback(
                                  transaction.transactionType ===
                                    TransactionType.Transaction
                                    ? client.callbackTrx
                                    : client.callbackTopup,
                                  resObj,
                                  sig,
                                )
                                  .then((responseData) => {
                                    res = responseData;
                                    sent = true;
                                  })
                                  .catch((error) => {
                                    res = error;
                                    sent = false;
                                  });

                                if (transactionCb) {
                                  transactionCb.isSent = sent;
                                  transactionCb.payload =
                                    JSON.stringify(resObj);
                                  transactionCb.callbackUrl =
                                    transaction.transactionType ===
                                    TransactionType.Transaction
                                      ? client.callbackTrx
                                      : client.callbackTopup;
                                  if (sent) {
                                    transactionCb.res = res;
                                  } else {
                                    transactionCb.error = res;
                                  }
                                  transactionCb.attempt =
                                    transactionCb.attempt + 1;
                                  transactionCb.last = new Date();

                                  await transactionCb.save();
                                } else {
                                  const newCallback = new this.Callback({
                                    isSent: sent,
                                    payload: JSON.stringify(resObj),
                                    callbackUrl:
                                      transaction.transactionType ===
                                      TransactionType.Transaction
                                        ? client.callbackTrx
                                        : client.callbackTopup,
                                    last: new Date(),
                                    type:
                                      transaction.transactionType ===
                                      TransactionType.Transaction
                                        ? CallbackType.Transaction
                                        : CallbackType.Topup,
                                    user: transaction.user.id,
                                  });

                                  if (
                                    transaction.transactionType ===
                                    TransactionType.Transaction
                                  ) {
                                    newCallback.transaction = transaction.id;
                                  } else {
                                    newCallback.topup = transaction.id;
                                  }

                                  if (sent) {
                                    newCallback.res = res;
                                  } else {
                                    newCallback.error = res;
                                  }

                                  await newCallback.save();
                                }
                              },
                            );
                          }
                        } else {
                          const error = response.initError(
                            404,
                            false,
                            new ErrorMessage('6 not found'),
                          );
                          return res.send(error);
                        }
                      });
                    } else if (transaction.usedBalance > 0) {
                      await this.Balance.findByIdAndUpdate(balance.id, {
                        $inc: {
                          balance: Number(transaction.usedBalance),
                        },
                      });

                      const newBalanceLog3 = new this.BalanceLog({
                        name: 'Refund ' + transaction.product.name,
                        balanceAmount: balance.balance,
                        balanceCredit: Number(transaction.usedBalance),
                        type: BalanceLogType.Refund,
                        balance: balance.id,
                        transaction: transaction.id,
                      });

                      await newBalanceLog3.save();
                    }
                  }
                  return res.status(200).send({
                    response: 'OK',
                  });
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('2 not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Transaction not found'),
              );
              return res.send(error);
            }
          });
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async linkquWd(data: LinkquWdDto, req: FastifyRequest, res: FastifyReply) {
    try {
      if (req.ip === '34.101.73.158') {
        await this.Withdraw.findOne({
          orderId: data.partner_reff,
          process: WithdrawProcess.Process,
          status: WithdrawStatus.Processing,
        })
          .populate('bank')
          .then(async (withdraw: any) => {
            if (
              withdraw &&
              withdraw.amount === data.amount &&
              withdraw.feeAdmin === data.additionalfee
            ) {
              await this.Balance.findOne({
                user: withdraw.user,
              }).then(async (balance) => {
                if (balance) {
                  const updateWithdraw: any = {
                    paidReff:
                      withdraw.bank.type === BankType.Cash
                        ? data.partner_reff2
                        : data.payment_reff,
                    paidDate: new Date(data.transaction_time),
                  };

                  if (data.status === PgType.Success) {
                    updateWithdraw.status = WithdrawStatus.Success;
                    updateWithdraw.serialNumber =
                      withdraw.bank.type === BankType.Cash
                        ? ''
                        : data.serialnumber;

                    const userRoot = await this.User.findOne({
                      role: Role.Root,
                    }).exec();

                    if (withdraw.withdrawType === WithdrawType.Client) {
                      updateWithdraw.uplineFee = [];

                      await this.Client.findOne({
                        user: withdraw.user,
                      }).then(async (client) => {
                        if (client) {
                          if (withdraw.accessFrom === AccessFrom.Api) {
                            const resObj: any = {
                              amount: withdraw.amount,
                              fee: withdraw.fee,
                              channelName: withdraw.bank.name,
                              accountNumber:
                                withdraw.bank.type === BankType.Cash
                                  ? ''
                                  : withdraw.accNumber,
                              name:
                                withdraw.bank.type === BankType.Cash
                                  ? `Cash Transfer ${withdraw.bank.name}`
                                  : withdraw.name,
                              ref1: withdraw.clientRef,
                              ref2: withdraw.withdrawId,
                              status: WithdrawStatus.Success,
                              desc: `Success ${
                                withdraw.bank.type === BankType.Cash
                                  ? `create ${withdraw.bank.name} transfer request`
                                  : `transfer to ${withdraw.name}-${withdraw.accNumber}`
                              }`,
                              paidDate: new Date(
                                data.transaction_time,
                              ).getTime(),
                              serialNumber:
                                withdraw.bank.type === BankType.Cash
                                  ? ''
                                  : data.serialnumber.replace(
                                      new RegExp('linkqu', 'ig'),
                                      '',
                                    ),
                              note:
                                withdraw.bank.type === BankType.Cash
                                  ? withdraw.note
                                  : withdraw.remark,
                            };

                            if (withdraw.bank.type === BankType.Cash) {
                              resObj.expired = new Date(withdraw.exp).getTime();
                            }

                            const callbackKey = decrypt(
                              process.env.ENCRYPT_ALG,
                              hash('sha256', client.id).substring(0, 32),
                              hash(
                                'sha256',
                                withdraw.user + client.clientId,
                              ).substring(0, 16),
                              client.callbackKey,
                            );

                            const sig = encryptHmac(
                              'sha512',
                              callbackKey,
                              minifyJson(resObj).toLowerCase(),
                              'hex',
                            );

                            await this.Callback.findOne({
                              withdraw: withdraw.id,
                              user: withdraw.user,
                            }).then(async (withdrawCb) => {
                              var res: string, sent: boolean;
                              await sendCallback(client.callbackWd, resObj, sig)
                                .then((responseData) => {
                                  res = responseData;
                                  sent = true;
                                })
                                .catch((error) => {
                                  res = error;
                                  sent = false;
                                });

                              if (withdrawCb) {
                                withdrawCb.isSent = sent;
                                withdrawCb.payload = JSON.stringify(resObj);
                                withdrawCb.callbackUrl = client.callbackWd;
                                if (sent) {
                                  withdrawCb.res = res;
                                } else {
                                  withdrawCb.error = res;
                                }
                                withdrawCb.attempt = withdrawCb.attempt + 1;
                                withdrawCb.last = new Date();

                                await withdrawCb.save();
                              } else {
                                const newCallback = new this.Callback({
                                  isSent: sent,
                                  payload: JSON.stringify(resObj),
                                  callbackUrl: client.callbackWd,
                                  last: new Date(),
                                  type: CallbackType.Withdraw,
                                  withdraw: withdraw.id,
                                  user: withdraw.user,
                                });

                                if (sent) {
                                  newCallback.res = res;
                                } else {
                                  newCallback.error = res;
                                }

                                await newCallback.save();
                              }
                            });
                          }

                          const rootBalance = await this.Balance.findOne({
                            user: userRoot.id,
                          }).exec();
                          var rootCredit = withdraw.fee - withdraw.feeAdmin;

                          var feeUpline1: number = 0,
                            feeUpline2: number = 0,
                            feeUpline3: number = 0;

                          const wdFeeQuery: any = {
                            user: withdraw.user,
                            feeType: withdraw.bank.type,
                          };
                          if (
                            withdraw.bank.type === BankType.Ewallet ||
                            withdraw.bank.type === BankType.Cash
                          ) {
                            wdFeeQuery.bank = withdraw.bank.id;
                          }

                          await this.Fee.findOne(wdFeeQuery).then(
                            async (fee) => {
                              if (
                                fee &&
                                fee.uplineFee &&
                                fee.uplineFee.length
                              ) {
                                await this.User.findById(withdraw.user)
                                  .populate({
                                    path: 'upline',
                                    populate: {
                                      path: 'upline',
                                      populate: {
                                        path: 'upline',
                                      },
                                    },
                                  })
                                  .then(async (userUpline: any) => {
                                    await this.ValueType.find().then(
                                      async (valueType) => {
                                        for (const uplineFee of fee.uplineFee) {
                                          const typeFound = searchArray(
                                            valueType,
                                            null,
                                            null,
                                            'id',
                                            uplineFee.type,
                                          );
                                          if (typeFound.length) {
                                            let feeAmount: number;
                                            switch (typeFound[0].name) {
                                              case VType.Percentage:
                                                feeAmount = Math.floor(
                                                  (withdraw.amount *
                                                    uplineFee.percentage) /
                                                    100,
                                                );
                                                break;
                                              case VType.Fixed:
                                                feeAmount = uplineFee.fixed;
                                                break;
                                              default:
                                                feeAmount = Math.floor(
                                                  (withdraw.amount *
                                                    uplineFee.percentage) /
                                                    100 +
                                                    uplineFee.fixed,
                                                );
                                                break;
                                            }
                                            if (
                                              uplineFee.id === 1 &&
                                              userUpline.upline &&
                                              !userUpline.upline.isBlocked &&
                                              !userUpline.upline.isDeleted
                                            ) {
                                              await this.Balance.findOne({
                                                user: userUpline.upline.id,
                                              }).then(async (balanceUpline) => {
                                                let debDec = Math.min(
                                                  balanceUpline.debt ?? 0,
                                                  feeAmount,
                                                );
                                                let feeFinal =
                                                  feeAmount - debDec;

                                                if (feeFinal > 0) {
                                                  const commission =
                                                    await this.Commission.findOneAndUpdate(
                                                      {
                                                        isActive: true,
                                                        user: userUpline.upline
                                                          .id,
                                                      },
                                                      {
                                                        $inc: {
                                                          clientWd: feeFinal,
                                                          clientWdQty: 1,
                                                        },
                                                      },
                                                      { new: true },
                                                    );

                                                  await this.Commission.findOneAndUpdate(
                                                    {
                                                      isActive: true,
                                                      upline:
                                                        userUpline.upline.id,
                                                      downline: userUpline.id,
                                                    },
                                                    {
                                                      $inc: {
                                                        amountWd: feeFinal,
                                                        amountWdQty: 1,
                                                      },
                                                    },
                                                  );

                                                  await this.Balance.findByIdAndUpdate(
                                                    balanceUpline.id,
                                                    {
                                                      $inc: {
                                                        balance:
                                                          Number(feeFinal),
                                                      },
                                                    },
                                                  );

                                                  const newBalanceLog =
                                                    new this.BalanceLog({
                                                      name: userUpline.username,
                                                      balanceAmount:
                                                        balanceUpline.balance,
                                                      balanceCredit:
                                                        Number(feeFinal),
                                                      type: BalanceLogType.In,
                                                      balance: balanceUpline.id,
                                                      withdraw: withdraw.id,
                                                    });

                                                  await newBalanceLog.save();

                                                  const newUplineFee = {
                                                    id: 1,
                                                    commission: commission.id,
                                                    amount: feeFinal,
                                                  };

                                                  updateWithdraw.uplineFee.push(
                                                    newUplineFee,
                                                  );

                                                  feeUpline1 = feeFinal;
                                                }

                                                if (debDec > 0) {
                                                  await this.Balance.findByIdAndUpdate(
                                                    balanceUpline.id,
                                                    {
                                                      $inc: {
                                                        debt: -Number(debDec),
                                                      },
                                                    },
                                                  );

                                                  const newBalanceLog =
                                                    new this.BalanceLog({
                                                      name: `Paying debt from ${
                                                        userUpline.username
                                                      } with amount ${toCurrency(
                                                        debDec,
                                                      )}`,
                                                      balanceAmount:
                                                        balanceUpline.debt,
                                                      balanceCredit:
                                                        Number(debDec),
                                                      type: BalanceLogType.Pay,
                                                      balance: balanceUpline.id,
                                                      withdraw: withdraw.id,
                                                    });

                                                  await newBalanceLog.save();
                                                }
                                              });
                                            } else if (
                                              uplineFee.id === 2 &&
                                              userUpline.upline &&
                                              userUpline.upline.upline &&
                                              !userUpline.upline.upline
                                                .isBlocked &&
                                              !userUpline.upline.upline
                                                .isDeleted
                                            ) {
                                              await this.Balance.findOne({
                                                user: userUpline.upline.upline
                                                  .id,
                                              }).then(async (balanceUpline) => {
                                                let debDec = Math.min(
                                                  balanceUpline.debt ?? 0,
                                                  feeAmount,
                                                );
                                                let feeFinal =
                                                  feeAmount - debDec;

                                                if (feeFinal > 0) {
                                                  const commission =
                                                    await this.Commission.findOneAndUpdate(
                                                      {
                                                        isActive: true,
                                                        user: userUpline.upline
                                                          .upline.id,
                                                      },
                                                      {
                                                        $inc: {
                                                          partnerWd: feeFinal,
                                                          partnerWdQty: 1,
                                                        },
                                                      },
                                                      { new: true },
                                                    );

                                                  await this.Commission.findOneAndUpdate(
                                                    {
                                                      isActive: true,
                                                      upline:
                                                        userUpline.upline.upline
                                                          .id,
                                                      downline:
                                                        userUpline.upline.id,
                                                    },
                                                    {
                                                      $inc: {
                                                        amountWd: feeFinal,
                                                        amountWdQty: 1,
                                                      },
                                                    },
                                                  );

                                                  await this.Balance.findByIdAndUpdate(
                                                    balanceUpline.id,
                                                    {
                                                      $inc: {
                                                        balance:
                                                          Number(feeFinal),
                                                      },
                                                    },
                                                  );

                                                  const newBalanceLog =
                                                    new this.BalanceLog({
                                                      name: userUpline.upline
                                                        .username,
                                                      balanceAmount:
                                                        balanceUpline.balance,
                                                      balanceCredit:
                                                        Number(feeFinal),
                                                      type: BalanceLogType.In,
                                                      balance: balanceUpline.id,
                                                      withdraw: withdraw.id,
                                                    });

                                                  await newBalanceLog.save();

                                                  const newUplineFee = {
                                                    id: 2,
                                                    commission: commission.id,
                                                    amount: feeFinal,
                                                  };
                                                  updateWithdraw.uplineFee.push(
                                                    newUplineFee,
                                                  );

                                                  feeUpline2 = feeFinal;
                                                }

                                                if (debDec > 0) {
                                                  await this.Balance.findByIdAndUpdate(
                                                    balanceUpline.id,
                                                    {
                                                      $inc: {
                                                        debt: -Number(debDec),
                                                      },
                                                    },
                                                  );

                                                  const newBalanceLog =
                                                    new this.BalanceLog({
                                                      name: `Paying debt from ${
                                                        userUpline.upline
                                                          .username
                                                      } with amount ${toCurrency(
                                                        debDec,
                                                      )}`,
                                                      balanceAmount:
                                                        balanceUpline.debt,
                                                      balanceCredit:
                                                        Number(debDec),
                                                      type: BalanceLogType.Pay,
                                                      balance: balanceUpline.id,
                                                      withdraw: withdraw.id,
                                                    });

                                                  await newBalanceLog.save();
                                                }
                                              });
                                            } else if (
                                              uplineFee.id === 3 &&
                                              userUpline.upline &&
                                              userUpline.upline.upline &&
                                              userUpline.upline.upline.upline &&
                                              !userUpline.upline.upline.upline
                                                .isBlocked &&
                                              !userUpline.upline.upline.upline
                                                .isDeleted
                                            ) {
                                              await this.Balance.findOne({
                                                user: userUpline.upline.upline
                                                  .upline.id,
                                              }).then(async (balanceUpline) => {
                                                let debDec = Math.min(
                                                  balanceUpline.debt ?? 0,
                                                  feeAmount,
                                                );
                                                let feeFinal =
                                                  feeAmount - debDec;

                                                if (feeFinal > 0) {
                                                  const commission =
                                                    await this.Commission.findOneAndUpdate(
                                                      {
                                                        isActive: true,
                                                        user: userUpline.upline
                                                          .upline.upline.id,
                                                      },
                                                      {
                                                        $inc: {
                                                          partnerWd: feeFinal,
                                                          partnerWdQty: 1,
                                                        },
                                                      },
                                                      { new: true },
                                                    );

                                                  await this.Commission.findOneAndUpdate(
                                                    {
                                                      isActive: true,
                                                      upline:
                                                        userUpline.upline.upline
                                                          .upline.id,
                                                      downline:
                                                        userUpline.upline.upline
                                                          .id,
                                                    },
                                                    {
                                                      $inc: {
                                                        amountWd: feeFinal,
                                                        amountWdQty: 1,
                                                      },
                                                    },
                                                  );

                                                  await this.Balance.findByIdAndUpdate(
                                                    balanceUpline.id,
                                                    {
                                                      $inc: {
                                                        balance:
                                                          Number(feeFinal),
                                                      },
                                                    },
                                                  );

                                                  const newBalanceLog =
                                                    new this.BalanceLog({
                                                      name: userUpline.upline
                                                        .upline.username,
                                                      balanceAmount:
                                                        balanceUpline.balance,
                                                      balanceCredit:
                                                        Number(feeFinal),
                                                      type: BalanceLogType.In,
                                                      balance: balanceUpline.id,
                                                      withdraw: withdraw.id,
                                                    });

                                                  await newBalanceLog.save();

                                                  const newUplineFee = {
                                                    id: 3,
                                                    commission: commission.id,
                                                    amount: feeFinal,
                                                  };
                                                  updateWithdraw.uplineFee.push(
                                                    newUplineFee,
                                                  );

                                                  feeUpline3 = feeFinal;
                                                }

                                                if (debDec > 0) {
                                                  await this.Balance.findByIdAndUpdate(
                                                    balanceUpline.id,
                                                    {
                                                      $inc: {
                                                        debt: -Number(debDec),
                                                      },
                                                    },
                                                  );

                                                  const newBalanceLog =
                                                    new this.BalanceLog({
                                                      name: `Paying debt from ${
                                                        userUpline.upline.upline
                                                          .username
                                                      } with amount ${toCurrency(
                                                        debDec,
                                                      )}`,
                                                      balanceAmount:
                                                        balanceUpline.debt,
                                                      balanceCredit:
                                                        Number(debDec),
                                                      type: BalanceLogType.Pay,
                                                      balance: balanceUpline.id,
                                                      withdraw: withdraw.id,
                                                    });

                                                  await newBalanceLog.save();
                                                }
                                              });
                                            }
                                          }
                                        }
                                      },
                                    );
                                  });
                              }
                            },
                          );

                          rootCredit -= feeUpline1 + feeUpline2 + feeUpline3;

                          await this.Balance.findByIdAndUpdate(rootBalance.id, {
                            $inc: {
                              balance: Number(rootCredit),
                            },
                          });

                          const newBalanceLog = new this.BalanceLog({
                            name: `${client.clientName}'s Transfer`,
                            balanceAmount: rootBalance.balance,
                            balanceCredit: Number(rootCredit),
                            pgAmount: data.balance,
                            pgCredit: data.totalcost,
                            type: BalanceLogType.In,
                            balance: rootBalance.id,
                            withdraw: withdraw.id,
                          });

                          await newBalanceLog.save();

                          if (updateWithdraw.uplineFee.length) {
                            updateWithdraw.uplineFee.sort((a: any, b: any) => {
                              if (a.id < b.id) return -1;
                              if (a.id > b.id) return 1;
                              return 0;
                            });
                          }
                        }
                      });
                    } else if (withdraw.withdrawType === WithdrawType.Partner) {
                      await this.Commission.updateMany(
                        {
                          user: new Types.ObjectId(withdraw.user),
                          isActive: false,
                          isDisbursed: false,
                        },
                        { isDisbursed: true },
                      );
                    } else if (withdraw.withdrawType === WithdrawType.Cair) {
                      await this.Commission.updateMany(
                        {
                          user: userRoot.id,
                          isActive: false,
                          isDisbursed: false,
                        },
                        { isDisbursed: true },
                      );
                    }
                  } else if (data.status === PgType.Failed) {
                    updateWithdraw.status = WithdrawStatus.Failed;
                    updateWithdraw.error = data.response_desc;

                    if (withdraw.withdrawType === WithdrawType.Client) {
                      await this.Client.findOne({
                        user: withdraw.user,
                      }).then(async (client) => {
                        if (client && withdraw.accessFrom === AccessFrom.Api) {
                          const resObj: any = {
                            amount: withdraw.amount,
                            fee: withdraw.fee,
                            channelName: withdraw.bank.name,
                            accountNumber:
                              withdraw.bank.type === BankType.Cash
                                ? ''
                                : withdraw.accNumber,
                            name:
                              withdraw.bank.type === BankType.Cash
                                ? `Cash Transfer ${withdraw.bank.name}`
                                : withdraw.name,
                            ref1: withdraw.clientRef,
                            ref2: withdraw.withdrawId,
                            status: WithdrawStatus.Failed,
                            desc: `Failed transfer to ${withdraw.name}-${withdraw.accNumber}`,
                            error: data.response_desc,
                            note:
                              withdraw.bank.type === BankType.Cash
                                ? withdraw.note
                                : withdraw.remark,
                          };

                          const callbackKey = decrypt(
                            process.env.ENCRYPT_ALG,
                            hash('sha256', client.id).substring(0, 32),
                            hash(
                              'sha256',
                              withdraw.user + client.clientId,
                            ).substring(0, 16),
                            client.callbackKey,
                          );

                          const sig = encryptHmac(
                            'sha512',
                            callbackKey,
                            minifyJson(resObj).toLowerCase(),
                            'hex',
                          );

                          await this.Callback.findOne({
                            withdraw: withdraw.id,
                            user: withdraw.user,
                          }).then(async (withdrawCb) => {
                            var res: string, sent: boolean;
                            await sendCallback(client.callbackWd, resObj, sig)
                              .then((responseData) => {
                                res = responseData;
                                sent = true;
                              })
                              .catch((error) => {
                                res = error;
                                sent = false;
                              });

                            if (withdrawCb) {
                              withdrawCb.isSent = sent;
                              withdrawCb.payload = JSON.stringify(resObj);
                              withdrawCb.callbackUrl = client.callbackWd;
                              if (sent) {
                                withdrawCb.res = res;
                              } else {
                                withdrawCb.error = res;
                              }
                              withdrawCb.attempt = withdrawCb.attempt + 1;
                              withdrawCb.last = new Date();

                              await withdrawCb.save();
                            } else {
                              const newCallback = new this.Callback({
                                isSent: sent,
                                payload: JSON.stringify(resObj),
                                callbackUrl: client.callbackWd,
                                last: new Date(),
                                type: CallbackType.Withdraw,
                                withdraw: withdraw.id,
                                user: withdraw.user,
                              });

                              if (sent) {
                                newCallback.res = res;
                              } else {
                                newCallback.error = res;
                              }

                              await newCallback.save();
                            }
                          });
                        }
                      });
                    }

                    const updatedBalance = await this.Balance.findOneAndUpdate(
                      {
                        user: withdraw.user,
                      },
                      {
                        $inc: {
                          balance: Number(withdraw.amount + withdraw.fee),
                        },
                      },
                      { new: true },
                    );

                    const newBalanceLog = new this.BalanceLog({
                      name: `system's return disburse`,
                      balanceAmount:
                        updatedBalance.balance -
                        (withdraw.amount + withdraw.fee),
                      balanceCredit: Number(withdraw.amount + withdraw.fee),
                      type: BalanceLogType.In,
                      balance: updatedBalance.id,
                      withdraw: withdraw.id,
                    });

                    await newBalanceLog.save();
                  }

                  await this.Withdraw.findByIdAndUpdate(
                    withdraw.id,
                    updateWithdraw,
                  );

                  return res.status(200).send({
                    response: 'OK',
                  });
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Data 2 not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Data not found'),
              );
              return res.send(error);
            }
          });
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async bncStore(req: FastifyRequest, res: FastifyReply) {
    try {
      const { headers, body }: { headers: any; body: any } = req;
      const stringToSign = `POST:/api/v1/callback/bnc/r/store:${hash(
        'sha256',
        minifyJson(body),
      ).toLowerCase()}:${headers['x-timestamp']}`;
      if (
        verifyRsa(bncPubKey, stringToSign, headers['x-signature'].toString())
      ) {
        await this.Provider.findOne({ storeId: body.mId }).then(
          async (provider) => {
            if (provider) {
              provider.auditStatus = body.auditStatus;
              provider.callbackPayload = JSON.stringify(body);
              if (body.auditStatus === '3') {
                provider.rejectReason = body.rejectReason;
              }
              await provider.save();

              const success = response.initSuccess(200, true, {
                message: 'OK',
              });
              return res.send(success);
            } else {
              const success = response.initSuccess(200, false, {
                message: 'NOT FOUND',
              });
              return res.send(success);
            }
          },
        );
      } else {
        const success = response.initSuccess(200, false, {
          message: 'NOT OK',
        });
        return res.send(success);
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async bncToken(req: FastifyRequest, res: FastifyReply) {
    try {
      const { headers } = req;
      const timestamp = headers['x-timestamp'];
      const mId = headers['x-client-key'];
      const sig = encryptRsa(primePrivKey, `${mId}|${timestamp}`);

      return res.send({
        responseCode: '2007300',
        responseMessage: 'Successful',
        accessToken: sig,
        tokenType: 'Bearer',
        expiresIn: '900',
      });
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async bncQris(data: BncQrisDto, req: FastifyRequest, res: FastifyReply) {
    try {
      const { headers } = req;
      const timestamp = headers['x-timestamp'];
      const sig = encryptRsa(primePrivKey, '843644305877016576|' + timestamp);

      const success = response.initSuccess(200, true, {
        responseCode: '2007300',
        responseMessage: 'Successful',
        accessToken: sig,
        tokenType: 'Bearer',
        expiresIn: '900',
      });
      return res.send(success);
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async mpiVaBcaTransaction(
    data: MpiBcaDto,
    req: FastifyRequest,
    res: FastifyReply,
  ) {
    try {
      const { headers, body } = req;
      console.log(headers, body);
      await this.Transaction.findOne({
        orderId: data.idtrx,
        payment: data.vaNumber,
        amount: data.amount,
        status: TransactionStatusType.Pending,
      })
        .populate('method')
        .populate('user')
        .populate('product')
        .then(async (transaction: any) => {
          if (transaction) {
            await this.Fee.findOne({
              user: transaction.user.id,
              method: transaction.method.id,
              feeType: FeeType.Transaction,
            })
              .populate('provider')
              .then(async (fee: any) => {
                if (fee) {
                  var keyDec: string;
                  if (fee.provider.key === 'root') {
                    keyDec = decrypt(
                      process.env.ENCRYPT_ALG,
                      hash(
                        'sha256',
                        fee.provider.providerRoot._id.valueOf(),
                      ).substring(0, 32),
                      hash(
                        'sha256',
                        fee.provider.providerRoot.user.valueOf() +
                          fee.provider.providerRoot.code,
                      ).substring(0, 16),
                      fee.provider.providerRoot.key,
                    );
                  } else {
                    keyDec = decrypt(
                      process.env.ENCRYPT_ALG,
                      hash('sha256', fee.provider._id.valueOf()).substring(
                        0,
                        32,
                      ),
                      hash(
                        'sha256',
                        fee.provider.user.valueOf() + fee.provider.code,
                      ).substring(0, 16),
                      fee.provider.key,
                    );
                  }
                  const key = JSON.parse(keyDec);
                  const jwt = Buffer.from(
                    `${key.storeId}:${key.username}:${key.password}:${key.pin}`,
                    'utf-8',
                  ).toString('base64');
                  const stringToSign = `POST:/api/mpstore/bca-va/callback:${jwt}:${hash(
                    'sha256',
                    minifyJson(body),
                  ).toLowerCase()}:${headers.timestamp}`;
                  const sig = encryptHmac(
                    'sha512',
                    key.pin,
                    stringToSign,
                    'base64',
                  );

                  if (
                    sig === headers.signature &&
                    `Basic ${jwt}` === headers.authorization
                  ) {
                    await this.Balance.findOne({
                      user: transaction.user.id,
                    }).then(async (balance) => {
                      if (balance) {
                        if (data.detail1.responseCode === '00') {
                          await this.User.aggregate([
                            {
                              $match: {
                                role: Role.Root,
                              },
                            },
                            {
                              $lookup: {
                                from: 'balances',
                                localField: '_id',
                                foreignField: 'user',
                                as: 'balance',
                              },
                            },
                            { $unwind: '$balance' },
                          ]).then(async (rootData: any) => {
                            const updateTransaction: any = {
                              feeAdmin: data.admin,
                              paidRef: data.detail1.issuerRefNo,
                              paidTime: new Date(),
                              serialNumber: data.detail2.sn.replace(
                                new RegExp('mpi', 'ig'),
                                '',
                              ),
                              pgSettled: true,
                              uplineFee: [],
                            };
                            if (transaction.user.role === Role.Client) {
                              await this.Client.findOne({
                                user: transaction.user.id,
                              }).then(async (client) => {
                                const amountCredit =
                                  transaction.amount - transaction.fee;
                                var rootCredit = transaction.fee - data.admin;

                                if (
                                  transaction.transactionType ===
                                    TransactionType.Transaction ||
                                  (transaction.transactionType ===
                                    TransactionType.Topup &&
                                    transaction.accessFrom === AccessFrom.Api)
                                ) {
                                  const resObj: any = {
                                    amount: transaction.amount,
                                    fee: transaction.fee,
                                    expired: new Date(
                                      transaction.exp,
                                    ).getTime(),
                                    method: transaction.method.code,
                                    methodName: transaction.method.name,
                                    customerName: transaction.clientCustName,
                                    ref1: transaction.clientRef,
                                    ref2: transaction.transactionId,
                                    status: TransactionStatusType.Paid,
                                    desc: `Your ${
                                      transaction.method.type === MethodType.Va
                                        ? 'Virtual Account'
                                        : ''
                                    } ${
                                      transaction.transactionType ===
                                      TransactionType.Transaction
                                        ? 'Transaction'
                                        : 'Topup'
                                    } is Paid`,
                                    paidTime:
                                      updateTransaction.paidTime.getTime(),
                                    serialNumber:
                                      updateTransaction.serialNumber,
                                  };

                                  const callbackKey = decrypt(
                                    process.env.ENCRYPT_ALG,
                                    hash(
                                      'sha256',
                                      client.id.valueOf(),
                                    ).substring(0, 32),
                                    hash(
                                      'sha256',
                                      transaction.user.id.valueOf() +
                                        client.clientId,
                                    ).substring(0, 16),
                                    client.callbackKey,
                                  );

                                  const sig = encryptHmac(
                                    'sha512',
                                    callbackKey,
                                    minifyJson(resObj).toLowerCase(),
                                    'hex',
                                  );

                                  const cbQuery: any = {
                                    user: transaction.user.id,
                                  };

                                  if (
                                    transaction.transactionType ===
                                    TransactionType.Transaction
                                  ) {
                                    cbQuery.transaction = transaction.id;
                                  } else {
                                    cbQuery.topup = transaction.id;
                                  }
                                  await this.Callback.findOne(cbQuery).then(
                                    async (transactionCb) => {
                                      var res: string, sent: boolean;
                                      await sendCallback(
                                        transaction.transactionType ===
                                          TransactionType.Transaction
                                          ? client.callbackTrx
                                          : client.callbackTopup,
                                        resObj,
                                        sig,
                                      )
                                        .then((responseData) => {
                                          res = responseData;
                                          sent = true;
                                        })
                                        .catch((error) => {
                                          res = error;
                                          sent = false;
                                        });

                                      if (transactionCb) {
                                        transactionCb.isSent = sent;
                                        transactionCb.payload =
                                          JSON.stringify(resObj);
                                        transactionCb.callbackUrl =
                                          transaction.transactionType ===
                                          TransactionType.Transaction
                                            ? client.callbackTrx
                                            : client.callbackTopup;
                                        if (sent) {
                                          transactionCb.res = res;
                                        } else {
                                          transactionCb.error = res;
                                        }
                                        transactionCb.attempt =
                                          transactionCb.attempt + 1;
                                        transactionCb.last = new Date();

                                        await transactionCb.save();
                                      } else {
                                        const newCallback = new this.Callback({
                                          isSent: sent,
                                          payload: JSON.stringify(resObj),
                                          callbackUrl:
                                            transaction.transactionType ===
                                            TransactionType.Transaction
                                              ? client.callbackTrx
                                              : client.callbackTopup,
                                          last: new Date(),
                                          type:
                                            transaction.transactionType ===
                                            TransactionType.Transaction
                                              ? CallbackType.Transaction
                                              : CallbackType.Topup,
                                          user: transaction.user.id,
                                        });

                                        if (
                                          transaction.transactionType ===
                                          TransactionType.Transaction
                                        ) {
                                          newCallback.transaction =
                                            transaction.id;
                                        } else {
                                          newCallback.topup = transaction.id;
                                        }

                                        if (sent) {
                                          newCallback.res = res;
                                        } else {
                                          newCallback.error = res;
                                        }

                                        await newCallback.save();
                                      }
                                    },
                                  );
                                }

                                const debtCredit = Math.min(
                                  balance.debt ?? 0,
                                  amountCredit,
                                );
                                const balanceCredit = amountCredit - debtCredit;

                                if (debtCredit > 0) {
                                  await this.Balance.findByIdAndUpdate(
                                    balance.id,
                                    {
                                      $inc: {
                                        debt: -Number(debtCredit),
                                      },
                                    },
                                  );

                                  const newBalanceLog = new this.BalanceLog({
                                    name: `Paying debt from ${
                                      transaction.clientRef
                                    } ${
                                      transaction.transactionType ===
                                      TransactionType.Topup
                                        ? "'s Topup"
                                        : ''
                                    } with amount ${toCurrency(debtCredit)}`,
                                    balanceAmount: balance.debt,
                                    balanceCredit: Number(debtCredit),
                                    type: BalanceLogType.Pay,
                                    balance: balance.id,
                                    transaction: transaction.id,
                                  });

                                  await newBalanceLog.save();

                                  updateTransaction.debt = debtCredit;
                                }

                                const feeMethodRoot = await this.Fee.findOne({
                                  user: rootData[0]._id,
                                  method: transaction.method.id,
                                  feeType: FeeType.Transaction,
                                });

                                if (
                                  fee.delay === 0 &&
                                  feeMethodRoot.delay === 0
                                ) {
                                  if (
                                    transaction.transactionType ===
                                      TransactionType.Transaction ||
                                    (transaction.transactionType ===
                                      TransactionType.Topup &&
                                      transaction.accessFrom === AccessFrom.Api)
                                  ) {
                                    const resObj: any = {
                                      amount: transaction.amount,
                                      fee: transaction.fee,
                                      expired: new Date(
                                        transaction.exp,
                                      ).getTime(),
                                      method: transaction.method.code,
                                      methodName: transaction.method.name,
                                      customerName: transaction.clientCustName,
                                      ref1: transaction.clientRef,
                                      ref2: transaction.transactionId,
                                      status: TransactionStatusType.Settled,
                                      desc: `Your ${
                                        transaction.method.type ===
                                        MethodType.Va
                                          ? 'Virtual Account'
                                          : ''
                                      } ${
                                        transaction.transactionType ===
                                        TransactionType.Transaction
                                          ? 'Transaction'
                                          : 'Topup'
                                      } is Settled to your balance`,
                                      paidTime:
                                        updateTransaction.paidTime.getTime(),
                                      serialNumber:
                                        updateTransaction.serialNumber,
                                      settleTime: new Date().getTime(),
                                    };

                                    const callbackKey = decrypt(
                                      process.env.ENCRYPT_ALG,
                                      hash('sha256', client.id).substring(
                                        0,
                                        32,
                                      ),
                                      hash(
                                        'sha256',
                                        transaction.user.id + client.clientId,
                                      ).substring(0, 16),
                                      client.callbackKey,
                                    );

                                    const sig = encryptHmac(
                                      'sha512',
                                      callbackKey,
                                      minifyJson(resObj).toLowerCase(),
                                      'hex',
                                    );

                                    const cbQuery: any = {
                                      user: transaction.user.id,
                                    };

                                    if (
                                      transaction.transactionType ===
                                      TransactionType.Transaction
                                    ) {
                                      cbQuery.transaction = transaction.id;
                                    } else {
                                      cbQuery.topup = transaction.id;
                                    }
                                    await this.Callback.findOne(cbQuery).then(
                                      async (transactionCb) => {
                                        var res: string, sent: boolean;
                                        await sendCallback(
                                          transaction.transactionType ===
                                            TransactionType.Transaction
                                            ? client.callbackTrx
                                            : client.callbackTopup,
                                          resObj,
                                          sig,
                                        )
                                          .then((responseData) => {
                                            res = responseData;
                                            sent = true;
                                          })
                                          .catch((error) => {
                                            res = error;
                                            sent = false;
                                          });

                                        if (transactionCb) {
                                          transactionCb.isSent = sent;
                                          transactionCb.payload =
                                            JSON.stringify(resObj);
                                          transactionCb.callbackUrl =
                                            transaction.transactionType ===
                                            TransactionType.Transaction
                                              ? client.callbackTrx
                                              : client.callbackTopup;
                                          if (sent) {
                                            transactionCb.res = res;
                                          } else {
                                            transactionCb.error = res;
                                          }
                                          transactionCb.attempt =
                                            transactionCb.attempt + 1;
                                          transactionCb.last = new Date();

                                          await transactionCb.save();
                                        } else {
                                          const newCallback = new this.Callback(
                                            {
                                              isSent: sent,
                                              payload: JSON.stringify(resObj),
                                              callbackUrl:
                                                transaction.transactionType ===
                                                TransactionType.Transaction
                                                  ? client.callbackTrx
                                                  : client.callbackTopup,
                                              last: new Date(),
                                              type:
                                                transaction.transactionType ===
                                                TransactionType.Transaction
                                                  ? CallbackType.Transaction
                                                  : CallbackType.Topup,
                                              user: transaction.user.id,
                                            },
                                          );

                                          if (
                                            transaction.transactionType ===
                                            TransactionType.Transaction
                                          ) {
                                            newCallback.transaction =
                                              transaction.id;
                                          } else {
                                            newCallback.topup = transaction.id;
                                          }

                                          if (sent) {
                                            newCallback.res = res;
                                          } else {
                                            newCallback.error = res;
                                          }

                                          await newCallback.save();
                                        }
                                      },
                                    );
                                  }

                                  updateTransaction.status =
                                    TransactionStatusType.Settled;
                                  updateTransaction.clientSettled = true;
                                  const settleDate = new Date();
                                  updateTransaction.clientSettleDate =
                                    settleDate;

                                  if (balanceCredit > 0) {
                                    await this.Balance.findByIdAndUpdate(
                                      balance.id,
                                      {
                                        $inc: {
                                          balance: Number(balanceCredit),
                                        },
                                      },
                                    );

                                    const newBalanceLog = new this.BalanceLog({
                                      name: `${
                                        transaction.clientRef
                                          ? `${transaction.clientRef}'s `
                                          : ''
                                      }${
                                        transaction.transactionType ===
                                        TransactionType.Topup
                                          ? 'Topup'
                                          : 'Transaction'
                                      }`,
                                      balanceAmount: balance.balance,
                                      balanceCredit: Number(balanceCredit),
                                      type: BalanceLogType.In,
                                      balance: balance.id,
                                      transaction: transaction.id,
                                    });

                                    await newBalanceLog.save();
                                  }
                                } else {
                                  updateTransaction.status =
                                    TransactionStatusType.Paid;

                                  if (balanceCredit > 0) {
                                    await this.Balance.findByIdAndUpdate(
                                      balance.id,
                                      {
                                        $inc: {
                                          pending: Number(balanceCredit),
                                        },
                                      },
                                    );
                                    const settleDate = new Date();
                                    settleDate.setDate(
                                      settleDate.getDate() + fee.delay,
                                    );
                                    settleDate.setHours(4, 0, 0, 0);
                                    updateTransaction.clientSettleDate =
                                      settleDate;
                                  }
                                }

                                var feeUpline1: number = 0,
                                  feeUpline2: number = 0,
                                  feeUpline3: number = 0;
                                if (transaction.accessFrom === AccessFrom.Api) {
                                  if (fee.uplineFee && fee.uplineFee.length) {
                                    await this.User.findById(
                                      transaction.user.id,
                                    )
                                      .populate({
                                        path: 'upline',
                                        populate: {
                                          path: 'upline',
                                          populate: {
                                            path: 'upline',
                                          },
                                        },
                                      })
                                      .then(async (userUpline: any) => {
                                        await this.ValueType.find().then(
                                          async (valueType) => {
                                            for (const uplineFee of fee.uplineFee) {
                                              const typeFound = searchArray(
                                                valueType,
                                                null,
                                                null,
                                                'id',
                                                uplineFee.type,
                                              );
                                              if (typeFound.length) {
                                                let feeAmount: number;
                                                switch (typeFound[0].name) {
                                                  case VType.Percentage:
                                                    feeAmount = Math.floor(
                                                      (amountCredit *
                                                        uplineFee.percentage) /
                                                        100,
                                                    );
                                                    break;
                                                  case VType.Fixed:
                                                    feeAmount = uplineFee.fixed;
                                                    break;
                                                  default:
                                                    feeAmount = Math.floor(
                                                      (amountCredit *
                                                        uplineFee.percentage) /
                                                        100 +
                                                        uplineFee.fixed,
                                                    );
                                                    break;
                                                }
                                                if (
                                                  uplineFee.id === 1 &&
                                                  userUpline.upline &&
                                                  !userUpline.upline
                                                    .isBlocked &&
                                                  !userUpline.upline.isDeleted
                                                ) {
                                                  await this.Balance.findOne({
                                                    user: userUpline.upline.id,
                                                  }).then(
                                                    async (balanceUpline) => {
                                                      let debDec = Math.min(
                                                        balanceUpline.debt ?? 0,
                                                        feeAmount,
                                                      );
                                                      let feeFinal =
                                                        feeAmount - debDec;

                                                      if (feeFinal > 0) {
                                                        const commission =
                                                          await this.Commission.findOneAndUpdate(
                                                            {
                                                              isActive: true,
                                                              user: userUpline
                                                                .upline.id,
                                                            },
                                                            {
                                                              $inc: {
                                                                clientTrx:
                                                                  feeFinal,
                                                                clientTrxQty: 1,
                                                              },
                                                            },
                                                            { new: true },
                                                          );

                                                        await this.Commission.findOneAndUpdate(
                                                          {
                                                            isActive: true,
                                                            upline:
                                                              userUpline.upline
                                                                .id,
                                                            downline:
                                                              userUpline.id,
                                                          },
                                                          {
                                                            $inc: {
                                                              amountTrx:
                                                                feeFinal,
                                                              amountTrxQty: 1,
                                                            },
                                                          },
                                                        );

                                                        await this.Balance.findByIdAndUpdate(
                                                          balanceUpline.id,
                                                          {
                                                            $inc: {
                                                              balance:
                                                                Number(
                                                                  feeFinal,
                                                                ),
                                                            },
                                                          },
                                                        );

                                                        const newBalanceLog =
                                                          new this.BalanceLog({
                                                            name: userUpline.username,
                                                            balanceAmount:
                                                              balanceUpline.balance,
                                                            balanceCredit:
                                                              Number(feeFinal),
                                                            type: BalanceLogType.In,
                                                            balance:
                                                              balanceUpline.id,
                                                            transaction:
                                                              transaction.id,
                                                          });

                                                        await newBalanceLog.save();

                                                        const newUplineFee = {
                                                          id: 1,
                                                          commission:
                                                            commission.id,
                                                          amount: feeFinal,
                                                        };
                                                        updateTransaction.uplineFee.push(
                                                          newUplineFee,
                                                        );

                                                        feeUpline1 = feeFinal;
                                                      }

                                                      if (debDec > 0) {
                                                        await this.Balance.findByIdAndUpdate(
                                                          balanceUpline.id,
                                                          {
                                                            $inc: {
                                                              debt: -Number(
                                                                debDec,
                                                              ),
                                                            },
                                                          },
                                                        );

                                                        const newBalanceLog =
                                                          new this.BalanceLog({
                                                            name: `Paying debt from ${
                                                              userUpline.username
                                                            } with amount ${toCurrency(
                                                              debDec,
                                                            )}`,
                                                            balanceAmount:
                                                              balanceUpline.debt,
                                                            balanceCredit:
                                                              Number(debDec),
                                                            type: BalanceLogType.Pay,
                                                            balance:
                                                              balanceUpline.id,
                                                            transaction:
                                                              transaction.id,
                                                          });

                                                        await newBalanceLog.save();
                                                      }
                                                    },
                                                  );
                                                } else if (
                                                  uplineFee.id === 2 &&
                                                  userUpline.upline &&
                                                  userUpline.upline.upline &&
                                                  !userUpline.upline.upline
                                                    .isBlocked &&
                                                  !userUpline.upline.upline
                                                    .isDeleted
                                                ) {
                                                  await this.Balance.findOne({
                                                    user: userUpline.upline
                                                      .upline.id,
                                                  }).then(
                                                    async (balanceUpline) => {
                                                      let debDec = Math.min(
                                                        balanceUpline.debt ?? 0,
                                                        feeAmount,
                                                      );
                                                      let feeFinal =
                                                        feeAmount - debDec;

                                                      if (feeFinal > 0) {
                                                        const commission =
                                                          await this.Commission.findOneAndUpdate(
                                                            {
                                                              isActive: true,
                                                              user: userUpline
                                                                .upline.upline
                                                                .id,
                                                            },
                                                            {
                                                              $inc: {
                                                                partnerTrx:
                                                                  feeFinal,
                                                                partnerTrxQty: 1,
                                                              },
                                                            },
                                                            { new: true },
                                                          );

                                                        await this.Commission.findOneAndUpdate(
                                                          {
                                                            isActive: true,
                                                            upline:
                                                              userUpline.upline
                                                                .upline.id,
                                                            downline:
                                                              userUpline.upline
                                                                .id,
                                                          },
                                                          {
                                                            $inc: {
                                                              amountTrx:
                                                                feeFinal,
                                                              amountTrxQty: 1,
                                                            },
                                                          },
                                                        );

                                                        await this.Balance.findByIdAndUpdate(
                                                          balanceUpline.id,
                                                          {
                                                            $inc: {
                                                              balance:
                                                                Number(
                                                                  feeFinal,
                                                                ),
                                                            },
                                                          },
                                                        );

                                                        const newBalanceLog =
                                                          new this.BalanceLog({
                                                            name: userUpline
                                                              .upline.username,
                                                            balanceAmount:
                                                              balanceUpline.balance,
                                                            balanceCredit:
                                                              Number(feeFinal),
                                                            type: BalanceLogType.In,
                                                            balance:
                                                              balanceUpline.id,
                                                            transaction:
                                                              transaction.id,
                                                          });

                                                        await newBalanceLog.save();

                                                        const newUplineFee = {
                                                          id: 2,
                                                          commission:
                                                            commission.id,
                                                          amount: feeFinal,
                                                        };
                                                        updateTransaction.uplineFee.push(
                                                          newUplineFee,
                                                        );

                                                        feeUpline2 = feeFinal;
                                                      }

                                                      if (debDec > 0) {
                                                        await this.Balance.findByIdAndUpdate(
                                                          balanceUpline.id,
                                                          {
                                                            $inc: {
                                                              debt: -Number(
                                                                debDec,
                                                              ),
                                                            },
                                                          },
                                                        );

                                                        const newBalanceLog =
                                                          new this.BalanceLog({
                                                            name: `Paying debt from ${
                                                              userUpline.upline
                                                                .username
                                                            } with amount ${toCurrency(
                                                              debDec,
                                                            )}`,
                                                            balanceAmount:
                                                              balanceUpline.debt,
                                                            balanceCredit:
                                                              Number(debDec),
                                                            type: BalanceLogType.Pay,
                                                            balance:
                                                              balanceUpline.id,
                                                            transaction:
                                                              transaction.id,
                                                          });

                                                        await newBalanceLog.save();
                                                      }
                                                    },
                                                  );
                                                } else if (
                                                  uplineFee.id === 3 &&
                                                  userUpline.upline &&
                                                  userUpline.upline.upline &&
                                                  userUpline.upline.upline
                                                    .upline &&
                                                  !userUpline.upline.upline
                                                    .upline.isBlocked &&
                                                  !userUpline.upline.upline
                                                    .upline.isDeleted
                                                ) {
                                                  await this.Balance.findOne({
                                                    user: userUpline.upline
                                                      .upline.upline.id,
                                                  }).then(
                                                    async (balanceUpline) => {
                                                      let debDec = Math.min(
                                                        balanceUpline.debt ?? 0,
                                                        feeAmount,
                                                      );
                                                      let feeFinal =
                                                        feeAmount - debDec;

                                                      if (feeFinal > 0) {
                                                        const commission =
                                                          await this.Commission.findOneAndUpdate(
                                                            {
                                                              isActive: true,
                                                              user: userUpline
                                                                .upline.upline
                                                                .upline.id,
                                                            },
                                                            {
                                                              $inc: {
                                                                partnerTrx:
                                                                  feeFinal,
                                                                partnerTrxQty: 1,
                                                              },
                                                            },
                                                            { new: true },
                                                          );

                                                        await this.Commission.findOneAndUpdate(
                                                          {
                                                            isActive: true,
                                                            upline:
                                                              userUpline.upline
                                                                .upline.upline
                                                                .id,
                                                            downline:
                                                              userUpline.upline
                                                                .upline.id,
                                                          },
                                                          {
                                                            $inc: {
                                                              amountTrx:
                                                                feeFinal,
                                                              amountTrxQty: 1,
                                                            },
                                                          },
                                                        );

                                                        await this.Balance.findByIdAndUpdate(
                                                          balanceUpline.id,
                                                          {
                                                            $inc: {
                                                              balance:
                                                                Number(
                                                                  feeFinal,
                                                                ),
                                                            },
                                                          },
                                                        );

                                                        const newBalanceLog =
                                                          new this.BalanceLog({
                                                            name: userUpline
                                                              .upline.upline
                                                              .username,
                                                            balanceAmount:
                                                              balanceUpline.balance,
                                                            balanceCredit:
                                                              Number(feeFinal),
                                                            type: BalanceLogType.In,
                                                            balance:
                                                              balanceUpline.id,
                                                            transaction:
                                                              transaction.id,
                                                          });

                                                        await newBalanceLog.save();

                                                        const newUplineFee = {
                                                          id: 3,
                                                          commission:
                                                            commission.id,
                                                          amount: feeFinal,
                                                        };
                                                        updateTransaction.uplineFee.push(
                                                          newUplineFee,
                                                        );

                                                        feeUpline3 = feeFinal;
                                                      }

                                                      if (debDec > 0) {
                                                        await this.Balance.findByIdAndUpdate(
                                                          balanceUpline.id,
                                                          {
                                                            $inc: {
                                                              debt: -Number(
                                                                debDec,
                                                              ),
                                                            },
                                                          },
                                                        );

                                                        const newBalanceLog =
                                                          new this.BalanceLog({
                                                            name: `Paying debt from ${
                                                              userUpline.upline
                                                                .upline.username
                                                            } with amount ${toCurrency(
                                                              debDec,
                                                            )}`,
                                                            balanceAmount:
                                                              balanceUpline.debt,
                                                            balanceCredit:
                                                              Number(debDec),
                                                            type: BalanceLogType.Pay,
                                                            balance:
                                                              balanceUpline.id,
                                                            transaction:
                                                              transaction.id,
                                                          });

                                                        await newBalanceLog.save();
                                                      }
                                                    },
                                                  );
                                                }
                                              }
                                            }
                                          },
                                        );
                                      });
                                  }
                                }

                                rootCredit -=
                                  feeUpline1 + feeUpline2 + feeUpline3;

                                await this.Balance.findByIdAndUpdate(
                                  rootData[0].balance._id,
                                  {
                                    $inc: {
                                      balance: Number(rootCredit),
                                    },
                                  },
                                );

                                const newBalanceLog = new this.BalanceLog({
                                  name: `${client.clientName}'s ${
                                    transaction.transactionType ===
                                    TransactionType.Topup
                                      ? 'Topup'
                                      : 'Transaction'
                                  }`,
                                  balanceAmount: rootData[0].balance.balance,
                                  balanceCredit: Number(rootCredit),
                                  msg: data.detail2.msg,
                                  type: BalanceLogType.In,
                                  balance: rootData[0].balance._id,
                                  transaction: transaction.id,
                                });

                                await newBalanceLog.save();

                                if (updateTransaction.uplineFee.length) {
                                  updateTransaction.uplineFee.sort(
                                    (a: any, b: any) => {
                                      if (a.id < b.id) return -1;
                                      if (a.id > b.id) return 1;
                                      return 0;
                                    },
                                  );
                                }

                                await this.Transaction.findByIdAndUpdate(
                                  transaction.id,
                                  updateTransaction,
                                );
                              });
                            } else {
                              if (transaction.product) {
                                const payload = {
                                  username: process.env.DF_USERNAME,
                                  buyer_sku_code: transaction.product.code,
                                  customer_no: transaction.form,
                                  ref_id: transaction.transactionId,
                                  sign: hash(
                                    'md5',
                                    `${process.env.DF_USERNAME}${process.env.DF_PROD_KEY}${transaction.transactionId}`,
                                  ),
                                };
                                const header = {
                                  'Content-Type': CT_APP_JSON,
                                };
                                await fetch(
                                  process.env.DF_BASE_URL + 'transaction',
                                  {
                                    method: 'POST',
                                    body: JSON.stringify(payload),
                                    headers: header,
                                  },
                                ).then(async (responseFetch) => {
                                  const responseData =
                                    await responseFetch.json();

                                  if (
                                    responseData.data.status === 'Sukses' &&
                                    responseData.data.rc === '00'
                                  ) {
                                    updateTransaction.status =
                                      TransactionStatusType.Paid;
                                    updateTransaction.dfTrxId =
                                      responseData.data.trx_id;
                                    updateTransaction.dfSn =
                                      responseData.data.sn;
                                  } else if (
                                    responseData.data.status === 'Pending'
                                  ) {
                                    updateTransaction.status =
                                      TransactionStatusType.Processing;
                                  } else {
                                    if (
                                      responseData.data.rc === '01' ||
                                      responseData.data.rc === '44' ||
                                      responseData.data.rc === '53' ||
                                      responseData.data.rc === '55' ||
                                      responseData.data.rc === '56' ||
                                      responseData.data.rc === '58' ||
                                      responseData.data.rc === '62' ||
                                      responseData.data.rc === '63' ||
                                      responseData.data.rc === '64' ||
                                      responseData.data.rc === '65' ||
                                      responseData.data.rc === '66' ||
                                      responseData.data.rc === '67' ||
                                      responseData.data.rc === '68' ||
                                      responseData.data.rc === '70' ||
                                      responseData.data.rc === '71' ||
                                      responseData.data.rc === '80' ||
                                      responseData.data.rc === '99'
                                    ) {
                                      updateTransaction.status =
                                        TransactionStatusType.Assist;
                                    } else {
                                      updateTransaction.status =
                                        TransactionStatusType.Failed;

                                      await this.Balance.findByIdAndUpdate(
                                        balance.id,
                                        {
                                          $inc: {
                                            balance: Number(
                                              transaction.amount -
                                                transaction.fee,
                                            ),
                                          },
                                        },
                                      );
                                      const newBalanceLog = new this.BalanceLog(
                                        {
                                          name:
                                            'Refund failed transaction: ' +
                                            transaction.product.name,
                                          balanceAmount: balance.balance,
                                          balanceCredit: Number(
                                            transaction.amount,
                                          ),
                                          type: BalanceLogType.Refund,
                                          balance: balance.id,
                                          transaction: transaction.id,
                                        },
                                      );

                                      await newBalanceLog.save();

                                      const newBalanceLog2 =
                                        new this.BalanceLog({
                                          name:
                                            'Fee: ' + transaction.product.name,
                                          balanceAmount:
                                            balance.balance +
                                            transaction.amount,
                                          balanceCredit: Number(
                                            transaction.fee,
                                          ),
                                          type: BalanceLogType.Out,
                                          balance: balance.id,
                                          transaction: transaction.id,
                                        });

                                      await newBalanceLog2.save();

                                      if (transaction.usedBalance > 0) {
                                        await this.Balance.findByIdAndUpdate(
                                          balance.id,
                                          {
                                            $inc: {
                                              balance: Number(
                                                transaction.usedBalance,
                                              ),
                                            },
                                          },
                                        );

                                        const newBalanceLog3 =
                                          new this.BalanceLog({
                                            name:
                                              'Refund used balance: ' +
                                              transaction.product.name,
                                            balanceAmount: balance.balance,
                                            balanceCredit: Number(
                                              transaction.usedBalance,
                                            ),
                                            type: BalanceLogType.Refund,
                                            balance: balance.id,
                                            transaction: transaction.id,
                                          });

                                        await newBalanceLog3.save();
                                      }
                                    }
                                    updateTransaction.error =
                                      responseData.data.message;
                                  }

                                  const rootCredit =
                                    transaction.fee - transaction.feeAdmin;

                                  await this.Balance.findByIdAndUpdate(
                                    rootData[0].balance._id,
                                    {
                                      $inc: {
                                        balance: Number(rootCredit),
                                      },
                                    },
                                  );
                                  const newBalanceLog = new this.BalanceLog({
                                    name: transaction.user.email,
                                    balanceAmount: rootData[0].balance.balance,
                                    balanceCredit: Number(rootCredit),
                                    msg: data.detail2.msg,
                                    dfAmount:
                                      responseData.data.buyer_last_saldo,
                                    type: BalanceLogType.In,
                                    balance: rootData[0].balance._id,
                                    transaction: transaction.id,
                                  });

                                  await newBalanceLog.save();

                                  await this.Transaction.findByIdAndUpdate(
                                    transaction.id,
                                    updateTransaction,
                                  );
                                });
                              } else {
                                const error = response.initError(
                                  404,
                                  false,
                                  new ErrorMessage('5 not found!'),
                                );
                                return res.send(error);
                              }
                            }
                          });
                        } else {
                          const updateTransaction: any = {
                            status: TransactionStatusType.Failed,
                          };
                          await this.Transaction.findByIdAndUpdate(
                            transaction.id,
                            updateTransaction,
                          );
                          if (transaction.user.role === Role.Client) {
                            await this.Client.findOne({
                              user: transaction.user.id,
                            }).then(async (client) => {
                              if (client) {
                                if (
                                  transaction.transactionType ===
                                    TransactionType.Transaction ||
                                  (transaction.transactionType ===
                                    TransactionType.Topup &&
                                    transaction.accessFrom === AccessFrom.Api)
                                ) {
                                  const resObj: any = {
                                    amount: transaction.amount,
                                    fee: transaction.fee,
                                    expired: new Date(
                                      transaction.exp,
                                    ).getTime(),
                                    method: transaction.method.code,
                                    methodName: transaction.method.name,
                                    customerName: transaction.clientCustName,
                                    ref1: transaction.clientRef,
                                    ref2: transaction.transactionId,
                                    status: TransactionStatusType.Failed,
                                    desc: `Your ${
                                      transaction.method.type === MethodType.Va
                                        ? 'Virtual Account'
                                        : ''
                                    } ${
                                      transaction.transactionType ===
                                      TransactionType.Transaction
                                        ? 'Transaction'
                                        : 'Topup'
                                    } is Failed`,
                                  };

                                  const callbackKey = decrypt(
                                    process.env.ENCRYPT_ALG,
                                    hash('sha256', client.id).substring(0, 32),
                                    hash(
                                      'sha256',
                                      transaction.user.id + client.clientId,
                                    ).substring(0, 16),
                                    client.callbackKey,
                                  );

                                  const sig = encryptHmac(
                                    'sha512',
                                    callbackKey,
                                    minifyJson(resObj).toLowerCase(),
                                    'hex',
                                  );

                                  const cbQuery: any = {
                                    user: transaction.user.id,
                                  };

                                  if (
                                    transaction.transactionType ===
                                    TransactionType.Transaction
                                  ) {
                                    cbQuery.transaction = transaction.id;
                                  } else {
                                    cbQuery.topup = transaction.id;
                                  }
                                  await this.Callback.findOne(cbQuery).then(
                                    async (transactionCb) => {
                                      var res: string, sent: boolean;
                                      await sendCallback(
                                        transaction.transactionType ===
                                          TransactionType.Transaction
                                          ? client.callbackTrx
                                          : client.callbackTopup,
                                        resObj,
                                        sig,
                                      )
                                        .then((responseData) => {
                                          res = responseData;
                                          sent = true;
                                        })
                                        .catch((error) => {
                                          res = error;
                                          sent = false;
                                        });

                                      if (transactionCb) {
                                        transactionCb.isSent = sent;
                                        transactionCb.payload =
                                          JSON.stringify(resObj);
                                        transactionCb.callbackUrl =
                                          transaction.transactionType ===
                                          TransactionType.Transaction
                                            ? client.callbackTrx
                                            : client.callbackTopup;
                                        if (sent) {
                                          transactionCb.res = res;
                                        } else {
                                          transactionCb.error = res;
                                        }
                                        transactionCb.attempt =
                                          transactionCb.attempt + 1;
                                        transactionCb.last = new Date();

                                        await transactionCb.save();
                                      } else {
                                        const newCallback = new this.Callback({
                                          isSent: sent,
                                          payload: JSON.stringify(resObj),
                                          callbackUrl:
                                            transaction.transactionType ===
                                            TransactionType.Transaction
                                              ? client.callbackTrx
                                              : client.callbackTopup,
                                          last: new Date(),
                                          type:
                                            transaction.transactionType ===
                                            TransactionType.Transaction
                                              ? CallbackType.Transaction
                                              : CallbackType.Topup,
                                          user: transaction.user.id,
                                        });

                                        if (
                                          transaction.transactionType ===
                                          TransactionType.Transaction
                                        ) {
                                          newCallback.transaction =
                                            transaction.id;
                                        } else {
                                          newCallback.topup = transaction.id;
                                        }

                                        if (sent) {
                                          newCallback.res = res;
                                        } else {
                                          newCallback.error = res;
                                        }

                                        await newCallback.save();
                                      }
                                    },
                                  );
                                }
                              } else {
                                const error = response.initError(
                                  404,
                                  false,
                                  new ErrorMessage('6 not found'),
                                );
                                return res.send(error);
                              }
                            });
                          } else if (transaction.usedBalance > 0) {
                            await this.Balance.findByIdAndUpdate(balance.id, {
                              $inc: {
                                balance: Number(transaction.usedBalance),
                              },
                            });

                            const newBalanceLog3 = new this.BalanceLog({
                              name: 'Refund ' + transaction.product.name,
                              balanceAmount: balance.balance,
                              balanceCredit: Number(transaction.usedBalance),
                              type: BalanceLogType.Refund,
                              balance: balance.id,
                              transaction: transaction.id,
                            });

                            await newBalanceLog3.save();
                          }
                        }
                        return res.status(200).send({
                          response: 'OK',
                        });
                      } else {
                        const error = response.initError(
                          404,
                          false,
                          new ErrorMessage('2 not found'),
                        );
                        return res.send(error);
                      }
                    });
                  } else {
                    const error = response.initError(
                      404,
                      false,
                      new ErrorMessage('Signature invalid'),
                    );
                    return res.send(error);
                  }
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('2 not found'),
                  );
                  return res.send(error);
                }
              });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Transaction not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async dfTransaction(
    data: DigiflazzDto,
    req: FastifyRequest,
    res: FastifyReply,
  ) {
    try {
      const signature = encryptHmac(
        'sha1',
        process.env.DF_HOOK_SECRET,
        minifyJson(data),
        'hex',
      );
      if (
        signature ===
          req.headers['x-hub-signature'].toString().replace('sha1=', '') &&
        req.headers['user-agent'] === 'Digiflazz-Hookshot' &&
        req.headers['x-digiflazz-event'] === 'update'
      ) {
        await this.Transaction.findOne({
          transactionId: data.data.ref_id,
        })
          .populate('method')
          .populate('user')
          .populate('product')
          .then(async (transaction: any) => {
            if (
              transaction &&
              transaction.product.code.toLowerCase() ===
                data.data.buyer_sku_code.toLowerCase() &&
              transaction.form.toLowerCase() ===
                data.data.customer_no.toLowerCase()
            ) {
              await this.Balance.findOne({
                user: transaction.user.id,
              }).then(async (balance) => {
                if (balance) {
                  const updateTransaction: any = {};
                  if (data.data.status === 'Sukses' && data.data.rc === '00') {
                    updateTransaction.status = TransactionStatusType.Paid;
                    updateTransaction.dfTrxId = data.data.trx_id;
                    updateTransaction.dfSn = data.data.sn;
                  } else if (data.data.status === 'Pending') {
                    updateTransaction.status = TransactionStatusType.Processing;
                  } else {
                    if (
                      data.data.rc === '01' ||
                      data.data.rc === '44' ||
                      data.data.rc === '53' ||
                      data.data.rc === '55' ||
                      data.data.rc === '56' ||
                      data.data.rc === '58' ||
                      data.data.rc === '62' ||
                      data.data.rc === '63' ||
                      data.data.rc === '64' ||
                      data.data.rc === '65' ||
                      data.data.rc === '66' ||
                      data.data.rc === '67' ||
                      data.data.rc === '68' ||
                      data.data.rc === '70' ||
                      data.data.rc === '71' ||
                      data.data.rc === '80' ||
                      data.data.rc === '99'
                    ) {
                      updateTransaction.status = TransactionStatusType.Assist;
                    } else if (
                      transaction.status !== TransactionStatusType.Failed
                    ) {
                      updateTransaction.status = TransactionStatusType.Failed;

                      await this.Balance.findByIdAndUpdate(balance.id, {
                        $inc: {
                          balance: Number(transaction.amount - transaction.fee),
                        },
                      });
                      const newBalanceLog = new this.BalanceLog({
                        name: 'Refund ' + transaction.product.name,
                        balanceAmount: balance.balance,
                        balanceCredit: Number(transaction.amount),
                        type: BalanceLogType.Refund,
                        balance: balance.id,
                        transaction: transaction.id,
                      });

                      await newBalanceLog.save();

                      if (transaction.fee > 0) {
                        const newBalanceLog2 = new this.BalanceLog({
                          name: 'Fee ' + transaction.product.name,
                          balanceAmount: balance.balance + transaction.amount,
                          balanceCredit: Number(transaction.fee),
                          type: BalanceLogType.Out,
                          balance: balance.id,
                          transaction: transaction.id,
                        });

                        await newBalanceLog2.save();
                      }

                      if (transaction.usedBalance > 0) {
                        await this.Balance.findByIdAndUpdate(balance.id, {
                          $inc: {
                            balance: Number(transaction.usedBalance),
                          },
                        });

                        const newBalanceLog3 = new this.BalanceLog({
                          name: 'Refund ' + transaction.product.name,
                          balanceAmount: balance.balance,
                          balanceCredit: Number(transaction.usedBalance),
                          type: BalanceLogType.Refund,
                          balance: balance.id,
                          transaction: transaction.id,
                        });

                        await newBalanceLog3.save();
                      }
                    }
                    updateTransaction.error = data.data.message;
                  }

                  await this.Transaction.findByIdAndUpdate(
                    transaction.id,
                    updateTransaction,
                  );
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('1 not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Transaction not found'),
              );
              return res.send(error);
            }
          });
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }
}
