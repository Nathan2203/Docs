import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';
import { CallbackType } from 'src/common/config/enum';

export type DevCallbackDocument = HydratedDocument<DevCallback>;

@Schema({ timestamps: true })
export class DevCallback {
  @Prop({ default: false })
  isSent: boolean;

  @Prop()
  payload: string;

  @Prop()
  callbackUrl: string;

  @Prop()
  error: string;

  @Prop()
  res: string;

  @Prop({ default: 1 })
  attempt: number;

  @Prop({ type: Date })
  last: Date;

  @Prop({ enum: CallbackType })
  type: CallbackType;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Transaction' })
  transaction: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Transaction' })
  topup: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Withdraw' })
  withdraw: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;
}

export const DevCallbackSchema = SchemaFactory.createForClass(DevCallback);
