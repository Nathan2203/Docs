import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';

import { CallbackService } from './callback.service';
import { CallbackController } from './callback.controller';

import {
  Transaction,
  TransactionSchema,
} from '../user/entities/transaction.entity';
import { User, UserSchema } from '../user/entities/user.entity';
import { Balance, BalanceSchema } from '../user/entities/balance.entity';
import {
  BalanceLog,
  BalanceLogSchema,
} from '../user/entities/balance-log.entity';
import { Client, ClientSchema } from '../open/entities/client.entity';
import { Fee, FeeSchema } from '../admin/entities/fee.entity';
import {
  Commission,
  CommissionSchema,
} from '../partner/entities/commission.entity';
import {
  ValueType,
  ValueTypeSchema,
} from '../admin/entities/value-type.entity';
import { Withdraw, WithdrawSchema } from '../user/entities/withdraw.entity';
import { Callback, CallbackSchema } from './entities/callback.entity';
import { Provider, ProviderSchema } from '../admin/entities/provider.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Transaction.name, schema: TransactionSchema },
      { name: Withdraw.name, schema: WithdrawSchema },
      { name: Balance.name, schema: BalanceSchema },
      { name: BalanceLog.name, schema: BalanceLogSchema },
      { name: Client.name, schema: ClientSchema },
      { name: Fee.name, schema: FeeSchema },
      { name: Commission.name, schema: CommissionSchema },
      { name: ValueType.name, schema: ValueTypeSchema },
      { name: Callback.name, schema: CallbackSchema },
      { name: Provider.name, schema: ProviderSchema },
    ]),
  ],
  controllers: [CallbackController],
  providers: [CallbackService],
})
export class CallbackModule {}
