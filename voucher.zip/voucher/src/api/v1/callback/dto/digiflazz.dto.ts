export class DigiflazzDto {
  data: {
    trx_id: string;
    ref_id: string;
    customer_no: string;
    buyer_sku_code: string;
    message: string;
    status: string;
    rc: string;
    buyer_last_saldo: number;
    sn: string;
    price: number;
  };
}
