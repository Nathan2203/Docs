export class LinkquWdDto {
  username: string;

  bankcode: string;

  transaction_time: string;

  accountnumber: string;

  amount: number;

  accountname: string;

  additionalfee: number;

  status: string;

  response_desc: string;

  partner_reff: number;

  partner_reff2: number;

  payment_reff: number;

  totalcost: number;

  balance: number;

  serialnumber: string;

  note: string;
}
