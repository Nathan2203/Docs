export class LinkquTDto {
  username: string;

  va_code: string;

  transaction_time: string;

  qris_id: string;

  va_number: string;

  amount: number;

  customer_name: string;

  additionalfee: number;

  status: string;

  partner_reff: number;

  payment_reff: number;

  credit_balance: number;

  balance: number;

  serialnumber: string;

  type: string;
}
