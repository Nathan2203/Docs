export class MpiBcaDto {
  timestamp: string;
  idtrx: string;
  vaNumber: string;
  amount: number;
  admin: number;
  total: number;
  detail1: {
    issuerRefNo: string;
    responseCode: string;
  };
  detail2: {
    sn: string;
    msg: string;
  };
}
