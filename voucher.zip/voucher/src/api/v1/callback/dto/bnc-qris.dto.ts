export class BncQrisDto {
  additionalInfo: {
    bankCode: string;
    bankName: string;
    rRN: string;
  };
  amount: {
    value: string;
  };
  customerNumber: string;
  latestTransactionStatus: string;
  originalPartnerReferenceNo: string;
  originalReferenceNo: string;
  originalServiceCode: string;
}
