import { Controller, Post, Body, Res, Req } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { FastifyReply, FastifyRequest } from 'fastify';

import { CallbackService } from './callback.service';

import { LinkquTDto } from './dto/linkqu-t.dto';
import { DigiflazzDto } from './dto/digiflazz.dto';
import { LinkquWdDto } from './dto/linkqu-wd.dto';
import { BncQrisDto } from './dto/bnc-qris.dto';
import { MpiBcaDto } from './dto/mpi-bca.dto';
import { SkipThrottle } from '@nestjs/throttler';

@ApiTags('Callback')
@Controller({ path: 'callback', version: '1' })
@SkipThrottle()
export class CallbackController {
  constructor(private readonly callbackService: CallbackService) {}

  @Post('/linkqu/t')
  linkquTransaction(
    @Body() data: LinkquTDto,
    @Req() req: FastifyRequest,
    @Res() res: FastifyReply,
  ) {
    return this.callbackService.linkquTransaction(data, req, res);
  }

  @Post('/linkqu/wd')
  linkquWithdraw(
    @Body() data: LinkquWdDto,
    @Req() req: FastifyRequest,
    @Res() res: FastifyReply,
  ) {
    return this.callbackService.linkquWd(data, req, res);
  }

  @Post('/bnc/r/store')
  BncStore(@Req() req: FastifyRequest, @Res() res: FastifyReply) {
    return this.callbackService.bncStore(req, res);
  }

  @Post('/bnc/token')
  BncToken(@Req() req: FastifyRequest, @Res() res: FastifyReply) {
    return this.callbackService.bncToken(req, res);
  }

  @Post('/bnc/qris')
  BncQris(
    @Body() data: BncQrisDto,
    @Req() req: FastifyRequest,
    @Res() res: FastifyReply,
  ) {
    return this.callbackService.bncQris(data, req, res);
  }

  @Post('/mpi')
  mpiVaBcaTransaction(
    @Body() data: MpiBcaDto,
    @Req() req: FastifyRequest,
    @Res() res: FastifyReply,
  ) {
    return this.callbackService.mpiVaBcaTransaction(data, req, res);
  }

  @Post('/df')
  dfTransaction(
    @Body() data: DigiflazzDto,
    @Req() req: FastifyRequest,
    @Res() res: FastifyReply,
  ) {
    return this.callbackService.dfTransaction(data, req, res);
  }
}
