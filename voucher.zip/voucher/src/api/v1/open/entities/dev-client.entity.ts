import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';

export type DevClientDocument = HydratedDocument<DevClient>;

@Schema({ timestamps: true })
export class DevClient {
  @Prop()
  clientName: string;

  @Prop()
  clientId: string;

  @Prop()
  clientSecret: string;

  @Prop()
  signatureKey: string;

  @Prop()
  callbackTrx: string;

  @Prop()
  callbackWd: string;

  @Prop()
  callbackTopup: string;

  @Prop()
  callbackKey: string;

  @Prop()
  limit: number;

  @Prop()
  ip: string;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;
}

export const DevClientSchema = SchemaFactory.createForClass(DevClient);
