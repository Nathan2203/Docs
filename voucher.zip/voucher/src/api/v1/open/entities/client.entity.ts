import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';

export type ClientDocument = HydratedDocument<Client>;

@Schema({ timestamps: true })
export class Client {
  @Prop()
  clientName: string;

  @Prop()
  clientId: string;

  @Prop()
  clientSecret: string;

  @Prop()
  signatureKey: string;

  @Prop()
  callbackTrx: string;

  @Prop()
  callbackWd: string;

  @Prop()
  callbackTopup: string;

  @Prop()
  callbackKey: string;

  @Prop()
  limit: number;

  @Prop()
  ip: string;

  @Prop({ default: 'root' })
  paymentClientName: string;

  @Prop({ default: 'root' })
  paymentCustName: string;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;
}

export const ClientSchema = SchemaFactory.createForClass(Client);
