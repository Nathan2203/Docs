import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';
import { TransactionStatusType, TransactionType } from 'src/common/config/enum';

export type DevTransactionDocument = HydratedDocument<DevTransaction>;

@Schema({ timestamps: true })
export class DevTransaction {
  @Prop()
  transactionId: string;

  @Prop()
  refId: string;

  @Prop()
  amount: number;

  @Prop()
  fee: number;

  @Prop()
  feeAdmin: number;

  @Prop()
  phone: string;

  @Prop()
  payment: string;

  @Prop()
  url: string;

  @Prop({ type: Date })
  exp: Date;

  @Prop({ enum: TransactionType, default: TransactionType.Transaction })
  transactionType: string;

  @Prop({ enum: TransactionStatusType, default: TransactionStatusType.Pending })
  status: string;

  @Prop({ default: false })
  pgSettled: boolean;

  @Prop()
  paidRef: string;

  @Prop({ type: Date })
  paidTime: Date;

  @Prop()
  clientRef: string;

  @Prop()
  clientCustName: string;

  @Prop({ default: false })
  clientSettled: boolean;

  @Prop()
  clientSettleDate: Date;

  @Prop({ default: false })
  callbackSent: boolean;

  @Prop()
  errorCallback: string;

  @Prop()
  resCallback: string;

  @Prop()
  ip: string;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Method' })
  method: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;
}

export const DevTransactionSchema =
  SchemaFactory.createForClass(DevTransaction);
