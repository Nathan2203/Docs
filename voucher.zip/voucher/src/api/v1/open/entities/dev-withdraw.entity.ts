import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';
import {
  AccessFrom,
  WithdrawProcess,
  WithdrawStatus,
  WithdrawType,
} from 'src/common/config/enum';

export type DevWithdrawDocument = HydratedDocument<DevWithdraw>;

@Schema({ timestamps: true })
export class DevWithdraw {
  @Prop()
  withdrawId: string;

  @Prop()
  orderId: string;

  @Prop()
  amount: number;

  @Prop()
  fee: number;

  @Prop()
  feeAdmin: number;

  @Prop()
  name: string;

  @Prop()
  accNumber: string;

  @Prop()
  email: string;

  @Prop()
  phone: string;

  @Prop()
  remark: string;

  @Prop({ default: 'dev' })
  inquiryReff: string;

  @Prop({ type: Date })
  exp: Date;

  @Prop({ enum: WithdrawProcess, default: WithdrawProcess.Inquiry })
  process: string;

  @Prop({ enum: WithdrawStatus })
  status: string;

  @Prop({ enum: WithdrawType, default: WithdrawType.Client })
  withdrawType: string;

  @Prop({ enum: AccessFrom })
  accessFrom: string;

  @Prop()
  clientRef: string;

  @Prop({ default: false })
  callbackSent: boolean;

  @Prop()
  errorCallback: string;

  @Prop()
  resCallback: string;

  @Prop()
  error: string;

  @Prop()
  note: string;

  @Prop({ type: Date })
  processedDate: Date;

  @Prop({ type: Date })
  paidDate: Date;

  @Prop()
  serialNumber: string;

  @Prop()
  paidReff: string;

  @Prop()
  ip: string;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  inquiryBy: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  processedBy: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Bank' })
  bank: Types.ObjectId;
}

export const DevWithdrawSchema = SchemaFactory.createForClass(DevWithdraw);
