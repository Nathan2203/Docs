import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';

export type DevBalanceDocument = HydratedDocument<DevBalance>;

@Schema({ timestamps: true })
export class DevBalance {
  @Prop({ default: 0 })
  balance: number;

  @Prop({ default: 0 })
  pending: number;

  @Prop({ default: 0 })
  freeze: number;

  @Prop({ default: 0 })
  debt: number;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;
}

export const DevBalanceSchema = SchemaFactory.createForClass(DevBalance);
