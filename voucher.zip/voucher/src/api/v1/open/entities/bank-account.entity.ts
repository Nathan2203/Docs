import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';

export type BankAccountDocument = HydratedDocument<BankAccount>;

@Schema({ timestamps: true })
export class BankAccount {
  @Prop()
  name: string;

  @Prop()
  account: string;

  @Prop({ default: false })
  isDeleted: boolean;

  @Prop()
  ip: string;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Bank' })
  bank: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;
}

export const BankAccountSchema = SchemaFactory.createForClass(BankAccount);
