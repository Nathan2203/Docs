import { Injectable } from '@nestjs/common';
import { FastifyReply, FastifyRequest } from 'fastify';
import fetch from 'node-fetch';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';

import { FastifyOpenRequest } from 'src/common/interface/fastify-open.interface';
import {
  ClientResponse,
  FeeType,
  MethodType,
  PgType,
  TransactionStatusType,
  ValueType,
  BankType,
  WithdrawType,
  AccessFrom,
  WithdrawStatus,
  WithdrawProcess,
  BalanceLogType,
  MethodApiType,
  TransactionType,
  MethodApi2Type,
  ProviderCodeType,
} from 'src/common/config/enum';
import { hash } from 'src/common/helper/hash';
import { minifyJson } from 'src/common/helper/minifyJson';
import { encryptHmac } from 'src/common/helper/encryptKey';
import { toCurrency } from 'src/common/helper/cast.helper';
import { generateRandomNumber } from 'src/common/helper/generateRandomNumber';
import {
  API_HOSTNAME,
  CT_APP_JSON,
  EMAIL_NOT_PROVIDED,
  HOSTNAME,
} from 'src/common/config/constants';

import { GeneratePaymentDto } from './dto/generate-payment.dto';
import { TransferInquiryDto } from './dto/transfer-inquiry.dto';
import { TransferPaymentDto } from './dto/transfer-payment.dto';

import { Method, MethodDocument } from '../public/entities/method.entity';
import {
  Transaction,
  TransactionDocument,
} from '../user/entities/transaction.entity';
import {
  DevTransaction,
  DevTransactionDocument,
} from './entities/dev-transaction.entity';
import { Bank, BankDocument } from '../admin/entities/bank.entity';
import {
  BalanceLog,
  BalanceLogDocument,
} from '../user/entities/balance-log.entity';
import { Withdraw, WithdrawDocument } from '../user/entities/withdraw.entity';
import { Balance, BalanceDocument } from '../user/entities/balance.entity';
import { User, UserDocument } from '../user/entities/user.entity';
import { DevBalance, DevBalanceDocument } from './entities/dev-balance.entity';
import {
  DevWithdraw,
  DevWithdrawDocument,
} from './entities/dev-withdraw.entity';

import { SOPResponse, SOPErrorMessage as ErrorMessage } from 'src/common/api';
import { TopupDto } from './dto/topup.dto';
import {
  Commission,
  CommissionDocument,
} from '../partner/entities/commission.entity';
import { decrypt } from 'src/common/helper/decryptKeyIv';
import { ProviderService } from 'src/core/provider/provider.service';
import { sortKeys } from 'src/common/helper/sortKeys';
import sendWaNotif from 'src/common/util/sendWaNotif';
import { ClientDocument } from './entities/client.entity';
import { DevClientDocument } from './entities/dev-client.entity';
const response = new SOPResponse();

const baseOpenImg = `${API_HOSTNAME}/v1/open/img/`;
const basePgImg = 'https://api-mitra.linkqu.id/app/assets/';

@Injectable()
export class OpenService {
  constructor(
    private readonly providerService: ProviderService,
    @InjectModel(User.name) private readonly User: Model<UserDocument>,
    @InjectModel(Method.name) private readonly Method: Model<MethodDocument>,
    @InjectModel(Bank.name) private readonly Bank: Model<BankDocument>,
    @InjectModel(Balance.name) private readonly Balance: Model<BalanceDocument>,
    @InjectModel(DevBalance.name)
    private readonly DevBalance: Model<DevBalanceDocument>,
    @InjectModel(BalanceLog.name)
    private readonly BalanceLog: Model<BalanceLogDocument>,
    @InjectModel(Transaction.name)
    private readonly Transaction: Model<TransactionDocument>,
    @InjectModel(DevTransaction.name)
    private readonly DevTransaction: Model<DevTransactionDocument>,
    @InjectModel(Withdraw.name)
    private readonly Withdraw: Model<WithdrawDocument>,
    @InjectModel(DevWithdraw.name)
    private readonly DevWithdraw: Model<DevWithdrawDocument>,
    @InjectModel(Commission.name)
    private readonly Commission: Model<CommissionDocument>,
  ) {}

  async getImg(val: string, res: FastifyReply) {
    try {
      await fetch(`${basePgImg}${val}`)
        .then(async (response) => {
          const contentType = response.headers.get('content-type');
          const buffer = await response.buffer();
          return res.type(contentType).send(buffer);
        })
        .catch((_) => {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Image not found'),
          );
          return res.status(200).send(error);
        });
    } catch (err) {
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async getMethod(res: FastifyReply) {
    try {
      await this.Method.find()
        .select('-_id name code type isActive img min max')
        .then((methods) => {
          if (methods) {
            const newMethod = methods.map((map) => {
              if (map.type === MethodType.Ewallet) {
                map.type = 'ewallet';
                map.code = map.code.substring(3);
              }
              map.img = `${HOSTNAME}${map.img}`;
              return map;
            });

            const success = response.initSuccess(200, true, newMethod);
            return res.status(200).send(success);
          } else {
            const error = response.initError(
              ClientResponse.MethodNotFound,
              false,
              new ErrorMessage("There's no method available right now"),
            );
            return res.status(200).send(error);
          }
        });
    } catch (err) {
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async getBank(req: FastifyOpenRequest, res: FastifyReply) {
    try {
      const { client } = req.user;
      await this.Bank.find()
        .select('-_id name code type min max isActive img')
        .then((banks) => {
          if (banks) {
            const newBank = banks.map((map) => {
              map.img = map.img
                ? map.img.toLowerCase().includes(basePgImg)
                  ? `${baseOpenImg}${map.img.replace(basePgImg, '')}`
                  : `${HOSTNAME}${map.img}`
                : `${HOSTNAME}/images/no-image.webp`;
              map.max = Math.min(client.limit, map.max);
              return map;
            });

            const success = response.initSuccess(200, true, newBank);
            return res.status(200).send(success);
          } else {
            const error = response.initError(
              ClientResponse.MethodNotFound,
              false,
              new ErrorMessage("There's no method available right now"),
            );
            return res.status(200).send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async getBalance(req: FastifyOpenRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      await this.Balance.findOne({ user: user.id })
        .select('-_id balance pending freeze debt')
        .then((balance) => {
          if (balance) {
            const success = response.initSuccess(200, true, balance);
            return res.status(200).send(success);
          } else {
            const error = response.initError(
              ClientResponse.MethodNotFound,
              false,
              new ErrorMessage("There's no balance data"),
            );
            return res.status(200).send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async generateSignature(
    payload: any,
    req: FastifyOpenRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, client } = req.user;
      const xMethod = req.headers['x-method'];
      const xUrl = req.headers['x-url'];
      const xTime = req.headers['x-timestamp'];
      console.log('signature', req.body, req.headers);

      const signature = encryptHmac(
        'sha512',
        client.signatureKey + user.id + client.id + xTime,
        xMethod.toString() +
          '|' +
          xUrl.toString() +
          '|' +
          hash('sha512', minifyJson(payload)).toLowerCase() +
          '|' +
          client.clientId +
          '|' +
          client.clientSecret,
        'hex',
      );

      const success = response.initSuccess(200, true, { signature });
      console.log(success);
      return res.status(200).send(success);
    } catch (err) {
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async generatePayment(
    payload: GeneratePaymentDto,
    type: string,
    req: FastifyOpenRequest,
    res: FastifyReply,
  ) {
    try {
      if (Object.values(MethodApiType).includes(type as MethodApiType)) {
        if (type === MethodApiType.Ewallet && !payload.phone) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage('Phone must not be empty'),
          );
          return res.status(200).send(error);
        } else {
          const { user, client } = req.user as {
            user: UserDocument;
            client: ClientDocument;
          };

          const xSig = req.headers['x-signature'];
          const xTime = req.headers['x-timestamp'];

          const signatureVerify = encryptHmac(
            'sha512',
            client.signatureKey,
            encryptHmac(
              'sha512',
              client.signatureKey + user.id + client.id + xTime,
              'POST' +
                '|' +
                `/generate/${type}` +
                '|' +
                hash('sha512', minifyJson(payload)).toLowerCase() +
                '|' +
                client.clientId +
                '|' +
                client.clientSecret,
              'hex',
            ) +
              '|' +
              client.clientId,
            'hex',
          );

          if (xSig === signatureVerify) {
            await this.Method.aggregate([
              {
                $match: {
                  code:
                    type === MethodApiType.Ewallet
                      ? 'PAY' + payload.method
                      : payload.method,
                  isActive: true,
                  type:
                    type === MethodApiType.Ewallet ? MethodType.Ewallet : type,
                },
              },
              {
                $lookup: {
                  from: 'fees',
                  let: { methodId: '$_id' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $and: [
                            { $eq: ['$method', '$$methodId'] },
                            { $eq: ['$feeType', FeeType.Transaction] },
                            { $eq: ['$user', { $toObjectId: user.id }] },
                          ],
                        },
                      },
                    },
                    {
                      $lookup: {
                        from: 'providers',
                        let: { providerId: '$provider' },
                        pipeline: [
                          {
                            $match: {
                              $expr: { $eq: ['$_id', '$$providerId'] },
                            },
                          },
                          {
                            $lookup: {
                              from: 'providers',
                              localField: 'providerRoot',
                              foreignField: '_id',
                              as: 'providerRoot',
                            },
                          },
                          {
                            $unwind: {
                              path: '$providerRoot',
                              preserveNullAndEmptyArrays: true,
                            },
                          },
                        ],
                        as: 'provider',
                      },
                    },
                    {
                      $unwind: '$provider',
                    },
                  ],
                  as: 'fee',
                },
              },
              {
                $unwind: '$fee',
              },
              {
                $lookup: {
                  from: 'valuetypes',
                  localField: 'fee.type',
                  foreignField: '_id',
                  as: 'fee.type',
                },
              },
              {
                $unwind: '$fee.type',
              },
            ]).then(async (methods) => {
              if (methods.length) {
                const method = methods[0];
                if (
                  method.fee.isActive &&
                  method.fee.provider &&
                  method.fee.provider.key
                ) {
                  if (payload.amount < method.min) {
                    const error = response.initError(
                      ClientResponse.InvalidData,
                      false,
                      new ErrorMessage(
                        `Minimal amount ${toCurrency(method.min)}`,
                      ),
                    );
                    return res.status(200).send(error);
                  } else if (payload.amount > method.max) {
                    const error = response.initError(
                      ClientResponse.InvalidData,
                      false,
                      new ErrorMessage(
                        `Maximal amount ${toCurrency(method.max)}`,
                      ),
                    );
                    return res.status(200).send(error);
                  } else {
                    const exp = new Date(Number(payload.expired));
                    if (exp.toString() === 'Invalid Date') {
                      const error = response.initError(
                        ClientResponse.InvalidData,
                        false,
                        new ErrorMessage('Invalid millis'),
                      );
                      return res.status(200).send(error);
                    } else {
                      const today = new Date();

                      if (today <= exp) {
                        await this.Transaction.findOne({
                          clientRef: payload.transactionRef,
                        }).then(async (trans) => {
                          if (trans) {
                            const error = response.initError(
                              ClientResponse.InvalidData,
                              false,
                              new ErrorMessage(
                                'Transaction Ref must be unique',
                              ),
                            );
                            return res.status(200).send(error);
                          } else {
                            let feeAmount: number;
                            switch (method.fee.type.name) {
                              case ValueType.Percentage:
                                feeAmount = Math.floor(
                                  (payload.amount * method.fee.percentage) /
                                    100,
                                );
                                break;
                              case ValueType.Fixed:
                                feeAmount = method.fee.fixed;
                                break;
                              default:
                                feeAmount = Math.floor(
                                  (payload.amount * method.fee.percentage) /
                                    100 +
                                    method.fee.fixed,
                                );
                                break;
                            }

                            var keyDec: string;
                            if (method.fee.provider.key === 'root') {
                              keyDec = decrypt(
                                process.env.ENCRYPT_ALG,
                                hash(
                                  'sha256',
                                  method.fee.provider.providerRoot._id.valueOf(),
                                ).substring(0, 32),
                                hash(
                                  'sha256',
                                  method.fee.provider.providerRoot.user.valueOf() +
                                    method.fee.provider.providerRoot.code,
                                ).substring(0, 16),
                                method.fee.provider.providerRoot.key,
                              );
                            } else {
                              keyDec = decrypt(
                                process.env.ENCRYPT_ALG,
                                hash(
                                  'sha256',
                                  method.fee.provider._id.valueOf(),
                                ).substring(0, 32),
                                hash(
                                  'sha256',
                                  method.fee.provider.user.valueOf() +
                                    method.fee.provider.code,
                                ).substring(0, 16),
                                method.fee.provider.key,
                              );
                            }

                            const orderId = generateRandomNumber(
                              method.fee.provider.code === ProviderCodeType.Mpi
                                ? 20
                                : 32,
                            );
                            const key = JSON.parse(keyDec);
                            const amount = method.fee.onClient
                              ? payload.amount
                              : payload.amount + feeAmount;

                            if (
                              method.fee.provider.code ===
                                ProviderCodeType.Bnc &&
                              type === MethodApiType.Qris
                            ) {
                              const accessToken =
                                await this.providerService.getBncAccessToken(
                                  key.clientId,
                                );

                              const expWib = new Date();
                              expWib.setMinutes(expWib.getMinutes() + 30);

                              const payloadPg = {
                                partnerReferenceNo: orderId,
                                amount: {
                                  value: `${amount}`,
                                  currency: 'IDR',
                                },
                                merchantId: key.merchantId,
                                storeId:
                                  method.fee.provider.auditStatus === '2'
                                    ? method.fee.provider.storeId
                                    : method.fee.providerRoot.storeId,
                                terminalId: 'A01',
                                validityPeriod: '1800',
                                additionalInfo: {
                                  qrType: '12',
                                  tipType: '00',
                                },
                              };

                              const resultPg =
                                await this.providerService.generateQrisBnc(
                                  key.clientId,
                                  accessToken,
                                  payloadPg,
                                );

                              const transactionId =
                                'T' +
                                hash('sha256', generateRandomNumber(5) + xTime);

                              const newTransaction = new this.Transaction({
                                clientCustName: payload.customerName,
                                transactionId,
                                orderId,
                                refId: '',
                                amount,
                                fee: feeAmount,
                                feeAdmin: 0,
                                exp: expWib.getTime(),
                                method: new Types.ObjectId(method._id),
                                user: user.id,
                                clientRef: payload.transactionRef,
                                accessFrom: AccessFrom.Api,
                                ip: req.ip,
                                provider: method.fee.provider._id,
                              });

                              var result: SOPResponse;
                              const resObj: any = {
                                amount,
                                fee: feeAmount,
                                expired: expWib.getTime(),
                                method: payload.method,
                                methodName: method.name,
                                customerName: payload.customerName,
                                ref1: payload.transactionRef,
                                ref2: transactionId,
                              };
                              if (resultPg) {
                                newTransaction.status =
                                  TransactionStatusType.Pending;
                                newTransaction.payment = resultPg.qrContent;
                                newTransaction.refId = resultPg.referenceNo;

                                resObj.status = TransactionStatusType.Pending;
                                resObj.desc = 'Success generate QRIS';
                                resObj.qris = resultPg.qrContent;

                                result = response.initSuccess(
                                  ClientResponse.Success,
                                  true,
                                  resObj,
                                );
                              } else {
                                newTransaction.status =
                                  TransactionStatusType.Failed;

                                resObj.status = TransactionStatusType.Failed;
                                resObj.desc = 'Failed generate QRIS';

                                resObj.error = 'Bank Not Supported';

                                result = response.initSuccess(
                                  ClientResponse.Success,
                                  false,
                                  resObj,
                                );
                              }
                              try {
                                await newTransaction.save();
                              } catch (err) {
                                result = response.initError(
                                  ClientResponse.InvalidData,
                                  false,
                                  new ErrorMessage(
                                    `Failed to save your transaction${
                                      err.code === 11000
                                        ? ', Duplicate Transaction Ref'
                                        : ''
                                    }`,
                                  ),
                                );
                              }
                              return res.status(200).send(result);
                            } else if (
                              type === MethodApiType.Va &&
                              method.name === 'BCA'
                            ) {
                              const expWib = new Date();
                              const expData = new Date(expWib);
                              expWib.setHours(expWib.getHours() + 19);
                              expData.setHours(expData.getHours() + 12);

                              const transactionId =
                                'T' +
                                hash('sha256', generateRandomNumber(5) + xTime);

                              const newTransaction = new this.Transaction({
                                clientCustName: payload.customerName,
                                transactionId,
                                orderId,
                                refId: '',
                                amount,
                                fee: feeAmount,
                                exp: expData.getTime(),
                                method: new Types.ObjectId(method._id),
                                user: user.id,
                                clientRef: payload.transactionRef,
                                accessFrom: AccessFrom.Api,
                                ip: req.ip,
                                provider: method.fee.provider._id,
                              });

                              var result: SOPResponse;
                              const resObj: any = {
                                amount,
                                fee: feeAmount,
                                expired: expWib.getTime(),
                                method: payload.method,
                                methodName: method.name,
                                customerName: payload.customerName,
                                ref1: payload.transactionRef,
                                ref2: transactionId,
                              };

                              if (
                                method.fee.provider.code ===
                                ProviderCodeType.Mpi
                              ) {
                                // console.log(
                                //   `${key.storeId}:${key.username}:${key.password}:${key.pin}`,
                                // );
                                const jwt = Buffer.from(
                                  `${key.storeId}:${key.username}:${key.password}:${key.pin}`,
                                  'utf-8',
                                ).toString('base64');

                                const payloadPg = {
                                  amount: amount,
                                  idtrx: orderId,
                                  email: EMAIL_NOT_PROVIDED,
                                  firstName:
                                    client.paymentClientName === 'root'
                                      ? client.clientName
                                      : client.paymentClientName,
                                  lastName:
                                    client.paymentCustName === 'root'
                                      ? payload.customerName
                                      : client.paymentCustName,
                                  phoneNumber: '08170025687',
                                  merchantName: 'MPS VABCA',
                                };

                                const resultPg =
                                  await this.providerService.generateBcaVaMpi(
                                    jwt,
                                    payloadPg,
                                    key.pin,
                                  );

                                if (resultPg) {
                                  newTransaction.status =
                                    TransactionStatusType.Pending;
                                  newTransaction.payment = resultPg.va;
                                  newTransaction.url = resultPg.url;
                                  newTransaction.refId = resultPg.refId;

                                  resObj.status = TransactionStatusType.Pending;
                                  resObj.desc =
                                    'Success generate Virtual Account';
                                  resObj.va = resultPg.va;

                                  result = response.initSuccess(
                                    ClientResponse.Success,
                                    true,
                                    resObj,
                                  );
                                } else {
                                  newTransaction.status =
                                    TransactionStatusType.Failed;

                                  resObj.status = TransactionStatusType.Failed;
                                  resObj.desc =
                                    'Failed generate Virtual Account';

                                  resObj.error = 'Bank Not Supported';

                                  result = response.initSuccess(
                                    ClientResponse.Success,
                                    false,
                                    resObj,
                                  );
                                }
                              } else {
                                const error = response.initError(
                                  ClientResponse.MethodNotAllowed,
                                  false,
                                  new ErrorMessage(`Bank not supported`),
                                );
                                return res.status(200).send(error);
                              }

                              try {
                                await newTransaction.save();
                              } catch (err) {
                                result = response.initError(
                                  ClientResponse.InvalidData,
                                  false,
                                  new ErrorMessage(
                                    `Failed to save your transaction${
                                      err.code === 11000
                                        ? ', Duplicate Transaction Ref'
                                        : ''
                                    }`,
                                  ),
                                );
                              }
                              return res.status(200).send(result);
                            } else {
                              const expWib = new Date(exp);
                              expWib.setHours(expWib.getHours() + 7);
                              const dateString = expWib
                                .toLocaleString('en-US', {
                                  year: 'numeric',
                                  month: '2-digit',
                                  day: '2-digit',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                  second: '2-digit',
                                })
                                .replace(/\/|,|:| /g, '');
                              const formattedDate = `${dateString.slice(
                                4,
                                8,
                              )}${dateString.slice(0, 2)}${dateString.slice(
                                2,
                                4,
                              )}${dateString.slice(8, 14)}`;
                              const customerId = exp.getTime();

                              const reqMethod = 'POST';
                              const paramX = `${method.path}${reqMethod}`;
                              const paramY = `${amount}${formattedDate}${
                                type === MethodApiType.Qris ? '' : method.code
                              }${orderId}${customerId}${
                                client.paymentClientName === 'root'
                                  ? client.clientName
                                  : client.paymentClientName
                              } ${
                                client.paymentCustName === 'root'
                                  ? payload.customerName
                                  : client.paymentCustName
                              }${EMAIL_NOT_PROVIDED}${
                                type === MethodApiType.Ewallet
                                  ? payload.phone
                                  : ''
                              }${key.clientId}`;
                              const sig = encryptHmac(
                                'sha256',
                                key.sigKey,
                                paramX +
                                  paramY
                                    .toLowerCase()
                                    .replace(/[^a-zA-Z0-9]/g, ''),
                                'hex',
                              );

                              const payloadPg: any = {
                                expired: formattedDate,
                                amount: Number(amount),
                                customer_id: Number(customerId),
                                partner_reff: orderId,
                                customer_email: EMAIL_NOT_PROVIDED,
                                username: key.username,
                                pin: key.pin,
                                customer_name: `${
                                  client.paymentClientName === 'root'
                                    ? client.clientName
                                    : client.paymentClientName
                                } ${
                                  client.paymentCustName === 'root'
                                    ? payload.customerName
                                    : client.paymentCustName
                                }`,
                                signature: sig,
                              };

                              if (type === MethodApiType.Ewallet) {
                                payloadPg.ewallet_phone = payload.phone;
                                payloadPg.bill_title = 'NiagaPay';
                                payloadPg.retail_code = method.code;
                              } else if (type === MethodApiType.Retail) {
                                payloadPg.retail_code = method.code;
                                payloadPg.customer_phone = '081234567890';
                              } else if (type === MethodApiType.Va) {
                                payloadPg.bank_code = method.code;
                              }

                              const header = {
                                'Content-Type': CT_APP_JSON,
                                'client-id': key.clientId,
                                'client-secret': key.clientSecret,
                              };

                              await fetch(
                                process.env.PG_BASE_URL +
                                  method.path.substring(1),
                                {
                                  method: reqMethod,
                                  body: JSON.stringify(payloadPg),
                                  headers: header,
                                },
                              ).then(async (responseFetch) => {
                                const responseData = await responseFetch.json();

                                const transactionId =
                                  'T' +
                                  hash(
                                    'sha256',
                                    generateRandomNumber(5) + xTime,
                                  );

                                const newTransaction = new this.Transaction({
                                  clientCustName: payload.customerName,
                                  transactionId,
                                  orderId,
                                  refId: responseData.partner_reff2,
                                  amount,
                                  fee: feeAmount,
                                  feeAdmin: responseData.feeadmin,
                                  payment:
                                    responseData.virtual_account ??
                                    responseData.payment_code ??
                                    responseData.qris_text,
                                  url: responseData.url_payment,
                                  exp,
                                  method: new Types.ObjectId(method._id),
                                  user: user.id,
                                  clientRef: payload.transactionRef,
                                  accessFrom: AccessFrom.Api,
                                  ip: req.ip,
                                  provider: method.fee.provider._id,
                                });

                                if (type === MethodApiType.Ewallet) {
                                  newTransaction.phone = payload.phone;
                                }

                                var result: SOPResponse;
                                const resObj: any = {
                                  amount,
                                  fee: feeAmount,
                                  expired: exp.getTime(),
                                  method: payload.method,
                                  methodName: method.name,
                                  customerName: payload.customerName,
                                  ref1: payload.transactionRef,
                                  ref2: transactionId,
                                };
                                if (
                                  responseData.status === PgType.Success &&
                                  responseData.response_code ===
                                    PgType.SuccessCode
                                ) {
                                  newTransaction.status =
                                    TransactionStatusType.Pending;

                                  resObj.status = TransactionStatusType.Pending;
                                  resObj.desc = `Success generate ${
                                    type === MethodApiType.Va
                                      ? 'Virtual Account'
                                      : type === MethodApiType.Retail
                                      ? 'Retail Payment Code'
                                      : type === MethodApiType.Qris
                                      ? 'QRIS'
                                      : type === MethodApiType.Ewallet
                                      ? 'Ewallet Transaction'
                                      : ''
                                  }`;

                                  if (type === MethodApiType.Va) {
                                    resObj.va = responseData.virtual_account;
                                  } else if (type === MethodApiType.Retail) {
                                    resObj.paymentCode =
                                      responseData.payment_code;
                                  } else if (type === MethodApiType.Qris) {
                                    resObj.qris = responseData.qris_text;
                                  } else if (type === MethodApiType.Ewallet) {
                                    resObj.phone = payload.phone;
                                    resObj.paymentCode =
                                      responseData.paymentCode;
                                    resObj.deepLink = responseData.url_payment;
                                  }

                                  result = response.initSuccess(
                                    ClientResponse.Success,
                                    true,
                                    resObj,
                                  );
                                } else {
                                  console.log(responseData);
                                  newTransaction.status =
                                    TransactionStatusType.Failed;

                                  resObj.status = TransactionStatusType.Failed;
                                  resObj.desc =
                                    type === MethodApiType.Va
                                      ? 'Failed generate Virtual Account'
                                      : type === MethodApiType.Retail
                                      ? 'Failed generate Retail Payment Code'
                                      : type === MethodApiType.Qris
                                      ? 'Failed generate QRIS'
                                      : type === MethodApiType.Ewallet
                                      ? 'Failed generate Ewallet Transaction'
                                      : '';

                                  resObj.error =
                                    type === MethodApiType.Va
                                      ? 'Bank Not Supported'
                                      : type === MethodApiType.Retail
                                      ? 'Retail Not Supported'
                                      : type === MethodApiType.Qris
                                      ? 'Bank Not Supported'
                                      : type === MethodApiType.Ewallet
                                      ? 'Ewallet Not Supported'
                                      : '';

                                  result = response.initSuccess(
                                    ClientResponse.Success,
                                    false,
                                    resObj,
                                  );
                                }
                                try {
                                  await newTransaction.save();
                                } catch (err) {
                                  result = response.initError(
                                    ClientResponse.InvalidData,
                                    false,
                                    new ErrorMessage(
                                      `Failed to save your transaction${
                                        err.code === 11000
                                          ? ', Duplicate Transaction Ref'
                                          : ''
                                      }`,
                                    ),
                                  );
                                }
                                return res.status(200).send(result);
                              });
                            }
                          }
                        });
                      } else {
                        const error = response.initError(
                          ClientResponse.InvalidData,
                          false,
                          new ErrorMessage(
                            'Expired must be greater than today',
                          ),
                        );
                        return res.status(200).send(error);
                      }
                    }
                  }
                } else {
                  const error = response.initError(
                    ClientResponse.MethodNotAllowed,
                    false,
                    new ErrorMessage('Payment method not allowed'),
                  );
                  return res.status(200).send(error);
                }
              } else {
                const error = response.initError(
                  ClientResponse.MethodNotFound,
                  false,
                  new ErrorMessage('Payment method not found'),
                );
                return res.status(200).send(error);
              }
            });
          } else {
            const error = response.initError(
              ClientResponse.InvalidSignature,
              false,
              new ErrorMessage('Invalid Signature'),
            );
            return res.status(200).send(error);
          }
        }
      } else {
        const error = response.initError(
          ClientResponse.MethodNotFound,
          false,
          new ErrorMessage(`${type} not exist`),
        );
        return res.status(200).send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async transferInquiry(
    payload: TransferInquiryDto,
    type: string,
    req: FastifyOpenRequest,
    res: FastifyReply,
  ) {
    try {
      const validBankTypes = Object.values(BankType).filter(
        (value) => value !== BankType.CC,
      );
      if (validBankTypes.includes(type as BankType)) {
        if (type !== BankType.Cash && !payload.accountNumber) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage('Bank Account must not be empty'),
          );
          return res.status(200).send(error);
        } else if (
          type === BankType.Cash &&
          !payload.customerEmail &&
          !payload.customerPhone
        ) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage(
              'Customer email and Customer phone must not be empty for Cash transfer',
            ),
          );
          return res.status(200).send(error);
        }
        const { user, client } = req.user as {
          user: UserDocument;
          client: ClientDocument;
        };

        const xSig = req.headers['x-signature'];
        const xTime = req.headers['x-timestamp'];

        const signatureVerify = encryptHmac(
          'sha512',
          client.signatureKey,
          encryptHmac(
            'sha512',
            client.signatureKey + user.id + client.id + xTime,
            'POST' +
              '|' +
              `/transfer/${type}/inquiry` +
              '|' +
              hash('sha512', minifyJson(payload)).toLowerCase() +
              '|' +
              client.clientId +
              '|' +
              client.clientSecret,
            'hex',
          ) +
            '|' +
            client.clientId,
          'hex',
        );

        if (xSig === signatureVerify) {
          await this.Bank.aggregate([
            {
              $match: {
                code: payload.channelCode,
                type: type,
                isActive: true,
              },
            },
            {
              $lookup: {
                from: 'fees',
                let: { bankId: '$_id' },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          type === BankType.Ewallet || type === BankType.Cash
                            ? { $eq: ['$bank', '$$bankId'] }
                            : {},
                          { $eq: ['$feeType', type] },
                          { $eq: ['$user', { $toObjectId: user.id }] },
                        ],
                      },
                    },
                  },
                  {
                    $lookup: {
                      from: 'providers',
                      localField: 'provider',
                      foreignField: '_id',
                      as: 'provider',
                    },
                  },
                  {
                    $unwind: '$provider',
                  },
                ],
                as: 'fee',
              },
            },
            {
              $unwind: '$fee',
            },
            {
              $lookup: {
                from: 'valuetypes',
                localField: 'fee.type',
                foreignField: '_id',
                as: 'fee.type',
              },
            },
            {
              $unwind: '$fee.type',
            },
          ]).then(async (banks) => {
            if (banks.length) {
              const bank = banks[0];
              if (bank.fee.isActive) {
                if (payload.amount > client.limit) {
                  const error = response.initError(
                    ClientResponse.InvalidData,
                    false,
                    new ErrorMessage(
                      `Your account limit is ${toCurrency(client.limit)}`,
                    ),
                  );
                  return res.status(200).send(error);
                } else if (payload.amount < bank.min) {
                  const error = response.initError(
                    ClientResponse.InvalidData,
                    false,
                    new ErrorMessage(`Minimal amount ${toCurrency(bank.min)}`),
                  );
                  return res.status(200).send(error);
                } else if (payload.amount > bank.max) {
                  const error = response.initError(
                    ClientResponse.InvalidData,
                    false,
                    new ErrorMessage(`Maximal amount ${toCurrency(bank.max)}`),
                  );
                  return res.status(200).send(error);
                } else if (
                  type === BankType.Cash &&
                  payload.amount % bank.multiple !== 0
                ) {
                  const error = response.initError(
                    ClientResponse.InvalidData,
                    false,
                    new ErrorMessage(
                      `Amount must be a multiple of  ${toCurrency(
                        bank.multiple,
                      )}`,
                    ),
                  );
                  return res.status(200).send(error);
                } else {
                  await this.Balance.findOne({
                    user: user.id,
                  }).then(async (balanceFound) => {
                    if (balanceFound) {
                      await this.Withdraw.findOne({
                        clientRef: payload.transferRef,
                      }).then(async (trans) => {
                        if (trans) {
                          const error = response.initError(
                            ClientResponse.InvalidData,
                            false,
                            new ErrorMessage('Transfer Ref must be unique'),
                          );
                          return res.status(200).send(error);
                        } else {
                          let feeAmount: number;
                          switch (bank.fee.type.name) {
                            case ValueType.Percentage:
                              feeAmount = Math.floor(
                                (payload.amount * bank.fee.percentage) / 100,
                              );
                              break;
                            case ValueType.Fixed:
                              feeAmount = bank.fee.fixed;
                              break;
                            default:
                              feeAmount = Math.floor(
                                (payload.amount * bank.fee.percentage) / 100 +
                                  bank.fee.fixed,
                              );
                              break;
                          }

                          if (
                            balanceFound.balance <
                            payload.amount + feeAmount
                          ) {
                            const error = response.initError(
                              ClientResponse.InvalidData,
                              false,
                              new ErrorMessage('Balance is not enough'),
                            );
                            return res.status(200).send(error);
                          }

                          if (type === BankType.Cash) {
                            const withdrawId =
                              'D' +
                              hash('sha256', generateRandomNumber(5) + xTime);
                            const signature = encryptHmac(
                              'sha512',
                              xTime +
                                user.username +
                                user.pass +
                                client.signatureKey,
                              'POST' +
                                `/transfer/${type}/payment` +
                                hash(
                                  'sha512',
                                  minifyJson(
                                    sortKeys({
                                      ...payload,
                                      paymentRef: withdrawId,
                                    }),
                                  ),
                                ).toLowerCase() +
                                '|' +
                                client.clientId +
                                '|' +
                                client.clientSecret +
                                '|' +
                                user.id +
                                '|' +
                                withdrawId,
                              'hex',
                            );

                            const newWithdraw = new this.Withdraw({
                              withdrawId,
                              amount: payload.amount,
                              fee: feeAmount,
                              name: `Cash Transfer ${bank.name}`,
                              email: payload.customerEmail,
                              phone: payload.customerPhone,
                              withdrawType: WithdrawType.Client,
                              inquiryBy: user.id,
                              bank: new Types.ObjectId(bank._id),
                              accessFrom: AccessFrom.Api,
                              user: user.id,
                              clientRef: payload.transferRef,
                              ip: req.ip,
                              provider: bank.fee.provider._id,
                            });

                            if (payload.remark) {
                              newWithdraw.remark = payload.remark;
                            }

                            var success: SOPResponse;
                            try {
                              await newWithdraw.save();
                              success = response.initSuccess(
                                ClientResponse.Success,
                                true,
                                {
                                  signature,
                                  amount: payload.amount,
                                  channelName: bank.name,
                                  accountNumber: '',
                                  name: `Cash Transfer ${bank.name}`,
                                  ref1: payload.transferRef,
                                  ref2: withdrawId,
                                  desc: 'Success create Transfer inquiry',
                                  fee: feeAmount,
                                },
                              );
                            } catch (err) {
                              success = response.initError(
                                ClientResponse.InvalidData,
                                false,
                                new ErrorMessage(
                                  `Failed to save your withdraw${
                                    err.code === 11000
                                      ? ', Duplicate Transaction Ref'
                                      : ''
                                  }`,
                                ),
                              );
                            }
                            return res.status(200).send(success);
                          } else {
                            const keyDec = decrypt(
                              process.env.ENCRYPT_ALG,
                              hash(
                                'sha256',
                                bank.fee.provider._id.valueOf(),
                              ).substring(0, 32),
                              hash(
                                'sha256',
                                bank.fee.provider.user.valueOf() +
                                  bank.fee.provider.code,
                              ).substring(0, 16),
                              bank.fee.provider.key,
                            );

                            const key = JSON.parse(keyDec);

                            const orderId = generateRandomNumber(50);
                            const url =
                              type === BankType.Bank
                                ? 'transaction/withdraw/inquiry'
                                : type === BankType.Ewallet
                                ? 'transaction/reload/inquiry'
                                : type === BankType.Va
                                ? 'transaction/transferva/inquiry'
                                : '';
                            const paramX = `/${url}POST`;
                            const paramY = `${payload.amount}${payload.accountNumber}${bank.code}${orderId}${key.clientId}`;

                            const sig = encryptHmac(
                              'sha256',
                              key.sigKey,
                              paramX +
                                paramY
                                  .toLowerCase()
                                  .replace(/[^a-zA-Z0-9]/g, ''),
                              'hex',
                            );
                            const payloadCheck: any = {
                              amount: Number(payload.amount),
                              partner_reff: orderId,
                              accountnumber: payload.accountNumber,
                              bankcode: bank.code,
                              username: key.username,
                              pin: key.pin,
                              signature: sig,
                            };

                            const header = {
                              'Content-Type': CT_APP_JSON,
                              'client-id': key.clientId,
                              'client-secret': key.clientSecret,
                            };
                            await fetch(process.env.PG_BASE_URL + url, {
                              method: 'POST',
                              body: JSON.stringify(payloadCheck),
                              headers: header,
                            }).then(async (responseFetch) => {
                              const responseData = await responseFetch.json();
                              console.log(responseData);
                              const withdrawId =
                                'D' +
                                hash('sha256', generateRandomNumber(5) + xTime);
                              if (
                                responseData.status === PgType.Success &&
                                responseData.response_code ===
                                  PgType.SuccessCode
                              ) {
                                const signature = encryptHmac(
                                  'sha512',
                                  xTime +
                                    user.username +
                                    user.pass +
                                    client.signatureKey,
                                  'POST' +
                                    `/transfer/${type}/payment` +
                                    hash(
                                      'sha512',
                                      minifyJson(
                                        sortKeys({
                                          ...payload,
                                          paymentRef: withdrawId,
                                        }),
                                      ),
                                    ).toLowerCase() +
                                    '|' +
                                    client.clientId +
                                    '|' +
                                    client.clientSecret +
                                    '|' +
                                    user.id +
                                    '|' +
                                    withdrawId +
                                    '|' +
                                    responseData.inquiry_reff,
                                  'hex',
                                );

                                const newWithdraw = new this.Withdraw({
                                  withdrawId,
                                  orderId,
                                  amount: payload.amount,
                                  fee: feeAmount,
                                  feeAdmin: responseData.additionalfee,
                                  name: responseData.accountname,
                                  accNumber: payload.accountNumber,
                                  inquiryReff: responseData.inquiry_reff,
                                  withdrawType: WithdrawType.Client,
                                  inquiryBy: user.id,
                                  bank: new Types.ObjectId(bank._id),
                                  accessFrom: AccessFrom.Api,
                                  user: user.id,
                                  clientRef: payload.transferRef,
                                  ip: req.ip,
                                  provider: bank.fee.provider._id,
                                });

                                if (payload.remark) {
                                  newWithdraw.remark = payload.remark;
                                }

                                var success: SOPResponse;

                                try {
                                  await newWithdraw.save();
                                  success = response.initSuccess(
                                    ClientResponse.Success,
                                    true,
                                    {
                                      signature,
                                      amount: payload.amount,
                                      fee: feeAmount,
                                      channelName: bank.name,
                                      accountNumber: payload.accountNumber,
                                      name: responseData.accountname,
                                      ref1: payload.transferRef,
                                      ref2: withdrawId,
                                      desc: 'Success create Transfer inquiry',
                                    },
                                  );
                                } catch (err) {
                                  success = response.initError(
                                    ClientResponse.InvalidData,
                                    false,
                                    new ErrorMessage(
                                      `Failed to save your withdraw${
                                        err.code === 11000
                                          ? ', Duplicate Transaction Ref'
                                          : ''
                                      }`,
                                    ),
                                  );
                                }
                                return res.status(200).send(success);
                              } else {
                                const newWithdraw = new this.Withdraw({
                                  withdrawId,
                                  orderId,
                                  amount: payload.amount,
                                  fee: feeAmount,
                                  feeAdmin: 0,
                                  name: '',
                                  accNumber: payload.accountNumber,
                                  inquiryReff: '',
                                  withdrawType: WithdrawType.Client,
                                  inquiryBy: user.id,
                                  bank: new Types.ObjectId(bank._id),
                                  accessFrom: AccessFrom.Api,
                                  user: user.id,
                                  clientRef: payload.transferRef,
                                  ip: req.ip,
                                  provider: bank.fee.provider._id,
                                  status: WithdrawStatus.Failed,
                                  error: responseData.response_desc,
                                });

                                if (payload.remark) {
                                  newWithdraw.remark = payload.remark;
                                }

                                try {
                                  await newWithdraw.save();
                                  const error = response.initError(
                                    ClientResponse.MethodNotFound,
                                    false,
                                    new ErrorMessage('Bank Account not found'),
                                  );
                                  return res.status(200).send(error);
                                } catch (err) {
                                  const error = response.initError(
                                    ClientResponse.MethodNotFound,
                                    false,
                                    new ErrorMessage(
                                      `Failed to save your withdraw${
                                        err.code === 11000
                                          ? ', Duplicate Transaction Ref'
                                          : ''
                                      }`,
                                    ),
                                  );
                                  return res.status(200).send(error);
                                }
                              }
                            });
                          }
                        }
                      });
                    } else {
                      const error = response.initError(
                        ClientResponse.MethodNotFound,
                        false,
                        new ErrorMessage('Balance data not found'),
                      );
                      return res.status(200).send(error);
                    }
                  });
                }
              } else {
                const error = response.initError(
                  ClientResponse.MethodNotAllowed,
                  false,
                  new ErrorMessage('Bank not allowed'),
                );
                return res.status(200).send(error);
              }
            } else {
              const error = response.initError(
                ClientResponse.MethodNotFound,
                false,
                new ErrorMessage('Bank not found'),
              );
              return res.status(200).send(error);
            }
          });
        } else {
          const error = response.initError(
            ClientResponse.InvalidSignature,
            false,
            new ErrorMessage('Invalid Signature'),
          );
          return res.status(200).send(error);
        }
      } else {
        const error = response.initError(
          ClientResponse.MethodNotFound,
          false,
          new ErrorMessage(`${type} not exist`),
        );
        return res.status(200).send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async transferPayment(
    payload: TransferPaymentDto,
    type: string,
    req: FastifyOpenRequest,
    res: FastifyReply,
  ) {
    try {
      const validBankTypes = Object.values(BankType).filter(
        (value) => value !== BankType.CC,
      );
      if (validBankTypes.includes(type as BankType)) {
        if (type !== BankType.Cash && !payload.paymentRef) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage('Payment Ref must not be empty'),
          );
          return res.status(200).send(error);
        } else if (type !== BankType.Cash && !payload.accountNumber) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage('Bank Account must not be empty'),
          );
          return res.status(200).send(error);
        } else if (
          type === BankType.Cash &&
          !payload.customerEmail &&
          !payload.customerPhone
        ) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage(
              'Customer email and Customer phone must not be empty for Cash transfer',
            ),
          );
          return res.status(200).send(error);
        }

        const { user, client } = req.user as {
          user: UserDocument;
          client: ClientDocument;
        };

        await this.Withdraw.findOne({
          clientRef: payload.transferRef,
          withdrawId: payload.paymentRef,
          user: new Types.ObjectId(user.id),
        })
          .populate('bank')
          .populate({
            path: 'provider',
            populate: {
              path: 'providerRoot',
            },
          })
          .then(async (withdraw: any) => {
            if (withdraw) {
              const xSig = req.headers['x-signature'];
              const xTime = req.headers['x-timestamp'];
              const signatureVerify = encryptHmac(
                'sha512',
                client.signatureKey,
                encryptHmac(
                  'sha512',
                  client.signatureKey + user.id + client.id + xTime,
                  'POST' +
                    '|' +
                    `/transfer/${type}/payment` +
                    '|' +
                    hash('sha512', minifyJson(payload)).toLowerCase() +
                    '|' +
                    client.clientId +
                    '|' +
                    client.clientSecret,
                  'hex',
                ) +
                  '|' +
                  client.clientId +
                  '|' +
                  encryptHmac(
                    'sha512',
                    xTime + user.username + user.pass + client.signatureKey,
                    'POST' +
                      `/transfer/${type}/payment` +
                      hash(
                        'sha512',
                        minifyJson(sortKeys(payload)),
                      ).toLowerCase() +
                      '|' +
                      client.clientId +
                      '|' +
                      client.clientSecret +
                      '|' +
                      user.id +
                      '|' +
                      withdraw.withdrawId +
                      (withdraw.bank.type === BankType.Cash
                        ? ''
                        : '|' + withdraw.inquiryReff),
                    'hex',
                  ),
                'hex',
              );
              if (xSig === signatureVerify) {
                await this.Balance.aggregate([
                  {
                    $match: {
                      $expr: { $eq: ['$user', { $toObjectId: user.id }] },
                    },
                  },
                  {
                    $lookup: {
                      from: 'fees',
                      let: { bankId: { $toObjectId: withdraw.bank._id } },
                      pipeline: [
                        {
                          $match: {
                            $expr: {
                              $and: [
                                type === BankType.Ewallet ||
                                type === BankType.Cash
                                  ? { $eq: ['$bank', '$$bankId'] }
                                  : {},
                                { $eq: ['$feeType', type] },
                                { $eq: ['$user', { $toObjectId: user.id }] },
                              ],
                            },
                          },
                        },
                      ],
                      as: 'fee',
                    },
                  },
                  {
                    $unwind: '$fee',
                  },
                  {
                    $lookup: {
                      from: 'valuetypes',
                      localField: 'fee.type',
                      foreignField: '_id',
                      as: 'fee.type',
                    },
                  },
                  {
                    $unwind: '$fee.type',
                  },
                ]).then(async (balances: any) => {
                  if (balances.length) {
                    const balance = balances[0];
                    if (balance.balance < withdraw.amount + withdraw.fee) {
                      const error = response.initError(
                        403,
                        false,
                        new ErrorMessage('Balance is not enough'),
                      );
                      return res.status(200).send(error);
                    } else {
                      await this.Balance.findByIdAndUpdate(balance._id, {
                        $inc: {
                          balance: -Number(withdraw.amount + withdraw.fee),
                        },
                      });

                      const newBalanceLog = new this.BalanceLog({
                        name: `${user.username} disburse ${toCurrency(
                          withdraw.amount,
                        )} with fee ${toCurrency(withdraw.fee)}`,
                        balanceAmount: balance.balance,
                        balanceCredit: Number(withdraw.amount + withdraw.fee),
                        type: BalanceLogType.Out,
                        balance: balance._id,
                        withdraw: withdraw.id,
                      });

                      await newBalanceLog.save();

                      var result: SOPResponse;
                      const objRes: any = {
                        amount: withdraw.amount,
                        fee: withdraw.fee,
                        channelName: withdraw.bank.name,
                        accountNumber:
                          withdraw.bank.type === BankType.Cash
                            ? ''
                            : payload.accountNumber,
                        name:
                          withdraw.bank.type === BankType.Cash
                            ? `Cash Transfer ${withdraw.bank.name}`
                            : withdraw.name,
                        ref1: withdraw.clientRef,
                        ref2: withdraw.withdrawId,
                      };

                      const updateWithdraw: any = {
                        process: WithdrawProcess.Process,
                        processedBy: user.id,
                        processedDate: new Date(),
                      };

                      var keyDec: string;
                      if (withdraw.provider.key === 'root') {
                        keyDec = decrypt(
                          process.env.ENCRYPT_ALG,
                          hash(
                            'sha256',
                            withdraw.provider.providerRoot.id.valueOf(),
                          ).substring(0, 32),
                          hash(
                            'sha256',
                            withdraw.provider.providerRoot.user.valueOf() +
                              withdraw.provider.providerRoot.code,
                          ).substring(0, 16),
                          withdraw.provider.providerRoot.key,
                        );
                      } else {
                        keyDec = decrypt(
                          process.env.ENCRYPT_ALG,
                          hash('sha256', withdraw.provider.id).substring(0, 32),
                          hash(
                            'sha256',
                            withdraw.provider.user.valueOf() +
                              withdraw.provider.code,
                          ).substring(0, 16),
                          withdraw.provider.key,
                        );
                      }
                      const key = JSON.parse(keyDec);

                      var providerBalance = 0;

                      const header = {
                        'client-id': key.clientId,
                        'client-secret': key.clientSecret,
                      };
                      await fetch(
                        process.env.PG_BASE_URL +
                          'akun/resume?username=' +
                          key.username,
                        {
                          method: 'GET',
                          headers: header,
                        },
                      ).then(async (responseFetch) => {
                        const responseData = await responseFetch.json();
                        if (
                          responseData.rc === '00' &&
                          responseData.rd === 'Berhasil'
                        ) {
                          providerBalance = responseData.balance;
                        }
                      });

                      if (
                        withdraw.amount < client.limit &&
                        withdraw.amount <= providerBalance
                      ) {
                        const exp = new Date();
                        exp.setDate(exp.getDate() + 1);

                        const dateString = exp
                          .toLocaleString('en-US', {
                            year: 'numeric',
                            month: '2-digit',
                            day: '2-digit',
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                          })
                          .replace(/\/|,|:| /g, '');
                        const formattedDate = `${dateString.slice(
                          4,
                          8,
                        )}${dateString.slice(0, 2)}${dateString.slice(
                          2,
                          4,
                        )}${dateString.slice(8, 14)}`;
                        const customerId = exp.getTime();

                        const url =
                          withdraw.bank.type === BankType.Bank
                            ? 'transaction/withdraw/payment'
                            : withdraw.bank.type === BankType.Ewallet
                            ? 'transaction/reload/payment'
                            : withdraw.bank.type === BankType.Va
                            ? 'transaction/transferva/payment'
                            : 'transaction/tarik/tunai';
                        const paramX = `/${url}POST`;
                        const paramY = `${withdraw.amount}${
                          withdraw.bank.type === BankType.Cash
                            ? `${formattedDate}${
                                withdraw.bank.code
                              }${customerId}${
                                client.paymentClientName === 'root'
                                  ? client.clientName
                                  : client.paymentClientName
                              }${withdraw.customerEmail}`
                            : `${withdraw.accNumber}${withdraw.bank.code}${withdraw.orderId}${withdraw.inquiryReff}`
                        }${key.clientId}`;

                        const sig = encryptHmac(
                          'sha256',
                          key.sigKey,
                          paramX +
                            paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
                          'hex',
                        );

                        const payloadPayment: any = {
                          amount: Number(withdraw.amount),
                          partner_reff: withdraw.orderId,
                          username: key.username,
                          pin: key.pin,
                          signature: sig,
                        };

                        if (withdraw.bank.type === BankType.Cash) {
                          payloadPayment.expired = formattedDate;
                          payloadPayment.customer_id = Number(customerId);
                          payloadPayment.customer_name =
                            client.paymentClientName === 'root'
                              ? client.clientName
                              : client.paymentClientName;
                          payloadPayment.retail_code = withdraw.bank.code;
                          payloadPayment.customer_email =
                            withdraw.customerEmail;
                          payloadPayment.customer_phone =
                            withdraw.customerPhone;
                        } else {
                          if (withdraw.remark) {
                            payloadPayment.remark = withdraw.remark;
                          }
                          payloadPayment.inquiry_reff = withdraw.inquiryReff;
                          payloadPayment.accountnumber = withdraw.accNumber;
                          payloadPayment.bankcode = withdraw.bank.code;
                        }

                        const header = {
                          'Content-Type': CT_APP_JSON,
                          'client-id': key.clientId,
                          'client-secret': key.clientSecret,
                        };
                        await fetch(process.env.PG_BASE_URL + url, {
                          method: 'POST',
                          body: JSON.stringify(payloadPayment),
                          headers: header,
                        }).then(async (responseFetch) => {
                          var responseData: any;
                          try {
                            responseData = await responseFetch.json();
                          } catch (err) {
                            console.log(err);
                            updateWithdraw.error =
                              "There's an error on our provider. Please kindly try again in a few minutes :)";
                            updateWithdraw.status = WithdrawStatus.Failed;

                            objRes.status = WithdrawStatus.Failed;
                            objRes.error =
                              "There's an error on our provider. Please kindly try again in a few minutes :)";
                            objRes.desc = `Fail ${
                              withdraw.bank.type === BankType.Cash
                                ? `create ${withdraw.bank.name} transfer request`
                                : `transfer to ${withdraw.name}-${withdraw.accNumber}`
                            }`;

                            const updatedBalance =
                              await this.Balance.findByIdAndUpdate(
                                balance._id,
                                {
                                  $inc: {
                                    balance: Number(
                                      withdraw.amount + withdraw.fee,
                                    ),
                                  },
                                },
                                { new: true },
                              );

                            const newBalanceLog = new this.BalanceLog({
                              name: `system's return disburse`,
                              balanceAmount:
                                updatedBalance.balance -
                                (withdraw.amount + withdraw.fee),
                              balanceCredit: Number(
                                withdraw.amount + withdraw.fee,
                              ),
                              type: BalanceLogType.Refund,
                              balance: balance._id,
                              withdraw: withdraw.id,
                            });

                            await newBalanceLog.save();

                            result = response.initSuccess(
                              ClientResponse.Success,
                              false,
                              objRes,
                            );

                            await this.Withdraw.findByIdAndUpdate(
                              withdraw.id,
                              updateWithdraw,
                            );

                            return res.status(200).send(result);
                          }
                          if (responseData.status === PgType.Failed) {
                            updateWithdraw.error = responseData.response_desc;
                            updateWithdraw.status = WithdrawStatus.Failed;

                            objRes.status = WithdrawStatus.Failed;
                            objRes.error = responseData.response_desc;
                            objRes.desc = `Fail ${
                              withdraw.bank.type === BankType.Cash
                                ? `create ${withdraw.bank.name} transfer request`
                                : `transfer to ${withdraw.name}-${withdraw.accNumber}`
                            }`;

                            const updatedBalance =
                              await this.Balance.findByIdAndUpdate(
                                balance._id,
                                {
                                  $inc: {
                                    balance: Number(
                                      withdraw.amount + withdraw.fee,
                                    ),
                                  },
                                },
                                { new: true },
                              );

                            const newBalanceLog = new this.BalanceLog({
                              name: `system's return disburse`,
                              balanceAmount:
                                updatedBalance.balance -
                                (withdraw.amount + withdraw.fee),
                              balanceCredit: Number(
                                withdraw.amount + withdraw.fee,
                              ),
                              type: BalanceLogType.Refund,
                              balance: balance._id,
                              withdraw: withdraw.id,
                            });

                            await newBalanceLog.save();

                            result = response.initSuccess(
                              ClientResponse.Success,
                              false,
                              objRes,
                            );
                          } else {
                            updateWithdraw.status = WithdrawStatus.Processing;

                            objRes.status = WithdrawStatus.Processing;
                            if (withdraw.bank.type === BankType.Cash) {
                              updateWithdraw.note = responseData.note;
                              updateWithdraw.exp = exp;

                              objRes.note = responseData.note;
                              objRes.expired = exp;
                              objRes.desc = `Success create ${withdraw.bank.name} transfer request`;
                            } else {
                              updateWithdraw.note =
                                responseData.response_desc ?? '';

                              objRes.note = withdraw.remark;
                              objRes.desc = `Processing your transfer to ${withdraw.name}-${withdraw.accNumber}`;
                            }

                            result = response.initSuccess(
                              ClientResponse.Success,
                              true,
                              objRes,
                            );
                          }

                          await this.Withdraw.findByIdAndUpdate(
                            withdraw.id,
                            updateWithdraw,
                          );

                          return res.status(200).send(result);
                        });
                      } else {
                        updateWithdraw.status = WithdrawStatus.Pending;

                        objRes.status = WithdrawStatus.Pending;

                        objRes.desc = `Your transfer request will undergo a review process by the NiagaPay team before it is processed further`;

                        await this.Withdraw.findByIdAndUpdate(
                          withdraw.id,
                          updateWithdraw,
                        );

                        sendWaNotif(
                          withdraw.withdrawId,
                          user.username,
                          toCurrency(withdraw.amount),
                        );

                        return res
                          .status(200)
                          .send(
                            response.initSuccess(
                              ClientResponse.Success,
                              true,
                              objRes,
                            ),
                          );
                      }
                    }
                  } else {
                    const error = response.initError(
                      ClientResponse.MethodNotFound,
                      false,
                      new ErrorMessage('Balance data not found'),
                    );
                    return res.status(200).send(error);
                  }
                });
              } else {
                const error = response.initError(
                  ClientResponse.InvalidSignature,
                  false,
                  new ErrorMessage('Invalid Signature'),
                );
                return res.status(200).send(error);
              }
            } else {
              const error = response.initError(
                ClientResponse.MethodNotFound,
                false,
                new ErrorMessage(`Transfer data not found`),
              );
              return res.status(200).send(error);
            }
          });
      } else {
        const error = response.initError(
          ClientResponse.MethodNotFound,
          false,
          new ErrorMessage(`${type} not exist`),
        );
        return res.status(200).send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async topupBalance(
    payload: TopupDto,
    type: string,
    req: FastifyOpenRequest,
    res: FastifyReply,
  ) {
    try {
      if (Object.values(MethodApiType).includes(type as MethodApiType)) {
        if (type === MethodApiType.Ewallet && !payload.phone) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage('Phone must not be empty'),
          );
          return res.status(200).send(error);
        } else {
          const { user, client } = req.user as {
            user: UserDocument;
            client: ClientDocument;
          };

          const xSig = req.headers['x-signature'];
          const xTime = req.headers['x-timestamp'];

          const signatureVerify = encryptHmac(
            'sha512',
            client.signatureKey,
            encryptHmac(
              'sha512',
              client.signatureKey + user.id + client.id + xTime,
              'POST' +
                '|' +
                `/topup/${type}` +
                '|' +
                hash('sha512', minifyJson(payload)).toLowerCase() +
                '|' +
                client.clientId +
                '|' +
                client.clientSecret,
              'hex',
            ) +
              '|' +
              client.clientId,
            'hex',
          );

          if (xSig === signatureVerify) {
            await this.Method.aggregate([
              {
                $match: {
                  code:
                    type === MethodApiType.Ewallet
                      ? 'PAY' + payload.method
                      : payload.method,
                  isActive: true,
                  type:
                    type === MethodApiType.Ewallet ? MethodType.Ewallet : type,
                },
              },
              {
                $lookup: {
                  from: 'fees',
                  let: { methodId: '$_id' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $and: [
                            { $eq: ['$method', '$$methodId'] },
                            { $eq: ['$feeType', FeeType.Transaction] },
                            { $eq: ['$user', { $toObjectId: user.id }] },
                          ],
                        },
                      },
                    },
                    {
                      $lookup: {
                        from: 'providers',
                        let: { providerId: '$provider' },
                        pipeline: [
                          {
                            $match: {
                              $expr: { $eq: ['$_id', '$$providerId'] },
                            },
                          },
                          {
                            $lookup: {
                              from: 'providers',
                              localField: 'providerRoot',
                              foreignField: '_id',
                              as: 'providerRoot',
                            },
                          },
                          {
                            $unwind: {
                              path: '$providerRoot',
                              preserveNullAndEmptyArrays: true,
                            },
                          },
                        ],
                        as: 'provider',
                      },
                    },
                    {
                      $unwind: '$provider',
                    },
                  ],
                  as: 'fee',
                },
              },
              {
                $unwind: '$fee',
              },
              {
                $lookup: {
                  from: 'valuetypes',
                  localField: 'fee.type',
                  foreignField: '_id',
                  as: 'fee.type',
                },
              },
              {
                $unwind: '$fee.type',
              },
            ]).then(async (methods) => {
              if (methods.length) {
                const method = methods[0];
                if (
                  method.fee.isActive &&
                  method.fee.provider &&
                  method.fee.provider.key
                ) {
                  if (payload.amount < method.min) {
                    const error = response.initError(
                      ClientResponse.InvalidData,
                      false,
                      new ErrorMessage(
                        `Minimal amount ${toCurrency(method.min)}`,
                      ),
                    );
                    return res.status(200).send(error);
                  } else if (payload.amount > method.max) {
                    const error = response.initError(
                      ClientResponse.InvalidData,
                      false,
                      new ErrorMessage(
                        `Maximal amount ${toCurrency(method.max)}`,
                      ),
                    );
                    return res.status(200).send(error);
                  } else {
                    await this.Transaction.findOne({
                      clientRef: payload.transactionRef,
                    }).then(async (trans) => {
                      if (trans) {
                        const error = response.initError(
                          ClientResponse.InvalidData,
                          false,
                          new ErrorMessage('Transaction Ref must be unique'),
                        );
                        return res.status(200).send(error);
                      } else {
                        let feeAmount: number;
                        switch (method.fee.type.name) {
                          case ValueType.Percentage:
                            feeAmount = Math.floor(
                              (payload.amount * method.fee.percentage) / 100,
                            );
                            break;
                          case ValueType.Fixed:
                            feeAmount = method.fee.fixed;
                            break;
                          default:
                            feeAmount = Math.floor(
                              (payload.amount * method.fee.percentage) / 100 +
                                method.fee.fixed,
                            );
                            break;
                        }

                        var keyDec: string;
                        if (method.fee.provider.key === 'root') {
                          keyDec = decrypt(
                            process.env.ENCRYPT_ALG,
                            hash(
                              'sha256',
                              method.fee.provider.providerRoot._id.valueOf(),
                            ).substring(0, 32),
                            hash(
                              'sha256',
                              method.fee.provider.providerRoot.user.valueOf() +
                                method.fee.provider.providerRoot.code,
                            ).substring(0, 16),
                            method.fee.provider.providerRoot.key,
                          );
                        } else {
                          keyDec = decrypt(
                            process.env.ENCRYPT_ALG,
                            hash(
                              'sha256',
                              method.fee.provider._id.valueOf(),
                            ).substring(0, 32),
                            hash(
                              'sha256',
                              method.fee.provider.user.valueOf() +
                                method.fee.provider.code,
                            ).substring(0, 16),
                            method.fee.provider.key,
                          );
                        }

                        const orderId = generateRandomNumber(
                          method.fee.provider.code === ProviderCodeType.Mpi
                            ? 20
                            : 50,
                        );
                        const key = JSON.parse(keyDec);
                        const amount = method.fee.onClient
                          ? payload.amount
                          : payload.amount + feeAmount;

                        if (
                          method.fee.provider.code === ProviderCodeType.Bnc &&
                          type === MethodApiType.Qris
                        ) {
                          const accessToken =
                            await this.providerService.getBncAccessToken(
                              key.clientId,
                            );

                          const expWib = new Date();
                          expWib.setMinutes(expWib.getMinutes() + 30);

                          const payloadPg = {
                            partnerReferenceNo: orderId,
                            amount: {
                              value: `${amount}`,
                              currency: 'IDR',
                            },
                            merchantId: key.merchantId,
                            storeId:
                              method.fee.provider.auditStatus === '2'
                                ? method.fee.provider.storeId
                                : method.fee.providerRoot.storeId,
                            terminalId: 'A01',
                            validityPeriod: '1800',
                            additionalInfo: {
                              qrType: '12',
                              tipType: '00',
                            },
                          };

                          const resultPg =
                            await this.providerService.generateQrisBnc(
                              key.clientId,
                              accessToken,
                              payloadPg,
                            );

                          const transactionId =
                            'T' +
                            hash('sha256', generateRandomNumber(5) + xTime);

                          const newTransaction = new this.Transaction({
                            clientCustName: client.clientName,
                            transactionId,
                            orderId,
                            refId: '',
                            amount,
                            fee: feeAmount,
                            feeAdmin: 0,
                            exp: expWib.getTime(),
                            method: new Types.ObjectId(method._id),
                            user: user.id,
                            clientRef: payload.transactionRef,
                            accessFrom: AccessFrom.Api,
                            ip: req.ip,
                            provider: method.fee.provider._id,
                            transactionType: TransactionType.Topup,
                          });

                          var result: SOPResponse;
                          const resObj: any = {
                            amount,
                            fee: feeAmount,
                            expired: expWib.getTime(),
                            method: payload.method,
                            methodName: method.name,
                            customerName: client.clientName,
                            ref1: payload.transactionRef,
                            ref2: transactionId,
                          };
                          if (resultPg) {
                            newTransaction.status =
                              TransactionStatusType.Pending;
                            newTransaction.payment = resultPg.qrContent;
                            newTransaction.refId = resultPg.referenceNo;

                            resObj.status = TransactionStatusType.Pending;
                            resObj.desc = 'Success generate QRIS';
                            resObj.qris = resultPg.qrContent;

                            result = response.initSuccess(
                              ClientResponse.Success,
                              true,
                              resObj,
                            );
                          } else {
                            newTransaction.status =
                              TransactionStatusType.Failed;

                            resObj.status = TransactionStatusType.Failed;
                            resObj.desc = 'Failed generate QRIS';

                            resObj.error = 'Bank Not Supported';

                            result = response.initSuccess(
                              ClientResponse.Success,
                              false,
                              resObj,
                            );
                          }
                          try {
                            await newTransaction.save();
                          } catch (err) {
                            result = response.initError(
                              ClientResponse.InvalidData,
                              false,
                              new ErrorMessage(
                                `Failed to save your transaction${
                                  err.code === 11000
                                    ? ', Duplicate Transaction Ref'
                                    : ''
                                }`,
                              ),
                            );
                          }
                          return res.status(200).send(result);
                        } else if (
                          type === MethodApiType.Va &&
                          method.name === 'BCA'
                        ) {
                          const expWib = new Date();
                          const expData = new Date(expWib);
                          expWib.setHours(expWib.getHours() + 19);
                          expData.setHours(expData.getHours() + 12);

                          const transactionId =
                            'T' +
                            hash('sha256', generateRandomNumber(5) + xTime);

                          const newTransaction = new this.Transaction({
                            clientCustName: client.clientName,
                            transactionId,
                            orderId,
                            refId: '',
                            amount,
                            fee: feeAmount,
                            exp: expData.getTime(),
                            method: new Types.ObjectId(method._id),
                            user: user.id,
                            clientRef: payload.transactionRef,
                            accessFrom: AccessFrom.Api,
                            ip: req.ip,
                            provider: method.fee.provider._id,
                            transactionType: TransactionType.Topup,
                          });

                          var result: SOPResponse;
                          const resObj: any = {
                            amount,
                            fee: feeAmount,
                            expired: expWib.getTime(),
                            method: payload.method,
                            methodName: method.name,
                            customerName: client.clientName,
                            ref1: payload.transactionRef,
                            ref2: transactionId,
                          };

                          if (
                            method.fee.provider.code === ProviderCodeType.Mpi
                          ) {
                            const jwt = Buffer.from(
                              `${key.storeId}:${key.username}:${key.password}:${key.pin}`,
                              'utf-8',
                            ).toString('base64');

                            const payloadPg = {
                              amount: amount,
                              idtrx: orderId,
                              email: EMAIL_NOT_PROVIDED,
                              firstName:
                                client.paymentClientName === 'root'
                                  ? client.clientName
                                  : client.paymentClientName,
                              lastName:
                                client.paymentCustName === 'root'
                                  ? client.clientName
                                  : client.paymentCustName,
                              phoneNumber: '08170025687',
                              merchantName: 'MPS VABCA',
                            };

                            const resultPg =
                              await this.providerService.generateBcaVaMpi(
                                jwt,
                                payloadPg,
                                key.pin,
                              );

                            if (resultPg) {
                              newTransaction.status =
                                TransactionStatusType.Pending;
                              newTransaction.payment = resultPg.va;
                              newTransaction.url = resultPg.url;
                              newTransaction.refId = resultPg.refId;

                              resObj.status = TransactionStatusType.Pending;
                              resObj.desc = 'Success generate Virtual Account';
                              resObj.va = resultPg.va;

                              result = response.initSuccess(
                                ClientResponse.Success,
                                true,
                                resObj,
                              );
                            } else {
                              newTransaction.status =
                                TransactionStatusType.Failed;

                              resObj.status = TransactionStatusType.Failed;
                              resObj.desc = 'Failed generate Virtual Account';

                              resObj.error = 'Bank Not Supported';

                              result = response.initSuccess(
                                ClientResponse.Success,
                                false,
                                resObj,
                              );
                            }
                          } else {
                            const error = response.initError(
                              ClientResponse.MethodNotAllowed,
                              false,
                              new ErrorMessage(`Bank not supported`),
                            );
                            return res.status(200).send(error);
                          }

                          try {
                            await newTransaction.save();
                          } catch (err) {
                            result = response.initError(
                              ClientResponse.InvalidData,
                              false,
                              new ErrorMessage(
                                `Failed to save your transaction${
                                  err.code === 11000
                                    ? ', Duplicate Transaction Ref'
                                    : ''
                                }`,
                              ),
                            );
                          }
                          return res.status(200).send(result);
                        } else {
                          const exp = new Date();
                          exp.setDate(exp.getDate() + 1);
                          const expWib = new Date(exp);
                          expWib.setHours(expWib.getHours() + 7);
                          const dateString = expWib
                            .toLocaleString('en-US', {
                              year: 'numeric',
                              month: '2-digit',
                              day: '2-digit',
                              hour: '2-digit',
                              minute: '2-digit',
                              second: '2-digit',
                            })
                            .replace(/\/|,|:| /g, '');
                          const formattedDate = `${dateString.slice(
                            4,
                            8,
                          )}${dateString.slice(0, 2)}${dateString.slice(
                            2,
                            4,
                          )}${dateString.slice(8, 14)}`;
                          const customerId = exp.getTime();

                          const reqMethod = 'POST';
                          const paramX = `${method.path}${reqMethod}`;
                          const paramY = `${amount}${formattedDate}${
                            type === MethodApiType.Qris ? '' : method.code
                          }${orderId}${customerId}${
                            client.paymentClientName === 'root'
                              ? client.clientName
                              : client.paymentClientName
                          }${EMAIL_NOT_PROVIDED}${
                            type === MethodApiType.Ewallet ? payload.phone : ''
                          }${key.clientId}`;
                          const sig = encryptHmac(
                            'sha256',
                            key.sigKey,
                            paramX +
                              paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
                            'hex',
                          );

                          const payloadPg: any = {
                            expired: formattedDate,
                            amount: Number(amount),
                            customer_id: Number(customerId),
                            partner_reff: orderId,
                            customer_email: EMAIL_NOT_PROVIDED,
                            username: key.username,
                            pin: key.pin,
                            customer_name: `${
                              client.paymentClientName === 'root'
                                ? client.clientName
                                : client.paymentClientName
                            }`,
                            signature: sig,
                          };

                          if (type === MethodApiType.Ewallet) {
                            payloadPg.ewallet_phone = payload.phone;
                            payloadPg.bill_title = 'NiagaPay';
                            payloadPg.retail_code = method.code;
                          } else if (type === MethodApiType.Retail) {
                            payloadPg.retail_code = method.code;
                            payloadPg.customer_phone = '081234567890';
                          } else if (type === MethodApiType.Va) {
                            payloadPg.bank_code = method.code;
                          }

                          const header = {
                            'Content-Type': CT_APP_JSON,
                            'client-id': key.clientId,
                            'client-secret': key.clientSecret,
                          };

                          await fetch(
                            process.env.PG_BASE_URL + method.path.substring(1),
                            {
                              method: reqMethod,
                              body: JSON.stringify(payloadPg),
                              headers: header,
                            },
                          ).then(async (responseFetch) => {
                            const responseData = await responseFetch.json();

                            const transactionId =
                              'T' +
                              hash('sha256', generateRandomNumber(5) + xTime);

                            const newTransaction = new this.Transaction({
                              clientCustName: client.clientName,
                              transactionId,
                              orderId,
                              refId: responseData.partner_reff2,
                              amount,
                              fee: feeAmount,
                              feeAdmin: responseData.feeadmin,
                              payment:
                                responseData.virtual_account ??
                                responseData.payment_code ??
                                responseData.qris_text,
                              url: responseData.url_payment,
                              exp,
                              method: new Types.ObjectId(method._id),
                              user: user.id,
                              clientRef: payload.transactionRef,
                              accessFrom: AccessFrom.Api,
                              provider: method.fee.provider._id,
                              transactionType: TransactionType.Topup,
                              ip: req.ip,
                            });

                            if (type === MethodApiType.Ewallet) {
                              newTransaction.phone = payload.phone;
                            }

                            var result: SOPResponse;
                            const resObj: any = {
                              amount,
                              fee: feeAmount,
                              expired: exp.getTime(),
                              method: payload.method,
                              methodName: method.name,
                              customerName: client.clientName,
                              ref1: payload.transactionRef,
                              ref2: transactionId,
                            };
                            if (
                              responseData.status === PgType.Success &&
                              responseData.response_code === PgType.SuccessCode
                            ) {
                              newTransaction.status =
                                TransactionStatusType.Pending;

                              resObj.status = TransactionStatusType.Pending;
                              resObj.desc = `Success generate ${
                                type === MethodApiType.Va
                                  ? 'Virtual Account'
                                  : type === MethodApiType.Retail
                                  ? 'Retail Payment Code'
                                  : type === MethodApiType.Qris
                                  ? 'QRIS'
                                  : type === MethodApiType.Ewallet
                                  ? 'Ewallet Transaction'
                                  : ''
                              }`;

                              if (type === MethodApiType.Va) {
                                resObj.va = responseData.virtual_account;
                              } else if (type === MethodApiType.Retail) {
                                resObj.paymentCode = responseData.payment_code;
                              } else if (type === MethodApiType.Qris) {
                                resObj.qris = responseData.qris_text;
                              } else if (type === MethodApiType.Ewallet) {
                                resObj.paymentCode = responseData.paymentCode;
                                resObj.deepLink = responseData.url_payment;
                              }

                              result = response.initSuccess(
                                ClientResponse.Success,
                                true,
                                resObj,
                              );
                            } else {
                              newTransaction.status =
                                TransactionStatusType.Failed;

                              resObj.status = TransactionStatusType.Failed;
                              resObj.desc =
                                type === MethodApiType.Va
                                  ? 'Failed generate Virtual Account'
                                  : type === MethodApiType.Retail
                                  ? 'Failed generate Retail Payment Code'
                                  : type === MethodApiType.Qris
                                  ? 'Failed generate QRIS'
                                  : type === MethodApiType.Ewallet
                                  ? 'Failed generate Ewallet Transaction'
                                  : '';

                              resObj.error =
                                type === MethodApiType.Va
                                  ? 'Bank Not Supported'
                                  : type === MethodApiType.Retail
                                  ? 'Retail Not Supported'
                                  : type === MethodApiType.Qris
                                  ? 'Bank Not Supported'
                                  : type === MethodApiType.Ewallet
                                  ? 'Ewallet Not Supported'
                                  : '';

                              result = response.initSuccess(
                                ClientResponse.Success,
                                false,
                                resObj,
                              );
                            }
                            try {
                              await newTransaction.save();
                            } catch (err) {
                              result = response.initError(
                                ClientResponse.InvalidData,
                                false,
                                new ErrorMessage(
                                  `Failed to save your transaction${
                                    err.code === 11000
                                      ? ', Duplicate Transaction Ref'
                                      : ''
                                  }`,
                                ),
                              );
                            }
                            return res.status(200).send(result);
                          });
                        }
                      }
                    });
                  }
                } else {
                  const error = response.initError(
                    ClientResponse.MethodNotAllowed,
                    false,
                    new ErrorMessage('Payment method not allowed'),
                  );
                  return res.status(200).send(error);
                }
              } else {
                const error = response.initError(
                  ClientResponse.MethodNotFound,
                  false,
                  new ErrorMessage('Payment method not found'),
                );
                return res.status(200).send(error);
              }
            });
          } else {
            const error = response.initError(
              ClientResponse.InvalidSignature,
              false,
              new ErrorMessage('Invalid Signature'),
            );
            return res.status(200).send(error);
          }
        }
      } else {
        const error = response.initError(
          ClientResponse.MethodNotFound,
          false,
          new ErrorMessage(`${type} not exist`),
        );
        return res.status(200).send(error);
      }
    } catch (err) {
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async checkStatus(
    type: string,
    clientRef: string,
    req: FastifyOpenRequest,
    res: FastifyReply,
  ) {
    try {
      if (Object.values(MethodApi2Type).includes(type as MethodApi2Type)) {
        const { user } = req.user;

        var result: SOPResponse;
        if (type === 'payment' || type === 'topup') {
          await this.Transaction.findOne({
            transactionType:
              type === 'payment'
                ? TransactionType.Transaction
                : TransactionType.Topup,
            clientRef,
            user: user.id,
          })
            .populate('method')
            .then(async (transaction: any) => {
              if (transaction) {
                const resObj: any = {
                  amount: transaction.amount,
                  fee: transaction.fee,
                  expired: transaction.exp,
                  method: transaction.method.code,
                  methodName: transaction.method.name,
                  customerName: transaction.clientCustName,
                  ref1: transaction.clientRef,
                  ref2: transaction.transactionId,
                  status: transaction.status,
                  desc: `Your ${
                    transaction.method.type === MethodType.Va
                      ? 'Virtual Account'
                      : transaction.method.type === MethodType.Retail
                      ? 'Retail'
                      : transaction.method.type === MethodType.Qris
                      ? 'QRIS'
                      : transaction.method.type === MethodType.Ewallet
                      ? 'Ewallet'
                      : ''
                  } Topup is ${
                    transaction.status === TransactionStatusType.Paid
                      ? 'Paid'
                      : transaction.status === TransactionStatusType.Settled
                      ? 'Settled to your balance'
                      : transaction.status === TransactionStatusType.Failed
                      ? 'Failed'
                      : 'Expired'
                  }`,
                };

                if (transaction.method.type === MethodType.Ewallet) {
                  resObj.phone = transaction.phone;
                }

                if (
                  transaction.status === TransactionStatusType.Paid ||
                  transaction.status === TransactionStatusType.Settled
                ) {
                  resObj.paidTime = transaction.paidTime;
                  resObj.serialNumber = transaction.serialNumber;
                  if (transaction.status === TransactionStatusType.Settled) {
                    resObj.settleTime = transaction.clientSettleDate;
                  }
                }

                result = response.initSuccess(
                  ClientResponse.Success,
                  true,
                  resObj,
                );
              } else {
                result = response.initError(
                  ClientResponse.MethodNotFound,
                  false,
                  new ErrorMessage('Transaction data not found'),
                );
              }
            });
        } else {
          await this.Withdraw.findOne({
            process: WithdrawProcess.Process,
            clientRef,
            user: user.id,
          })
            .populate('bank')
            .then(async (withdraw: any) => {
              if (withdraw) {
                const resObj: any = {
                  amount: withdraw.amount,
                  fee: withdraw.fee,
                  channelName: withdraw.bank.name,
                  accountNumber:
                    withdraw.bank.type === BankType.Cash
                      ? ''
                      : withdraw.accNumber,
                  name:
                    withdraw.bank.type === BankType.Cash
                      ? `Cash Transfer ${withdraw.bank.name}`
                      : withdraw.name,
                  ref1: withdraw.clientRef,
                  ref2: withdraw.withdrawId,
                  status: withdraw.status,
                  desc: `${
                    withdraw.status === WithdrawStatus.Success
                      ? 'Success'
                      : withdraw.status === WithdrawStatus.Pending
                      ? 'Pending'
                      : withdraw.status === WithdrawStatus.Processing
                      ? 'Processing'
                      : withdraw.status === WithdrawStatus.Failed
                      ? 'Failed'
                      : 'Rejected'
                  } transfer to ${
                    withdraw.bank.type === BankType.Cash
                      ? `${withdraw.bank.name}`
                      : `${withdraw.name}-${withdraw.accNumber}`
                  }`,
                };

                if (withdraw.bank.type === BankType.Cash) {
                  resObj.note = withdraw.note;
                  resObj.expired = withdraw.exp;
                }

                if (withdraw.status === WithdrawStatus.Success) {
                  resObj.paidDate = withdraw.paidDate;
                }

                result = response.initSuccess(
                  ClientResponse.Success,
                  true,
                  resObj,
                );
              } else {
                result = response.initError(
                  ClientResponse.MethodNotFound,
                  false,
                  new ErrorMessage('Transfer data not found'),
                );
              }
            });
        }

        return res.status(200).send(result);
      } else {
        const error = response.initError(
          ClientResponse.MethodNotFound,
          false,
          new ErrorMessage(`${type} not exist`),
        );
        return res.status(200).send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  // DEV

  async getDevBalance(req: FastifyOpenRequest, res: FastifyReply) {
    try {
      try {
        const { user } = req.user;
        await this.DevBalance.findOne({ user: user.id })
          .select('-_id balance pending freeze debt')
          .then((balance) => {
            if (balance) {
              const success = response.initSuccess(200, true, balance);
              return res.status(200).send(success);
            } else {
              const error = response.initError(
                ClientResponse.MethodNotFound,
                false,
                new ErrorMessage("There's no balance data"),
              );
              return res.status(200).send(error);
            }
          });
      } catch (err) {
        console.log(err);
        const error = response.initError(
          ClientResponse.ServerError,
          false,
          new ErrorMessage("There's an error on the server, please wait :)"),
        );
        return res.status(200).send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async generateDevPayment(
    payload: GeneratePaymentDto,
    type: string,
    req: FastifyOpenRequest,
    res: FastifyReply,
  ) {
    try {
      if (Object.values(MethodApiType).includes(type as MethodApiType)) {
        if (type === MethodApiType.Ewallet && !payload.phone) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage('Phone must not be empty'),
          );
          return res.status(200).send(error);
        } else {
          const { user, client } = req.user as {
            user: UserDocument;
            client: DevClientDocument;
          };

          const xSig = req.headers['x-signature'];
          const xTime = req.headers['x-timestamp'];

          const signatureVerify = encryptHmac(
            'sha512',
            client.signatureKey,
            encryptHmac(
              'sha512',
              client.signatureKey + user.id + client.id + xTime,
              'POST' +
                '|' +
                `/generate/${type}` +
                '|' +
                hash('sha512', minifyJson(payload)).toLowerCase() +
                '|' +
                client.clientId +
                '|' +
                client.clientSecret,
              'hex',
            ) +
              '|' +
              client.clientId,
            'hex',
          );

          if (xSig === signatureVerify) {
            await this.Method.aggregate([
              {
                $match: {
                  code:
                    type === MethodApiType.Ewallet
                      ? 'PAY' + payload.method
                      : payload.method,
                  isActive: true,
                  type:
                    type === MethodApiType.Ewallet ? MethodType.Ewallet : type,
                },
              },
              {
                $lookup: {
                  from: 'fees',
                  let: { methodId: '$_id' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $and: [
                            { $eq: ['$method', '$$methodId'] },
                            { $eq: ['$feeType', FeeType.Transaction] },
                            { $eq: ['$user', { $toObjectId: user.id }] },
                          ],
                        },
                      },
                    },
                  ],
                  as: 'fee',
                },
              },
              {
                $unwind: '$fee',
              },
              {
                $lookup: {
                  from: 'valuetypes',
                  localField: 'fee.type',
                  foreignField: '_id',
                  as: 'fee.type',
                },
              },
              {
                $unwind: '$fee.type',
              },
            ]).then(async (methods) => {
              if (methods.length) {
                const method = methods[0];
                if (method.fee.isActive) {
                  if (payload.amount < method.min) {
                    const error = response.initError(
                      ClientResponse.InvalidData,
                      false,
                      new ErrorMessage(
                        `Minimal amount ${toCurrency(method.min)}`,
                      ),
                    );
                    return res.status(200).send(error);
                  } else if (payload.amount > method.max) {
                    const error = response.initError(
                      ClientResponse.InvalidData,
                      false,
                      new ErrorMessage(
                        `Maximal amount ${toCurrency(method.max)}`,
                      ),
                    );
                    return res.status(200).send(error);
                  } else {
                    const exp = new Date(Number(payload.expired));
                    if (exp.toString() === 'Invalid Date') {
                      const error = response.initError(
                        ClientResponse.InvalidData,
                        false,
                        new ErrorMessage('Invalid millis'),
                      );
                      return res.status(200).send(error);
                    } else {
                      const today = new Date();

                      if (today <= exp) {
                        await this.DevTransaction.findOne({
                          clientRef: payload.transactionRef,
                        }).then(async (trans) => {
                          if (trans) {
                            const error = response.initError(
                              ClientResponse.InvalidData,
                              false,
                              new ErrorMessage(
                                'Transaction Ref must be unique',
                              ),
                            );
                            return res.status(200).send(error);
                          } else {
                            const orderId = generateRandomNumber(50);

                            let feeAmount: number;
                            switch (method.fee.type.name) {
                              case ValueType.Percentage:
                                feeAmount = Math.floor(
                                  (payload.amount * method.fee.percentage) /
                                    100,
                                );
                                break;
                              case ValueType.Fixed:
                                feeAmount = method.fee.fixed;
                                break;
                              default:
                                feeAmount = Math.floor(
                                  (payload.amount * method.fee.percentage) /
                                    100 +
                                    method.fee.fixed,
                                );
                                break;
                            }

                            const amount = method.fee.onClient
                              ? payload.amount
                              : payload.amount + feeAmount;

                            const transactionId =
                              'T' +
                              hash('sha256', generateRandomNumber(25) + xTime);

                            const newDevTransaction = new this.DevTransaction({
                              clientCustName: payload.customerName,
                              transactionId,
                              orderId,
                              refId: 'dev_refId',
                              amount,
                              fee: feeAmount,
                              feeAdmin: 0,
                              payment: `${
                                type === MethodApiType.Qris ? 'qris_test_' : ''
                              }${generateRandomNumber(15)}`,
                              exp,
                              method: new Types.ObjectId(method._id),
                              user: user.id,
                              clientRef: payload.transactionRef,
                              accessFrom: AccessFrom.Api,
                              status: TransactionStatusType.Pending,
                              ip: req.ip,
                            });

                            if (type === MethodApiType.Ewallet) {
                              newDevTransaction.phone = payload.phone;
                              newDevTransaction.url = `deeplink_test_${generateRandomNumber(
                                20,
                              )}`;
                            }

                            await newDevTransaction.save();

                            const resObj: any = {
                              amount,
                              fee: feeAmount,
                              expired: exp.getTime(),
                              method: payload.method,
                              methodName: method.name,
                              customerName: payload.customerName,
                              ref1: payload.transactionRef,
                              ref2: transactionId,
                              status: TransactionStatusType.Pending,
                              desc: `Success generate ${
                                type === MethodApiType.Va
                                  ? 'Virtual Account'
                                  : type === MethodApiType.Retail
                                  ? 'Retail Payment Code'
                                  : type === MethodApiType.Qris
                                  ? 'QRIS'
                                  : type === MethodApiType.Ewallet
                                  ? 'Ewallet Transaction'
                                  : ''
                              }`,
                            };

                            if (type === MethodApiType.Va) {
                              resObj.va = newDevTransaction.payment;
                            } else if (type === MethodApiType.Retail) {
                              resObj.paymentCode = newDevTransaction.payment;
                            } else if (type === MethodApiType.Qris) {
                              resObj.qris = newDevTransaction.payment;
                            } else if (type === MethodApiType.Ewallet) {
                              resObj.phone = payload.phone;
                              resObj.paymentCode = newDevTransaction.payment;
                              resObj.deepLink = newDevTransaction.url;
                            }

                            return res
                              .status(200)
                              .send(
                                response.initSuccess(
                                  ClientResponse.Success,
                                  true,
                                  resObj,
                                ),
                              );
                          }
                        });
                      } else {
                        const error = response.initError(
                          ClientResponse.InvalidData,
                          false,
                          new ErrorMessage(
                            'Expired must be greater than today',
                          ),
                        );
                        return res.status(200).send(error);
                      }
                    }
                  }
                } else {
                  const error = response.initError(
                    ClientResponse.MethodNotAllowed,
                    false,
                    new ErrorMessage('Payment method not allowed'),
                  );
                  return res.status(200).send(error);
                }
              } else {
                const error = response.initError(
                  ClientResponse.MethodNotFound,
                  false,
                  new ErrorMessage('Payment method not found'),
                );
                return res.status(200).send(error);
              }
            });
          } else {
            const error = response.initError(
              ClientResponse.InvalidSignature,
              false,
              new ErrorMessage('Invalid Signature'),
            );
            return res.status(200).send(error);
          }
        }
      } else {
        const error = response.initError(
          ClientResponse.MethodNotFound,
          false,
          new ErrorMessage(`${type} not exist`),
        );
        return res.status(200).send(error);
      }
    } catch (err) {
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async transferDevInquiry(
    payload: TransferInquiryDto,
    type: string,
    req: FastifyOpenRequest,
    res: FastifyReply,
  ) {
    try {
      console.log('Inquiry: ', req.body, req.headers, req.url);
      const validBankTypes = Object.values(BankType).filter(
        (value) => value !== BankType.CC,
      );
      if (validBankTypes.includes(type as BankType)) {
        if (type !== BankType.Cash && !payload.accountNumber) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage('Bank Account must not be empty'),
          );
          return res.status(200).send(error);
        } else if (
          type === BankType.Cash &&
          !payload.customerEmail &&
          !payload.customerPhone
        ) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage(
              'Customer email and Customer phone must not be empty for Cash transfer',
            ),
          );
          return res.status(200).send(error);
        }
        const { user, client } = req.user as {
          user: UserDocument;
          client: DevClientDocument;
        };

        const xSig = req.headers['x-signature'];
        const xTime = req.headers['x-timestamp'];

        const signatureVerify = encryptHmac(
          'sha512',
          client.signatureKey,
          encryptHmac(
            'sha512',
            client.signatureKey + user.id + client.id + xTime,
            'POST' +
              '|' +
              `/transfer/${type}/inquiry` +
              '|' +
              hash('sha512', minifyJson(payload)).toLowerCase() +
              '|' +
              client.clientId +
              '|' +
              client.clientSecret,
            'hex',
          ) +
            '|' +
            client.clientId,
          'hex',
        );

        if (xSig === signatureVerify) {
          await this.Bank.aggregate([
            {
              $match: {
                code: payload.channelCode,
                type: type,
                isActive: true,
              },
            },
            {
              $lookup: {
                from: 'fees',
                let: { bankId: '$_id' },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          type === BankType.Ewallet || type === BankType.Cash
                            ? { $eq: ['$bank', '$$bankId'] }
                            : {},
                          { $eq: ['$feeType', type] },
                          { $eq: ['$user', { $toObjectId: user.id }] },
                        ],
                      },
                    },
                  },
                ],
                as: 'fee',
              },
            },
            {
              $unwind: '$fee',
            },
            {
              $lookup: {
                from: 'valuetypes',
                localField: 'fee.type',
                foreignField: '_id',
                as: 'fee.type',
              },
            },
            {
              $unwind: '$fee.type',
            },
          ]).then(async (banks) => {
            if (banks.length) {
              const bank = banks[0];
              if (bank.fee.isActive) {
                if (payload.amount > client.limit) {
                  const error = response.initError(
                    ClientResponse.InvalidData,
                    false,
                    new ErrorMessage(
                      `Your account limit is ${toCurrency(client.limit)}`,
                    ),
                  );
                  return res.status(200).send(error);
                } else if (payload.amount < bank.min) {
                  const error = response.initError(
                    ClientResponse.InvalidData,
                    false,
                    new ErrorMessage(`Minimal amount ${toCurrency(bank.min)}`),
                  );
                  return res.status(200).send(error);
                } else if (payload.amount > bank.max) {
                  const error = response.initError(
                    ClientResponse.InvalidData,
                    false,
                    new ErrorMessage(`Maximal amount ${toCurrency(bank.max)}`),
                  );
                  return res.status(200).send(error);
                } else if (
                  type === BankType.Cash &&
                  payload.amount % bank.multiple !== 0
                ) {
                  const error = response.initError(
                    ClientResponse.InvalidData,
                    false,
                    new ErrorMessage(
                      `Amount must be a multiple of  ${toCurrency(
                        bank.multiple,
                      )}`,
                    ),
                  );
                  return res.status(200).send(error);
                } else {
                  await this.DevBalance.findOne({
                    user: user.id,
                  }).then(async (balanceFound) => {
                    if (balanceFound) {
                      await this.DevWithdraw.findOne({
                        clientRef: payload.transferRef,
                      }).then(async (trans) => {
                        if (trans) {
                          const error = response.initError(
                            ClientResponse.InvalidData,
                            false,
                            new ErrorMessage('Transfer Ref must be unique'),
                          );
                          return res.status(200).send(error);
                        } else {
                          let feeAmount: number;
                          switch (bank.fee.type.name) {
                            case ValueType.Percentage:
                              feeAmount = Math.floor(
                                (payload.amount * bank.fee.percentage) / 100,
                              );
                              break;
                            case ValueType.Fixed:
                              feeAmount = bank.fee.fixed;
                              break;
                            default:
                              feeAmount = Math.floor(
                                (payload.amount * bank.fee.percentage) / 100 +
                                  bank.fee.fixed,
                              );
                              break;
                          }

                          if (
                            balanceFound.balance <
                            payload.amount + feeAmount
                          ) {
                            const error = response.initError(
                              ClientResponse.InvalidData,
                              false,
                              new ErrorMessage('Balance is not enough'),
                            );
                            return res.status(200).send(error);
                          }

                          const orderId = generateRandomNumber(50);
                          const withdrawId =
                            'D' +
                            hash('sha256', generateRandomNumber(25) + xTime);
                          const signature = encryptHmac(
                            'sha512',
                            xTime +
                              user.username +
                              user.pass +
                              client.signatureKey,
                            'POST' +
                              `/transfer/${type}/payment` +
                              hash(
                                'sha512',
                                minifyJson(
                                  sortKeys({
                                    ...payload,
                                    paymentRef: withdrawId,
                                  }),
                                ),
                              ).toLowerCase() +
                              '|' +
                              client.clientId +
                              '|' +
                              client.clientSecret +
                              '|' +
                              user.id +
                              '|' +
                              withdrawId,
                            'hex',
                          );

                          const newDevWithdraw = new this.DevWithdraw({
                            withdrawId,
                            orderId,
                            amount: payload.amount,
                            fee: feeAmount,
                            feeAdmin: 0,
                            withdrawType: WithdrawType.Client,
                            inquiryBy: user.id,
                            bank: new Types.ObjectId(bank._id),
                            accessFrom: AccessFrom.Api,
                            user: user.id,
                            clientRef: payload.transferRef,
                            ip: req.ip,
                          });

                          if (payload.remark) {
                            newDevWithdraw.remark = payload.remark;
                          }

                          if (type === BankType.Cash) {
                            newDevWithdraw.name = `Cash Transfer ${bank.name}`;
                            newDevWithdraw.email = payload.customerEmail;
                            newDevWithdraw.phone = payload.customerPhone;
                          } else {
                            newDevWithdraw.name = 'test_transfer_name';
                            newDevWithdraw.accNumber = payload.accountNumber;
                          }

                          await newDevWithdraw.save();

                          const success = response.initSuccess(
                            ClientResponse.Success,
                            true,
                            {
                              signature,
                              amount: payload.amount,
                              channelName: bank.name,
                              accountNumber:
                                type === BankType.Cash
                                  ? ''
                                  : payload.accountNumber,
                              name: newDevWithdraw.name,
                              ref1: payload.transferRef,
                              ref2: withdrawId,
                              desc: 'Success create Transfer inquiry',
                              fee: feeAmount,
                            },
                          );
                          console.log('Inquiry Res: ', success);
                          return res.status(200).send(success);
                        }
                      });
                    } else {
                      const error = response.initError(
                        ClientResponse.MethodNotFound,
                        false,
                        new ErrorMessage('Balance data not found'),
                      );
                      return res.status(200).send(error);
                    }
                  });
                }
              } else {
                const error = response.initError(
                  ClientResponse.MethodNotAllowed,
                  false,
                  new ErrorMessage('Bank not allowed'),
                );
                return res.status(200).send(error);
              }
            } else {
              const error = response.initError(
                ClientResponse.MethodNotFound,
                false,
                new ErrorMessage('Bank not found'),
              );
              return res.status(200).send(error);
            }
          });
        } else {
          const error = response.initError(
            ClientResponse.InvalidSignature,
            false,
            new ErrorMessage('Invalid Signature'),
          );
          return res.status(200).send(error);
        }
      } else {
        const error = response.initError(
          ClientResponse.MethodNotFound,
          false,
          new ErrorMessage(`${type} not exist`),
        );
        return res.status(200).send(error);
      }
    } catch (err) {
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async transferDevPayment(
    payload: TransferPaymentDto,
    type: string,
    req: FastifyOpenRequest,
    res: FastifyReply,
  ) {
    try {
      console.log('Payment: ', req.body, req.headers, req.url);
      const validBankTypes = Object.values(BankType).filter(
        (value) => value !== BankType.CC,
      );
      if (validBankTypes.includes(type as BankType)) {
        if (type !== BankType.Cash && !payload.paymentRef) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage('Payment Ref must not be empty'),
          );
          return res.status(200).send(error);
        } else if (type !== BankType.Cash && !payload.accountNumber) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage('Bank Account must not be empty'),
          );
          return res.status(200).send(error);
        } else if (
          type === BankType.Cash &&
          !payload.customerEmail &&
          !payload.customerPhone
        ) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage(
              'Customer email and Customer phone must not be empty for Cash transfer',
            ),
          );
          return res.status(200).send(error);
        }

        const { user, client } = req.user as {
          user: UserDocument;
          client: DevClientDocument;
        };

        await this.DevWithdraw.findOne({
          clientRef: payload.transferRef,
          withdrawId: payload.paymentRef,
          user: new Types.ObjectId(user.id),
        })
          .populate('bank')
          .then(async (withdraw: any) => {
            if (withdraw) {
              const xSig = req.headers['x-signature'];
              const xTime = req.headers['x-timestamp'];
              const signatureVerify = encryptHmac(
                'sha512',
                client.signatureKey,
                encryptHmac(
                  'sha512',
                  client.signatureKey + user.id + client.id + xTime,
                  'POST' +
                    '|' +
                    `/transfer/${type}/payment` +
                    '|' +
                    hash('sha512', minifyJson(payload)).toLowerCase() +
                    '|' +
                    client.clientId +
                    '|' +
                    client.clientSecret,
                  'hex',
                ) +
                  '|' +
                  client.clientId +
                  '|' +
                  encryptHmac(
                    'sha512',
                    xTime + user.username + user.pass + client.signatureKey,
                    'POST' +
                      `/transfer/${type}/payment` +
                      hash(
                        'sha512',
                        minifyJson(sortKeys(payload)),
                      ).toLowerCase() +
                      '|' +
                      client.clientId +
                      '|' +
                      client.clientSecret +
                      '|' +
                      user.id +
                      '|' +
                      withdraw.withdrawId,
                    'hex',
                  ),
                'hex',
              );
              if (xSig === signatureVerify) {
                await this.DevBalance.aggregate([
                  {
                    $match: {
                      $expr: { $eq: ['$user', { $toObjectId: user.id }] },
                    },
                  },
                ]).then(async (balances: any) => {
                  if (balances.length) {
                    const balance = balances[0];
                    if (balance.balance < withdraw.amount + withdraw.fee) {
                      const error = response.initError(
                        403,
                        false,
                        new ErrorMessage('Balance is not enough'),
                      );
                      return res.status(200).send(error);
                    } else {
                      await this.DevBalance.findByIdAndUpdate(balance._id, {
                        $inc: {
                          balance: -Number(withdraw.amount + withdraw.fee),
                        },
                      });

                      const exp = new Date();
                      exp.setDate(exp.getDate() + 1);

                      const updateWithdraw: any = {
                        process: WithdrawProcess.Process,
                        processedBy: user.id,
                        processedDate: new Date(),
                        uplineFee: [],
                        paidReff: 'dev',
                      };

                      const objRes: any = {
                        amount: withdraw.amount,
                        fee: withdraw.fee,
                        channelName: withdraw.bank.name,
                        accountNumber:
                          withdraw.bank.type === BankType.Cash
                            ? ''
                            : payload.accountNumber,
                        name:
                          withdraw.bank.type === BankType.Cash
                            ? `Cash Transfer ${withdraw.bank.name}`
                            : withdraw.name,
                        ref1: withdraw.clientRef,
                        ref2: withdraw.withdrawId,
                      };

                      if (withdraw.bank.type === BankType.Cash) {
                        updateWithdraw.serialNumber = '';
                        updateWithdraw.exp = exp;
                        updateWithdraw.note = 'note_dev';
                        updateWithdraw.status = WithdrawStatus.Processing;

                        objRes.note = updateWithdraw.note;
                        objRes.expired = exp;
                        objRes.status = WithdrawStatus.Processing;
                        objRes.desc = `Success create ${withdraw.bank.name} transfer request`;
                      } else {
                        updateWithdraw.serialNumber = 'serialNumber_dev';
                        updateWithdraw.status = WithdrawStatus.Success;
                        updateWithdraw.paidDate = new Date();

                        objRes.status = WithdrawStatus.Success;
                        objRes.paidDate = updateWithdraw.paidDate;
                        objRes.desc = `Success transfer to ${withdraw.name}-${withdraw.accNumber}`;
                      }

                      await this.DevWithdraw.findByIdAndUpdate(
                        withdraw.id,
                        updateWithdraw,
                      );

                      return res
                        .status(200)
                        .send(
                          response.initSuccess(
                            ClientResponse.Success,
                            true,
                            objRes,
                          ),
                        );
                    }
                  } else {
                    const error = response.initError(
                      ClientResponse.MethodNotFound,
                      false,
                      new ErrorMessage('Balance data not found'),
                    );
                    return res.status(200).send(error);
                  }
                });
              } else {
                const error = response.initError(
                  ClientResponse.InvalidSignature,
                  false,
                  new ErrorMessage('Invalid Signature'),
                );
                return res.status(200).send(error);
              }
            } else {
              const error = response.initError(
                ClientResponse.MethodNotFound,
                false,
                new ErrorMessage(`Transfer data not found`),
              );
              return res.status(200).send(error);
            }
          });
      } else {
        const error = response.initError(
          ClientResponse.MethodNotFound,
          false,
          new ErrorMessage(`${type} not exist`),
        );
        return res.status(200).send(error);
      }
    } catch (err) {
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async topupDevBalance(
    payload: TopupDto,
    type: string,
    req: FastifyOpenRequest,
    res: FastifyReply,
  ) {
    try {
      if (Object.values(MethodApiType).includes(type as MethodApiType)) {
        if (type === MethodApiType.Ewallet && !payload.phone) {
          const error = response.initError(
            ClientResponse.InvalidData,
            false,
            new ErrorMessage('Phone must not be empty'),
          );
          return res.status(200).send(error);
        } else {
          const { user, client } = req.user;
          const xSig = req.headers['x-signature'];
          const xTime = req.headers['x-timestamp'];

          const signatureVerify = encryptHmac(
            'sha512',
            client.signatureKey,
            encryptHmac(
              'sha512',
              client.signatureKey + user.id + client.id + xTime,
              'POST' +
                '|' +
                `/topup/${type}` +
                '|' +
                hash('sha512', minifyJson(payload)).toLowerCase() +
                '|' +
                client.clientId +
                '|' +
                client.clientSecret,
              'hex',
            ) +
              '|' +
              client.clientId,
            'hex',
          );

          if (xSig === signatureVerify) {
            await this.Method.aggregate([
              {
                $match: {
                  code:
                    type === MethodApiType.Ewallet
                      ? 'PAY' + payload.method
                      : payload.method,
                  isActive: true,
                  type:
                    type === MethodApiType.Ewallet ? MethodType.Ewallet : type,
                },
              },
              {
                $lookup: {
                  from: 'fees',
                  let: { methodId: '$_id' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $and: [
                            { $eq: ['$method', '$$methodId'] },
                            { $eq: ['$feeType', FeeType.Transaction] },
                            { $eq: ['$user', { $toObjectId: user.id }] },
                          ],
                        },
                      },
                    },
                  ],
                  as: 'fee',
                },
              },
              {
                $unwind: '$fee',
              },
              {
                $lookup: {
                  from: 'valuetypes',
                  localField: 'fee.type',
                  foreignField: '_id',
                  as: 'fee.type',
                },
              },
              {
                $unwind: '$fee.type',
              },
            ]).then(async (methods) => {
              if (methods.length) {
                const method = methods[0];
                if (method.fee.isActive) {
                  if (payload.amount < method.min) {
                    const error = response.initError(
                      ClientResponse.InvalidData,
                      false,
                      new ErrorMessage(
                        `Minimal amount ${toCurrency(method.min)}`,
                      ),
                    );
                    return res.status(200).send(error);
                  } else if (payload.amount > method.max) {
                    const error = response.initError(
                      ClientResponse.InvalidData,
                      false,
                      new ErrorMessage(
                        `Maximal amount ${toCurrency(method.max)}`,
                      ),
                    );
                    return res.status(200).send(error);
                  } else {
                    const exp = new Date();
                    exp.setDate(exp.getDate() + 1);
                    await this.Transaction.findOne({
                      clientRef: payload.transactionRef,
                    }).then(async (trans) => {
                      if (trans) {
                        const error = response.initError(
                          ClientResponse.InvalidData,
                          false,
                          new ErrorMessage('Transaction Ref must be unique'),
                        );
                        return res.status(200).send(error);
                      } else {
                        const dateString = exp
                          .toLocaleString('en-US', {
                            year: 'numeric',
                            month: '2-digit',
                            day: '2-digit',
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                          })
                          .replace(/\/|,|:| /g, '');
                        const formattedDate = `${dateString.slice(
                          4,
                          8,
                        )}${dateString.slice(0, 2)}${dateString.slice(
                          2,
                          4,
                        )}${dateString.slice(8, 14)}`;
                        const orderId = generateRandomNumber(50);
                        const customerId = exp.getTime();

                        let feeAmount: number;
                        switch (method.fee.type.name) {
                          case ValueType.Percentage:
                            feeAmount = Math.floor(
                              (payload.amount * method.fee.percentage) / 100,
                            );
                            break;
                          case ValueType.Fixed:
                            feeAmount = method.fee.fixed;
                            break;
                          default:
                            feeAmount = Math.floor(
                              (payload.amount * method.fee.percentage) / 100 +
                                method.fee.fixed,
                            );
                            break;
                        }

                        const amount = method.fee.onClient
                          ? payload.amount
                          : payload.amount + feeAmount;

                        const transactionId =
                          'T' +
                          hash('sha256', generateRandomNumber(25) + xTime);

                        const newDevTransaction = new this.DevTransaction({
                          clientCustName: client.clientName,
                          transactionId,
                          orderId,
                          refId: 'dev_topupRefId',
                          amount,
                          fee: feeAmount,
                          feeAdmin: 0,
                          payment: `${
                            type === MethodApiType.Qris ? 'qris_test_' : ''
                          }${generateRandomNumber(15)}`,
                          exp,
                          method: new Types.ObjectId(method._id),
                          user: user.id,
                          clientRef: payload.transactionRef,
                          accessFrom: AccessFrom.Api,
                          transactionType: TransactionType.Topup,
                          status: TransactionStatusType.Pending,
                          ip: req.ip,
                        });

                        if (type === MethodApiType.Ewallet) {
                          newDevTransaction.phone = payload.phone;
                          newDevTransaction.url = `deeplink_test_${generateRandomNumber(
                            20,
                          )}`;
                        }

                        await newDevTransaction.save();

                        const resObj: any = {
                          amount,
                          fee: feeAmount,
                          expired: exp.getTime(),
                          method: payload.method,
                          methodName: method.name,
                          customerName: client.clientName,
                          ref1: payload.transactionRef,
                          ref2: transactionId,
                          status: TransactionStatusType.Pending,
                          desc: `Success generate ${
                            type === MethodApiType.Va
                              ? 'Virtual Account'
                              : type === MethodApiType.Retail
                              ? 'Retail Payment Code'
                              : type === MethodApiType.Qris
                              ? 'QRIS'
                              : type === MethodApiType.Ewallet
                              ? 'Ewallet Transaction'
                              : ''
                          }`,
                        };

                        if (type === MethodApiType.Va) {
                          resObj.va = newDevTransaction.payment;
                        } else if (type === MethodApiType.Retail) {
                          resObj.paymentCode = newDevTransaction.payment;
                        } else if (type === MethodApiType.Qris) {
                          resObj.qris = newDevTransaction.payment;
                        } else if (type === MethodApiType.Ewallet) {
                          resObj.phone = payload.phone;
                          resObj.paymentCode = newDevTransaction.payment;
                          resObj.deepLink = newDevTransaction.url;
                        }

                        return res
                          .status(200)
                          .send(
                            response.initSuccess(
                              ClientResponse.Success,
                              true,
                              resObj,
                            ),
                          );
                      }
                    });
                  }
                } else {
                  const error = response.initError(
                    ClientResponse.MethodNotAllowed,
                    false,
                    new ErrorMessage('Payment method not allowed'),
                  );
                  return res.status(200).send(error);
                }
              } else {
                const error = response.initError(
                  ClientResponse.MethodNotFound,
                  false,
                  new ErrorMessage('Payment method not found'),
                );
                return res.status(200).send(error);
              }
            });
          } else {
            const error = response.initError(
              ClientResponse.InvalidSignature,
              false,
              new ErrorMessage('Invalid Signature'),
            );
            return res.status(200).send(error);
          }
        }
      } else {
        const error = response.initError(
          ClientResponse.MethodNotFound,
          false,
          new ErrorMessage(`${type} not exist`),
        );
        return res.status(200).send(error);
      }
    } catch (err) {
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async checkDevStatus(
    type: string,
    clientRef: string,
    req: FastifyOpenRequest,
    res: FastifyReply,
  ) {
    try {
      if (Object.values(MethodApi2Type).includes(type as MethodApi2Type)) {
        const { user } = req.user;

        var result: SOPResponse;
        if (type === 'payment' || type === 'topup') {
          await this.DevTransaction.findOne({
            transactionType:
              type === 'payment'
                ? TransactionType.Transaction
                : TransactionType.Topup,
            clientRef,
            user: user.id,
          })
            .populate('method')
            .then(async (transaction: any) => {
              if (transaction) {
                const resObj: any = {
                  amount: transaction.amount,
                  fee: transaction.fee,
                  expired: transaction.exp,
                  method: transaction.method.code,
                  methodName: transaction.method.name,
                  customerName: transaction.clientCustName,
                  ref1: transaction.clientRef,
                  ref2: transaction.transactionId,
                  status: transaction.status,
                  desc: `Your ${
                    transaction.method.type === MethodType.Va
                      ? 'Virtual Account'
                      : transaction.method.type === MethodType.Retail
                      ? 'Retail'
                      : transaction.method.type === MethodType.Qris
                      ? 'QRIS'
                      : transaction.method.type === MethodType.Ewallet
                      ? 'Ewallet'
                      : ''
                  } Topup is ${
                    transaction.status === TransactionStatusType.Paid
                      ? 'Paid'
                      : transaction.status === TransactionStatusType.Settled
                      ? 'Settled to your balance'
                      : transaction.status === TransactionStatusType.Failed
                      ? 'Failed'
                      : 'Expired'
                  }`,
                };

                if (transaction.method.type === MethodType.Ewallet) {
                  resObj.phone = transaction.phone;
                }

                if (
                  transaction.status === TransactionStatusType.Paid ||
                  transaction.status === TransactionStatusType.Settled
                ) {
                  resObj.paidTime = transaction.paidTime;
                  resObj.serialNumber = transaction.serialNumber;
                  if (transaction.status === TransactionStatusType.Settled) {
                    resObj.settleTime = transaction.clientSettleDate;
                  }
                }

                result = response.initSuccess(
                  ClientResponse.Success,
                  true,
                  resObj,
                );
              } else {
                result = response.initError(
                  ClientResponse.MethodNotFound,
                  false,
                  new ErrorMessage('Transaction data not found'),
                );
              }
            });
        } else {
          await this.DevWithdraw.findOne({
            process: WithdrawProcess.Process,
            clientRef,
            user: user.id,
          })
            .populate('bank')
            .then(async (withdraw: any) => {
              if (withdraw) {
                const resObj: any = {
                  amount: withdraw.amount,
                  fee: withdraw.fee,
                  channelName: withdraw.bank.name,
                  accountNumber:
                    withdraw.bank.type === BankType.Cash
                      ? ''
                      : withdraw.accNumber,
                  name:
                    withdraw.bank.type === BankType.Cash
                      ? `Cash Transfer ${withdraw.bank.name}`
                      : withdraw.name,
                  ref1: withdraw.clientRef,
                  ref2: withdraw.withdrawId,
                  status: withdraw.status,
                  desc: `${
                    withdraw.status === WithdrawStatus.Success
                      ? 'Success'
                      : withdraw.status === WithdrawStatus.Pending
                      ? 'Pending'
                      : withdraw.status === WithdrawStatus.Processing
                      ? 'Processing'
                      : withdraw.status === WithdrawStatus.Failed
                      ? 'Failed'
                      : 'Rejected'
                  } transfer to ${withdraw.name}${
                    withdraw.bank.type === BankType.Cash
                      ? ''
                      : `-${withdraw.accNumber}`
                  }`,
                };

                if (withdraw.bank.type === BankType.Cash) {
                  resObj.note = withdraw.note;
                  resObj.expired = withdraw.exp;
                }

                if (withdraw.status === WithdrawStatus.Success) {
                  resObj.paidDate = withdraw.paidDate;
                }

                result = response.initSuccess(
                  ClientResponse.Success,
                  true,
                  resObj,
                );
              } else {
                result = response.initError(
                  ClientResponse.MethodNotFound,
                  false,
                  new ErrorMessage('Transfer data not found'),
                );
              }
            });
        }

        return res.status(200).send(result);
      } else {
        const error = response.initError(
          ClientResponse.MethodNotFound,
          false,
          new ErrorMessage(`${type} not exist`),
        );
        return res.status(200).send(error);
      }
    } catch (err) {
      const error = response.initError(
        ClientResponse.ServerError,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async test(data: any, req: FastifyRequest, res: FastifyReply) {
    try {
      // await this.Commission.deleteMany();

      // await this.User.find({
      //   isBlocked: false,
      //   isDeleted: false,
      //   role: { $in: [Role.Partner, Role.Root] },
      // }).then(async (users) => {
      //   for (const user of users) {
      //     const newCommission = new this.Commission({
      //       user: new Types.ObjectId(user.id),
      //       cutoff: user.role === Role.Root ? 0 : undefined,
      //       clientTrx: user.role === Role.Root ? undefined : 0,
      //       clientTrxQty: user.role === Role.Root ? undefined : 0,
      //       partnerTrx: user.role === Role.Root ? undefined : 0,
      //       partnerTrxQty: user.role === Role.Root ? undefined : 0,
      //       clientWd: user.role === Role.Root ? undefined : 0,
      //       clientWdQty: user.role === Role.Root ? undefined : 0,
      //       partnerWd: user.role === Role.Root ? undefined : 0,
      //       partnerWdQty: user.role === Role.Root ? undefined : 0,
      //     });
      //     await newCommission.save();

      //     await this.Balance.updateMany(
      //       {
      //         user: user.id,
      //       },
      //       { balance: 0, pending: 0, freeze: 0, debt: 0 },
      //     );
      //   }
      // });

      // const today = new Date();
      // today.setMonth(today.getMonth() - 1);
      // await this.Transaction.aggregate([
      //   {
      //     $match: {
      //       transactionType: TransactionType.Topup,
      //     },
      //   },
      //   {
      //     $lookup: {
      //       from: 'users',
      //       localField: 'user',
      //       foreignField: '_id',
      //       as: 'user',
      //     },
      //   },
      //   {
      //     $unwind: '$user',
      //   },
      //   {
      //     $match: {
      //       'user.role': Role.Client,
      //     },
      //   },
      //   {
      //     $facet: {
      //       all: [
      //         {
      //           $group: {
      //             _id: '$status',
      //             totalAmount: { $sum: '$amount' },
      //             total: {
      //               $sum: 1,
      //             },
      //           },
      //         },
      //         {
      //           $group: {
      //             _id: null,
      //             objects: {
      //               $push: {
      //                 k: '$_id',
      //                 v: {
      //                   totalAmount: '$totalAmount',
      //                   total: '$total',
      //                 },
      //               },
      //             },
      //           },
      //         },
      //         {
      //           $replaceRoot: {
      //             newRoot: { $arrayToObject: '$objects' },
      //           },
      //         },
      //       ],
      //       today: [
      //         {
      //           $match: {
      //             $expr: {
      //               $eq: [{ $month: '$createdAt' }, { $month: today }],
      //             },
      //           },
      //         },
      //         {
      //           $group: {
      //             _id: '$status',
      //             totalAmount: { $sum: '$amount' },
      //             total: {
      //               $sum: 1,
      //             },
      //           },
      //         },
      //         {
      //           $group: {
      //             _id: null,
      //             objects: {
      //               $push: {
      //                 k: '$_id',
      //                 v: {
      //                   totalAmount: '$totalAmount',
      //                   total: '$total',
      //                 },
      //               },
      //             },
      //           },
      //         },
      //         {
      //           $replaceRoot: {
      //             newRoot: { $arrayToObject: '$objects' },
      //           },
      //         },
      //       ],
      //     },
      //   },
      //   {
      //     $project: {
      //       all: { $arrayElemAt: ['$all', 0] },
      //       today: { $arrayElemAt: ['$today', 0] },
      //     },
      //   },
      //   {
      //     $addFields: {
      //       all: { $mergeObjects: ['$all', '$today'] },
      //     },
      //   },
      // ]).then((a) => {
      //   const success = response.initSuccess(200, true, a);
      //   return res.status(200).send(success);
      // });

      const today = new Date();
      // today.setDate(today.getDate() - 1);
      // const t = await this.Commission.find({
      //   $and: [
      //     { user: { $exists: true } },
      //     {
      //       $expr: {
      //         $eq: [{ $dayOfMonth: '$createdAt' }, { $dayOfMonth: today }],
      //       },
      //     },
      //   ],
      // });
      // await this.Commission.updateMany(
      //   {
      //     $and: [
      //       { user: { $exists: true } },
      //       {
      //         $expr: {
      //           $eq: [{ $dayOfMonth: '$createdAt' }, { $dayOfMonth: today }],
      //         },
      //       },
      //     ],
      //   },
      //   { isActive: false },
      // );

      // const t = await this.Transaction.aggregate([
      //   {
      //     $lookup: {
      //       from: 'users',
      //       localField: 'user',
      //       foreignField: '_id',
      //       as: 'user',
      //     },
      //   },
      //   {
      //     $unwind: '$user',
      //   },
      //   {
      //     $match: {
      //       'user.role': { $in: [Role.User, Role.Client] },
      //       transactionType: TransactionType.Transaction,
      //     },
      //   },
      //   {
      //     $facet: {
      //       all: [
      //         {
      //           $group: {
      //             _id: {
      //               role: '$user.role',
      //               status: '$status',
      //             },
      //             totalAmount: { $sum: '$amount' },
      //             total: {
      //               $sum: 1,
      //             },
      //           },
      //         },
      //         {
      //           $group: {
      //             _id: '$_id.role',
      //             statuses: {
      //               $push: {
      //                 k: '$_id.status',
      //                 v: {
      //                   totalAmount: '$totalAmount',
      //                   total: '$total',
      //                 },
      //               },
      //             },
      //           },
      //         },
      //         {
      //           $group: {
      //             _id: null,
      //             objects: {
      //               $push: {
      //                 k: '$_id',
      //                 v: { $arrayToObject: '$statuses' },
      //               },
      //             },
      //           },
      //         },
      //         {
      //           $replaceRoot: {
      //             newRoot: { $arrayToObject: '$objects' },
      //           },
      //         },
      //       ],
      //       today: [
      //         {
      //           $match: {
      //             $expr: {
      //               $eq: [
      //                 { $dayOfMonth: '$createdAt' },
      //                 { $dayOfMonth: today },
      //               ],
      //             },
      //           },
      //         },
      //         {
      //           $group: {
      //             _id: {
      //               role: '$user.role',
      //               status: '$status',
      //             },
      //             totalAmount: { $sum: '$amount' },
      //             total: {
      //               $sum: 1,
      //             },
      //           },
      //         },
      //         {
      //           $group: {
      //             _id: '$_id.role',
      //             statuses: {
      //               $push: {
      //                 k: '$_id.status',
      //                 v: {
      //                   totalAmount: '$totalAmount',
      //                   total: '$total',
      //                 },
      //               },
      //             },
      //           },
      //         },
      //         {
      //           $group: {
      //             _id: null,
      //             objects: {
      //               $push: {
      //                 k: '$_id',
      //                 v: { $arrayToObject: '$statuses' },
      //               },
      //             },
      //           },
      //         },
      //         {
      //           $replaceRoot: {
      //             newRoot: { $arrayToObject: '$objects' },
      //           },
      //         },
      //       ],
      //     },
      //   },
      //   {
      //     $project: {
      //       all: { $arrayElemAt: ['$all', 0] },
      //       today: { $arrayElemAt: ['$today', 0] },
      //     },
      //   },
      //   {
      //     $addFields: {
      //       all: { $mergeObjects: ['$all', '$today'] },
      //     },
      //   },
      // ]);

      const success = response.initSuccess(200, true, {
        header: req.headers,
        body: req.body,
      });
      return res.status(200).send(success);
      // const today = new Date();
      // today.setDate(today.getDate() - 1);
      // const user = await this.User.findOne({ role: Role.Root }).exec();
      // const balance = await this.Balance.findOne({ user: user.id }).exec();
      // await this.Commission.aggregate([
      //   {
      //     $lookup: {
      //       from: 'users',
      //       localField: 'user',
      //       foreignField: '_id',
      //       as: 'user',
      //     },
      //   },
      //   {
      //     $unwind: {
      //       path: '$user',
      //       preserveNullAndEmptyArrays: true,
      //     },
      //   },
      //   {
      //     $match: {
      //       user: { $exists: true },
      //       isActive: true,
      //       'user.role': { $in: [Role.Partner, Role.Root] },
      //       'user.isBlocked': false,
      //       'user.isDeleted': false,
      //     },
      //   },
      // ]).then(async (commissions) => {
      //   for (const commission of commissions) {
      //     const newCommission = new this.Commission({
      //       user: new Types.ObjectId(commission.user._id),
      //       cutoff: commission.user.role === Role.Root ? 0 : undefined,
      //       clientTrx: commission.user.role === Role.Root ? undefined : 0,
      //       clientTrxQty: commission.user.role === Role.Root ? undefined : 0,
      //       partnerTrx: commission.user.role === Role.Root ? undefined : 0,
      //       partnerTrxQty: commission.user.role === Role.Root ? undefined : 0,
      //       clientWd: commission.user.role === Role.Root ? undefined : 0,
      //       clientWdQty: commission.user.role === Role.Root ? undefined : 0,
      //       partnerWd: commission.user.role === Role.Root ? undefined : 0,
      //       partnerWdQty: commission.user.role === Role.Root ? undefined : 0,
      //     });
      //     await newCommission.save();

      //     if (commission.user.role === Role.Root) {
      //       var nominal = balance.balance;
      //       await this.Commission.aggregate([
      //         {
      //           $match: {
      //             user: user.id,
      //             isActive: false,
      //             isDisbursed: false,
      //           },
      //         },
      //         {
      //           $group: {
      //             _id: null,
      //             totalCutoff: { $sum: '$cutoff' },
      //           },
      //         },
      //       ]).then((rootCommission) => {
      //         if (rootCommission.length) {
      //           nominal -= rootCommission[0].totalCutoff;
      //         }
      //       });
      //       commission.cutoff = nominal;
      //       await commission.save();
      //     }
      //   }
      // });

      // await this.Commission.updateMany(
      //   {
      //     $and: [
      //       { user: { $exists: true } },
      //       {
      //         $expr: {
      //           $eq: [{ $dayOfMonth: '$createdAt' }, { $dayOfMonth: today }],
      //         },
      //       },
      //     ],
      //   },
      //   { isActive: false },
      // );
      // await this.Transaction.aggregate([
      //   {
      //     $match: {
      //       transactionType: TransactionType.Transaction,
      //     },
      //   },
      //   {
      //     $lookup: {
      //       from: 'users',
      //       localField: 'user',
      //       foreignField: '_id',
      //       as: 'user',
      //     },
      //   },
      //   {
      //     $unwind: '$user',
      //   },
      //   {
      //     $match: {
      //       'user.role': { $in: [Role.User, Role.Client] },
      //     },
      //   },
      //   {
      //     $group: {
      //       _id: {
      //         role: '$user.role',
      //         status: '$status',
      //       },
      //       totalAmount: { $sum: '$amount' },
      //     },
      //   },
      //   {
      //     $group: {
      //       _id: '$_id.role',
      //       statuses: {
      //         $push: {
      //           k: '$_id.status',
      //           v: '$totalAmount',
      //         },
      //       },
      //     },
      //   },
      //   {
      //     $group: {
      //       _id: null,
      //       objects: {
      //         $push: {
      //           k: '$_id',
      //           v: { $arrayToObject: '$statuses' },
      //         },
      //       },
      //     },
      //   },
      //   {
      //     $replaceRoot: {
      //       newRoot: { $arrayToObject: '$objects' },
      //     },
      //   },

      //   // {
      //   //   $project: {
      //   //     _id: 0,
      //   //     user: {
      //   //       $cond: {
      //   //         if: { $eq: ['$_id', Role.User] },
      //   //         then: {
      //   //           paidAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Paid,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //           processingAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Processing,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //           pendingAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Pending,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //           failedAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Failed,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //           expiredAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Expired,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //           assistAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Assist,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //         },
      //   //         else: {
      //   //           paidAmount: 0,
      //   //           processingAmount: 0,
      //   //           pendingAmount: 0,
      //   //           failedAmount: 0,
      //   //           expiredAmount: 0,
      //   //           assistAmount: 0,
      //   //         },
      //   //       },
      //   //     },
      //   //     client: {
      //   //       $cond: {
      //   //         if: { $eq: ['$_id', Role.Client] },
      //   //         then: {
      //   //           settledAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Settled,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //           paidAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Paid,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //           pendingAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Pending,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //           failedAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Failed,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //           expiredAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Expired,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //           assistAmount: {
      //   //             $ifNull: [
      //   //               {
      //   //                 $arrayElemAt: [
      //   //                   '$statuses.v',
      //   //                   {
      //   //                     $indexOfArray: [
      //   //                       '$statuses.k',
      //   //                       TransactionStatusType.Settled,
      //   //                     ],
      //   //                   },
      //   //                 ],
      //   //               },
      //   //               0,
      //   //             ],
      //   //           },
      //   //         },
      //   //         else: {
      //   //           settledAmount: 0,
      //   //           paidAmount: 0,
      //   //           pendingAmount: 0,
      //   //           failedAmount: 0,
      //   //           expiredAmount: 0,
      //   //           assistAmount: 0,
      //   //         },
      //   //       },
      //   //     },
      //   //   },
      //   // },
      // ]).then(async (commissions) => {
      //   const success = response.initSuccess(200, true, commissions);
      //   return res.status(200).send(success);
      // });

      // await this.Bank.updateMany(
      //   {
      //     type: { $in: [BankType.Bank, BankType.CC, BankType.Va] },
      //   },
      //   { min: 10000, max: 50000000 },
      // );

      // await this.Bank.updateMany(
      //   {
      //     type: BankType.Ewallet,
      //   },
      //   { min: 10000, max: 100000 },
      // );

      // await this.Method.updateMany({}, { min: 10000, max: 100000 });
      // await this.DevTransaction.updateMany(
      //   {},
      //   { transactionType: TransactionType.Transaction },
      // );
      // await this.Commission.aggregate([
      //   {
      //     $lookup: {
      //       from: 'users',
      //       localField: 'user',
      //       foreignField: '_id',
      //       as: 'user',
      //     },
      //   },
      //   {
      //     $unwind: {
      //       path: '$user',
      //       preserveNullAndEmptyArrays: true,
      //     },
      //   },
      //   {
      //     $match: {
      //       user: { $exists: true },
      //       isActive: true,
      //       'user.role': { $in: [Role.Partner, Role.Root] },
      //       'user.isBlocked': false,
      //       'user.isDeleted': false,
      //     },
      //   },
      // ]).then(async (commissions) => {
      //   const success = response.initSuccess(200, true, commissions);
      //   return res.status(200).send(success);
      // });
      // const today = new Date();
      // const yesterday = new Date(today);
      // yesterday.setDate(yesterday.getDate() - 1);
      // this.Commission.aggregate([
      //   {
      //     $match: {
      //       isActive: true,
      //       $expr: {
      //         $eq: [{ $dayOfMonth: '$createdAt' }, { $dayOfMonth: today }],
      //       },
      //     },
      //   },
      //   {
      //     $lookup: {
      //       from: 'commissions',
      //       let: { userId: '$user' },
      //       pipeline: [
      //         {
      //           $match: {
      //             $expr: {
      //               $and: [
      //                 { $eq: ['$user', '$$userId'] },
      //                 {
      //                   $eq: [
      //                     { $dayOfMonth: '$createdAt' },
      //                     { $dayOfMonth: yesterday },
      //                   ],
      //                 },
      //               ],
      //             },
      //             isActive: false,
      //           },
      //         },
      //       ],
      //       as: 'commissionYtd',
      //     },
      //   },
      //   {
      //     $unwind: {
      //       path: '$commissionYtd',
      //       preserveNullAndEmptyArrays: true,
      //     },
      //   },
      // ]).then((commissions) => {
      //   for(const commission of commissions) {
      //     const totalCm = commission.client ?? 0 + commission.partner ?? 0
      //     var cutoff = 0
      //     if(commission.commissionYtd) {
      //       const totalCmY = commission.commissionYtd.client + commission.commissionYtd.partner
      //       cutoff = totalCm + (totalCmY - commission.commissionYtd.cutoff ?? 0)
      //     } else {
      //       cutoff = totalCm
      //     }
      //   }
      // });
      // await this.Commission.aggregate([
      //   {
      //     $lookup: {
      //       from: 'users',
      //       localField: 'user',
      //       foreignField: '_id',
      //       as: 'user',
      //     },
      //   },
      //   {
      //     $unwind: {
      //       path: '$user',
      //     },
      //   },
      //   {
      //     $match: {
      //       'user.role': { $in: [Role.Partner, Role.Root] },
      //       'user.isBlocked': false,
      //       'user.isDeleted': false,
      //     },
      //   },
      // ]).then(async (cmm) => {
      //   for (const cm of cmm) {
      //     if (cm.user.role === Role.Root) {
      //       const newCommission = new this.Commission({
      //         cutoff: 0,
      //         user: new Types.ObjectId(cm.user._id),
      //       });
      //       await newCommission.save();
      //     } else {
      //       const newCommission = new this.Commission({
      //         client: 0,
      //         partner: 0,
      //         user: new Types.ObjectId(cm.user._id),
      //       });
      //       await newCommission.save();
      //     }
      //   }
      // });
      //  const today = new Date();
      // await this.Commission.aggregate([
      //   {
      //     $lookup: {
      //       from: 'users',
      //       localField: 'user',
      //       foreignField: '_id',
      //       as: 'user',
      //     },
      //   },
      //   {
      //     $unwind: {
      //       path: '$user',
      //       preserveNullAndEmptyArrays: true,
      //     },
      //   },
      //   {
      //     $match: {
      //       isActive: true,
      //       'user.role': { $in: [Role.Partner, Role.Root] },
      //       'user.isBlocked': false,
      //       'user.isDeleted': false,
      //     },
      //   },
      // ]).then((commissions) => {
      //  for (const commission of commissions) {
      //    var newCommission: CommissionDocument;
      //    if (commission.user.role === Role.Root) {
      //      newCommission = new this.Commission({
      //        cutoff: 0,
      //        user: new Types.ObjectId(commission.user._id),
      //      });
      //    } else {
      //      newCommission = new this.Commission({
      //        client: 0,
      //        partner: 0,
      //        user: new Types.ObjectId(commission.user._id),
      //      });
      //    }
      //    newCommission.save();
      //  }
      //   console.log(commissions);
      // });
      // const success = response.initSuccess(200, true, {
      //   header: req.headers,
      //   body: data,
      // });
      // return res.status(200).send(success);
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage(err.message),
      );
      return res.status(200).send(error);
    }
  }

  // async generateVa(
  //   payload: GeneratePaymentDto,
  //   req: FastifyOpenRequest,
  //   res: FastifyReply,
  // ) {
  //   try {
  //     const { user, client } = req.user;
  //     const xSig = req.headers['x-signature'];
  //     const xTime = req.headers['x-timestamp'];

  //     const signatureVerify = encryptHmac(
  //       'sha512',
  //       client.signatureKey,
  //       encryptHmac(
  //         'sha512',
  //         client.signatureKey + user.id + client.id + xTime,
  //         'POST' +
  //           '|' +
  //           '/generate/va' +
  //           '|' +
  //           hash('sha512', minifyJson(payload)).toLowerCase() +
  //           '|' +
  //           client.clientId +
  //           '|' +
  //           client.clientSecret,
  //         'hex',
  //       ) +
  //         '|' +
  //         client.clientId,
  //       'hex',
  //     );

  //     if (xSig === signatureVerify) {
  //       await this.Method.aggregate([
  //         {
  //           $match: {
  //             code: payload.method,
  //             isActive: true,
  //             type: MethodType.Va,
  //           },
  //         },
  //         {
  //           $lookup: {
  //             from: 'fees',
  //             let: { methodId: '$_id' },
  //             pipeline: [
  //               {
  //                 $match: {
  //                   $expr: {
  //                     $and: [
  //                       { $eq: ['$method', '$$methodId'] },
  //                       { $eq: ['$feeType', FeeType.Transaction] },
  //                       { $eq: ['$user', { $toObjectId: user.id }] },
  //                     ],
  //                   },
  //                 },
  //               },
  //             ],
  //             as: 'fee',
  //           },
  //         },
  //         {
  //           $unwind: '$fee',
  //         },
  //         {
  //           $lookup: {
  //             from: 'valuetypes',
  //             localField: 'fee.type',
  //             foreignField: '_id',
  //             as: 'fee.type',
  //           },
  //         },
  //         {
  //           $unwind: '$fee.type',
  //         },
  //       ]).then(async (methods) => {
  //         if (methods.length) {
  //           const method = methods[0];
  //           if (method.fee.isActive) {
  //             if (payload.amount < method.min) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Minimal amount ${toCurrency(method.min)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else if (payload.amount > method.max) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Maximal amount ${toCurrency(method.max)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else {
  //               const exp = new Date(payload.expired);
  //               if (exp.toString() === 'Invalid Date') {
  //                 const error = response.initError(
  //                   ClientResponse.InvalidData,
  //                   false,
  //                   new ErrorMessage('Invalid millis'),
  //                 );
  //                 return res.status(200).send(error);
  //               } else {
  //                 const today = new Date();
  //                 today.setDate(today.getDate() + 1);
  //                 today.setHours(0, 0, 0, 0);

  //                 if (today <= exp) {
  //                   await this.Transaction.findOne({
  //                     clientRef: payload.transactionRef,
  //                   }).then(async (trans) => {
  //                     if (trans) {
  //                       const error = response.initError(
  //                         ClientResponse.InvalidData,
  //                         false,
  //                         new ErrorMessage('Transaction Ref must be unique'),
  //                       );
  //                       return res.status(200).send(error);
  //                     } else {
  //                       const dateString = exp
  //                         .toLocaleString('en-US', {
  //                           year: 'numeric',
  //                           month: '2-digit',
  //                           day: '2-digit',
  //                           hour: '2-digit',
  //                           minute: '2-digit',
  //                           second: '2-digit',
  //                         })
  //                         .replace(/\/|,|:| /g, '');
  //                       const formattedDate = `${dateString.slice(
  //                         4,
  //                         8,
  //                       )}${dateString.slice(0, 2)}${dateString.slice(
  //                         2,
  //                         4,
  //                       )}${dateString.slice(8, 14)}`;
  //                       const orderId = generateRandomNumber(50);
  //                       const customerId = exp.getTime();

  //                       let feeAmount: number;
  //                       switch (method.fee.type.name) {
  //                         case ValueType.Percentage:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100,
  //                           );
  //                           break;
  //                         case ValueType.Fixed:
  //                           feeAmount = method.fee.fixed;
  //                           break;
  //                         default:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100 +
  //                               method.fee.fixed,
  //                           );
  //                           break;
  //                       }

  //                       const amount = method.fee.onClient
  //                         ? payload.amount
  //                         : payload.amount + feeAmount;
  //                       const reqMethod = 'POST';
  //                       const paramX = `${method.path}${reqMethod}`;
  //                       const paramY = `${amount}${formattedDate}${method.code}${orderId}${customerId}${APP_NAME}${EMAIL_NOT_PROVIDED}${process.env.PG_CLIENT_ID}`;
  //                       const sig = encryptHmac(
  //                         'sha256',
  //                         process.env.PG_SIG_KEY,
  //                         paramX +
  //                           paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
  //                         'hex',
  //                       );

  //                       const payloadPg: any = {
  //                         expired: formattedDate,
  //                         amount: Number(amount),
  //                         customer_id: Number(customerId),
  //                         partner_reff: orderId,
  //                         customer_email: EMAIL_NOT_PROVIDED,
  //                         username: process.env.PG_USERNAME,
  //                         pin: process.env.PG_PIN,
  //                         customer_name: APP_NAME,
  //                         signature: sig,
  //                         bank_code: method.code,
  //                       };
  //                       const header = {
  //                         'Content-Type': CT_APP_JSON,
  //                         'client-id': process.env.PG_CLIENT_ID,
  //                         'client-secret': process.env.PG_CLIENT_SECRET,
  //                       };
  //                       await fetch(
  //                         process.env.PG_BASE_URL + method.path.substring(1),
  //                         {
  //                           method: reqMethod,
  //                           body: JSON.stringify(payloadPg),
  //                           headers: header,
  //                         },
  //                       )
  //                         .then(async (responseFetch) => {
  //                           const responseData = await responseFetch.json();

  //                           const transactionId =
  //                             'T' +
  //                             hash('sha256', generateRandomNumber(25) + xTime);

  //                           const newTransaction = new this.Transaction({
  //                             clientCustName: payload.customerName,
  //                             transactionId,
  //                             orderId,
  //                             refId: responseData.partner_reff2,
  //                             amount,
  //                             fee: feeAmount,
  //                             feeAdmin: responseData.feeadmin,
  //                             payment:
  //                               responseData.virtual_account ??
  //                               responseData.payment_code ??
  //                               responseData.qris_text,
  //                             url: responseData.url_payment,
  //                             exp,
  //                             method: new Types.ObjectId(method._id),
  //                             user: user.id,
  //                             clientRef: payload.transactionRef,
  //                             accessFrom: AccessFrom.Api,
  //                           });

  //                           var result: SOPResponse;
  //                           if (
  //                             responseData.status === PgType.Success &&
  //                             responseData.response_code === PgType.SuccessCode
  //                           ) {
  //                             newTransaction.status =
  //                               TransactionStatusType.Pending;
  //                             result = response.initSuccess(
  //                               ClientResponse.Success,
  //                               true,
  //                               {
  //                                 amount,
  //                                 expired: exp.getTime(),
  //                                 method: payload.method,
  //                                 methodName: method.name,
  //                                 customerName: payload.customerName,
  //                                 ref1: payload.transactionRef,
  //                                 ref2: transactionId,
  //                                 desc: 'Success generate Virtual Account',
  //                                 va: responseData.virtual_account,
  //                               },
  //                             );
  //                           } else {
  //                             newTransaction.status =
  //                               TransactionStatusType.Failed;
  //                             result = response.initSuccess(
  //                               ClientResponse.Success,
  //                               false,
  //                               {
  //                                 amount,
  //                                 expired: exp.getTime(),
  //                                 method: payload.method,
  //                                 methodName: method.name,
  //                                 customerName: payload.customerName,
  //                                 ref1: payload.transactionRef,
  //                                 ref2: transactionId,
  //                                 desc: 'Failed generate Virtual Account',
  //                                 error: 'Bank Not Supported',
  //                               },
  //                             );
  //                           }
  //                           await newTransaction.save();
  //                           return res.status(200).send(result);
  //                         })
  //                         .catch((err) => {
  //                           console.log(err);
  //                           const error = response.initError(
  //                             ClientResponse.ServerError,
  //                             false,
  //                             new ErrorMessage(
  //                               "There's an error on the server, please wait :)",
  //                             ),
  //                           );
  //                           return res.status(200).send(error);
  //                         });
  //                     }
  //                   });
  //                 } else {
  //                   const error = response.initError(
  //                     ClientResponse.InvalidData,
  //                     false,
  //                     new ErrorMessage('Expired must be greater than today'),
  //                   );
  //                   return res.status(200).send(error);
  //                 }
  //               }
  //             }
  //           } else {
  //             const error = response.initError(
  //               ClientResponse.MethodNotAllowed,
  //               false,
  //               new ErrorMessage('Payment method not allowed'),
  //             );
  //             return res.status(200).send(error);
  //           }
  //         } else {
  //           const error = response.initError(
  //             ClientResponse.MethodNotFound,
  //             false,
  //             new ErrorMessage('Payment method not found'),
  //           );
  //           return res.status(200).send(error);
  //         }
  //       });
  //     } else {
  //       const error = response.initError(
  //         ClientResponse.InvalidSignature,
  //         false,
  //         new ErrorMessage('Invalid Signature'),
  //       );
  //       return res.status(200).send(error);
  //     }
  //   } catch (err) {
  //     const error = response.initError(
  //       ClientResponse.ServerError,
  //       false,
  //       new ErrorMessage("There's an error on the server, please wait :)"),
  //     );
  //     return res.status(200).send(error);
  //   }
  // }

  // async generateRetail(
  //   payload: GeneratePaymentDto,
  //   req: FastifyOpenRequest,
  //   res: FastifyReply,
  // ) {
  //   try {
  //     const { user, client } = req.user;
  //     const xSig = req.headers['x-signature'];
  //     const xTime = req.headers['x-timestamp'];

  //     const signatureVerify = encryptHmac(
  //       'sha512',
  //       client.signatureKey,
  //       encryptHmac(
  //         'sha512',
  //         client.signatureKey + user.id + client.id + xTime,
  //         'POST' +
  //           '|' +
  //           '/generate/retail' +
  //           '|' +
  //           hash('sha512', minifyJson(payload)).toLowerCase() +
  //           '|' +
  //           client.clientId +
  //           '|' +
  //           client.clientSecret,
  //         'hex',
  //       ) +
  //         '|' +
  //         client.clientId,
  //       'hex',
  //     );

  //     if (xSig === signatureVerify) {
  //       await this.Method.aggregate([
  //         {
  //           $match: {
  //             code: payload.method,
  //             isActive: true,
  //             type: MethodType.Retail,
  //           },
  //         },
  //         {
  //           $lookup: {
  //             from: 'fees',
  //             let: { methodId: '$_id' },
  //             pipeline: [
  //               {
  //                 $match: {
  //                   $expr: {
  //                     $and: [
  //                       { $eq: ['$method', '$$methodId'] },
  //                       { $eq: ['$feeType', FeeType.Transaction] },
  //                       { $eq: ['$user', { $toObjectId: user.id }] },
  //                     ],
  //                   },
  //                 },
  //               },
  //             ],
  //             as: 'fee',
  //           },
  //         },
  //         {
  //           $unwind: '$fee',
  //         },
  //         {
  //           $lookup: {
  //             from: 'valuetypes',
  //             localField: 'fee.type',
  //             foreignField: '_id',
  //             as: 'fee.type',
  //           },
  //         },
  //         {
  //           $unwind: '$fee.type',
  //         },
  //       ]).then(async (methods) => {
  //         if (methods.length) {
  //           const method = methods[0];
  //           if (method.fee.isActive) {
  //             if (payload.amount < method.min) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Minimal amount ${toCurrency(method.min)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else if (payload.amount > method.max) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Maximal amount ${toCurrency(method.max)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else {
  //               const exp = new Date(payload.expired);
  //               if (exp.toString() === 'Invalid Date') {
  //                 const error = response.initError(
  //                   ClientResponse.InvalidData,
  //                   false,
  //                   new ErrorMessage('Invalid millis'),
  //                 );
  //                 return res.status(200).send(error);
  //               } else {
  //                 const today = new Date();
  //                 today.setDate(today.getDate() + 1);
  //                 today.setHours(0, 0, 0, 0);

  //                 if (today <= exp) {
  //                   await this.Transaction.findOne({
  //                     clientRef: payload.transactionRef,
  //                   }).then(async (trans) => {
  //                     if (trans) {
  //                       const error = response.initError(
  //                         ClientResponse.InvalidData,
  //                         false,
  //                         new ErrorMessage('Transaction Ref must be unique'),
  //                       );
  //                       return res.status(200).send(error);
  //                     } else {
  //                       const dateString = exp
  //                         .toLocaleString('en-US', {
  //                           year: 'numeric',
  //                           month: '2-digit',
  //                           day: '2-digit',
  //                           hour: '2-digit',
  //                           minute: '2-digit',
  //                           second: '2-digit',
  //                         })
  //                         .replace(/\/|,|:| /g, '');
  //                       const formattedDate = `${dateString.slice(
  //                         4,
  //                         8,
  //                       )}${dateString.slice(0, 2)}${dateString.slice(
  //                         2,
  //                         4,
  //                       )}${dateString.slice(8, 14)}`;
  //                       const orderId = generateRandomNumber(50);
  //                       const customerId = exp.getTime();

  //                       let feeAmount: number;
  //                       switch (method.fee.type.name) {
  //                         case ValueType.Percentage:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100,
  //                           );
  //                           break;
  //                         case ValueType.Fixed:
  //                           feeAmount = method.fee.fixed;
  //                           break;
  //                         default:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100 +
  //                               method.fee.fixed,
  //                           );
  //                           break;
  //                       }

  //                       const amount = method.fee.onClient
  //                         ? payload.amount
  //                         : payload.amount + feeAmount;
  //                       const reqMethod = 'POST';
  //                       const paramX = `${method.path}${reqMethod}`;
  //                       const paramY = `${amount}${formattedDate}${method.code}${orderId}${customerId}${APP_NAME}${EMAIL_NOT_PROVIDED}${process.env.PG_CLIENT_ID}`;
  //                       const sig = encryptHmac(
  //                         'sha256',
  //                         process.env.PG_SIG_KEY,
  //                         paramX +
  //                           paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
  //                         'hex',
  //                       );

  //                       const payloadPg: any = {
  //                         expired: formattedDate,
  //                         amount: Number(amount),
  //                         customer_id: Number(customerId),
  //                         partner_reff: orderId,
  //                         customer_email: EMAIL_NOT_PROVIDED,
  //                         username: process.env.PG_USERNAME,
  //                         pin: process.env.PG_PIN,
  //                         customer_name: APP_NAME,
  //                         signature: sig,
  //                         retail_code: method.code,
  //                         customer_phone: '081234567890',
  //                       };
  //                       const header = {
  //                         'Content-Type': CT_APP_JSON,
  //                         'client-id': process.env.PG_CLIENT_ID,
  //                         'client-secret': process.env.PG_CLIENT_SECRET,
  //                       };
  //                       await fetch(
  //                         process.env.PG_BASE_URL + method.path.substring(1),
  //                         {
  //                           method: reqMethod,
  //                           body: JSON.stringify(payloadPg),
  //                           headers: header,
  //                         },
  //                       )
  //                         .then(async (responseFetch) => {
  //                           const responseData = await responseFetch.json();

  //                           const transactionId =
  //                             'T' +
  //                             hash('sha256', generateRandomNumber(25) + xTime);

  //                           const newTransaction = new this.Transaction({
  //                             clientCustName: payload.customerName,
  //                             transactionId,
  //                             orderId,
  //                             refId: responseData.partner_reff2,
  //                             amount,
  //                             fee: feeAmount,
  //                             feeAdmin: responseData.feeadmin,
  //                             payment:
  //                               responseData.virtual_account ??
  //                               responseData.payment_code ??
  //                               responseData.qris_text,
  //                             url: responseData.url_payment,
  //                             exp,
  //                             method: new Types.ObjectId(method._id),
  //                             user: user.id,
  //                             clientRef: payload.transactionRef,
  //                             accessFrom: AccessFrom.Api,
  //                           });

  //                           var result: SOPResponse;
  //                           if (
  //                             responseData.status === PgType.Success &&
  //                             responseData.response_code === PgType.SuccessCode
  //                           ) {
  //                             newTransaction.status =
  //                               TransactionStatusType.Pending;
  //                             result = response.initSuccess(
  //                               ClientResponse.Success,
  //                               true,
  //                               {
  //                                 amount,
  //                                 expired: exp.getTime(),
  //                                 method: payload.method,
  //                                 methodName: method.name,
  //                                 customerName: payload.customerName,
  //                                 ref1: payload.transactionRef,
  //                                 ref2: transactionId,
  //                                 desc: 'Success generate Retail Payment Code',
  //                                 paymentCode: responseData.payment_code,
  //                               },
  //                             );
  //                           } else {
  //                             newTransaction.status =
  //                               TransactionStatusType.Failed;
  //                             result = response.initSuccess(
  //                               ClientResponse.Success,
  //                               false,
  //                               {
  //                                 amount,
  //                                 expired: exp.getTime(),
  //                                 method: payload.method,
  //                                 methodName: method.name,
  //                                 customerName: payload.customerName,
  //                                 ref1: payload.transactionRef,
  //                                 ref2: transactionId,
  //                                 desc: 'Failed generate Retail Payment Code',
  //                                 error: 'Retail Not Supported',
  //                               },
  //                             );
  //                           }
  //                           await newTransaction.save();
  //                           return res.status(200).send(result);
  //                         })
  //                         .catch((err) => {
  //                           console.log(err);
  //                           const error = response.initError(
  //                             ClientResponse.ServerError,
  //                             false,
  //                             new ErrorMessage(
  //                               "There's an error on the server, please wait :)",
  //                             ),
  //                           );
  //                           return res.status(200).send(error);
  //                         });
  //                     }
  //                   });
  //                 } else {
  //                   const error = response.initError(
  //                     ClientResponse.InvalidData,
  //                     false,
  //                     new ErrorMessage('Expired must be greater than today'),
  //                   );
  //                   return res.status(200).send(error);
  //                 }
  //               }
  //             }
  //           } else {
  //             const error = response.initError(
  //               ClientResponse.MethodNotAllowed,
  //               false,
  //               new ErrorMessage('Payment method not allowed'),
  //             );
  //             return res.status(200).send(error);
  //           }
  //         } else {
  //           const error = response.initError(
  //             ClientResponse.MethodNotFound,
  //             false,
  //             new ErrorMessage('Payment method not found'),
  //           );
  //           return res.status(200).send(error);
  //         }
  //       });
  //     } else {
  //       const error = response.initError(
  //         ClientResponse.InvalidSignature,
  //         false,
  //         new ErrorMessage('Invalid Signature'),
  //       );
  //       return res.status(200).send(error);
  //     }
  //   } catch (err) {
  //     const error = response.initError(
  //       ClientResponse.ServerError,
  //       false,
  //       new ErrorMessage("There's an error on the server, please wait :)"),
  //     );
  //     return res.status(200).send(error);
  //   }
  // }

  // async generateQris(
  //   payload: GeneratePaymentDto,
  //   req: FastifyOpenRequest,
  //   res: FastifyReply,
  // ) {
  //   try {
  //     const { user, client } = req.user;
  //     const xSig = req.headers['x-signature'];
  //     const xTime = req.headers['x-timestamp'];

  //     const signatureVerify = encryptHmac(
  //       'sha512',
  //       client.signatureKey,
  //       encryptHmac(
  //         'sha512',
  //         client.signatureKey + user.id + client.id + xTime,
  //         'POST' +
  //           '|' +
  //           '/generate/qris' +
  //           '|' +
  //           hash('sha512', minifyJson(payload)).toLowerCase() +
  //           '|' +
  //           client.clientId +
  //           '|' +
  //           client.clientSecret,
  //         'hex',
  //       ) +
  //         '|' +
  //         client.clientId,
  //       'hex',
  //     );

  //     if (xSig === signatureVerify) {
  //       await this.Method.aggregate([
  //         {
  //           $match: {
  //             code: payload.method,
  //             isActive: true,
  //             type: MethodType.Qris,
  //           },
  //         },
  //         {
  //           $lookup: {
  //             from: 'fees',
  //             let: { methodId: '$_id' },
  //             pipeline: [
  //               {
  //                 $match: {
  //                   $expr: {
  //                     $and: [
  //                       { $eq: ['$method', '$$methodId'] },
  //                       { $eq: ['$feeType', FeeType.Transaction] },
  //                       { $eq: ['$user', { $toObjectId: user.id }] },
  //                     ],
  //                   },
  //                 },
  //               },
  //             ],
  //             as: 'fee',
  //           },
  //         },
  //         {
  //           $unwind: '$fee',
  //         },
  //         {
  //           $lookup: {
  //             from: 'valuetypes',
  //             localField: 'fee.type',
  //             foreignField: '_id',
  //             as: 'fee.type',
  //           },
  //         },
  //         {
  //           $unwind: '$fee.type',
  //         },
  //       ]).then(async (methods) => {
  //         if (methods.length) {
  //           const method = methods[0];
  //           if (method.fee.isActive) {
  //             if (payload.amount < method.min) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Minimal amount ${toCurrency(method.min)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else if (payload.amount > method.max) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Maximal amount ${toCurrency(method.max)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else {
  //               const exp = new Date(payload.expired);
  //               if (exp.toString() === 'Invalid Date') {
  //                 const error = response.initError(
  //                   ClientResponse.InvalidData,
  //                   false,
  //                   new ErrorMessage('Invalid millis'),
  //                 );
  //                 return res.status(200).send(error);
  //               } else {
  //                 const today = new Date();
  //                 today.setDate(today.getDate() + 1);
  //                 today.setHours(0, 0, 0, 0);

  //                 if (today <= exp) {
  //                   await this.Transaction.findOne({
  //                     clientRef: payload.transactionRef,
  //                   }).then(async (trans) => {
  //                     if (trans) {
  //                       const error = response.initError(
  //                         ClientResponse.InvalidData,
  //                         false,
  //                         new ErrorMessage('Transaction Ref must be unique'),
  //                       );
  //                       return res.status(200).send(error);
  //                     } else {
  //                       const dateString = exp
  //                         .toLocaleString('en-US', {
  //                           year: 'numeric',
  //                           month: '2-digit',
  //                           day: '2-digit',
  //                           hour: '2-digit',
  //                           minute: '2-digit',
  //                           second: '2-digit',
  //                         })
  //                         .replace(/\/|,|:| /g, '');
  //                       const formattedDate = `${dateString.slice(
  //                         4,
  //                         8,
  //                       )}${dateString.slice(0, 2)}${dateString.slice(
  //                         2,
  //                         4,
  //                       )}${dateString.slice(8, 14)}`;
  //                       const orderId = generateRandomNumber(50);
  //                       const customerId = exp.getTime();

  //                       let feeAmount: number;
  //                       switch (method.fee.type.name) {
  //                         case ValueType.Percentage:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100,
  //                           );
  //                           break;
  //                         case ValueType.Fixed:
  //                           feeAmount = method.fee.fixed;
  //                           break;
  //                         default:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100 +
  //                               method.fee.fixed,
  //                           );
  //                           break;
  //                       }

  //                       const amount = method.fee.onClient
  //                         ? payload.amount
  //                         : payload.amount + feeAmount;
  //                       const reqMethod = 'POST';
  //                       const paramX = `${method.path}${reqMethod}`;
  //                       const paramY = `${amount}${formattedDate}${orderId}${customerId}${APP_NAME}${EMAIL_NOT_PROVIDED}${process.env.PG_CLIENT_ID}`;
  //                       const sig = encryptHmac(
  //                         'sha256',
  //                         process.env.PG_SIG_KEY,
  //                         paramX +
  //                           paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
  //                         'hex',
  //                       );

  //                       const payloadPg: any = {
  //                         expired: formattedDate,
  //                         amount: Number(amount),
  //                         customer_id: Number(customerId),
  //                         partner_reff: orderId,
  //                         customer_email: EMAIL_NOT_PROVIDED,
  //                         username: process.env.PG_USERNAME,
  //                         pin: process.env.PG_PIN,
  //                         customer_name: APP_NAME,
  //                         signature: sig,
  //                       };
  //                       const header = {
  //                         'Content-Type': CT_APP_JSON,
  //                         'client-id': process.env.PG_CLIENT_ID,
  //                         'client-secret': process.env.PG_CLIENT_SECRET,
  //                       };
  //                       await fetch(
  //                         process.env.PG_BASE_URL + method.path.substring(1),
  //                         {
  //                           method: reqMethod,
  //                           body: JSON.stringify(payloadPg),
  //                           headers: header,
  //                         },
  //                       )
  //                         .then(async (responseFetch) => {
  //                           const responseData = await responseFetch.json();
  //                           const transactionId =
  //                             'T' +
  //                             hash('sha256', generateRandomNumber(25) + xTime);

  //                           const newTransaction = new this.Transaction({
  //                             clientCustName: payload.customerName,
  //                             transactionId,
  //                             orderId,
  //                             refId: responseData.partner_reff2,
  //                             amount,
  //                             fee: feeAmount,
  //                             feeAdmin: responseData.feeadmin,
  //                             payment:
  //                               responseData.virtual_account ??
  //                               responseData.payment_code ??
  //                               responseData.qris_text,
  //                             url: responseData.url_payment,
  //                             exp,
  //                             method: new Types.ObjectId(method._id),
  //                             user: user.id,
  //                             clientRef: payload.transactionRef,
  //                             accessFrom: AccessFrom.Api,
  //                           });

  //                           var result: SOPResponse;
  //                           if (
  //                             responseData.status === PgType.Success &&
  //                             responseData.response_code === PgType.SuccessCode
  //                           ) {
  //                             newTransaction.status =
  //                               TransactionStatusType.Pending;
  //                             result = response.initSuccess(
  //                               ClientResponse.Success,
  //                               true,
  //                               {
  //                                 amount,
  //                                 expired: exp.getTime(),
  //                                 method: payload.method,
  //                                 methodName: method.name,
  //                                 customerName: payload.customerName,
  //                                 ref1: payload.transactionRef,
  //                                 ref2: transactionId,
  //                                 desc: 'Success generate QRIS',
  //                                 qris: responseData.qris_text,
  //                               },
  //                             );
  //                           } else {
  //                             newTransaction.status =
  //                               TransactionStatusType.Failed;
  //                             result = response.initSuccess(
  //                               ClientResponse.Success,
  //                               false,
  //                               {
  //                                 amount,
  //                                 expired: exp.getTime(),
  //                                 method: payload.method,
  //                                 methodName: method.name,
  //                                 customerName: payload.customerName,
  //                                 ref1: payload.transactionRef,
  //                                 ref2: transactionId,
  //                                 desc: 'Failed generate QRIS',
  //                                 error: 'Bank Not Supported',
  //                               },
  //                             );
  //                           }
  //                           await newTransaction.save();
  //                           return res.status(200).send(result);
  //                         })
  //                         .catch((err) => {
  //                           console.log(err);
  //                           const error = response.initError(
  //                             ClientResponse.ServerError,
  //                             false,
  //                             new ErrorMessage(
  //                               "There's an error on the server, please wait :)",
  //                             ),
  //                           );
  //                           return res.status(200).send(error);
  //                         });
  //                     }
  //                   });
  //                 } else {
  //                   const error = response.initError(
  //                     ClientResponse.InvalidData,
  //                     false,
  //                     new ErrorMessage('Expired must be greater than today'),
  //                   );
  //                   return res.status(200).send(error);
  //                 }
  //               }
  //             }
  //           } else {
  //             const error = response.initError(
  //               ClientResponse.MethodNotAllowed,
  //               false,
  //               new ErrorMessage('Payment method not allowed'),
  //             );
  //             return res.status(200).send(error);
  //           }
  //         } else {
  //           const error = response.initError(
  //             ClientResponse.MethodNotFound,
  //             false,
  //             new ErrorMessage('Payment method not found'),
  //           );
  //           return res.status(200).send(error);
  //         }
  //       });
  //     } else {
  //       const error = response.initError(
  //         ClientResponse.InvalidSignature,
  //         false,
  //         new ErrorMessage('Invalid Signature'),
  //       );
  //       return res.status(200).send(error);
  //     }
  //   } catch (err) {
  //     const error = response.initError(
  //       ClientResponse.ServerError,
  //       false,
  //       new ErrorMessage("There's an error on the server, please wait :)"),
  //     );
  //     return res.status(200).send(error);
  //   }
  // }

  // async generateEwallet(
  //   payload: GeneratePaymentDto,
  //   req: FastifyOpenRequest,
  //   res: FastifyReply,
  // ) {
  //   try {
  //     if (payload.phone) {
  //       const { user, client } = req.user;
  //       const xSig = req.headers['x-signature'];
  //       const xTime = req.headers['x-timestamp'];

  //       const signatureVerify = encryptHmac(
  //         'sha512',
  //         client.signatureKey,
  //         encryptHmac(
  //           'sha512',
  //           client.signatureKey + user.id + client.id + xTime,
  //           'POST' +
  //             '|' +
  //             '/generate/ewallet' +
  //             '|' +
  //             hash('sha512', minifyJson(payload)).toLowerCase() +
  //             '|' +
  //             client.clientId +
  //             '|' +
  //             client.clientSecret,
  //           'hex',
  //         ) +
  //           '|' +
  //           client.clientId,
  //         'hex',
  //       );

  //       if (xSig === signatureVerify) {
  //         await this.Method.aggregate([
  //           {
  //             $match: {
  //               code: 'PAY' + payload.method,
  //               isActive: true,
  //               type: 'paymentewallet',
  //             },
  //           },
  //           {
  //             $lookup: {
  //               from: 'fees',
  //               let: { methodId: '$_id' },
  //               pipeline: [
  //                 {
  //                   $match: {
  //                     $expr: {
  //                       $and: [
  //                         { $eq: ['$method', '$$methodId'] },
  //                         { $eq: ['$feeType', FeeType.Transaction] },
  //                         { $eq: ['$user', { $toObjectId: user.id }] },
  //                       ],
  //                     },
  //                   },
  //                 },
  //               ],
  //               as: 'fee',
  //             },
  //           },
  //           {
  //             $unwind: '$fee',
  //           },
  //           {
  //             $lookup: {
  //               from: 'valuetypes',
  //               localField: 'fee.type',
  //               foreignField: '_id',
  //               as: 'fee.type',
  //             },
  //           },
  //           {
  //             $unwind: '$fee.type',
  //           },
  //         ]).then(async (methods) => {
  //           if (methods.length) {
  //             const method = methods[0];
  //             if (method.fee.isActive) {
  //               if (payload.amount < method.min) {
  //                 const error = response.initError(
  //                   ClientResponse.InvalidData,
  //                   false,
  //                   new ErrorMessage(
  //                     `Minimal amount ${toCurrency(method.min)}`,
  //                   ),
  //                 );
  //                 return res.status(200).send(error);
  //               } else if (payload.amount > method.max) {
  //                 const error = response.initError(
  //                   ClientResponse.InvalidData,
  //                   false,
  //                   new ErrorMessage(
  //                     `Maximal amount ${toCurrency(method.max)}`,
  //                   ),
  //                 );
  //                 return res.status(200).send(error);
  //               } else {
  //                 const exp = new Date(payload.expired);
  //                 if (exp.toString() === 'Invalid Date') {
  //                   const error = response.initError(
  //                     ClientResponse.InvalidData,
  //                     false,
  //                     new ErrorMessage('Invalid millis'),
  //                   );
  //                   return res.status(200).send(error);
  //                 } else {
  //                   const today = new Date();
  //                   today.setDate(today.getDate() + 1);
  //                   today.setHours(0, 0, 0, 0);

  //                   if (today <= exp) {
  //                     await this.Transaction.findOne({
  //                       clientRef: payload.transactionRef,
  //                     }).then(async (trans) => {
  //                       if (trans) {
  //                         const error = response.initError(
  //                           ClientResponse.InvalidData,
  //                           false,
  //                           new ErrorMessage('Transaction Ref must be unique'),
  //                         );
  //                         return res.status(200).send(error);
  //                       } else {
  //                         const dateString = exp
  //                           .toLocaleString('en-US', {
  //                             year: 'numeric',
  //                             month: '2-digit',
  //                             day: '2-digit',
  //                             hour: '2-digit',
  //                             minute: '2-digit',
  //                             second: '2-digit',
  //                           })
  //                           .replace(/\/|,|:| /g, '');
  //                         const formattedDate = `${dateString.slice(
  //                           4,
  //                           8,
  //                         )}${dateString.slice(0, 2)}${dateString.slice(
  //                           2,
  //                           4,
  //                         )}${dateString.slice(8, 14)}`;
  //                         const orderId = generateRandomNumber(50);
  //                         const customerId = exp.getTime();

  //                         let feeAmount: number;
  //                         switch (method.fee.type.name) {
  //                           case ValueType.Percentage:
  //                             feeAmount = Math.floor(
  //                               (payload.amount * method.fee.percentage) / 100,
  //                             );
  //                             break;
  //                           case ValueType.Fixed:
  //                             feeAmount = method.fee.fixed;
  //                             break;
  //                           default:
  //                             feeAmount = Math.floor(
  //                               (payload.amount * method.fee.percentage) / 100 +
  //                                 method.fee.fixed,
  //                             );
  //                             break;
  //                         }

  //                         const amount = method.fee.onClient
  //                           ? payload.amount
  //                           : payload.amount + feeAmount;
  //                         const reqMethod = 'POST';
  //                         const paramX = `${method.path}${reqMethod}`;
  //                         const paramY = `${amount}${formattedDate}${method.code}${orderId}${customerId}${APP_NAME}${EMAIL_NOT_PROVIDED}${payload.phone}${process.env.PG_CLIENT_ID}`;
  //                         const sig = encryptHmac(
  //                           'sha256',
  //                           process.env.PG_SIG_KEY,
  //                           paramX +
  //                             paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
  //                           'hex',
  //                         );

  //                         const payloadPg: any = {
  //                           expired: formattedDate,
  //                           amount: Number(amount),
  //                           customer_id: Number(customerId),
  //                           partner_reff: orderId,
  //                           customer_email: EMAIL_NOT_PROVIDED,
  //                           username: process.env.PG_USERNAME,
  //                           pin: process.env.PG_PIN,
  //                           customer_name: APP_NAME,
  //                           signature: sig,
  //                           ewallet_phone: payload.phone,
  //                           bill_title: 'NiagaPay',
  //                           retail_code: method.code,
  //                         };
  //                         const header = {
  //                           'Content-Type': CT_APP_JSON,
  //                           'client-id': process.env.PG_CLIENT_ID,
  //                           'client-secret': process.env.PG_CLIENT_SECRET,
  //                         };
  //                         await fetch(
  //                           process.env.PG_BASE_URL + method.path.substring(1),
  //                           {
  //                             method: reqMethod,
  //                             body: JSON.stringify(payloadPg),
  //                             headers: header,
  //                           },
  //                         )
  //                           .then(async (responseFetch) => {
  //                             const responseData = await responseFetch.json();

  //                             const transactionId =
  //                               'T' +
  //                               hash(
  //                                 'sha256',
  //                                 generateRandomNumber(25) + xTime,
  //                               );

  //                             const newTransaction = new this.Transaction({
  //                               clientCustName: payload.customerName,
  //                               transactionId,
  //                               orderId,
  //                               refId: responseData.partner_reff2,
  //                               amount,
  //                               fee: feeAmount,
  //                               feeAdmin: responseData.feeadmin,
  //                               phone: payload.phone,
  //                               payment:
  //                                 responseData.virtual_account ??
  //                                 responseData.payment_code ??
  //                                 responseData.qris_text,
  //                               url: responseData.url_payment,
  //                               exp,
  //                               method: new Types.ObjectId(method._id),
  //                               user: user.id,
  //                               clientRef: payload.transactionRef,
  //                               accessFrom: AccessFrom.Api,
  //                             });

  //                             var result: SOPResponse;
  //                             if (
  //                               responseData.status === PgType.Success &&
  //                               responseData.response_code ===
  //                                 PgType.SuccessCode
  //                             ) {
  //                               newTransaction.status =
  //                                 TransactionStatusType.Pending;
  //                               result = response.initSuccess(
  //                                 ClientResponse.Success,
  //                                 true,
  //                                 {
  //                                   amount,
  //                                   expired: exp.getTime(),
  //                                   method: payload.method,
  //                                   methodName: method.name,
  //                                   customerName: payload.customerName,
  //                                   ref1: payload.transactionRef,
  //                                   ref2: transactionId,
  //                                   desc: 'Success generate Ewallet Transaction',
  //                                   paymentCode: responseData.payment_code,
  //                                   deepLink: responseData.url_payment,
  //                                 },
  //                               );
  //                             } else {
  //                               newTransaction.status =
  //                                 TransactionStatusType.Failed;
  //                               result = response.initSuccess(
  //                                 ClientResponse.Success,
  //                                 false,
  //                                 {
  //                                   amount,
  //                                   expired: exp.getTime(),
  //                                   method: payload.method,
  //                                   methodName: method.name,
  //                                   customerName: payload.customerName,
  //                                   ref1: payload.transactionRef,
  //                                   ref2: transactionId,
  //                                   desc: 'Failed generate Ewallet Transaction',
  //                                   error: 'Ewallet Not Supported',
  //                                 },
  //                               );
  //                             }
  //                             await newTransaction.save();
  //                             return res.status(200).send(result);
  //                           })
  //                           .catch((err) => {
  //                             console.log(err);
  //                             const error = response.initError(
  //                               ClientResponse.ServerError,
  //                               false,
  //                               new ErrorMessage(
  //                                 "There's an error on the server, please wait :)",
  //                               ),
  //                             );
  //                             return res.status(200).send(error);
  //                           });
  //                       }
  //                     });
  //                   } else {
  //                     const error = response.initError(
  //                       ClientResponse.InvalidData,
  //                       false,
  //                       new ErrorMessage('Expired must be greater than today'),
  //                     );
  //                     return res.status(200).send(error);
  //                   }
  //                 }
  //               }
  //             } else {
  //               const error = response.initError(
  //                 ClientResponse.MethodNotAllowed,
  //                 false,
  //                 new ErrorMessage('Payment method not allowed'),
  //               );
  //               return res.status(200).send(error);
  //             }
  //           } else {
  //             const error = response.initError(
  //               ClientResponse.MethodNotFound,
  //               false,
  //               new ErrorMessage('Payment method not found'),
  //             );
  //             return res.status(200).send(error);
  //           }
  //         });
  //       } else {
  //         const error = response.initError(
  //           ClientResponse.InvalidSignature,
  //           false,
  //           new ErrorMessage('Invalid Signature'),
  //         );
  //         return res.status(200).send(error);
  //       }
  //     } else {
  //       const error = response.initError(
  //         ClientResponse.InvalidData,
  //         false,
  //         new ErrorMessage('Phone must not be empty'),
  //       );
  //       return res.status(200).send(error);
  //     }
  //   } catch (err) {
  //     const error = response.initError(
  //       ClientResponse.ServerError,
  //       false,
  //       new ErrorMessage("There's an error on the server, please wait :)"),
  //     );
  //     return res.status(200).send(error);
  //   }
  // }

  // async generateDevVa(
  //   payload: GeneratePaymentDto,
  //   req: FastifyOpenRequest,
  //   res: FastifyReply,
  // ) {
  //   try {
  //     const { user, client } = req.user;
  //     const xSig = req.headers['x-signature'];
  //     const xTime = req.headers['x-timestamp'];

  //     const signatureVerify = encryptHmac(
  //       'sha512',
  //       client.signatureKey,
  //       encryptHmac(
  //         'sha512',
  //         client.signatureKey + user.id + client.id + xTime,
  //         'POST' +
  //           '|' +
  //           '/dev/generate/va' +
  //           '|' +
  //           hash('sha512', minifyJson(payload)).toLowerCase() +
  //           '|' +
  //           client.clientId +
  //           '|' +
  //           client.clientSecret,
  //         'hex',
  //       ) +
  //         '|' +
  //         client.clientId,
  //       'hex',
  //     );

  //     if (xSig === signatureVerify) {
  //       await this.Method.aggregate([
  //         {
  //           $match: {
  //             code: payload.method,
  //             isActive: true,
  //             type: MethodType.Va,
  //           },
  //         },
  //         {
  //           $lookup: {
  //             from: 'fees',
  //             let: { methodId: '$_id' },
  //             pipeline: [
  //               {
  //                 $match: {
  //                   $expr: {
  //                     $and: [
  //                       { $eq: ['$method', '$$methodId'] },
  //                       { $eq: ['$feeType', FeeType.Transaction] },
  //                       { $eq: ['$user', { $toObjectId: user.id }] },
  //                     ],
  //                   },
  //                 },
  //               },
  //             ],
  //             as: 'fee',
  //           },
  //         },
  //         {
  //           $unwind: '$fee',
  //         },
  //         {
  //           $lookup: {
  //             from: 'valuetypes',
  //             localField: 'fee.type',
  //             foreignField: '_id',
  //             as: 'fee.type',
  //           },
  //         },
  //         {
  //           $unwind: '$fee.type',
  //         },
  //       ]).then(async (methods) => {
  //         if (methods.length) {
  //           const method = methods[0];
  //           if (method.fee.isActive) {
  //             if (payload.amount < method.min) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Minimal amount ${toCurrency(method.min)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else if (payload.amount > method.max) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Maximal amount ${toCurrency(method.max)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else {
  //               const exp = new Date(payload.expired);
  //               if (exp.toString() === 'Invalid Date') {
  //                 const error = response.initError(
  //                   ClientResponse.InvalidData,
  //                   false,
  //                   new ErrorMessage('Invalid millis'),
  //                 );
  //                 return res.status(200).send(error);
  //               } else {
  //                 const today = new Date();
  //                 today.setDate(today.getDate() + 1);
  //                 today.setHours(0, 0, 0, 0);

  //                 if (today <= exp) {
  //                   await this.DevTransaction.findOne({
  //                     clientRef: payload.transactionRef,
  //                   }).then(async (trans) => {
  //                     if (trans) {
  //                       const error = response.initError(
  //                         ClientResponse.InvalidData,
  //                         false,
  //                         new ErrorMessage('Transaction Ref must be unique'),
  //                       );
  //                       return res.status(200).send(error);
  //                     } else {
  //                       const orderId = generateRandomNumber(50);

  //                       let feeAmount: number;
  //                       switch (method.fee.type.name) {
  //                         case ValueType.Percentage:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100,
  //                           );
  //                           break;
  //                         case ValueType.Fixed:
  //                           feeAmount = method.fee.fixed;
  //                           break;
  //                         default:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100 +
  //                               method.fee.fixed,
  //                           );
  //                           break;
  //                       }

  //                       const amount = method.fee.onClient
  //                         ? payload.amount
  //                         : payload.amount + feeAmount;

  //                       const transactionId =
  //                         'T' +
  //                         hash('sha256', generateRandomNumber(25) + xTime);

  //                       const newDevTransaction = new this.DevTransaction({
  //                         clientCustName: payload.customerName,
  //                         transactionId,
  //                         orderId,
  //                         refId: 'dev_refId',
  //                         amount,
  //                         fee: feeAmount,
  //                         feeAdmin: 0,
  //                         payment: generateRandomNumber(15),
  //                         exp,
  //                         method: new Types.ObjectId(method._id),
  //                         user: user.id,
  //                         clientRef: payload.transactionRef,
  //                         status: TransactionStatusType.Pending,
  //                       });

  //                       await newDevTransaction.save();
  //                       return res.status(200).send(
  //                         response.initSuccess(ClientResponse.Success, true, {
  //                           amount,
  //                           expired: exp.getTime(),
  //                           method: payload.method,
  //                           methodName: method.name,
  //                           customerName: payload.customerName,
  //                           ref1: payload.transactionRef,
  //                           ref2: transactionId,
  //                           desc: 'Success generate Virtual Account',
  //                           va: newDevTransaction.payment,
  //                         }),
  //                       );
  //                     }
  //                   });
  //                 } else {
  //                   const error = response.initError(
  //                     ClientResponse.InvalidData,
  //                     false,
  //                     new ErrorMessage('Expired must be greater than today'),
  //                   );
  //                   return res.status(200).send(error);
  //                 }
  //               }
  //             }
  //           } else {
  //             const error = response.initError(
  //               ClientResponse.MethodNotAllowed,
  //               false,
  //               new ErrorMessage('Payment method not allowed'),
  //             );
  //             return res.status(200).send(error);
  //           }
  //         } else {
  //           const error = response.initError(
  //             ClientResponse.MethodNotFound,
  //             false,
  //             new ErrorMessage('Payment method not found'),
  //           );
  //           return res.status(200).send(error);
  //         }
  //       });
  //     } else {
  //       const error = response.initError(
  //         ClientResponse.InvalidSignature,
  //         false,
  //         new ErrorMessage('Invalid Signature'),
  //       );
  //       return res.status(200).send(error);
  //     }
  //   } catch (err) {
  //     const error = response.initError(
  //       ClientResponse.ServerError,
  //       false,
  //       new ErrorMessage("There's an error on the server, please wait :)"),
  //     );
  //     return res.status(200).send(error);
  //   }
  // }

  // async generateDevRetail(
  //   payload: GeneratePaymentDto,
  //   req: FastifyOpenRequest,
  //   res: FastifyReply,
  // ) {
  //   try {
  //     const { user, client } = req.user;
  //     const xSig = req.headers['x-signature'];
  //     const xTime = req.headers['x-timestamp'];

  //     const signatureVerify = encryptHmac(
  //       'sha512',
  //       client.signatureKey,
  //       encryptHmac(
  //         'sha512',
  //         client.signatureKey + user.id + client.id + xTime,
  //         'POST' +
  //           '|' +
  //           '/dev/generate/retail' +
  //           '|' +
  //           hash('sha512', minifyJson(payload)).toLowerCase() +
  //           '|' +
  //           client.clientId +
  //           '|' +
  //           client.clientSecret,
  //         'hex',
  //       ) +
  //         '|' +
  //         client.clientId,
  //       'hex',
  //     );

  //     if (xSig === signatureVerify) {
  //       await this.Method.aggregate([
  //         {
  //           $match: {
  //             code: payload.method,
  //             isActive: true,
  //             type: MethodType.Retail,
  //           },
  //         },
  //         {
  //           $lookup: {
  //             from: 'fees',
  //             let: { methodId: '$_id' },
  //             pipeline: [
  //               {
  //                 $match: {
  //                   $expr: {
  //                     $and: [
  //                       { $eq: ['$method', '$$methodId'] },
  //                       { $eq: ['$feeType', FeeType.Transaction] },
  //                       { $eq: ['$user', { $toObjectId: user.id }] },
  //                     ],
  //                   },
  //                 },
  //               },
  //             ],
  //             as: 'fee',
  //           },
  //         },
  //         {
  //           $unwind: '$fee',
  //         },
  //         {
  //           $lookup: {
  //             from: 'valuetypes',
  //             localField: 'fee.type',
  //             foreignField: '_id',
  //             as: 'fee.type',
  //           },
  //         },
  //         {
  //           $unwind: '$fee.type',
  //         },
  //       ]).then(async (methods) => {
  //         if (methods.length) {
  //           const method = methods[0];
  //           if (method.fee.isActive) {
  //             if (payload.amount < method.min) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Minimal amount ${toCurrency(method.min)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else if (payload.amount > method.max) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Maximal amount ${toCurrency(method.max)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else {
  //               const exp = new Date(payload.expired);
  //               if (exp.toString() === 'Invalid Date') {
  //                 const error = response.initError(
  //                   ClientResponse.InvalidData,
  //                   false,
  //                   new ErrorMessage('Invalid millis'),
  //                 );
  //                 return res.status(200).send(error);
  //               } else {
  //                 const today = new Date();
  //                 today.setDate(today.getDate() + 1);
  //                 today.setHours(0, 0, 0, 0);

  //                 if (today <= exp) {
  //                   await this.DevTransaction.findOne({
  //                     clientRef: payload.transactionRef,
  //                   }).then(async (trans) => {
  //                     if (trans) {
  //                       const error = response.initError(
  //                         ClientResponse.InvalidData,
  //                         false,
  //                         new ErrorMessage('Transaction Ref must be unique'),
  //                       );
  //                       return res.status(200).send(error);
  //                     } else {
  //                       const orderId = generateRandomNumber(50);

  //                       let feeAmount: number;
  //                       switch (method.fee.type.name) {
  //                         case ValueType.Percentage:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100,
  //                           );
  //                           break;
  //                         case ValueType.Fixed:
  //                           feeAmount = method.fee.fixed;
  //                           break;
  //                         default:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100 +
  //                               method.fee.fixed,
  //                           );
  //                           break;
  //                       }

  //                       const amount = method.fee.onClient
  //                         ? payload.amount
  //                         : payload.amount + feeAmount;

  //                       const transactionId =
  //                         'T' +
  //                         hash('sha256', generateRandomNumber(25) + xTime);

  //                       const newDevTransaction = new this.DevTransaction({
  //                         clientCustName: payload.customerName,
  //                         transactionId,
  //                         orderId,
  //                         refId: 'dev_refId',
  //                         amount,
  //                         fee: feeAmount,
  //                         feeAdmin: 0,
  //                         payment: generateRandomNumber(15),
  //                         exp,
  //                         method: new Types.ObjectId(method._id),
  //                         user: user.id,
  //                         clientRef: payload.transactionRef,
  //                         status: TransactionStatusType.Pending,
  //                       });

  //                       await newDevTransaction.save();
  //                       return res.status(200).send(
  //                         response.initSuccess(ClientResponse.Success, true, {
  //                           amount,
  //                           expired: exp.getTime(),
  //                           method: payload.method,
  //                           methodName: method.name,
  //                           customerName: payload.customerName,
  //                           ref1: payload.transactionRef,
  //                           ref2: transactionId,
  //                           desc: 'Success generate Retail Payment Code',
  //                           paymentCode: newDevTransaction.payment,
  //                         }),
  //                       );
  //                     }
  //                   });
  //                 } else {
  //                   const error = response.initError(
  //                     ClientResponse.InvalidData,
  //                     false,
  //                     new ErrorMessage('Expired must be greater than today'),
  //                   );
  //                   return res.status(200).send(error);
  //                 }
  //               }
  //             }
  //           } else {
  //             const error = response.initError(
  //               ClientResponse.MethodNotAllowed,
  //               false,
  //               new ErrorMessage('Payment method not allowed'),
  //             );
  //             return res.status(200).send(error);
  //           }
  //         } else {
  //           const error = response.initError(
  //             ClientResponse.MethodNotFound,
  //             false,
  //             new ErrorMessage('Payment method not found'),
  //           );
  //           return res.status(200).send(error);
  //         }
  //       });
  //     } else {
  //       const error = response.initError(
  //         ClientResponse.InvalidSignature,
  //         false,
  //         new ErrorMessage('Invalid Signature'),
  //       );
  //       return res.status(200).send(error);
  //     }
  //   } catch (err) {
  //     const error = response.initError(
  //       ClientResponse.ServerError,
  //       false,
  //       new ErrorMessage("There's an error on the server, please wait :)"),
  //     );
  //     return res.status(200).send(error);
  //   }
  // }

  // async generateDevQris(
  //   payload: GeneratePaymentDto,
  //   req: FastifyOpenRequest,
  //   res: FastifyReply,
  // ) {
  //   try {
  //     const { user, client } = req.user;
  //     const xSig = req.headers['x-signature'];
  //     const xTime = req.headers['x-timestamp'];

  //     const signatureVerify = encryptHmac(
  //       'sha512',
  //       client.signatureKey,
  //       encryptHmac(
  //         'sha512',
  //         client.signatureKey + user.id + client.id + xTime,
  //         'POST' +
  //           '|' +
  //           '/dev/generate/qris' +
  //           '|' +
  //           hash('sha512', minifyJson(payload)).toLowerCase() +
  //           '|' +
  //           client.clientId +
  //           '|' +
  //           client.clientSecret,
  //         'hex',
  //       ) +
  //         '|' +
  //         client.clientId,
  //       'hex',
  //     );

  //     if (xSig === signatureVerify) {
  //       await this.Method.aggregate([
  //         {
  //           $match: {
  //             code: payload.method,
  //             isActive: true,
  //             type: MethodType.Qris,
  //           },
  //         },
  //         {
  //           $lookup: {
  //             from: 'fees',
  //             let: { methodId: '$_id' },
  //             pipeline: [
  //               {
  //                 $match: {
  //                   $expr: {
  //                     $and: [
  //                       { $eq: ['$method', '$$methodId'] },
  //                       { $eq: ['$feeType', FeeType.Transaction] },
  //                       { $eq: ['$user', { $toObjectId: user.id }] },
  //                     ],
  //                   },
  //                 },
  //               },
  //             ],
  //             as: 'fee',
  //           },
  //         },
  //         {
  //           $unwind: '$fee',
  //         },
  //         {
  //           $lookup: {
  //             from: 'valuetypes',
  //             localField: 'fee.type',
  //             foreignField: '_id',
  //             as: 'fee.type',
  //           },
  //         },
  //         {
  //           $unwind: '$fee.type',
  //         },
  //       ]).then(async (methods) => {
  //         if (methods.length) {
  //           const method = methods[0];
  //           if (method.fee.isActive) {
  //             if (payload.amount < method.min) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Minimal amount ${toCurrency(method.min)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else if (payload.amount > method.max) {
  //               const error = response.initError(
  //                 ClientResponse.InvalidData,
  //                 false,
  //                 new ErrorMessage(`Maximal amount ${toCurrency(method.max)}`),
  //               );
  //               return res.status(200).send(error);
  //             } else {
  //               const exp = new Date(payload.expired);
  //               if (exp.toString() === 'Invalid Date') {
  //                 const error = response.initError(
  //                   ClientResponse.InvalidData,
  //                   false,
  //                   new ErrorMessage('Invalid millis'),
  //                 );
  //                 return res.status(200).send(error);
  //               } else {
  //                 const today = new Date();
  //                 today.setDate(today.getDate() + 1);
  //                 today.setHours(0, 0, 0, 0);

  //                 if (today <= exp) {
  //                   await this.DevTransaction.findOne({
  //                     clientRef: payload.transactionRef,
  //                   }).then(async (trans) => {
  //                     if (trans) {
  //                       const error = response.initError(
  //                         ClientResponse.InvalidData,
  //                         false,
  //                         new ErrorMessage('Transaction Ref must be unique'),
  //                       );
  //                       return res.status(200).send(error);
  //                     } else {
  //                       const orderId = generateRandomNumber(50);

  //                       let feeAmount: number;
  //                       switch (method.fee.type.name) {
  //                         case ValueType.Percentage:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100,
  //                           );
  //                           break;
  //                         case ValueType.Fixed:
  //                           feeAmount = method.fee.fixed;
  //                           break;
  //                         default:
  //                           feeAmount = Math.floor(
  //                             (payload.amount * method.fee.percentage) / 100 +
  //                               method.fee.fixed,
  //                           );
  //                           break;
  //                       }

  //                       const amount = method.fee.onClient
  //                         ? payload.amount
  //                         : payload.amount + feeAmount;

  //                       const transactionId =
  //                         'T' +
  //                         hash('sha256', generateRandomNumber(25) + xTime);

  //                       const newDevTransaction = new this.DevTransaction({
  //                         clientCustName: payload.customerName,
  //                         transactionId,
  //                         orderId,
  //                         refId: 'dev_refId',
  //                         amount,
  //                         fee: feeAmount,
  //                         feeAdmin: 0,
  //                         payment: `qris_test_${generateRandomNumber(20)}`,
  //                         exp,
  //                         method: new Types.ObjectId(method._id),
  //                         user: user.id,
  //                         clientRef: payload.transactionRef,
  //                         status: TransactionStatusType.Pending,
  //                       });

  //                       await newDevTransaction.save();
  //                       return res.status(200).send(
  //                         response.initSuccess(ClientResponse.Success, true, {
  //                           amount,
  //                           expired: exp.getTime(),
  //                           method: payload.method,
  //                           methodName: method.name,
  //                           customerName: payload.customerName,
  //                           ref1: payload.transactionRef,
  //                           ref2: transactionId,
  //                           desc: 'Success generate QRIS',
  //                           qris: newDevTransaction.payment,
  //                         }),
  //                       );
  //                     }
  //                   });
  //                 } else {
  //                   const error = response.initError(
  //                     ClientResponse.InvalidData,
  //                     false,
  //                     new ErrorMessage('Expired must be greater than today'),
  //                   );
  //                   return res.status(200).send(error);
  //                 }
  //               }
  //             }
  //           } else {
  //             const error = response.initError(
  //               ClientResponse.MethodNotAllowed,
  //               false,
  //               new ErrorMessage('Payment method not allowed'),
  //             );
  //             return res.status(200).send(error);
  //           }
  //         } else {
  //           const error = response.initError(
  //             ClientResponse.MethodNotFound,
  //             false,
  //             new ErrorMessage('Payment method not found'),
  //           );
  //           return res.status(200).send(error);
  //         }
  //       });
  //     } else {
  //       const error = response.initError(
  //         ClientResponse.InvalidSignature,
  //         false,
  //         new ErrorMessage('Invalid Signature'),
  //       );
  //       return res.status(200).send(error);
  //     }
  //   } catch (err) {
  //     const error = response.initError(
  //       ClientResponse.ServerError,
  //       false,
  //       new ErrorMessage("There's an error on the server, please wait :)"),
  //     );
  //     return res.status(200).send(error);
  //   }
  // }

  // async generateDevEwallet(
  //   payload: GeneratePaymentDto,
  //   req: FastifyOpenRequest,
  //   res: FastifyReply,
  // ) {
  //   try {
  //     if (payload.phone) {
  //       const { user, client } = req.user;
  //       const xSig = req.headers['x-signature'];
  //       const xTime = req.headers['x-timestamp'];

  //       const signatureVerify = encryptHmac(
  //         'sha512',
  //         client.signatureKey,
  //         encryptHmac(
  //           'sha512',
  //           client.signatureKey + user.id + client.id + xTime,
  //           'POST' +
  //             '|' +
  //             '/dev/generate/ewallet' +
  //             '|' +
  //             hash('sha512', minifyJson(payload)).toLowerCase() +
  //             '|' +
  //             client.clientId +
  //             '|' +
  //             client.clientSecret,
  //           'hex',
  //         ) +
  //           '|' +
  //           client.clientId,
  //         'hex',
  //       );

  //       if (xSig === signatureVerify) {
  //         await this.Method.aggregate([
  //           {
  //             $match: {
  //               code: 'PAY' + payload.method,
  //               isActive: true,
  //               type: MethodType.Ewallet,
  //             },
  //           },
  //           {
  //             $lookup: {
  //               from: 'fees',
  //               let: { methodId: '$_id' },
  //               pipeline: [
  //                 {
  //                   $match: {
  //                     $expr: {
  //                       $and: [
  //                         { $eq: ['$method', '$$methodId'] },
  //                         { $eq: ['$feeType', FeeType.Transaction] },
  //                         { $eq: ['$user', { $toObjectId: user.id }] },
  //                       ],
  //                     },
  //                   },
  //                 },
  //               ],
  //               as: 'fee',
  //             },
  //           },
  //           {
  //             $unwind: '$fee',
  //           },
  //           {
  //             $lookup: {
  //               from: 'valuetypes',
  //               localField: 'fee.type',
  //               foreignField: '_id',
  //               as: 'fee.type',
  //             },
  //           },
  //           {
  //             $unwind: '$fee.type',
  //           },
  //         ]).then(async (methods) => {
  //           if (methods.length) {
  //             const method = methods[0];
  //             if (method.fee.isActive) {
  //               if (payload.amount < method.min) {
  //                 const error = response.initError(
  //                   ClientResponse.InvalidData,
  //                   false,
  //                   new ErrorMessage(
  //                     `Minimal amount ${toCurrency(method.min)}`,
  //                   ),
  //                 );
  //                 return res.status(200).send(error);
  //               } else if (payload.amount > method.max) {
  //                 const error = response.initError(
  //                   ClientResponse.InvalidData,
  //                   false,
  //                   new ErrorMessage(
  //                     `Maximal amount ${toCurrency(method.max)}`,
  //                   ),
  //                 );
  //                 return res.status(200).send(error);
  //               } else {
  //                 const exp = new Date(payload.expired);
  //                 if (exp.toString() === 'Invalid Date') {
  //                   const error = response.initError(
  //                     ClientResponse.InvalidData,
  //                     false,
  //                     new ErrorMessage('Invalid millis'),
  //                   );
  //                   return res.status(200).send(error);
  //                 } else {
  //                   const today = new Date();
  //                   today.setDate(today.getDate() + 1);
  //                   today.setHours(0, 0, 0, 0);

  //                   if (today <= exp) {
  //                     await this.DevTransaction.findOne({
  //                       clientRef: payload.transactionRef,
  //                     }).then(async (trans) => {
  //                       if (trans) {
  //                         const error = response.initError(
  //                           ClientResponse.InvalidData,
  //                           false,
  //                           new ErrorMessage('Transaction Ref must be unique'),
  //                         );
  //                         return res.status(200).send(error);
  //                       } else {
  //                         const orderId = generateRandomNumber(50);

  //                         let feeAmount: number;
  //                         switch (method.fee.type.name) {
  //                           case ValueType.Percentage:
  //                             feeAmount = Math.floor(
  //                               (payload.amount * method.fee.percentage) / 100,
  //                             );
  //                             break;
  //                           case ValueType.Fixed:
  //                             feeAmount = method.fee.fixed;
  //                             break;
  //                           default:
  //                             feeAmount = Math.floor(
  //                               (payload.amount * method.fee.percentage) / 100 +
  //                                 method.fee.fixed,
  //                             );
  //                             break;
  //                         }

  //                         const amount = method.fee.onClient
  //                           ? payload.amount
  //                           : payload.amount + feeAmount;

  //                         const transactionId =
  //                           'T' +
  //                           hash('sha256', generateRandomNumber(25) + xTime);

  //                         const newDevTransaction = new this.DevTransaction({
  //                           clientCustName: payload.customerName,
  //                           transactionId,
  //                           orderId,
  //                           refId: 'dev_refId',
  //                           amount,
  //                           fee: feeAmount,
  //                           feeAdmin: 0,
  //                           phone: payload.phone,
  //                           payment: generateRandomNumber(15),
  //                           url: `deeplink_test_${generateRandomNumber(20)}`,
  //                           exp,
  //                           method: new Types.ObjectId(method._id),
  //                           user: user.id,
  //                           clientRef: payload.transactionRef,
  //                           status: TransactionStatusType.Pending,
  //                         });

  //                         await newDevTransaction.save();
  //                         return res.status(200).send(
  //                           response.initSuccess(ClientResponse.Success, true, {
  //                             amount,
  //                             expired: exp.getTime(),
  //                             method: payload.method,
  //                             methodName: method.name,
  //                             customerName: payload.customerName,
  //                             ref1: payload.transactionRef,
  //                             ref2: transactionId,
  //                             desc: 'Success generate Ewallet Transaction',
  //                             paymentCode: newDevTransaction.payment,
  //                             deepLink: newDevTransaction.url,
  //                           }),
  //                         );
  //                       }
  //                     });
  //                   } else {
  //                     const error = response.initError(
  //                       ClientResponse.InvalidData,
  //                       false,
  //                       new ErrorMessage('Expired must be greater than today'),
  //                     );
  //                     return res.status(200).send(error);
  //                   }
  //                 }
  //               }
  //             } else {
  //               const error = response.initError(
  //                 ClientResponse.MethodNotAllowed,
  //                 false,
  //                 new ErrorMessage('Payment method not allowed'),
  //               );
  //               return res.status(200).send(error);
  //             }
  //           } else {
  //             const error = response.initError(
  //               ClientResponse.MethodNotFound,
  //               false,
  //               new ErrorMessage('Payment method not found'),
  //             );
  //             return res.status(200).send(error);
  //           }
  //         });
  //       } else {
  //         const error = response.initError(
  //           ClientResponse.InvalidSignature,
  //           false,
  //           new ErrorMessage('Invalid Signature'),
  //         );
  //         return res.status(200).send(error);
  //       }
  //     } else {
  //       const error = response.initError(
  //         ClientResponse.InvalidData,
  //         false,
  //         new ErrorMessage('Phone must not be empty'),
  //       );
  //       return res.status(200).send(error);
  //     }
  //   } catch (err) {
  //     const error = response.initError(
  //       ClientResponse.ServerError,
  //       false,
  //       new ErrorMessage("There's an error on the server, please wait :)"),
  //     );
  //     return res.status(200).send(error);
  //   }
  // }
}
