import {
  Controller,
  Body,
  UseGuards,
  Req,
  Res,
  Post,
  Get,
  Param,
} from '@nestjs/common';
import { OpenService } from './open.service';
import { FastifyReply, FastifyRequest } from 'fastify';
import { SkipThrottle } from '@nestjs/throttler';

import { FastifyOpenRequest } from 'src/common/interface/fastify-open.interface';
import { ValidationPipe } from 'src/core/pipes/validation.pipe';
import { OpenGuard } from 'src/common/middleware/open/open.guard';
import { Public, Roles } from 'src/core/decorators/role.decorator';
import { Role } from 'src/common/config/enum';

import { GeneratePaymentDto } from './dto/generate-payment.dto';
import { TransferInquiryDto } from './dto/transfer-inquiry.dto';
import { TransferPaymentDto } from './dto/transfer-payment.dto';
import { TopupDto } from './dto/topup.dto';
import { API_HOSTNAME } from 'src/common/config/constants';
import { ApiBasicAuth } from '@nestjs/swagger';

@Controller({ path: 'open', version: '1' })
@SkipThrottle()
@ApiBasicAuth()
@Roles(Role.Client)
@UseGuards(OpenGuard)
export class OpenController {
  constructor(private readonly openService: OpenService) {}

  @Public()
  @Get('/img/:filename')
  getImg(@Param('filename') filename: string, @Res() res: FastifyReply) {
    this.openService.getImg(filename, res);
  }

  @Get('/utility/method')
  getMethod(@Res() res: FastifyReply) {
    this.openService.getMethod(res);
  }

  @Get('/utility/bank')
  getBank(@Req() req: FastifyOpenRequest, @Res() res: FastifyReply) {
    this.openService.getBank(req, res);
  }

  @Get('/utility/balance')
  getBalance(@Req() req: FastifyOpenRequest, @Res() res: FastifyReply) {
    if (req.headers['hostname'] === API_HOSTNAME) {
      this.openService.getBalance(req, res);
    } else {
      this.openService.getDevBalance(req, res);
    }
  }

  @Post('/signature')
  generateSignature(
    @Body() payload: any,
    @Req() req: FastifyOpenRequest,
    @Res() res: FastifyReply,
  ) {
    this.openService.generateSignature(payload, req, res);
  }

  @Post('/generate/:type')
  generatePayment(
    @Body(new ValidationPipe()) data: GeneratePaymentDto,
    @Param('type') type: string,
    @Req() req: FastifyOpenRequest,
    @Res() res: FastifyReply,
  ) {
    if (req.headers['hostname'] === API_HOSTNAME) {
      this.openService.generatePayment(data, type, req, res);
    } else {
      this.openService.generateDevPayment(data, type, req, res);
    }
  }

  @Post('/transfer/:type/inquiry')
  transferInquiry(
    @Body(new ValidationPipe()) data: TransferInquiryDto,
    @Param('type') type: string,
    @Req() req: FastifyOpenRequest,
    @Res() res: FastifyReply,
  ) {
    if (req.headers['hostname'] === API_HOSTNAME) {
      this.openService.transferInquiry(data, type, req, res);
    } else {
      this.openService.transferDevInquiry(data, type, req, res);
    }
  }

  @Post('/transfer/:type/payment')
  transferPayment(
    @Body(new ValidationPipe()) data: TransferPaymentDto,
    @Param('type') type: string,
    @Req() req: FastifyOpenRequest,
    @Res() res: FastifyReply,
  ) {
    if (req.headers['hostname'] === API_HOSTNAME) {
      this.openService.transferPayment(data, type, req, res);
    } else {
      this.openService.transferDevPayment(data, type, req, res);
    }
  }

  @Post('/topup/:type')
  topupBalance(
    @Body(new ValidationPipe()) data: TopupDto,
    @Param('type') type: string,
    @Req() req: FastifyOpenRequest,
    @Res() res: FastifyReply,
  ) {
    if (req.headers['hostname'] === API_HOSTNAME) {
      this.openService.topupBalance(data, type, req, res);
    } else {
      this.openService.topupDevBalance(data, type, req, res);
    }
  }

  @Get('/status/:type/:clientRef')
  status(
    @Param('type') type: string,
    @Param('clientRef') clientRef: string,
    @Req() req: FastifyOpenRequest,
    @Res() res: FastifyReply,
  ) {
    if (req.headers['hostname'] === API_HOSTNAME) {
      this.openService.checkStatus(type, clientRef, req, res);
    } else {
      this.openService.checkDevStatus(type, clientRef, req, res);
    }
  }

  // @Post('/transaction/qr/dynamic')
  // createTransactionQrDynamic(
  //   @Body(new ValidationPipe()) createQrDynamicDto: CreateQrDynamicDto,
  //   @Req() req: FastifyOpenRequest,
  //   @Res() res: FastifyReply,
  // ) {
  //   // this.openService.createQrDynamic(createQrDynamicDto, req, res);
  // }

  @Public()
  @Post('/test')
  test(
    @Body() body: any,
    @Req() req: FastifyRequest,
    @Res() res: FastifyReply,
  ) {
    this.openService.test(body, req, res);
  }

  // @Get('/stream')
  // getStreamKey(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
  //   this.overlayService.getStreamKey(req, res);
  // }

  // @Patch(':name')
  // @ApiParam({
  //   name: 'name',
  //   type: 'string',
  //   example: [
  //     'alert',
  //     'mediashare',
  //     'subathon',
  //     'voting',
  //     'qr',
  //     'milestone',
  //     'leaderboard',
  //     'runningtext',
  //     'wheel',
  //   ],
  //   description: 'Overlay Name',
  // })
  // update(
  //   @Param('name') name: string,
  //   @Body() body: any,
  //   @Req() req: FastifyUserRequest,
  //   @Res() res: FastifyReply,
  // ) {
  //   this.overlayService.updateOverlayConfig(name, body, req, res);
  // }
}
