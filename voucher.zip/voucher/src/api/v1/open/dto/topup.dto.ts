import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class TopupDto {
  @IsNotEmpty({ message: 'Amount must not be empty' })
  @IsNumber()
  amount: number;

  @IsNotEmpty({ message: 'Transaction Ref must not be empty' })
  @IsString()
  transactionRef: string;

  @IsNotEmpty({ message: 'Method must not be empty' })
  @IsString()
  method: string;

  @IsString()
  @IsOptional()
  phone: string;
}
