import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class TransferPaymentDto {
  @IsNotEmpty({ message: 'Amount must not be empty' })
  @IsNumber()
  amount: number;

  @IsNotEmpty({ message: 'Transaction Ref must not be empty' })
  @IsString()
  transferRef: string;

  @IsString()
  @IsNotEmpty({ message: 'Payment Ref must not be empty' })
  paymentRef: string;

  @IsNotEmpty({ message: 'Bank Code must not be empty' })
  @IsString()
  channelCode: string;

  @IsString()
  @IsOptional()
  accountNumber: string;

  @IsString()
  @IsOptional()
  remark: string;

  @IsString()
  @IsOptional()
  customerPhone: string;

  @IsString()
  @IsOptional()
  customerEmail: string;
}
