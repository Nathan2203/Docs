import { IsString } from 'class-validator';

export class CreateWalletDto {
  @IsString()
  signature: string;

  @IsString()
  username: string;

  @IsString()
  email: string;

  @IsString()
  name: string;

  @IsString()
  phoneNo: string;
}
