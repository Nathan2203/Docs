import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class GeneratePaymentDto {
  @IsNotEmpty({ message: 'Expired must not be empty' })
  @IsNumber()
  expired: number;

  @IsNotEmpty({ message: 'Amount must not be empty' })
  @IsNumber()
  amount: number;

  @IsNotEmpty({ message: 'Transaction Ref must not be empty' })
  @IsString()
  transactionRef: string;

  @IsNotEmpty({ message: 'Customer Name must not be empty' })
  @IsString()
  customerName: string;

  @IsNotEmpty({ message: 'Method must not be empty' })
  @IsString()
  method: string;

  @IsString()
  @IsOptional()
  phone: string;
}
