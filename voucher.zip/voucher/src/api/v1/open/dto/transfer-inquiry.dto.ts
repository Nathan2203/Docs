import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class TransferInquiryDto {
  @IsNotEmpty({ message: 'Amount must not be empty' })
  @IsNumber()
  amount: number;

  @IsNotEmpty({ message: 'Transaction Ref must not be empty' })
  @IsString()
  transferRef: string;

  @IsNotEmpty({ message: 'Channel Code must not be empty' })
  @IsString()
  channelCode: string;

  @IsString()
  @IsOptional()
  accountNumber: string;

  @IsString()
  @IsOptional()
  customerEmail: string;

  @IsString()
  @IsOptional()
  customerPhone: string;

  @IsString()
  @IsOptional()
  remark: string;
}
