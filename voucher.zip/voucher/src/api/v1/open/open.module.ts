import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';

import { OpenStrategy } from 'src/common/middleware/open/open.strategy';
import { OpenGuard } from 'src/common/middleware/open/open.guard';

import { OpenService } from './open.service';
import { OpenController } from './open.controller';

import { User, UserSchema } from '../user/entities/user.entity';
import { Client, ClientSchema } from './entities/client.entity';
import { Method, MethodSchema } from '../public/entities/method.entity';
import {
  Transaction,
  TransactionSchema,
} from '../user/entities/transaction.entity';
import { DevClient, DevClientSchema } from './entities/dev-client.entity';
import {
  DevTransaction,
  DevTransactionSchema,
} from './entities/dev-transaction.entity';
import { Bank, BankSchema } from '../admin/entities/bank.entity';
import {
  Commission,
  CommissionSchema,
} from '../partner/entities/commission.entity';
import { Balance, BalanceSchema } from '../user/entities/balance.entity';
import { Withdraw, WithdrawSchema } from '../user/entities/withdraw.entity';
import {
  BalanceLog,
  BalanceLogSchema,
} from '../user/entities/balance-log.entity';
import { DevBalance, DevBalanceSchema } from './entities/dev-balance.entity';
import { DevWithdraw, DevWithdrawSchema } from './entities/dev-withdraw.entity';
import { ProviderModule } from 'src/core/provider/provider.module';

@Module({
  imports: [
    ProviderModule,
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Client.name, schema: ClientSchema },
      { name: DevClient.name, schema: DevClientSchema },
      { name: Method.name, schema: MethodSchema },
      { name: Bank.name, schema: BankSchema },
      { name: Transaction.name, schema: TransactionSchema },
      { name: DevTransaction.name, schema: DevTransactionSchema },
      { name: Commission.name, schema: CommissionSchema },
      { name: Balance.name, schema: BalanceSchema },
      { name: DevBalance.name, schema: DevBalanceSchema },
      { name: BalanceLog.name, schema: BalanceLogSchema },
      { name: Withdraw.name, schema: WithdrawSchema },
      { name: DevWithdraw.name, schema: DevWithdrawSchema },
    ]),
  ],
  controllers: [OpenController],
  providers: [OpenService, OpenStrategy, OpenGuard],
})
export class OpenModule {}
