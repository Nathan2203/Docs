import { Module } from '@nestjs/common';
import { PublicService } from './public.service';
import { PublicController } from './public.controller';
import { MongooseModule } from '@nestjs/mongoose';

import { BrowserStrategy } from 'src/common/middleware/public/browser.strategy';
import { BrowserGuard } from 'src/common/middleware/public/browser.guard';

import { Category, CategorySchema } from './entities/category.entity';
import { Browser, BrowserSchema } from '../user/entities/browser.entity';
import { Method, MethodSchema } from './entities/method.entity';
import { BrandType, BrandTypeSchema } from './entities/brand-type.entity';
import { User, UserSchema } from '../user/entities/user.entity';
import { Fee, FeeSchema } from '../admin/entities/fee.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Browser.name, schema: BrowserSchema },
      { name: Category.name, schema: CategorySchema },
      { name: BrandType.name, schema: BrandTypeSchema },
      { name: Fee.name, schema: FeeSchema },
      { name: Method.name, schema: MethodSchema },
      { name: User.name, schema: UserSchema },
    ]),
  ],
  controllers: [PublicController],
  providers: [PublicService, BrowserStrategy, BrowserGuard],
})
export class PublicModule {}
