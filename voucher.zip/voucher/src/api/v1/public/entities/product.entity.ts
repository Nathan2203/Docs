import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';

export type ProductDocument = HydratedDocument<Product>;

@Schema({ timestamps: true })
export class Product {
  @Prop()
  name: string;

  @Prop()
  type: string;

  @Prop()
  seller: string;

  @Prop()
  price: number;

  @Prop()
  code: string;

  @Prop()
  status: boolean;

  @Prop()
  multi: boolean;

  @Prop()
  desc: string;

  @Prop()
  startCutOff: string;

  @Prop()
  endCutOff: string;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'BrandType' })
  brandType: Types.ObjectId;
}

export const ProductSchema = SchemaFactory.createForClass(Product);
