import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';

export type BrandTypeDocument = HydratedDocument<BrandType>;

@Schema({ timestamps: true })
export class BrandType {
  @Prop()
  name: string;

  @Prop()
  form: string;

  @Prop({
    default: undefined,
  })
  servers: [string];

  @Prop()
  code: number;

  @Prop({ default: true })
  isActive: boolean;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Brand' })
  brand: Types.ObjectId;
}

export const BrandTypeSchema = SchemaFactory.createForClass(BrandType);
