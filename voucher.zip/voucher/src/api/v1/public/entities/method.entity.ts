import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { MethodType } from 'src/common/config/enum';

export type MethodDocument = HydratedDocument<Method>;

@Schema({ timestamps: true })
export class Method {
  @Prop()
  name: string;

  @Prop()
  code: string;

  @Prop({ enum: MethodType })
  type: string;

  @Prop()
  img: string;

  @Prop()
  path: string;

  @Prop()
  min: number;

  @Prop()
  max: number;

  @Prop({ default: true })
  isActive: boolean;
}

export const MethodSchema = SchemaFactory.createForClass(Method);
