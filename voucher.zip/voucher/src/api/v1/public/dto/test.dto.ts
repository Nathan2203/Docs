import { IsNumber, IsOptional, IsString } from 'class-validator';

export class TestDto {
  @IsNumber()
  type: number;

  @IsString()
  path: string;

  @IsString()
  method: string;

  @IsString()
  amount: string;

  @IsString()
  code: string;

  @IsString()
  customerId: string;

  @IsString()
  customerName: string;

  @IsString()
  customerEmail: string;

  @IsString()
  @IsOptional()
  phone: string;
}
