import { IsNotEmpty, IsString } from 'class-validator';

export class GetBrandDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  category: string;

  @IsString()
  brand: string;
}
