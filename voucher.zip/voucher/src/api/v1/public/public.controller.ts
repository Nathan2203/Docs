import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import { ApiHeader, ApiOperation, ApiTags } from '@nestjs/swagger';
import { FastifyReply, FastifyRequest } from 'fastify';

import { Public } from 'src/core/decorators/public.decorator';
import { BrowserGuard } from 'src/common/middleware/public/browser.guard';
import { FastifyBrowserRequest } from 'src/common/interface/fastify-browser.interface';

import { PublicService } from './public.service';
import { ValidationPipe } from 'src/core/pipes/validation.pipe';

import { TestDto } from './dto/test.dto';
import { GetBrandDto } from './dto/get-brand.dto';

@ApiTags('Public')
@Controller({ path: 'p', version: '1' })
@ApiHeader({
  name: 'x-browser-id',
  description: 'Browser ID',
  required: true,
})
@UseGuards(BrowserGuard)
export class PublicController {
  constructor(private readonly publicService: PublicService) {}

  @Public()
  @Get('/browser')
  getBrowserId(@Req() req: FastifyRequest, @Res() res: FastifyReply) {
    this.publicService.getBrowserId(req, res);
  }

  @Get('/csrf')
  getCsrf(@Req() req: FastifyBrowserRequest, @Res() res: FastifyReply) {
    this.publicService.getCsrf(req, res);
  }

  @Get('/category')
  getCategory(@Req() req: FastifyRequest, @Res() res: FastifyReply) {
    this.publicService.getCategory(res);
  }

  @Post('/category')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  getProduct(
    @Body(new ValidationPipe()) data: GetBrandDto,
    @Req() req: FastifyBrowserRequest,
    @Res() res: FastifyReply,
  ) {
    this.publicService.getProduct(data, req, res);
  }

  @Get('/lp/method')
  getLpMethod(@Res() res: FastifyReply) {
    this.publicService.getLpMethod(res);
  }

  @Get('/product/method')
  getMethod(@Res() res: FastifyReply) {
    this.publicService.getMethod(res);
  }

  @Get('/product/server/:id')
  getServer(@Param('id') id: string, @Res() res: FastifyReply) {
    this.publicService.getServer(id, res);
  }

  @Public()
  @Get('/test')
  test(
    // @Body(new ValidationPipe()) test: TestDto,
    @Req() req: FastifyBrowserRequest,
    @Res() res: FastifyReply,
  ) {
    // this.publicService.test(test, req, res);
    this.publicService.test(req, res);
  }
}
