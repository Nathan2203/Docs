import { Injectable } from '@nestjs/common';
import { FastifyReply, FastifyRequest } from 'fastify';
import { hash } from 'src/common/helper/hash';
import fetch from 'node-fetch';
import { Model, Types } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import * as crypto from 'crypto';
import { decodeJwt } from 'jose';

import { FastifyBrowserRequest } from 'src/common/interface/fastify-browser.interface';
import { CT_APP_JSON } from 'src/common/config/constants';
import { encryptHmac } from 'src/common/helper/encryptKey';
import { minifyJson } from 'src/common/helper/minifyJson';
import { removeSpace } from 'src/common/helper/removeSpace';

import { Category, CategoryDocument } from './entities/category.entity';
import { Browser, BrowserDocument } from '../user/entities/browser.entity';
import { Method, MethodDocument } from './entities/method.entity';
import { BrandType, BrandTypeDocument } from './entities/brand-type.entity';

import { TestDto } from './dto/test.dto';
import { GetBrandDto } from './dto/get-brand.dto';

import { SOPResponse, SOPErrorMessage as ErrorMessage } from 'src/common/api';
import { User, UserDocument } from '../user/entities/user.entity';
import { FeeType, Role } from 'src/common/config/enum';
import { Fee, FeeDocument } from '../admin/entities/fee.entity';
const response = new SOPResponse();

@Injectable()
export class PublicService {
  constructor(
    @InjectModel(Browser.name) private readonly Browser: Model<BrowserDocument>,
    @InjectModel(Category.name)
    private readonly Category: Model<CategoryDocument>,
    @InjectModel(BrandType.name)
    private readonly BrandType: Model<BrandTypeDocument>,
    @InjectModel(Fee.name) private readonly Fee: Model<FeeDocument>,
    @InjectModel(Method.name) private readonly Method: Model<MethodDocument>,
    @InjectModel(User.name) private readonly User: Model<UserDocument>,
  ) {}

  async getBrowserId(req: FastifyRequest, res: FastifyReply) {
    try {
      const browserId = req.headers['x-browser-id'];
      this.Browser.findOne({
        browserId: browserId,
      }).then(async (browser) => {
        var result = '';
        if (browser) {
          result = browser.browserId;
        } else {
          const jwt = req.headers.authorization;
          if (jwt) {
            const payloadData = decodeJwt(jwt.replace('Bearer ', ''));
            this.Browser.findOne({
              user: new Types.ObjectId(payloadData.id.toString()),
            }).then(async (browser) => {
              if (browser) {
                result = browser.browserId;
              } else {
                result = await this.createBrowser(
                  req,
                  payloadData.id.toString(),
                );
              }
            });
          } else {
            result = await this.createBrowser(req);
          }
        }
        const success = response.initSuccess(200, true, result);
        return res.send(success);
      });
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async createBrowser(req: FastifyRequest, userId?: string): Promise<string> {
    const uuid = crypto.randomUUID();
    const newBrowser = new this.Browser({
      userAgent: req.headers['user-agent'],
    });
    if (userId) {
      newBrowser.user = new Types.ObjectId(userId);
    }
    const saved = await newBrowser.save();
    const update = await this.Browser.findByIdAndUpdate(
      saved.id,
      {
        browserId: uuid + '-' + saved.id,
        $push: { ip: req.ip },
      },
      { new: true },
    );
    return update.browserId;
  }

  async getCsrf(req: FastifyBrowserRequest, res: FastifyReply) {
    try {
      const browser = req.user;
      const randomBytes = crypto.randomBytes(32).toString('hex');
      const csrf = hash(
        'sha256',
        browser.browserId.substring(
          browser.browserId.length - 16,
          browser.browserId.length,
        ) +
          randomBytes +
          browser.browserId.substring(0, 16),
      );

      await this.Browser.findByIdAndUpdate(browser.id, {
        csrf: csrf,
      });

      const success = response.initSuccess(200, true, csrf);
      return res.send(success);
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getCategory(res: FastifyReply) {
    try {
      this.Category.aggregate([
        {
          $match: {
            isActive: true,
          },
        },
        {
          $lookup: {
            from: 'brands',
            let: { catId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $eq: ['$category', '$$catId'],
                  },
                  isActive: true,
                },
              },
              {
                $addFields: {
                  brandId: '$_id',
                },
              },
              {
                $project: {
                  _id: 0,
                  categoryId: 0,
                  createdAt: 0,
                  updatedAt: 0,
                  __v: 0,
                },
              },
            ],
            as: 'brands',
          },
        },
        {
          $project: {
            _id: 0,
            __v: 0,
            createdAt: 0,
            updatedAt: 0,
          },
        },
      ])
        .then((data) => {
          const success = response.initSuccess(200, true, data);
          return res.send(success);
        })
        .catch((err) => {
          console.log(err);
          const error = response.initError(
            404,
            false,
            new ErrorMessage("Can't find category data"),
          );
          return res.send(error);
        });
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getProduct(
    data: GetBrandDto,
    req: FastifyBrowserRequest,
    res: FastifyReply,
  ) {
    try {
      const browser = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );
      const updateBrowser = {
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.Category.aggregate([
          {
            $match: {
              isActive: true,
            },
          },
          {
            $lookup: {
              from: 'brands',
              let: { catId: '$_id' },
              pipeline: [
                {
                  $match: {
                    $expr: {
                      $eq: ['$category', '$$catId'],
                    },
                    isActive: true,
                  },
                },
                {
                  $addFields: {
                    brandId: '$_id',
                  },
                },
                {
                  $project: {
                    _id: 0,
                    categoryId: 0,
                    createdAt: 0,
                    updatedAt: 0,
                    category: 0,
                    isActive: 0,
                    __v: 0,
                  },
                },
              ],
              as: 'brands',
            },
          },
          {
            $project: {
              _id: 0,
              __v: 0,
              createdAt: 0,
              updatedAt: 0,
            },
          },
        ]).then((category) => {
          if (category.length) {
            for (const cat of category) {
              if (
                removeSpace(cat.categoryName).toLowerCase() === data.category
              ) {
                for (const brand of cat.brands) {
                  if (
                    removeSpace(brand.brandName).toLowerCase() === data.brand
                  ) {
                    this.BrandType.aggregate([
                      {
                        $match: {
                          $expr: {
                            $eq: ['$brand', { $toObjectId: brand.brandId }],
                          },
                          isActive: true,
                        },
                      },
                      {
                        $lookup: {
                          from: 'products',
                          let: { brandTypeId: '$_id' },
                          pipeline: [
                            {
                              $match: {
                                $expr: {
                                  $eq: ['$brandType', '$$brandTypeId'],
                                },
                                status: true,
                              },
                            },
                            {
                              $addFields: {
                                productId: '$_id',
                              },
                            },
                            {
                              $project: {
                                _id: 0,
                                productId: 1,
                                name: 1,
                                type: 1,
                                price: 1,
                                status: 1,
                                multi: 1,
                                desc: 1,
                                startCutOff: 1,
                                endCutOff: 1,
                              },
                            },
                          ],
                          as: 'products',
                        },
                      },
                      {
                        $project: {
                          _id: 1,
                          name: 1,
                          form: 1,
                          servers: 1,
                          products: 1,
                        },
                      },
                    ])
                      .then((products) => {
                        const { brandId: _, ...brandNew } = brand;
                        const success = response.initSuccess(200, true, {
                          brand: brandNew,
                          products,
                        });
                        return res.send(success);
                      })
                      .catch((err) => {
                        console.log(err);
                        const error = response.initError(
                          404,
                          false,
                          new ErrorMessage("Can't find product data"),
                        );
                        return res.send(error);
                      });
                  }
                }
              }
            }
          } else {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Category not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getLpMethod(res: FastifyReply) {
    try {
      await this.Fee.aggregate([
        {
          $match: {
            feeType: FeeType.Transaction,
          },
        },
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        { $unwind: '$user' },
        { $match: { 'user.role': Role.Root } },
        { $unset: 'user' },
        {
          $lookup: {
            from: 'methods',
            localField: 'method',
            foreignField: '_id',
            as: 'method',
          },
        },
        {
          $unwind: {
            path: '$method',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            methodType: '$method.type',
            methodImg: '$method.img',
            lp: 1,
          },
        },
      ]).then(async (fee) => {
        const success = response.initSuccess(200, true, fee);
        return res.send(success);
      });
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getMethod(res: FastifyReply) {
    try {
      const userRoot = await this.User.findOne({
        role: Role.Root,
      }).exec();
      await this.Method.aggregate([
        {
          $lookup: {
            from: 'fees',
            let: { methodId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $eq: ['$method', '$$methodId'],
                  },
                  feeType: FeeType.Transaction,
                  user: new Types.ObjectId(userRoot.id),
                },
              },
              {
                $lookup: {
                  from: 'valuetypes',
                  localField: 'type',
                  foreignField: '_id',
                  as: 'type',
                },
              },
              {
                $unwind: '$type',
              },
              {
                $project: {
                  _id: 0,
                  fixed: 1,
                  percentage: 1,
                  type: '$type.name',
                  isActive: 1,
                },
              },
            ],
            as: 'fee',
          },
        },
        {
          $unwind: '$fee',
        },
        {
          $project: {
            fee: 1,
            name: 1,
            type: 1,
            isActive: 1,
            img: 1,
            min: 1,
            max: 1,
          },
        },
      ]).then((method) => {
        const success = response.initSuccess(200, true, method);
        return res.send(success);
      });
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getServer(id: string, res: FastifyReply) {
    try {
      this.BrandType.findById(id).then(async (brandType) => {
        if (brandType) {
          const sig = hash(
            'md5',
            `${process.env.IAK_USERNAME}${process.env.IAK_KEY}${brandType.code}`,
          );

          const payload = {
            game_code: brandType.code,
            username: process.env.IAK_USERNAME,
            sign: sig,
          };

          const header = {
            'Content-Type': CT_APP_JSON,
          };

          await fetch(process.env.IAK_BASE_URL + 'inquiry-game-server', {
            method: 'POST',
            body: JSON.stringify(payload),
            headers: header,
          }).then(async (responseFetch) => {
            const responseData = await responseFetch.json();
            if (responseData.data.rc === '00') {
              const success = response.initSuccess(
                200,
                true,
                responseData.data.servers,
              );
              return res.send(success);
            } else {
              const error = response.initError(
                400,
                false,
                new ErrorMessage('Cannot find server'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Configuration not found!'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async test(req: FastifyBrowserRequest, res: FastifyReply) {
    try {
      // const { amount: _, ...obj } = data;
      // const success = response.initSuccess(200, true, {
      //   data,
      //   obj,
      // });
      // return res.send(success);
      // const exp = new Date();
      // exp.setDate(exp.getDate() + 1);
      // const dateString = exp
      //   .toLocaleString('en-US', {
      //     year: 'numeric',
      //     month: '2-digit',
      //     day: '2-digit',
      //     hour: '2-digit',
      //     minute: '2-digit',
      //     second: '2-digit',
      //   })
      //   .replace(/\/|,|:| /g, '');
      // const formattedDate = `${dateString.slice(4, 8)}${dateString.slice(
      //   0,
      //   2,
      // )}${dateString.slice(2, 4)}${dateString.slice(8, 14)}`;
      // const orderId = crypto.randomBytes(10).readBigUInt64BE().toString(10);
      // const paramX = `${data.path}${data.method}`;
      // // const paramY = `${data.amount}${formattedDate}${data.code}${orderId}${data.customerId}${data.customerName}${data.customerEmail}${process.env.PG_CLIENT_ID}`;
      // const paramY = `${data.amount}${formattedDate}${orderId}${data.customerId}${data.customerName}${data.customerEmail}${process.env.PG_CLIENT_ID}`;
      // console.log(paramX, paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''));
      // const sig = encryptHmac(
      //   'sha256',
      //   process.env.PG_SIG_KEY,
      //   paramX + paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
      //   'hex',
      // );
      // const payload = {
      //   expired: formattedDate,
      //   amount: Number(data.amount),
      //   customer_id: Number(data.customerId),
      //   partner_reff: orderId,
      //   customer_email: data.customerEmail,
      //   bank_code: data.code,
      //   username: process.env.PG_USERNAME,
      //   pin: process.env.PG_PIN,
      //   customer_name: data.customerName,
      //   customer_phone: data.phone,
      //   signature: sig,
      // };
      // const header = {
      //   'Content-Type': CT_APP_JSON,
      //   'client-id': process.env.PG_CLIENT_ID,
      //   'client-secret': process.env.PG_CLIENT_SECRET,
      // };
      // await fetch(
      //   process.env.PG_BASE_URL +
      //     'data/emoney?username=' +
      //     process.env.PG_USERNAME,
      //   {
      //     method: 'GET',
      //     headers: header,
      //   },
      // ).then(async (responseFetch) => {
      //   const responseData = await responseFetch.json();
      //   await fetch(process.env.PG_BASE_URL + 'masterbank/list', {
      //     method: 'GET',
      //     headers: header,
      //   }).then(async (responseFetch2) => {
      //     const responseData2 = await responseFetch2.json();
      //     const success = response.initSuccess(200, true, {
      //       responseData,
      //       responseData2,
      //     });
      //     return res.send(success);
      //   });
      // });
      // await this.BrandType.findById('6425862625310bff2a9bec7d')
      //   .populate('brand')
      //   .then(async (brandType) => {
      //     const success = response.initSuccess(200, true, brandType);
      //     return res.send(success);
      //   });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }
}
