import {
  Controller,
  Res,
  Param,
  Get,
  Body,
  Post,
  ValidationPipe,
  UseGuards,
  Req,
  Query,
  Patch,
  Delete,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiSecurity,
  ApiTags,
} from '@nestjs/swagger';
import { FastifyReply } from 'fastify';

import { AdminService } from './admin.service';
import { Role } from 'src/common/config/enum';
import { FastifyUserRequest } from 'src/common/interface/fastify-user.interface';
import { UserGuard } from 'src/common/middleware/user/user.guard';
import { Roles } from 'src/core/decorators/role.decorator';

import { CreateAdminDto } from './dto/create-admin.dto';
import { QueryDto } from './dto/query.dto';
import { CreateClientDto } from './dto/create-client.dto';
import { CreateMethodDto } from './dto/create-method.dto';
import { UpdateMethodDto } from './dto/update-method.dto';
import { UpdateBrandDto } from './dto/update-brand.dto';
import { UpdateBrandTypeDto } from './dto/update-brand-type.dto';
import { UpdateMethodFeeDto } from './dto/update-method-fee.dto';
import { UpdateBankFeeDto } from './dto/update-bank-fee.dto';
import { ActionClientDto } from './dto/action-client.dto';
import { CreatePartnerDto } from './dto/create-partner.dto';
import { ActionPartnerDto } from './dto/action-partner.dto';
import { UpdateMethodUplineFeeDto } from './dto/update-method-upline-fee.dto';
import { UpdateBankUplineFeeDto } from './dto/update-bank-upline-fee.dto';
import { Verify2FaDto } from './dto/verify-2fa.dto';
import { CheckBankAccountDto } from '../portal/dto/check-bank-account.dto';
import { ProcessDisburseDto } from './dto/disburse-process.dto';
import { UpdateBankDto } from './dto/update-bank.dto';
import { ActionBankDto } from './dto/action-bank.dto';
import { AddDisburseCashDto } from './dto/add-disburse-cash.dto';
import { ApprovalDisburseDto } from './dto/disburse-approval.dto';
import { RejectDisburseDto } from './dto/disburse-reject.dto';
import { UpdateTransactionDto } from './dto/update-transaction.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
import { UpdateMethodFeeRootDto } from './dto/update-method-fee-root.dto';
import { AddProviderDto } from './dto/add-provider.dto';
import { UpdateProviderDto } from './dto/update-provider.dto';
import { GetProviderKeyDto } from './dto/get-provider-key.dto';
import { MerchantRegisterBncDto } from './dto/merchant-register-bnc.dto';
import { TestImgDto } from './dto/test-img.dto';
import { MerchantRegisterBnc1Dto } from './dto/merchant-register-bnc-1.dto';
import { MerchantUploadImgDto } from './dto/merchant-upload-img.dto';
import { AssistTransactionDto } from './dto/assist-transaction.dto';

@ApiTags('Admin')
@Controller({ path: 'admin', version: '1' })
@ApiBearerAuth()
@ApiSecurity('session')
@ApiSecurity('browserId')
@Roles(Role.Admin, Role.Super)
@UseGuards(UserGuard)
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Roles(Role.Super)
  @Get('/update/product')
  updateProduct(@Res() res: FastifyReply) {
    this.adminService.updateProduct(res);
  }

  @Roles(Role.Super)
  @Get('/update/bank')
  updateBank(@Res() res: FastifyReply) {
    this.adminService.updateBank(res);
  }

  @Roles(Role.Super)
  @Post('/create/admin')
  createClient(
    @Body(new ValidationPipe()) createAdminDto: CreateAdminDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.createAdmin(createAdminDto, req, res);
  }

  @Roles(Role.Super)
  @Get('/update/commission')
  updateCommission(@Res() res: FastifyReply) {
    this.adminService.updateCommission(res);
  }

  @Get('/logout')
  doLogout(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.adminService.doLogout(req, res);
  }

  @Post('/change/password')
  changePassword(
    @Body(new ValidationPipe()) payload: ChangePasswordDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.changePassword(payload, req, res);
  }

  @Get('/log/activity/type')
  getLogType(@Res() res: FastifyReply) {
    this.adminService.getLogType(res);
  }

  @Get('/log/balance/type')
  getBalanceLogType(@Res() res: FastifyReply) {
    this.adminService.getBalanceLogType(res);
  }

  @Get('/overview/:offset')
  getOverview(@Param('offset') offset: string, @Res() res: FastifyReply) {
    this.adminService.getOverview(offset, res);
  }

  @Get('/balance/:type')
  getBalance(@Param('type') type: string, @Res() res: FastifyReply) {
    this.adminService.getBalance(type, res);
  }

  @Get('/balance/provider/:type')
  getBalanceProvider(@Param('type') type: string, @Res() res: FastifyReply) {
    this.adminService.getBalanceProvider(type, res);
  }

  @Get('/disburse/bank/list/:type/:userId')
  getDisburseBankList(
    @Param('type') type: string,
    @Param('userId') userId: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getDisburseBankList(type, userId, res);
  }

  @Post('/disburse/bank/check')
  getDisburseBankCheck(
    @Body(new ValidationPipe()) data: CheckBankAccountDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getDisburseBankCheck(data, req, res);
  }

  @Post('/disburse/inquiry')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  disburseInquiry(
    @Body(new ValidationPipe()) payload: ProcessDisburseDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.disburseInquiry(payload, req, res);
  }

  @Post('/disburse/process/:withdrawId')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, xSignatureInquiry + '|' + browserId) encoding hex",
  })
  disburseProcess(
    @Param('withdrawId') withdrawId: string,
    @Body(new ValidationPipe()) payload: ProcessDisburseDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.disburseProcess(withdrawId, payload, req, res);
  }

  @Get('/transaction/client')
  getTransactionClient(@Query() query: QueryDto, @Res() res: FastifyReply) {
    this.adminService.getTransactionClient(query, res);
  }

  @Get('/transaction/user')
  getTransactionUser(@Query() query: QueryDto, @Res() res: FastifyReply) {
    this.adminService.getTransactionUser(query, res);
  }

  @Get('/topup/client')
  getTopupClient(@Query() query: QueryDto, @Res() res: FastifyReply) {
    this.adminService.getTopupClient(query, res);
  }

  @Get('/check/bca/:trxId')
  checkBca(@Param('trxId') trxId: string, @Res() res: FastifyReply) {
    this.adminService.checkBca(trxId, res);
  }

  @Get('/withdraw/:type/:process')
  getWithdraw(
    @Query() query: QueryDto,
    @Param('type') type: string,
    @Param('process') process: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getWithdraw(query, type, process, res);
  }

  @Get('/withdraw/:type/:withdrawId/:modeType')
  getWithdrawDetail(
    @Param('type') type: string,
    @Param('withdrawId') withdrawId: string,
    @Param('modeType') modeType: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getWithdrawDetail(type, withdrawId, modeType, res);
  }

  @Post('/withdraw/approval/signature')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  getApprovalSignature(
    @Body(new ValidationPipe()) payload: ApprovalDisburseDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getApprovalSignature(payload, req, res);
  }

  @Post('/withdraw/approval/process')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  processApproval(
    @Body(new ValidationPipe()) payload: ApprovalDisburseDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.processApproval(payload, req, res);
  }

  @Post('/withdraw/reject')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  rejectApproval(
    @Body(new ValidationPipe()) payload: RejectDisburseDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.rejectApproval(payload, req, res);
  }

  @Get('/report/filter/:type')
  getReportFilter(@Param('type') type: string, @Res() res: FastifyReply) {
    this.adminService.getReportFilter(type, res);
  }

  @Get('/report/:cashIn/:cashOut/:offset/:type')
  getReport(
    @Query() query: QueryDto,
    @Param('cashIn') cashIn: string,
    @Param('cashOut') cashOut: string,
    @Param('offset') offset: string,
    @Param('type') type: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getReport(query, cashIn, cashOut, offset, type, res);
  }

  @Get('/log/activity/:logTypeId')
  getLogs(
    @Param('logTypeId') logTypeId: string,
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getLogs(query, logTypeId, req, res);
  }

  @Get('/log/balance/:logTypeName')
  getBalanceLogs(
    @Query() query: QueryDto,
    @Param('logTypeName') logTypeName: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getBalanceLogs(query, logTypeName, res);
  }

  @Get('/method')
  getMethod(@Res() res: FastifyReply) {
    this.adminService.getMethod(res);
  }

  @Post('/method')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, name + '|' + code + '|' + type + '|' + path + '|' + browserId) encoding hex",
  })
  addMethod(
    @Body(new ValidationPipe()) data: CreateMethodDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.createMethod(data, req, res);
  }

  @Patch('/method')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, method + '|' + browserId) encoding hex",
  })
  updateMethod(
    @Body(new ValidationPipe()) data: UpdateMethodDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateMethod(data, req, res);
  }

  @Delete('/method/:id')
  deleteMethod(
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.deleteMethod(id, req, res);
  }

  @Get('/methodFee/:type')
  getMethodFee(@Param('type') type: string, @Res() res: FastifyReply) {
    this.adminService.getMethodFee(type, res);
  }

  @Patch('/methodFee')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, method + '|' + browserId) encoding hex",
  })
  updateMethodFee(
    @Body(new ValidationPipe()) update: UpdateMethodFeeRootDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateMethodFee(update, req, res);
  }

  @Get('/disburse/channel/:bank')
  getDisburseChannel(
    @Param('bank') bank: string,
    @Query() query: QueryDto,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getDisburseChannel(bank, query, res);
  }

  @Patch('/disburse/channel/:bank')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  updateDisburseChannel(
    @Param('bank') bank: string,
    @Body(new ValidationPipe()) update: UpdateBankDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateDisburseChannel(bank, update, req, res);
  }

  @Delete('/disburse/channel/:bank')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  deleteDisburseChannel(
    @Param('bank') bank: string,
    @Body(new ValidationPipe()) update: UpdateBankDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.deleteDisburseChannel(bank, update, req, res);
  }

  @Post('/disburse/channel/bank')
  actionDisburseChannelBank(
    @Body(new ValidationPipe()) payload: ActionBankDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.actionDisburseChannelBank(payload, req, res);
  }

  @Post('/disburse/channel/cash')
  addDisburseChannelCash(
    @Body(new ValidationPipe()) payload: AddDisburseCashDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.addDisburseChannelCash(payload, req, res);
  }

  @Get('/product')
  getProduct(@Res() res: FastifyReply) {
    this.adminService.getProduct(res);
  }

  @Patch('/brand')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, brandId + '|' + browserId) encoding hex",
  })
  updateBrand(
    @Body(new ValidationPipe()) update: UpdateBrandDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateBrand(update, req, res);
  }

  @Patch('/brand/type')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, form + '|' + brandTypeId + '|' + browserId) encoding hex",
  })
  updateBrandType(
    @Body(new ValidationPipe()) update: UpdateBrandTypeDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateBrandType(update, req, res);
  }

  @Get('/2fa/status')
  get2FaStatus(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.adminService.get2FaStatus(req, res);
  }

  @Get('/2fa/setup')
  get2FaSetup(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.adminService.get2FaSetup(req, res);
  }

  @Post('/2fa/verify')
  get2FaVerify(
    @Body(new ValidationPipe()) data: Verify2FaDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.get2FaVerify(data, req, res);
  }

  @Get('/client')
  getClient(@Query() query: QueryDto, @Res() res: FastifyReply) {
    this.adminService.getClient(query, res);
  }

  @Post('/client/add')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  addClient(
    @Body(new ValidationPipe()) createClientDto: CreateClientDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.createClient(createClientDto, req, res);
  }

  @Get('/client/overview/:id')
  getClientOverview(@Param('id') id: string, @Res() res: FastifyReply) {
    this.adminService.getClientOverview(id, res);
  }

  @Get('/client/topup/:id/:type')
  getClientTopup(
    @Query() query: QueryDto,
    @Param('id') id: string,
    @Param('type') type: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientTopup(query, id, type, res);
  }

  @Get('/client/topup/:id/:transId/:type')
  getClientTopupDetail(
    @Param('id') id: string,
    @Param('transId') transId: string,
    @Param('type') type: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientTopupDetail(id, transId, type, res);
  }

  @Get('/client/transaction/:id/:type')
  getClientTransaction(
    @Query() query: QueryDto,
    @Param('id') id: string,
    @Param('type') type: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientTransaction(query, id, type, res);
  }

  @Get('/client/transaction/:id/:transId/:type')
  getClientTransactionDetail(
    @Param('id') id: string,
    @Param('transId') transId: string,
    @Param('type') type: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientTransactionDetail(id, transId, type, res);
  }

  @Patch('/client/transaction/:id/:transId')
  updateClientTransactionDetail(
    @Body(new ValidationPipe()) update: UpdateTransactionDto,
    @Param('id') id: string,
    @Param('transId') transId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateClientTransactionDetail(
      update,
      id,
      transId,
      req,
      res,
    );
  }

  @Get('/client/withdraw/:id/:type/:process')
  getClientWithdraw(
    @Query() query: QueryDto,
    @Param('id') id: string,
    @Param('type') type: string,
    @Param('process') process: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientWithdraw(query, id, type, process, res);
  }

  @Get('/client/tree/:id')
  getClientTree(@Param('id') id: string, @Res() res: FastifyReply) {
    this.adminService.getClientTree(id, res);
  }

  @Get('/client/methodFee/:id')
  getClientMethodFee(@Param('id') id: string, @Res() res: FastifyReply) {
    this.adminService.getClientMethodFee(id, res);
  }

  @Patch('/client/methodFee/:id')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, method + '|' + browserId) encoding hex",
  })
  updateClientMethodFee(
    @Body(new ValidationPipe()) update: UpdateMethodFeeDto,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateClientMethodFee(update, id, req, res);
  }

  @Patch('/client/methodUplineFee/:id')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  updateClientMethodUplineFee(
    @Body(new ValidationPipe()) update: UpdateMethodUplineFeeDto,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateClientMethodUplineFee(update, id, req, res);
  }

  @Get('/client/bankFee/:id/:type')
  getClientBankFee(
    @Param('id') id: string,
    @Param('type') type: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientBankFee(id, type, res);
  }

  @Patch('/client/bankFee/:id')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, method + '|' + browserId) encoding hex",
  })
  updateClientBankFee(
    @Body(new ValidationPipe()) update: UpdateBankFeeDto,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateClientBankFee(update, id, req, res);
  }

  @Patch('/client/bankUplineFee/:id')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  updateClientBankUplineFee(
    @Body(new ValidationPipe()) update: UpdateBankUplineFeeDto,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateClientBankUplineFee(update, id, req, res);
  }

  @Get('/client/provider/:id')
  getClientProviderList(@Param('id') id: string, @Res() res: FastifyReply) {
    this.adminService.getClientProviderList(id, res);
  }

  @Post('/client/provider/key/:id')
  getClientProviderKey(
    @Body(new ValidationPipe()) data: GetProviderKeyDto,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientProviderKey(id, data, req, res);
  }

  @Post('/client/provider/:id')
  addClientProvider(
    @Body(new ValidationPipe()) data: AddProviderDto,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.addClientProvider(id, data, req, res);
  }

  @Patch('/client/provider/:id')
  updateClientProvider(
    @Body(new ValidationPipe()) data: UpdateProviderDto,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateClientProvider(id, data, req, res);
  }

  @Delete('/client/provider/:id')
  deleteClientProvider(
    @Body(new ValidationPipe()) data: UpdateProviderDto,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.deleteClientProvider(id, data, req, res);
  }

  @Get('/client/whitelistBank/:id')
  getClientWhitelistBank(@Param('id') id: string, @Res() res: FastifyReply) {
    this.adminService.getClientWhitelistBank(id, res);
  }

  @Get('/client/callback/check/:type/:clientId/:id/:modeType')
  checkClientCallback(
    @Param('type') type: string,
    @Param('clientId') clientId: string,
    @Param('id') id: string,
    @Param('modeType') modeType: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.checkClientCallback(type, clientId, id, modeType, res);
  }

  @Get('/client/callback/history/:type/:clientId/:modeType')
  getClientCallbackHistory(
    @Query() query: QueryDto,
    @Param('type') type: string,
    @Param('clientId') clientId: string,
    @Param('modeType') modeType: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientCallbackHistory(
      query,
      type,
      clientId,
      modeType,
      res,
    );
  }

  @Get('/client/callback/history/:type/:clientId/:id/:modeType')
  getClientCallbackHistoryDetail(
    @Param('type') type: string,
    @Param('clientId') clientId: string,
    @Param('id') id: string,
    @Param('modeType') modeType: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientCallbackHistoryDetail(
      type,
      clientId,
      id,
      modeType,
      res,
    );
  }

  @Get('/client/report/filter/:type/:clientId')
  getClientReportFilter(
    @Param('type') type: string,
    @Param('clientId') clientId: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientReportFilter(type, clientId, res);
  }

  @Get('/client/report/:cashIn/:cashOut/:offset/:type/:clientId')
  getClientReport(
    @Query() query: QueryDto,
    @Param('cashIn') cashIn: string,
    @Param('cashOut') cashOut: string,
    @Param('offset') offset: string,
    @Param('type') type: string,
    @Param('clientId') clientId: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientReport(
      query,
      cashIn,
      cashOut,
      offset,
      type,
      clientId,
      res,
    );
  }

  @Get('/client/log/balance/:logTypeName/:userId')
  getClientBalanceLogs(
    @Query() query: QueryDto,
    @Param('logTypeName') logTypeName: string,
    @Param('userId') userId: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientBalanceLogs(query, logTypeName, userId, res);
  }

  @Get('/client/log/activity/:logTypeId/:userId')
  getClientLogs(
    @Query() query: QueryDto,
    @Param('logTypeId') logTypeId: string,
    @Param('userId') userId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getClientLogs(query, logTypeId, userId, req, res);
  }

  @Post('/client/action')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  actionClient(
    @Body(new ValidationPipe()) data: ActionClientDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.actionClient(data, req, res);
  }

  @Get('/partner')
  getPartner(@Query() query: QueryDto, @Res() res: FastifyReply) {
    this.adminService.getPartner(query, res);
  }

  @Get('/partner/search/:val')
  searchPartner(@Param('val') val: string, @Res() res: FastifyReply) {
    this.adminService.searchPartner(val, res);
  }

  @Post('/partner/add')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  addPartner(
    @Body(new ValidationPipe()) data: CreatePartnerDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.createPartner(data, req, res);
  }

  @Get('/partner/overview/:id')
  getPartnerOverview(@Param('id') id: string, @Res() res: FastifyReply) {
    this.adminService.getPartnerOverview(id, res);
  }

  @Get('/partner/client/:id')
  getPartnerClient(
    @Query() query: QueryDto,
    @Param('id') id: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getPartnerClient(query, id, res);
  }

  @Get('/partner/team/:id')
  getPartnerTeam(
    @Query() query: QueryDto,
    @Param('id') id: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getPartnerTeam(query, id, res);
  }

  @Get('/partner/withdraw/:id/:process')
  getPartnerWithdraw(
    @Query() query: QueryDto,
    @Param('id') id: string,
    @Param('process') process: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getPartnerWithdraw(query, id, process, res);
  }

  @Get('/partner/commission/:id')
  getPartnerCommission(
    @Query() query: QueryDto,
    @Param('id') id: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getPartnerCommission(query, id, res);
  }

  @Get('/partner/log/balance/:logTypeName/:userId')
  getPartnerBalanceLogs(
    @Query() query: QueryDto,
    @Param('logTypeName') logTypeName: string,
    @Param('userId') userId: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getPartnerBalanceLogs(query, logTypeName, userId, res);
  }

  @Get('/partner/log/activity/:logTypeId/:userId')
  getPartnerLogs(
    @Query() query: QueryDto,
    @Param('logTypeId') logTypeId: string,
    @Param('userId') userId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getPartnerLogs(query, logTypeId, userId, req, res);
  }

  @Post('/partner/action')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  actionPartner(
    @Body(new ValidationPipe()) data: ActionPartnerDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.actionPartner(data, req, res);
  }

  @Get('/user')
  getUser(@Query() query: QueryDto, @Res() res: FastifyReply) {
    this.adminService.getUser(query, res);
  }

  @Get('/user/overview/:id')
  getUserOverview(@Param('id') id: string, @Res() res: FastifyReply) {
    this.adminService.getUserOverview(id, res);
  }

  @Get('/user/transaction/:id')
  getUserTransaction(@Param('id') id: string, @Res() res: FastifyReply) {
    this.adminService.getUserTransaction(id, res);
  }

  @Get('/user/transaction/:id/:transId')
  getUserTransactionDetail(
    @Param('id') id: string,
    @Param('transId') transId: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getUserTransactionDetail(id, transId, res);
  }

  @Get('/provider/:type')
  getProviderList(
    @Query() query: QueryDto,
    @Param('type') type: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getProviderList(query, type, res);
  }

  @Post('/provider/key')
  getProviderKey(
    @Body(new ValidationPipe()) data: GetProviderKeyDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getProviderKey(data, req, res);
  }

  @Post('/provider')
  addProvider(
    @Body(new ValidationPipe()) data: AddProviderDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.addProvider(data, req, res);
  }

  @Patch('/provider')
  updateProvider(
    @Body(new ValidationPipe()) data: UpdateProviderDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.updateProvider(data, req, res);
  }

  @Delete('/provider')
  deleteProvider(
    @Body(new ValidationPipe()) data: UpdateProviderDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.deleteProvider(data, req, res);
  }

  @Get('/provider/merchant/province/:providerId')
  getProviderProvince(
    @Param('providerId') providerId: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getProviderProvince(providerId, res);
  }

  @Get('/provider/merchant/city/:providerId/:provinceId')
  getProviderCity(
    @Param('providerId') providerId: string,
    @Param('provinceId') provinceId: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getProviderCity(providerId, provinceId, res);
  }

  @Get('/provider/merchant/district/:providerId/:cityId')
  getProviderDistrict(
    @Param('providerId') providerId: string,
    @Param('cityId') cityId: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getProviderDistrict(providerId, cityId, res);
  }

  @Get('/provider/merchant/post/:providerId/:districtId')
  getProviderPost(
    @Param('providerId') providerId: string,
    @Param('districtId') districtId: string,
    @Res() res: FastifyReply,
  ) {
    this.adminService.getProviderPost(providerId, districtId, res);
  }

  @Post('/provider/merchant/upload/img/:type')
  providerUploadImg(
    @Param('type') type: string,
    @Body(new ValidationPipe()) data: MerchantUploadImgDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.providerMerchantUploadImg(type, data, req, res);
  }

  @Post('/provider/merchant/register/bnc/1')
  providerMerchantRegisterBnc1(
    @Body(new ValidationPipe()) data: MerchantRegisterBnc1Dto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.providerMerchantRegisterBnc(1, data, req, res);
  }

  @Post('/provider/merchant/register/bnc/2')
  providerMerchantRegisterBnc2(
    @Body(new ValidationPipe()) data: MerchantRegisterBncDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.providerMerchantRegisterBnc(2, data, req, res);
  }

  @Post('/provider/merchant/register/bnc/test')
  providerMerchantRegisterBncTest(
    @Body(new ValidationPipe()) data: TestImgDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.providerMerchantRegisterBncTest(data, req, res);
  }

  @Post('/user/transaction/assist')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  assistTransaction(
    @Body(new ValidationPipe()) data: AssistTransactionDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.adminService.assistUserTransaction(data, req, res);
  }
}
