import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { SharpModule } from 'nestjs-sharp';

import { AdminService } from './admin.service';
import { AdminController } from './admin.controller';
import { UserStrategy } from 'src/common/middleware/user/user.strategy';
import { UserGuard } from 'src/common/middleware/user/user.guard';

import { Client, ClientSchema } from '../open/entities/client.entity';
import { User, UserSchema } from '../user/entities/user.entity';
import { Brand, BrandSchema } from '../public/entities/brand.entity';
import { Category, CategorySchema } from '../public/entities/category.entity';
import { Product, ProductSchema } from '../public/entities/product.entity';
import { Method, MethodSchema } from '../public/entities/method.entity';
import { Fee, FeeSchema } from './entities/fee.entity';
import { Session, SessionSchema } from '../user/entities/session.entity';
import { Browser, BrowserSchema } from '../user/entities/browser.entity';
import {
  Transaction,
  TransactionSchema,
} from '../user/entities/transaction.entity';
import { Withdraw, WithdrawSchema } from '../user/entities/withdraw.entity';
import { Balance, BalanceSchema } from '../user/entities/balance.entity';
import { ValueType, ValueTypeSchema } from './entities/value-type.entity';
import { Log, LogSchema } from './entities/log.entity';
import { LogType, LogTypeSchema } from './entities/log-type.entity';
import {
  BrandType,
  BrandTypeSchema,
} from '../public/entities/brand-type.entity';
import { Bank, BankSchema } from './entities/bank.entity';
import {
  Commission,
  CommissionSchema,
} from '../partner/entities/commission.entity';
import {
  DevBalance,
  DevBalanceSchema,
} from '../open/entities/dev-balance.entity';
import { DevClient, DevClientSchema } from '../open/entities/dev-client.entity';
import {
  BalanceLog,
  BalanceLogSchema,
} from '../user/entities/balance-log.entity';
import {
  BankAccount,
  BankAccountSchema,
} from '../open/entities/bank-account.entity';
import {
  DevTransaction,
  DevTransactionSchema,
} from '../open/entities/dev-transaction.entity';
import {
  DevWithdraw,
  DevWithdrawSchema,
} from '../open/entities/dev-withdraw.entity';
import { Callback, CallbackSchema } from '../callback/entities/callback.entity';
import {
  DevCallback,
  DevCallbackSchema,
} from '../callback/entities/dev-callback.entity';
import { Provider, ProviderSchema } from './entities/provider.entity';
import { ProviderModule } from 'src/core/provider/provider.module';

@Module({
  imports: [
    SharpModule,
    ProviderModule,
    MongooseModule.forFeature([
      { name: Client.name, schema: ClientSchema },
      { name: DevClient.name, schema: DevClientSchema },
      { name: User.name, schema: UserSchema },
      { name: Category.name, schema: CategorySchema },
      { name: Brand.name, schema: BrandSchema },
      { name: BrandType.name, schema: BrandTypeSchema },
      { name: Product.name, schema: ProductSchema },
      { name: Method.name, schema: MethodSchema },
      { name: Bank.name, schema: BankSchema },
      { name: Fee.name, schema: FeeSchema },
      { name: Session.name, schema: SessionSchema },
      { name: Browser.name, schema: BrowserSchema },
      { name: Transaction.name, schema: TransactionSchema },
      { name: DevTransaction.name, schema: DevTransactionSchema },
      { name: Withdraw.name, schema: WithdrawSchema },
      { name: DevWithdraw.name, schema: DevWithdrawSchema },
      { name: DevBalance.name, schema: DevBalanceSchema },
      { name: Balance.name, schema: BalanceSchema },
      { name: BalanceLog.name, schema: BalanceLogSchema },
      { name: ValueType.name, schema: ValueTypeSchema },
      { name: Log.name, schema: LogSchema },
      { name: LogType.name, schema: LogTypeSchema },
      { name: Commission.name, schema: CommissionSchema },
      { name: BankAccount.name, schema: BankAccountSchema },
      { name: Callback.name, schema: CallbackSchema },
      { name: DevCallback.name, schema: DevCallbackSchema },
      { name: Provider.name, schema: ProviderSchema },
    ]),
  ],
  controllers: [AdminController],
  providers: [AdminService, UserStrategy, UserGuard],
})
export class AdminModule {}
