import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import * as crypto from 'crypto';
import { FastifyReply } from 'fastify';
import fetch from 'node-fetch';
import * as fs from 'fs';
import { authenticator } from 'otplib';

import { FastifyUserRequest } from 'src/common/interface/fastify-user.interface';
import { hash } from 'src/common/helper/hash';
import { encryptHmac } from 'src/common/helper/encryptKey';
import { searchArray } from 'src/common/helper/searchArray';
import { encryptPass } from 'src/common/helper/encryptPass';
import {
  Role,
  TransactionStatusType,
  LogType as LogTypes,
  FeeType,
  BankType,
  ActionClientType,
  PgType,
  BankActionType,
  MethodType,
  WithdrawType,
  TransactionType,
  ValueType as VType,
  WithdrawProcess,
  WithdrawStatus,
  BalanceLogType,
  CallbackType,
  ProviderImgType,
} from 'src/common/config/enum';
import { SharpService } from 'nestjs-sharp/dist/sharp.service';
import { CT_APP_JSON } from 'src/common/config/constants';
import { generateRandomNumber } from 'src/common/helper/generateRandomNumber';
import { minifyJson } from 'src/common/helper/minifyJson';
import { encrypt } from 'src/common/helper/encryptKeyIv';
import { decrypt } from 'src/common/helper/decryptKeyIv';
import { toCurrency } from 'src/common/helper/cast.helper';
import { getMonthDifference } from 'src/common/helper/monthDifference';
import { ProviderCodeType } from 'src/common/config/enum';
import { ProviderService } from '../../../core/provider/provider.service';

import { Client, ClientDocument } from '../open/entities/client.entity';
import { User, UserDocument } from '../user/entities/user.entity';
import { Brand, BrandDocument } from '../public/entities/brand.entity';
import {
  BrandType,
  BrandTypeDocument,
} from '../public/entities/brand-type.entity';
import { Category, CategoryDocument } from '../public/entities/category.entity';
import { Product, ProductDocument } from '../public/entities/product.entity';
import { Method, MethodDocument } from '../public/entities/method.entity';
import { Fee, FeeDocument } from './entities/fee.entity';
import {
  Transaction,
  TransactionDocument,
} from '../user/entities/transaction.entity';
import { Withdraw, WithdrawDocument } from '../user/entities/withdraw.entity';
import { Balance, BalanceDocument } from '../user/entities/balance.entity';
import { ValueType, ValueTypeDocument } from './entities/value-type.entity';
import { LogType, LogTypeDocument } from './entities/log-type.entity';
import { Log, LogDocument } from './entities/log.entity';
import { Bank, BankDocument } from './entities/bank.entity';
import { Browser, BrowserDocument } from '../user/entities/browser.entity';
import {
  Commission,
  CommissionDocument,
} from '../partner/entities/commission.entity';
import {
  DevBalance,
  DevBalanceDocument,
} from '../open/entities/dev-balance.entity';
import {
  DevClient,
  DevClientDocument,
} from '../open/entities/dev-client.entity';
import {
  BankAccount,
  BankAccountDocument,
} from '../open/entities/bank-account.entity';
import {
  DevTransaction,
  DevTransactionDocument,
} from '../open/entities/dev-transaction.entity';
import {
  DevWithdraw,
  DevWithdrawDocument,
} from '../open/entities/dev-withdraw.entity';
import { Session, SessionDocument } from '../user/entities/session.entity';
import {
  BalanceLog,
  BalanceLogDocument,
} from '../user/entities/balance-log.entity';
import {
  Callback,
  CallbackDocument,
} from '../callback/entities/callback.entity';
import {
  DevCallback,
  DevCallbackDocument,
} from '../callback/entities/dev-callback.entity';
import { Provider, ProviderDocument } from './entities/provider.entity';

import { CreateAdminDto } from './dto/create-admin.dto';
import { CreateClientDto } from './dto/create-client.dto';
import { QueryDto } from './dto/query.dto';
import { UpdateBrandDto } from './dto/update-brand.dto';
import { CreateMethodDto } from './dto/create-method.dto';
import { UpdateMethodDto } from './dto/update-method.dto';
import { UpdateBrandTypeDto } from './dto/update-brand-type.dto';
import { UpdateMethodFeeDto } from './dto/update-method-fee.dto';
import { UpdateMethodFeeRootDto } from './dto/update-method-fee-root.dto';
import { UpdateBankFeeDto } from './dto/update-bank-fee.dto';
import { ActionClientDto } from './dto/action-client.dto';
import { CreatePartnerDto } from './dto/create-partner.dto';
import { ActionPartnerDto } from './dto/action-partner.dto';
import { UpdateMethodUplineFeeDto } from './dto/update-method-upline-fee.dto';
import { UpdateBankUplineFeeDto } from './dto/update-bank-upline-fee.dto';
import { Verify2FaDto } from './dto/verify-2fa.dto';
import { CheckBankAccountDto } from '../portal/dto/check-bank-account.dto';
import { ProcessDisburseDto } from './dto/disburse-process.dto';
import { UpdateBankDto } from './dto/update-bank.dto';
import { ActionBankDto } from './dto/action-bank.dto';
import { AddDisburseCashDto } from './dto/add-disburse-cash.dto';
import { ApprovalDisburseDto } from './dto/disburse-approval.dto';
import { RejectDisburseDto } from './dto/disburse-reject.dto';
import { AddProviderDto } from './dto/add-provider.dto';
import { UpdateProviderDto } from './dto/update-provider.dto';
import { GetProviderKeyDto } from './dto/get-provider-key.dto';
import { UpdateTransactionDto } from './dto/update-transaction.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
import { TestImgDto } from './dto/test-img.dto';
import { MerchantRegisterBnc1Dto } from './dto/merchant-register-bnc-1.dto';
import { MerchantUploadImgDto } from './dto/merchant-upload-img.dto';
import { MerchantRegisterBncDto } from './dto/merchant-register-bnc.dto';
import { AssistTransactionDto } from './dto/assist-transaction.dto';

import { SOPResponse, SOPErrorMessage as ErrorMessage } from 'src/common/api';
import { getFormattedTime } from 'src/common/helper/formattedTime';
import sendCallback from 'src/common/util/sendCallback';
const response = new SOPResponse();

@Injectable()
export class AdminService {
  constructor(
    private sharpService: SharpService,
    private readonly providerService: ProviderService,
    @InjectModel(Session.name) private readonly Session: Model<SessionDocument>,
    @InjectModel(Browser.name) private readonly Browser: Model<BrowserDocument>,
    @InjectModel(Client.name) private readonly Client: Model<ClientDocument>,
    @InjectModel(DevClient.name)
    private readonly DevClient: Model<DevClientDocument>,
    @InjectModel(User.name) private readonly User: Model<UserDocument>,
    @InjectModel(Category.name)
    private readonly Category: Model<CategoryDocument>,
    @InjectModel(Brand.name) private readonly Brand: Model<BrandDocument>,
    @InjectModel(BrandType.name)
    private readonly BrandType: Model<BrandTypeDocument>,
    @InjectModel(Product.name) private readonly Product: Model<ProductDocument>,
    @InjectModel(Method.name) private readonly Method: Model<MethodDocument>,
    @InjectModel(Bank.name) private readonly Bank: Model<BankDocument>,
    @InjectModel(Fee.name) private readonly Fee: Model<FeeDocument>,
    @InjectModel(Transaction.name)
    private readonly Transaction: Model<TransactionDocument>,
    @InjectModel(DevTransaction.name)
    private readonly DevTransaction: Model<DevTransactionDocument>,
    @InjectModel(Withdraw.name)
    private readonly Withdraw: Model<WithdrawDocument>,
    @InjectModel(DevWithdraw.name)
    private readonly DevWithdraw: Model<DevWithdrawDocument>,
    @InjectModel(Balance.name)
    private readonly Balance: Model<BalanceDocument>,
    @InjectModel(DevBalance.name)
    private readonly DevBalance: Model<DevBalanceDocument>,
    @InjectModel(BalanceLog.name)
    private readonly BalanceLog: Model<BalanceLogDocument>,
    @InjectModel(ValueType.name)
    private readonly ValueType: Model<ValueTypeDocument>,
    @InjectModel(LogType.name)
    private readonly LogType: Model<LogTypeDocument>,
    @InjectModel(Log.name)
    private readonly Log: Model<LogDocument>,
    @InjectModel(Commission.name)
    private readonly Commission: Model<CommissionDocument>,
    @InjectModel(BankAccount.name)
    private readonly BankAccount: Model<BankAccountDocument>,
    @InjectModel(Callback.name)
    private readonly Callback: Model<CallbackDocument>,
    @InjectModel(DevCallback.name)
    private readonly DevCallback: Model<DevCallbackDocument>,
    @InjectModel(Provider.name)
    private readonly Provider: Model<ProviderDocument>,
  ) {}

  async updateProduct(res: FastifyReply) {
    try {
      const payload = {
        cmd: 'prepaid',
        username: process.env.DF_USERNAME,
        sign: hash(
          'md5',
          process.env.DF_USERNAME + process.env.DF_PROD_KEY + 'pricelist',
        ),
      };

      const dfFetch = await fetch(process.env.DF_BASE_URL + 'price-list', {
        method: 'post',
        body: JSON.stringify(payload),
      });
      const result = await dfFetch.json();
      const data = result.data;

      const cat = await this.Category.find();
      const brand = await this.Brand.find();
      const product = await this.Product.find();
      const brandType = await this.BrandType.find();

      const catNew = [],
        brandNew = [],
        productNew = [],
        brandTypeNew = [];

      for (const d of data) {
        const catFound = searchArray(cat, 'categoryName', d.category);
        var catId = '';
        if (catFound.length == 0) {
          const newCategory = new this.Category({
            categoryName: d.category,
          });
          const saved = await newCategory.save();
          catId = saved.id;
        } else {
          if (!catFound[0].isActive) {
            await this.Category.findByIdAndUpdate(
              catFound[0].id,
              {
                $set: {
                  isActive: true,
                },
              },
              { new: true, upsert: true },
            );
          }
          catId = catFound[0].id;
        }

        const brandFound = searchArray(
          brand,
          'brandName',
          d.brand,
          'category',
          catId,
        );
        var brandId = '';
        if (brandFound.length == 0) {
          const newBrand = new this.Brand({
            brandName: d.brand,
            category: new Types.ObjectId(catId),
          });
          const saved = await newBrand.save();
          brandId = saved.id;
        } else {
          if (!brandFound[0].isActive) {
            await this.Brand.findByIdAndUpdate(
              brandFound[0].id,
              {
                $set: {
                  isActive: true,
                },
              },
              { new: true, upsert: true },
            );
          }
          brandId = brandFound[0].id;
        }

        const brandTypeFound = searchArray(
          brandType,
          'name',
          d.type,
          'brand',
          brandId,
        );
        var brandTypeId = '';
        if (brandTypeFound.length == 0) {
          const newBrandType = new this.BrandType({
            name: d.type,
            brand: new Types.ObjectId(brandId),
          });
          const saved = await newBrandType.save();
          brandType.push(saved);
          brandTypeId = saved.id;
        } else {
          if (!brandTypeFound[0].isActive) {
            await this.BrandType.findByIdAndUpdate(
              brandTypeFound[0].id,
              {
                $set: {
                  isActive: true,
                },
              },
              { new: true, upsert: true },
            );
          }
          brandTypeId = brandTypeFound[0].id;
        }

        const productFound = searchArray(product, 'code', d.buyer_sku_code);
        var productId = '';
        if (productFound.length == 0) {
          const newProduct = new this.Product({
            name: d.product_name,
            type: d.type,
            seller: d.seller_name,
            price: d.price,
            code: d.buyer_sku_code,
            status: d.seller_product_status && d.buyer_product_status,
            multi: d.multi,
            desc: d.desc,
            startCutOff: d.start_cut_off,
            endCutOff: d.end_cut_off,
            brandType: new Types.ObjectId(brandTypeId),
          });
          const saved = await newProduct.save();
          productId = saved.id;
        } else {
          const update = {
            name: d.product_name,
            type: d.type,
            seller: d.seller_name,
            price: d.price,
            code: d.buyer_sku_code,
            status: d.seller_product_status && d.buyer_product_status,
            multi: d.multi,
            desc: d.desc,
            startCutOff: d.start_cut_off,
            endCutOff: d.end_cut_off,
          };

          await this.Product.findByIdAndUpdate(
            productFound[0].id,
            {
              $set: update,
            },
            { new: true, upsert: true },
          );

          productId = productFound[0].id;
        }

        const catIdObj = new Types.ObjectId(catId);
        if (!catNew.some((objId) => objId.equals(catIdObj))) {
          catNew.push(catIdObj);
        }

        const brandIdObj = new Types.ObjectId(brandId);
        if (!brandNew.some((objId) => objId.equals(brandIdObj))) {
          brandNew.push(brandIdObj);
        }

        const brandTypeIdObj = new Types.ObjectId(brandTypeId);
        if (!brandTypeNew.some((objId) => objId.equals(brandTypeIdObj))) {
          brandTypeNew.push(brandTypeIdObj);
        }

        const productIdObj = new Types.ObjectId(productId);
        if (!productNew.some((objId) => objId.equals(productIdObj))) {
          productNew.push(productIdObj);
        }
      }

      await this.Category.updateMany(
        {
          _id: { $nin: catNew },
        },
        {
          $set: {
            isActive: false,
          },
        },
      );

      await this.Brand.updateMany(
        {
          _id: { $nin: brandNew },
        },
        {
          $set: {
            isActive: false,
          },
        },
      );

      await this.BrandType.updateMany(
        {
          _id: { $nin: brandTypeNew },
        },
        {
          $set: {
            isActive: false,
          },
        },
      );

      await this.Product.updateMany(
        {
          _id: { $nin: productNew },
        },
        {
          $set: {
            status: false,
          },
        },
      );

      const success = response.initSuccess(200, true, true);
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateBank(res: FastifyReply) {
    try {
      const userRoot = await this.User.findOne({
        role: Role.Root,
      }).exec();
      await this.Provider.findOne({
        code: ProviderCodeType.Linkqu,
        user: userRoot.id,
        isActive: true,
      }).then(async (provider) => {
        const keyDec = decrypt(
          process.env.ENCRYPT_ALG,
          hash('sha256', provider.id).substring(0, 32),
          hash('sha256', userRoot.id + provider.code).substring(0, 16),
          provider.key,
        );

        const key = JSON.parse(keyDec);

        await this.Bank.find().then(async (banks) => {
          const header = {
            'Content-Type': CT_APP_JSON,
            'client-id': key.clientId,
            'client-secret': key.clientSecret,
          };

          await fetch(
            process.env.PG_BASE_URL + 'data/emoney?username=' + key.username,
            {
              method: 'GET',
              headers: header,
            },
          ).then(async (responseEwallet) => {
            const ewalletData = await responseEwallet.json();
            await fetch(process.env.PG_BASE_URL + 'masterbank/list', {
              method: 'GET',
              headers: header,
            }).then(async (responseBank) => {
              const bankData = await responseBank.json();

              for (const bank of bankData.data) {
                const bankFound = searchArray(banks, 'code', bank.kodeBank);
                if (bankFound.length) {
                  await this.Bank.findByIdAndUpdate(
                    bankFound[0].id,
                    {
                      $set: {
                        isActive: true,
                        name: bank.name,
                        img: bank.url_image,
                      },
                    },
                    { new: true, upsert: true },
                  );
                } else {
                  const newBank = new this.Bank({
                    name: bank.namaBank,
                    code: bank.kodeBank,
                    img: bank.url_image,
                    type: BankType.Bank,
                  });
                  await newBank.save();
                }
              }

              for (const ewallet of ewalletData.data[0].dataproduk) {
                const ewalletFound = searchArray(
                  banks,
                  'code',
                  ewallet.kodebank,
                );
                if (ewalletFound.length) {
                  await this.Bank.findByIdAndUpdate(
                    ewalletFound[0].id,
                    {
                      $set: {
                        isActive: true,
                        name: ewallet.namaproduk,
                      },
                    },
                    { new: true, upsert: true },
                  );
                } else {
                  const newBank = new this.Bank({
                    name: ewallet.namaproduk,
                    code: ewallet.kodebank,
                    type: BankType.Ewallet,
                  });
                  await newBank.save();
                }
              }
              const success = response.initSuccess(200, true, true);
              return res.send(success);
            });
          });
        });
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateCommission(res: FastifyReply) {
    try {
      const user = await this.User.findOne({ role: Role.Root }).exec();
      const balance = await this.Balance.findOne({ user: user.id }).exec();
      await this.Commission.aggregate([
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: {
            path: '$user',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            user: { $exists: true },
            isActive: true,
            'user.role': { $in: [Role.Partner, Role.Root] },
            'user.isBlocked': false,
            'user.isDeleted': false,
          },
        },
      ]).then(async (commissions) => {
        for (const commission of commissions) {
          const newCommission = new this.Commission({
            user: new Types.ObjectId(commission.user._id),
            cutoff: commission.user.role === Role.Root ? 0 : undefined,
            clientTrx: commission.user.role === Role.Root ? undefined : 0,
            clientTrxQty: commission.user.role === Role.Root ? undefined : 0,
            partnerTrx: commission.user.role === Role.Root ? undefined : 0,
            partnerTrxQty: commission.user.role === Role.Root ? undefined : 0,
            clientWd: commission.user.role === Role.Root ? undefined : 0,
            clientWdQty: commission.user.role === Role.Root ? undefined : 0,
            partnerWd: commission.user.role === Role.Root ? undefined : 0,
            partnerWdQty: commission.user.role === Role.Root ? undefined : 0,
          });
          await newCommission.save();

          const update: any = {
            isActive: false,
          };

          if (commission.user.role === Role.Root) {
            var nominal = balance.balance;
            await this.Commission.aggregate([
              {
                $match: {
                  user: new Types.ObjectId(user.id),
                  isActive: false,
                  isDisbursed: false,
                },
              },
              {
                $group: {
                  _id: null,
                  totalCutoff: { $sum: '$cutoff' },
                },
              },
            ]).then((rootCommission) => {
              if (rootCommission.length) {
                nominal -= rootCommission[0].totalCutoff;
              }
            });
            update.cutoff = nominal;
          }

          await this.Commission.findByIdAndUpdate(commission._id, update);
        }

        const success = response.initSuccess(200, true, true);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async createAdmin(
    data: CreateAdminDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { browser } = req.user;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        data.username +
          '|' +
          data.pass +
          '|' +
          data.role +
          '|' +
          browser.browserId,
        'hex',
      );

      if (data.signature === signatureVerify) {
        const newUser = new this.User({
          username: data.username,
          pass: await encryptPass(data.pass),
          role: data.role,
        });

        await newUser.save();

        const success = response.initSuccess(200, true, true);
        return res.send(success);
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async doLogout(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      await this.Session.findOne({ user: user.id }).then(
        async (sessionFind) => {
          const updateSession = {
            sessionToken: undefined,
            sessionExpires: undefined,
            refreshToken: undefined,
            refreshExpires: undefined,
            lastActivityDate: new Date(),
          };

          await this.Session.findByIdAndUpdate(
            sessionFind.id,
            { $set: updateSession },
            { new: true, upsert: true },
          );

          await this.LogType.findOne({
            type: LogTypes.Logout,
          }).then(async (logType) => {
            if (logType) {
              const newLog = new this.Log({
                message: `${user.username} Logout`,
                ip: req.ip,
                type: logType.id,
                admin: user.id,
              });

              await newLog.save();
            }
          });

          const success = response.initSuccess(200, true, true);
          return res.send(success);
        },
      );
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async changePassword(
    data: ChangePasswordDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (data.old !== data.new) {
        const { user, browser } = req.user;
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };
        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (data.signature === signatureVerify) {
          if (user.secret2Fa && user.isVerified && !data.code) {
            if (data.code) {
              const keyDec = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', user.id).substring(0, 32),
                hash('sha256', user.id + user.username).substring(0, 16),
                user.secret2Fa,
              );

              if (!authenticator.check(data.code, keyDec)) {
                const error = response.initError(
                  403,
                  false,
                  new ErrorMessage('Invalid 2FA Code'),
                );
                return res.send(error);
              }
            } else {
              const error = response.initError(
                403,
                false,
                new ErrorMessage('2FA code must not be empty'),
              );
              return res.send(error);
            }
          }
          if (!user.comparePass(data.old)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Invalid Old Password'),
            );
            return res.send(error);
          } else {
            await this.User.findByIdAndUpdate(user.id, {
              pass: await encryptPass(data.new),
            });

            const success = response.initSuccess(200, true, true);
            return res.send(success);
          }
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage("New password can't be same with the old one"),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getLogType(res: FastifyReply) {
    try {
      await this.LogType.find().then((logTypes) => {
        const success = response.initSuccess(200, true, logTypes);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getBalanceLogType(res: FastifyReply) {
    try {
      const success = response.initSuccess(
        200,
        true,
        Object.values(BalanceLogType),
      );
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getOverview(offset: string = '7', res: FastifyReply) {
    try {
      const userRoot = await this.User.findOne({
        role: Role.Root,
      }).exec();
      const todayStart = new Date();
      todayStart.setHours(todayStart.getHours() + Number(offset));
      todayStart.setDate(todayStart.getDate() - 1);
      todayStart.setHours(17, 0, 0, 0);
      const todayEnd = new Date();
      todayEnd.setHours(todayEnd.getHours() + Number(offset));
      todayEnd.setHours(16, 59, 59, 999);

      const cutoff = await this.Commission.aggregate([
        {
          $match: {
            user: new Types.ObjectId(userRoot.id),
            isActive: false,
            isDisbursed: false,
          },
        },
        {
          $group: {
            _id: null,
            totalCutoff: { $sum: '$cutoff' },
          },
        },
      ]);

      const commission = await this.Commission.aggregate([
        {
          $match: {
            clientTrx: { $exists: true },
            partnerTrx: { $exists: true },
            clientWd: { $exists: true },
            partnerWd: { $exists: true },
            isActive: false,
            isDisbursed: false,
          },
        },
        {
          $group: {
            _id: null,
            clientTrx: { $sum: '$clientTrx' },
            partnerTrx: { $sum: '$partnerTrx' },
            clientWd: { $sum: '$clientWd' },
            partnerWd: { $sum: '$partnerWd' },
          },
        },
        {
          $project: {
            _id: 0,
          },
        },
      ]);

      const balance = await this.Balance.aggregate([
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: '$user',
        },
        {
          $match: {
            'user.role': { $in: [Role.User, Role.Client, Role.Partner] },
          },
        },
        {
          $group: {
            _id: '$user.role',
            totalBalance: { $sum: '$balance' },
            totalPending: { $sum: '$pending' },
            totalFreeze: { $sum: '$freeze' },
            totalDebt: { $sum: '$debt' },
          },
        },
        {
          $group: {
            _id: null,
            roles: {
              $push: {
                k: '$_id',
                v: {
                  totalBalance: '$totalBalance',
                  totalPending: '$totalPending',
                  totalFreeze: '$totalFreeze',
                  totalDebt: '$totalDebt',
                },
              },
            },
          },
        },
        {
          $replaceRoot: {
            newRoot: { $arrayToObject: '$roles' },
          },
        },
      ]);

      const transaction = await this.Transaction.aggregate([
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: '$user',
        },
        {
          $match: {
            'user.role': { $in: [Role.User, Role.Client] },
            transactionType: TransactionType.Transaction,
          },
        },
        {
          $facet: {
            all: [
              {
                $group: {
                  _id: {
                    role: '$user.role',
                    status: '$status',
                  },
                  totalAmount: { $sum: '$amount' },
                  total: {
                    $sum: 1,
                  },
                },
              },
              {
                $group: {
                  _id: '$_id.role',
                  statuses: {
                    $push: {
                      k: '$_id.status',
                      v: {
                        totalAmount: '$totalAmount',
                        total: '$total',
                      },
                    },
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  objects: {
                    $push: {
                      k: '$_id',
                      v: { $arrayToObject: '$statuses' },
                    },
                  },
                },
              },
              {
                $replaceRoot: {
                  newRoot: { $arrayToObject: '$objects' },
                },
              },
            ],
            today: [
              {
                $match: {
                  createdAt: {
                    $gte: todayStart,
                    $lte: todayEnd,
                  },
                },
              },
              {
                $group: {
                  _id: {
                    role: '$user.role',
                    status: '$status',
                  },
                  totalAmount: { $sum: '$amount' },
                  total: {
                    $sum: 1,
                  },
                },
              },
              {
                $group: {
                  _id: '$_id.role',
                  statuses: {
                    $push: {
                      k: '$_id.status',
                      v: {
                        totalAmount: '$totalAmount',
                        total: '$total',
                      },
                    },
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  objects: {
                    $push: {
                      k: '$_id',
                      v: { $arrayToObject: '$statuses' },
                    },
                  },
                },
              },
              {
                $replaceRoot: {
                  newRoot: { $arrayToObject: '$objects' },
                },
              },
            ],
          },
        },
        {
          $project: {
            all: { $arrayElemAt: ['$all', 0] },
            today: { $arrayElemAt: ['$today', 0] },
          },
        },
      ]);

      const topup = await this.Transaction.aggregate([
        {
          $match: {
            transactionType: TransactionType.Topup,
          },
        },
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: '$user',
        },
        {
          $match: {
            'user.role': Role.Client,
          },
        },
        {
          $facet: {
            all: [
              {
                $group: {
                  _id: '$status',
                  totalAmount: { $sum: '$amount' },
                  total: {
                    $sum: 1,
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  objects: {
                    $push: {
                      k: '$_id',
                      v: {
                        totalAmount: '$totalAmount',
                        total: '$total',
                      },
                    },
                  },
                },
              },
              {
                $replaceRoot: {
                  newRoot: { $arrayToObject: '$objects' },
                },
              },
            ],
            today: [
              {
                $match: {
                  createdAt: {
                    $gte: todayStart,
                    $lte: todayEnd,
                  },
                },
              },
              {
                $group: {
                  _id: '$status',
                  totalAmount: { $sum: '$amount' },
                  total: {
                    $sum: 1,
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  objects: {
                    $push: {
                      k: '$_id',
                      v: {
                        totalAmount: '$totalAmount',
                        total: '$total',
                      },
                    },
                  },
                },
              },
              {
                $replaceRoot: {
                  newRoot: { $arrayToObject: '$objects' },
                },
              },
            ],
          },
        },
        {
          $project: {
            all: { $arrayElemAt: ['$all', 0] },
            today: { $arrayElemAt: ['$today', 0] },
          },
        },
      ]);

      const withdraw = await this.Withdraw.aggregate([
        {
          $match: {
            process: WithdrawProcess.Process,
          },
        },
        {
          $facet: {
            all: [
              {
                $group: {
                  _id: {
                    withdrawType: '$withdrawType',
                    status: '$status',
                  },
                  totalAmount: {
                    $sum: '$amount',
                  },
                  total: {
                    $sum: 1,
                  },
                },
              },
              {
                $group: {
                  _id: '$_id.withdrawType',
                  statuses: {
                    $push: {
                      k: '$_id.status',
                      v: {
                        totalAmount: '$totalAmount',
                        total: '$total',
                      },
                    },
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  objects: {
                    $push: {
                      k: '$_id',
                      v: { $arrayToObject: '$statuses' },
                    },
                  },
                },
              },
              {
                $replaceRoot: {
                  newRoot: { $arrayToObject: '$objects' },
                },
              },
            ],
            today: [
              {
                $match: {
                  createdAt: {
                    $gte: todayStart,
                    $lte: todayEnd,
                  },
                },
              },
              {
                $group: {
                  _id: {
                    withdrawType: '$withdrawType',
                    status: '$status',
                  },
                  totalAmount: {
                    $sum: '$amount',
                  },
                  total: {
                    $sum: 1,
                  },
                },
              },
              {
                $group: {
                  _id: '$_id.withdrawType',
                  statuses: {
                    $push: {
                      k: '$_id.status',
                      v: {
                        totalAmount: '$totalAmount',
                        total: '$total',
                      },
                    },
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  objects: {
                    $push: {
                      k: '$_id',
                      v: { $arrayToObject: '$statuses' },
                    },
                  },
                },
              },
              {
                $replaceRoot: {
                  newRoot: { $arrayToObject: '$objects' },
                },
              },
            ],
          },
        },
        {
          $project: {
            all: { $arrayElemAt: ['$all', 0] },
            today: { $arrayElemAt: ['$today', 0] },
          },
        },
      ]);

      const success = response.initSuccess(200, true, {
        cutoff: cutoff.length ? cutoff[0].totalCutoff : null,
        commission: commission.length ? commission[0] : null,
        balance: balance.length ? balance[0] : null,
        transaction: transaction.length ? transaction[0] : null,
        topup: topup.length ? topup[0] : null,
        withdraw: withdraw.length ? withdraw[0] : null,
      });
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getBalance(type: string, res: FastifyReply) {
    try {
      const userRoot = await this.User.findOne({
        role: Role.Root,
      }).exec();

      const result: any = {};
      if (type === 'system') {
        await this.Balance.findOne({
          user: userRoot.id,
        }).then((balance) => {
          result.balance = balance.balance;
          result.pending = balance.pending;
        });
      } else if (type === 'df') {
        const payloadDf = {
          cmd: 'deposit',
          username: process.env.DF_USERNAME,
          sign: hash(
            'md5',
            `${process.env.DF_USERNAME}${process.env.DF_PROD_KEY}depo`,
          ),
        };
        await fetch(process.env.DF_BASE_URL + 'cek-saldo', {
          method: 'POST',
          body: JSON.stringify(payloadDf),
          headers: {
            'Content-Type': CT_APP_JSON,
          },
        }).then(async (responseFetchDf) => {
          const responseDataDf = await responseFetchDf.json();
          result.balance = responseDataDf.data.deposit;
        });
      } else if (type === ProviderCodeType.Linkqu) {
        await this.Provider.find({
          code: ProviderCodeType.Linkqu,
          user: userRoot.id,
          isActive: true,
        }).then(async (providers) => {
          if (providers.length) {
            var balance = 0,
              pending = 0;
            for (const provider of providers) {
              if (provider.key) {
                const keyDec = decrypt(
                  process.env.ENCRYPT_ALG,
                  hash('sha256', provider.id).substring(0, 32),
                  hash('sha256', userRoot.id + provider.code).substring(0, 16),
                  provider.key,
                );

                const key = JSON.parse(keyDec);

                const header = {
                  'client-id': key.clientId,
                  'client-secret': key.clientSecret,
                };
                await fetch(
                  process.env.PG_BASE_URL +
                    'akun/resume?username=' +
                    key.username,
                  {
                    method: 'GET',
                    headers: header,
                  },
                ).then(async (responseFetch) => {
                  const responseData = await responseFetch.json();

                  if (
                    responseData.rc === '00' &&
                    responseData.rd === 'Berhasil'
                  ) {
                    balance += responseData.balance;
                    pending += responseData.data.unsettle_amount;
                  }
                });
              }
            }

            result.balance = balance;
            result.pending = pending;
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Provider not found'),
            );
            return res.send(error);
          }
        });
      } else if (type === ProviderCodeType.Bnc) {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Under Maintenance'),
        );
        return res.send(error);
      } else if (type === ProviderCodeType.Mpi) {
        await this.Provider.findOne({
          code: ProviderCodeType.Mpi,
          user: userRoot.id,
          isActive: true,
        }).then(async (provider) => {
          var balance = '0',
            point = '0',
            commission = '0';
          if (provider) {
            const keyDec = decrypt(
              process.env.ENCRYPT_ALG,
              hash('sha256', provider.id).substring(0, 32),
              hash('sha256', userRoot.id + provider.code).substring(0, 16),
              provider.key,
            );

            const key = JSON.parse(keyDec);
            const timestamp = getFormattedTime();
            const jwt = Buffer.from(
              `${key.storeId}:${key.username}:${key.password}:${key.pin}`,
              'utf-8',
            ).toString('base64');
            const stringToSign = `GET:/api/h2h/prod/get-balance:${jwt}:${hash(
              'sha256',
              '',
            ).toLowerCase()}:${timestamp}`;
            const sig = encryptHmac('sha512', key.pin, stringToSign, 'base64');
            const header = {
              'Content-Type': CT_APP_JSON,
              Authorization: `Basic ${jwt}`,
              Timestamp: timestamp,
              Signature: sig,
            };
            await fetch(
              'https://apps-mpulsa.com:9889/mpi/api/h2h/prod/get-balance',
              {
                method: 'GET',
                headers: header,
              },
            ).then(async (responseFetch) => {
              const responseData = await responseFetch.json();
              // console.log(responseData);
              if (responseData.status === 200 && responseData.values.success) {
                balance = responseData.values.message.balance;
                point = responseData.values.message.point;
                commission = responseData.values.message.commission;
              }
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Provider not found'),
            );
            return res.send(error);
          }
          result.balance = balance;
          result.point = point;
          result.commission = commission;
        });
      } else {
        const error = response.initError(
          404,
          false,
          new ErrorMessage('Invalid Type'),
        );
        return res.send(error);
      }

      const success = response.initSuccess(200, true, result);
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getBalanceProvider(type: string, res: FastifyReply) {
    try {
      var result: any;
      if (type === ProviderCodeType.Linkqu) {
        await this.Provider.find({
          code: ProviderCodeType.Linkqu,
          isActive: true,
        })
          .populate('user')
          .populate('providerRoot')
          .then(async (providers: any[]) => {
            if (providers.length) {
              const temp = [];
              for (const provider of providers) {
                if (provider.key) {
                  var keyDec = '';
                  if (provider.key === 'root') {
                    keyDec = decrypt(
                      process.env.ENCRYPT_ALG,
                      hash('sha256', provider.providerRoot.id).substring(0, 32),
                      hash(
                        'sha256',
                        provider.providerRoot.user + provider.providerRoot.code,
                      ).substring(0, 16),
                      provider.providerRoot.key,
                    );
                  } else {
                    keyDec = decrypt(
                      process.env.ENCRYPT_ALG,
                      hash('sha256', provider.id).substring(0, 32),
                      hash(
                        'sha256',
                        provider.user.id + provider.code,
                      ).substring(0, 16),
                      provider.key,
                    );
                  }

                  const key = JSON.parse(keyDec);

                  const header = {
                    'client-id': key.clientId,
                    'client-secret': key.clientSecret,
                  };
                  await fetch(
                    process.env.PG_BASE_URL +
                      'akun/resume?username=' +
                      key.username,
                    {
                      method: 'GET',
                      headers: header,
                    },
                  ).then(async (responseFetch) => {
                    const responseData = await responseFetch.json();
                    if (
                      responseData.rc === '00' &&
                      responseData.rd === 'Berhasil'
                    ) {
                      temp.push({
                        providerId: provider.id,
                        owner: {
                          userId: provider.user.id,
                          username: provider.user.username,
                        },
                        balance: responseData.balance,
                        pending: responseData.data.unsettle_amount,
                        type: provider.user.role,
                        name: provider.name,
                      });
                    }
                  });
                }
              }

              result = temp;
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Provider not found'),
              );
              return res.send(error);
            }
          });
      } else if (type === ProviderCodeType.Bnc) {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Under Maintenance'),
        );
        return res.send(error);
      } else if (type === ProviderCodeType.Mpi) {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Under Maintenance'),
        );
        return res.send(error);
      } else {
        const error = response.initError(
          404,
          false,
          new ErrorMessage('Invalid Type'),
        );
        return res.send(error);
      }

      const success = response.initSuccess(200, true, result);
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDisburseBankList(type: string, userId: string, res: FastifyReply) {
    try {
      await this.Bank.find({
        type: BankType.Bank,
      })
        .select('_id name img isActive min max')
        .then(async (banks) => {
          var fee = null;
          if (type === WithdrawType.Client) {
            await this.Fee.findOne({
              feeType: FeeType.Bank,
              user: new Types.ObjectId(userId),
            })
              .populate('type', 'name')
              .select('fixed percentage type')
              .then(async (feeFound) => {
                fee = feeFound;
              });
          } else if (type === WithdrawType.Partner) {
            const userRoot = await this.User.findOne({
              role: Role.Root,
            });
            await this.Fee.findOne({
              feeType: FeeType.Bank,
              user: userRoot.id,
            })
              .populate('type', 'name')
              .select('fixed percentage type')
              .then(async (feeFound) => {
                fee = feeFound;
              });
          }
          const success = response.initSuccess(200, true, {
            banks,
            fee,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDisburseBankCheck(
    data: CheckBankAccountDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };
      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        const userRoot = await this.User.findOne({
          role: Role.Root,
        }).exec();
        await this.Provider.findOne({
          code: ProviderCodeType.Linkqu,
          user: userRoot.id,
          isActive: true,
        }).then(async (provider) => {
          const keyDec = decrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', provider.id).substring(0, 32),
            hash('sha256', userRoot.id + provider.code).substring(0, 16),
            provider.key,
          );

          const key = JSON.parse(keyDec);

          await this.Bank.findById(data.bankId).then(async (bank) => {
            if (bank) {
              const amount = 10000;
              const orderId = generateRandomNumber(20);
              const url =
                bank.type === BankType.Bank
                  ? 'transaction/withdraw/inquiry'
                  : 'transaction/reload/inquiry';
              const paramX = `/${url}POST`;
              const paramY = `${amount}${data.account}${bank.code}${orderId}${key.clientId}`;

              const sig = encryptHmac(
                'sha256',
                key.sigKey,
                paramX + paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
                'hex',
              );
              const payload: any = {
                amount: Number(amount),
                partner_reff: orderId,
                accountnumber: data.account,
                bankcode: bank.code,
                username: key.username,
                pin: key.pin,
                signature: sig,
              };

              const header = {
                'Content-Type': CT_APP_JSON,
                'client-id': key.clientId,
                'client-secret': key.clientSecret,
              };
              await fetch(process.env.PG_BASE_URL + url, {
                method: 'POST',
                body: JSON.stringify(payload),
                headers: header,
              }).then(async (responseFetch) => {
                const responseData = await responseFetch.json();
                if (
                  responseData.status === PgType.Success &&
                  responseData.response_code === PgType.SuccessCode
                ) {
                  const success = response.initSuccess(
                    200,
                    true,
                    responseData.accountname,
                  );
                  return res.send(success);
                } else {
                  const success = response.initSuccess(200, false, null);
                  return res.send(success);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Bank not found'),
              );
              return res.send(error);
            }
          });
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async disburseInquiry(
    payload: ProcessDisburseDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const xTime = req.headers['x-timestamp'];
      const xSig = req.headers['x-signature'];
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === xSig) {
        if (user.secret2Fa && user.isVerified) {
          await this.Bank.findOne({
            _id: payload.bankId,
            type: BankType.Bank,
          }).then(async (bank) => {
            if (bank) {
              if (payload.amount < bank.min) {
                const error = response.initError(
                  403,
                  false,
                  new ErrorMessage('Minimum amount is ' + toCurrency(bank.min)),
                );
                return res.send(error);
              } else if (payload.amount > bank.max) {
                const error = response.initError(
                  403,
                  false,
                  new ErrorMessage('Maximum amount is ' + toCurrency(bank.max)),
                );
                return res.send(error);
              } else {
                var fee = 0;
                const userRoot = await this.User.findOne({
                  role: Role.Root,
                }).exec();
                if (
                  payload.type === WithdrawType.Client ||
                  payload.type === WithdrawType.Partner
                ) {
                  if (payload.user) {
                    await this.User.findById(payload.user).then(
                      async (userFound) => {
                        if (userFound) {
                          var nominal = 0;
                          if (payload.type === WithdrawType.Client) {
                            await this.Balance.findOne({
                              user: userFound.id,
                            }).then(async (balanceFound) => {
                              if (balanceFound) {
                                nominal = balanceFound.balance;
                              } else {
                                const error = response.initError(
                                  404,
                                  false,
                                  new ErrorMessage('Balance not found'),
                                );
                                return res.send(error);
                              }
                            });
                          } else {
                            await this.Commission.aggregate([
                              {
                                $match: {
                                  user: new Types.ObjectId(payload.user),
                                  isActive: false,
                                  isDisbursed: false,
                                },
                              },
                              {
                                $group: {
                                  _id: null,
                                  totalPartnerTrx: { $sum: '$partnerTrx' },
                                  totalClientTrx: { $sum: '$clientTrx' },
                                },
                              },
                            ]).then((commission) => {
                              if (commission.length) {
                                nominal =
                                  commission[0].totalPartnerTrx +
                                  commission[0].totalClientTrx;
                              }
                            });
                          }
                          await this.Fee.findOne({
                            feeType: FeeType.Bank,
                            user:
                              payload.type === WithdrawType.Client
                                ? userFound.id
                                : userRoot.id,
                          })
                            .populate('type')
                            .then((feeFound: any) => {
                              if (feeFound) {
                                switch (feeFound.type.name) {
                                  case VType.Percentage:
                                    fee = Math.floor(
                                      (payload.amount * feeFound.percentage) /
                                        100,
                                    );
                                    break;
                                  case VType.Fixed:
                                    fee = feeFound.fixed;
                                    break;
                                  default:
                                    fee = Math.floor(
                                      (payload.amount * feeFound.percentage) /
                                        100 +
                                        feeFound.fixed,
                                    );
                                    break;
                                }
                              } else {
                                const error = response.initError(
                                  404,
                                  false,
                                  new ErrorMessage('Fee not found'),
                                );
                                return res.send(error);
                              }
                            });
                          if (nominal < payload.amount + fee) {
                            const error = response.initError(
                              403,
                              false,
                              new ErrorMessage('Balance is not enough'),
                            );
                            return res.send(error);
                          }
                        } else {
                          const error = response.initError(
                            404,
                            false,
                            new ErrorMessage('User not found'),
                          );
                          return res.send(error);
                        }
                      },
                    );
                  } else {
                    const error = response.initError(
                      403,
                      false,
                      new ErrorMessage('User must not be empty'),
                    );
                    return res.send(error);
                  }
                } else {
                  if (payload.type === WithdrawType.Deposit) {
                    const balance = await this.Balance.findOne({
                      user: userRoot.id,
                    }).exec();

                    if (balance.balance < payload.amount) {
                      const error = response.initError(
                        403,
                        false,
                        new ErrorMessage('Balance is not enough'),
                      );
                      return res.send(error);
                    }
                  } else {
                    const rootCommission = await this.Commission.aggregate([
                      {
                        $match: {
                          user: new Types.ObjectId(userRoot.id),
                          isActive: false,
                          isDisbursed: false,
                        },
                      },
                      {
                        $group: {
                          _id: null,
                          totalCutoff: { $sum: '$cutoff' },
                        },
                      },
                    ]);

                    const commission = await this.Commission.aggregate([
                      {
                        $match: {
                          clientTrx: { $exists: true },
                          partnerTrx: { $exists: true },
                          clientWd: { $exists: true },
                          partnerWd: { $exists: true },
                          isActive: false,
                          isDisbursed: false,
                        },
                      },
                      {
                        $group: {
                          _id: null,
                          totalClientTrx: { $sum: '$clientTrx' },
                          totalPartnerTrx: { $sum: '$partnerTrx' },
                          totalClientWd: { $sum: '$clientWd' },
                          totalPartnerWd: { $sum: '$partnerWd' },
                        },
                      },
                    ]);

                    var nominal = 0;
                    if (rootCommission.length) {
                      nominal += rootCommission[0].totalCutoff;
                    }

                    if (commission.length) {
                      nominal +=
                        commission[0].totalClientTrx +
                        commission[0].totalPartnerTrx +
                        commission[0].totalClientWd +
                        commission[0].totalPartnerWd;
                    }

                    if (nominal < payload.amount) {
                      const error = response.initError(
                        403,
                        false,
                        new ErrorMessage('Balance is not enough'),
                      );
                      return res.send(error);
                    }
                  }
                }

                await this.Provider.findById(payload.providerId).then(
                  async (provider: any) => {
                    if (provider) {
                      var keyDec = '';
                      if (provider.key === 'root') {
                        keyDec = decrypt(
                          process.env.ENCRYPT_ALG,
                          hash(
                            'sha256',
                            provider.providerRoot.id.valueOf(),
                          ).substring(0, 32),
                          hash(
                            'sha256',
                            provider.providerRoot.user.valueOf() +
                              provider.providerRoot.code,
                          ).substring(0, 16),
                          provider.providerRoot.key,
                        );
                      } else {
                        keyDec = decrypt(
                          process.env.ENCRYPT_ALG,
                          hash('sha256', provider.id).substring(0, 32),
                          hash(
                            'sha256',
                            provider.user.valueOf() + provider.code,
                          ).substring(0, 16),
                          provider.key,
                        );
                      }

                      const key = JSON.parse(keyDec);

                      const amount = payload.amount;
                      const orderId = generateRandomNumber(50);
                      const url = 'transaction/withdraw/inquiry';
                      const paramX = `/${url}POST`;
                      const paramY = `${amount}${payload.account}${bank.code}${orderId}${key.clientId}`;

                      const sig = encryptHmac(
                        'sha256',
                        key.sigKey,
                        paramX +
                          paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
                        'hex',
                      );
                      const payloadCheck: any = {
                        amount: Number(amount),
                        partner_reff: orderId,
                        accountnumber: payload.account,
                        bankcode: bank.code,
                        username: key.username,
                        pin: key.pin,
                        signature: sig,
                      };

                      const header = {
                        'Content-Type': CT_APP_JSON,
                        'client-id': key.clientId,
                        'client-secret': key.clientSecret,
                      };
                      await fetch(process.env.PG_BASE_URL + url, {
                        method: 'POST',
                        body: JSON.stringify(payloadCheck),
                        headers: header,
                      }).then(async (responseFetch) => {
                        const responseData = await responseFetch.json();
                        if (
                          responseData.status === PgType.Success &&
                          responseData.response_code === PgType.SuccessCode
                        ) {
                          if (responseData.accountname === payload.name) {
                            const withdrawId =
                              'D' +
                              hash('sha256', generateRandomNumber(5) + xTime);
                            const signature = encryptHmac(
                              'sha512',
                              xTime + user.username + user.pass,
                              'POST' +
                                '/disburse/process'.toString() +
                                hash(
                                  'sha512',
                                  minifyJson(payload),
                                ).toLowerCase() +
                                '|' +
                                browser.id +
                                '|' +
                                user.id +
                                '|' +
                                withdrawId +
                                '|' +
                                responseData.inquiry_reff,
                              'hex',
                            );

                            const newWithdraw = new this.Withdraw({
                              withdrawId,
                              orderId,
                              amount,
                              fee,
                              feeAdmin: responseData.additionalfee,
                              name: responseData.accountname,
                              accNumber: payload.account,
                              inquiryReff: responseData.inquiry_reff,
                              withdrawType: payload.type,
                              inquiryBy: user.id,
                              bank: bank.id,
                              ip: req.ip,
                              provider: provider.id,
                            });

                            if (
                              (payload.type === WithdrawType.Client ||
                                payload.type === WithdrawType.Partner) &&
                              payload.user
                            ) {
                              newWithdraw.user = new Types.ObjectId(
                                payload.user,
                              );
                            } else {
                              newWithdraw.user = userRoot.id;
                            }

                            if (payload.remark) {
                              newWithdraw.remark = payload.remark;
                            }

                            await newWithdraw.save();
                            const success = response.initSuccess(200, true, {
                              signature,
                              withdrawId,
                              amount,
                              fee,
                              addFee: responseData.additionalfee,
                              name: responseData.accountname,
                              account: payload.account,
                              bank: bank.name,
                            });
                            return res.send(success);
                          } else {
                            const error = response.initError(
                              404,
                              false,
                              new ErrorMessage('Bank account name not valid'),
                            );
                            return res.send(error);
                          }
                        } else {
                          console.log(responseData);
                          const error = response.initError(
                            404,
                            false,
                            new ErrorMessage('Bank account not found'),
                          );
                          return res.send(error);
                        }
                      });
                    } else {
                      const error = response.initError(
                        404,
                        false,
                        new ErrorMessage('Provider not found'),
                      );
                      return res.send(error);
                    }
                  },
                );
              }
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Bank not found'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Please setup 2FA first'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async disburseProcess(
    withdrawId: string,
    data: ProcessDisburseDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (data.code) {
        const { user, browser } = req.user;
        if (user.secret2Fa && user.isVerified) {
          const keyDec = decrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', user.id).substring(0, 32),
            hash('sha256', user.id + user.username).substring(0, 16),
            user.secret2Fa,
          );

          if (!authenticator.check(data.code, keyDec)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Invalid 2FA Code'),
            );
            return res.send(error);
          }

          await this.Withdraw.findOne({
            withdrawId,
            process: WithdrawProcess.Inquiry,
          })
            .populate('bank')
            .then(async (withdraw: any) => {
              if (withdraw) {
                const xTime = req.headers['x-timestamp'];
                const xSig = req.headers['x-signature'];
                const { code: _, ...payload } = data;
                const signature = encryptHmac(
                  'sha512',
                  xTime + user.username + user.pass,
                  'POST' +
                    '/disburse/process'.toString() +
                    hash('sha512', minifyJson(payload)).toLowerCase() +
                    '|' +
                    browser.id +
                    '|' +
                    user.id +
                    '|' +
                    withdraw.withdrawId +
                    '|' +
                    withdraw.inquiryReff,
                  'hex',
                );
                const signatureVerify = encryptHmac(
                  'sha256',
                  browser.csrf,
                  signature + '|' + browser.browserId,
                  'hex',
                );

                const updateBrowser = {
                  user: user.id,
                  $push: { ip: req.ip },
                };

                await this.Browser.findByIdAndUpdate(
                  browser.id,
                  {
                    $set: updateBrowser,
                    $unset: {
                      csrf: undefined,
                    },
                  },
                  { new: true, upsert: true },
                );

                if (signatureVerify === xSig) {
                  const userRoot = await this.User.findOne({
                    role: Role.Root,
                  }).exec();
                  const rootBalance = await this.Balance.findOne({
                    user: userRoot.id,
                  }).exec();

                  var balanceDocument: BalanceDocument;
                  var name = '';

                  const updateWithdraw: any = {
                    status: WithdrawStatus.Processing,
                    process: WithdrawProcess.Process,
                    processedBy: user.id,
                    processedDate: new Date(),
                  };

                  if (
                    withdraw.withdrawType === WithdrawType.Client ||
                    withdraw.withdrawType === WithdrawType.Partner
                  ) {
                    await this.Balance.findOne({
                      user: withdraw.user,
                    })
                      .populate('user')
                      .then(async (balanceFound: any) => {
                        if (balanceFound) {
                          balanceDocument = balanceFound;

                          if (withdraw.withdrawType === WithdrawType.Client) {
                            updateWithdraw.uplineFee = [];
                            await this.Client.findOne({
                              user: withdraw.user,
                            }).then(async (client) => {
                              if (client) {
                                name = client.clientName;
                              } else {
                                const error = response.initError(
                                  404,
                                  false,
                                  new ErrorMessage('Client not found'),
                                );
                                return res.send(error);
                              }
                            });

                            if (updateWithdraw.uplineFee.length) {
                              updateWithdraw.uplineFee.sort(
                                (a: any, b: any) => {
                                  if (a.id < b.id) return -1;
                                  if (a.id > b.id) return 1;
                                  return 0;
                                },
                              );
                            }
                          } else {
                            name = balanceFound.user.username;
                          }
                        } else {
                          const error = response.initError(
                            404,
                            false,
                            new ErrorMessage('Balance not found'),
                          );
                          return res.send(error);
                        }
                      });
                  } else {
                    balanceDocument = rootBalance;
                  }

                  if (balanceDocument.balance < payload.amount + withdraw.fee) {
                    const error = response.initError(
                      403,
                      false,
                      new ErrorMessage('Balance is not enough'),
                    );
                    return res.send(error);
                  } else {
                    await this.Balance.findByIdAndUpdate(balanceDocument.id, {
                      $inc: {
                        balance: -Number(withdraw.amount + withdraw.fee),
                      },
                    });

                    const newBalanceLog = new this.BalanceLog({
                      name: `system's disburse for ${withdraw.withdrawType}${
                        withdraw.withdrawType === WithdrawType.Client ||
                        withdraw.withdrawType === WithdrawType.Partner
                          ? ` ${name}`
                          : ''
                      }`,
                      balanceAmount: balanceDocument.balance,
                      balanceCredit: Number(withdraw.amount + withdraw.fee),
                      type: BalanceLogType.Out,
                      balance: balanceDocument.id,
                      withdraw: withdraw.id,
                    });

                    await newBalanceLog.save();
                  }

                  await this.Withdraw.findByIdAndUpdate(
                    withdraw.id,
                    updateWithdraw,
                  );

                  await this.LogType.findOne({
                    type: LogTypes.AdminDisburse,
                  }).then(async (logType) => {
                    if (logType) {
                      const newLog = new this.Log({
                        message: `${
                          user.username
                        } disburse ${name} amount ${toCurrency(
                          payload.amount,
                        )}`,
                        target: withdraw.id,
                        ip: req.ip,
                        type: logType.id,
                        user: new Types.ObjectId(payload.userId),
                        admin: user.id,
                      });

                      await newLog.save();
                    }
                  });

                  await this.Provider.findById(payload.providerId).then(
                    async (provider: any) => {
                      if (provider) {
                        var keyDec = '';
                        if (provider.key === 'root') {
                          keyDec = decrypt(
                            process.env.ENCRYPT_ALG,
                            hash(
                              'sha256',
                              provider.providerRoot.id.valueOf(),
                            ).substring(0, 32),
                            hash(
                              'sha256',
                              provider.providerRoot.user.valueOf() +
                                provider.providerRoot.code,
                            ).substring(0, 16),
                            provider.providerRoot.key,
                          );
                        } else {
                          keyDec = decrypt(
                            process.env.ENCRYPT_ALG,
                            hash('sha256', provider.id).substring(0, 32),
                            hash(
                              'sha256',
                              provider.user.valueOf() + provider.code,
                            ).substring(0, 16),
                            provider.key,
                          );
                        }

                        const key = JSON.parse(keyDec);

                        const url = 'transaction/withdraw/payment';
                        const paramX = `/${url}POST`;
                        const paramY = `${withdraw.amount}${payload.account}${withdraw.bank.code}${withdraw.orderId}${withdraw.inquiryReff}${key.clientId}`;

                        const sig = encryptHmac(
                          'sha256',
                          key.sigKey,
                          paramX +
                            paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
                          'hex',
                        );
                        const payloadPayment: any = {
                          amount: Number(withdraw.amount),
                          partner_reff: withdraw.orderId,
                          inquiry_reff: withdraw.inquiryReff,
                          accountnumber: payload.account,
                          bankcode: withdraw.bank.code,
                          username: key.username,
                          pin: key.pin,
                          signature: sig,
                        };

                        if (withdraw.remark) {
                          payloadPayment.remark = withdraw.remark;
                        }

                        const header = {
                          'Content-Type': CT_APP_JSON,
                          'client-id': key.clientId,
                          'client-secret': key.clientSecret,
                        };
                        await fetch(process.env.PG_BASE_URL + url, {
                          method: 'POST',
                          body: JSON.stringify(payloadPayment),
                          headers: header,
                        })
                          .then(async (responseFetch) => {
                            const responseData = await responseFetch.json();

                            if (responseData.status === PgType.Failed) {
                              withdraw.note = responseData.response_desc;
                              withdraw.status = WithdrawStatus.Failed;
                              await withdraw.save();

                              const updatedBalance =
                                await this.Balance.findByIdAndUpdate(
                                  balanceDocument.id,
                                  {
                                    $inc: {
                                      balance: Number(
                                        withdraw.amount + withdraw.fee,
                                      ),
                                    },
                                  },
                                );

                              const newBalanceLog = new this.BalanceLog({
                                name: `system's return disburse`,
                                balanceAmount:
                                  updatedBalance.balance -
                                  (withdraw.amount + withdraw.fee),
                                balanceCredit: Number(
                                  withdraw.amount + withdraw.fee,
                                ),
                                type: BalanceLogType.Refund,
                                balance: balanceDocument.id,
                                withdraw: withdraw.id,
                              });

                              await newBalanceLog.save();

                              const error = response.initError(
                                200,
                                false,
                                new ErrorMessage(
                                  'Failed to process your disburse',
                                ),
                              );
                              return res.send(error);
                            } else {
                              withdraw.note = responseData.response_desc ?? '';
                              await withdraw.save();

                              const success = response.initSuccess(
                                200,
                                true,
                                true,
                              );
                              return res.send(success);
                            }
                          })
                          .catch((err) => {
                            console.log(err);
                            const success = response.initSuccess(
                              200,
                              true,
                              true,
                            );
                            return res.send(success);
                          });
                      } else {
                        const error = response.initError(
                          404,
                          false,
                          new ErrorMessage('Provider not found'),
                        );
                        return res.send(error);
                      }
                    },
                  );
                } else {
                  const error = response.initError(
                    403,
                    false,
                    new ErrorMessage('Signature invalid'),
                  );
                  return res.send(error);
                }
              } else {
                const error = response.initError(
                  404,
                  false,
                  new ErrorMessage('Withdraw data not found'),
                );
                return res.send(error);
              }
            });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Please setup 2FA first'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Code must not be empty'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getTransactionClient(query: QueryDto, res: FastifyReply) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        transactionId: { transactionId: query.sortOrder === 'asc' ? 1 : -1 },
        refId: { refId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
        paidTime: { paidTime: query.sortOrder === 'asc' ? 1 : -1 },
      };
      await this.Transaction.aggregate([
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: {
            path: '$user',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'methods',
            let: { methodId: { $toObjectId: '$method' } },
            pipeline: [
              {
                $match: { $expr: { $eq: ['$_id', '$$methodId'] } },
              },
            ],
            as: 'method',
          },
        },
        {
          $unwind: {
            path: '$method',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              query.search
                ? {
                    $or: [
                      {
                        transactionId: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        refId: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        clientRef: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        'method.name': {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        'user.username': {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                    ],
                  }
                : {},
              {
                transactionType: TransactionType.Transaction,
                'user.role': Role.Client,
                createdAt: {
                  $gte: new Date(Number(query.dateStart)),
                  $lte: new Date(Number(query.dateEnd)),
                },
              },
              query.filter.trim() !== 'all'
                ? {
                    status: query.filter.trim(),
                  }
                : {},
            ],
          },
        },
        {
          $facet: {
            results: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $project: {
                  _id: 0,
                  id: '$_id',
                  transactionId: 1,
                  payment: 1,
                  url: 1,
                  fee: 1,
                  feeAdmin: 1,
                  refId: 1,
                  amount: 1,
                  status: 1,
                  pgSettled: 1,
                  clientRef: 1,
                  method: '$method.name',
                  methodType: '$method.type',
                  username: '$user.username',
                  userId: '$user._id',
                  createdAt: 1,
                  paidTime: 1,
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((transactions) => {
        const success = response.initSuccess(200, true, transactions[0]);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getTransactionUser(query: QueryDto, res: FastifyReply) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        orderId: { orderId: query.sortOrder === 'asc' ? 1 : -1 },
        refId: { refId: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        transactionId: { transactionId: query.sortOrder === 'asc' ? 1 : -1 },
        method: { 'method.name': query.sortOrder === 'asc' ? 1 : -1 },
        email: { 'user.email': query.sortOrder === 'asc' ? 1 : -1 },
        product: { 'product.name': query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
        paidTime: { paidTime: query.sortOrder === 'asc' ? 1 : -1 },
      };
      await this.Transaction.aggregate([
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: {
            path: '$user',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'methods',
            let: { methodId: { $toObjectId: '$method' } },
            pipeline: [
              {
                $match: { $expr: { $eq: ['$_id', '$$methodId'] } },
              },
            ],
            as: 'method',
          },
        },
        {
          $unwind: {
            path: '$method',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'products',
            let: { productId: { $toObjectId: '$product' } },
            pipeline: [
              {
                $match: { $expr: { $eq: ['$_id', '$$productId'] } },
              },
            ],
            as: 'product',
          },
        },
        {
          $unwind: {
            path: '$product',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              query.search
                ? {
                    $or: [
                      {
                        transactionId: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        refId: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        orderId: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        'product.name': {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        'method.name': {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        'user.email': {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                    ],
                  }
                : {},
              {
                transactionType: TransactionType.Transaction,
                'user.role': Role.User,
                createdAt: {
                  $gte: new Date(Number(query.dateStart)),
                  $lte: new Date(Number(query.dateEnd)),
                },
              },
              query.filter.trim() !== 'all'
                ? {
                    status: query.filter.trim(),
                  }
                : {},
            ],
          },
        },
        {
          $facet: {
            results: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $project: {
                  _id: 0,
                  id: '$_id',
                  transactionId: 1,
                  payment: 1,
                  url: 1,
                  refId: 1,
                  amount: 1,
                  status: 1,
                  orderId: 1,
                  method: '$method.name',
                  methodType: '$method.type',
                  email: '$user.email',
                  userId: '$user._id',
                  product: '$product.name',
                  createdAt: 1,
                  paidTime: 1,
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((transactions) => {
        const success = response.initSuccess(200, true, transactions[0]);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getTopupClient(query: QueryDto, res: FastifyReply) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        transactionId: { transactionId: query.sortOrder === 'asc' ? 1 : -1 },
        refId: { refId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      await this.Transaction.aggregate([
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: {
            path: '$user',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'methods',
            let: { methodId: { $toObjectId: '$method' } },
            pipeline: [
              {
                $match: { $expr: { $eq: ['$_id', '$$methodId'] } },
              },
            ],
            as: 'method',
          },
        },
        {
          $unwind: {
            path: '$method',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              query.search
                ? {
                    $or: [
                      {
                        transactionId: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        refId: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        clientRef: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        'method.name': {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        'user.username': {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                    ],
                  }
                : {},
              {
                transactionType: TransactionType.Topup,
                'user.role': Role.Client,
                createdAt: {
                  $gte: new Date(Number(query.dateStart)),
                  $lte: new Date(Number(query.dateEnd)),
                },
              },
              query.filter.trim() !== 'all'
                ? {
                    status: query.filter.trim(),
                  }
                : {},
            ],
          },
        },
        {
          $facet: {
            results: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $project: {
                  _id: 0,
                  id: '$_id',
                  transactionId: 1,
                  payment: 1,
                  url: 1,
                  refId: 1,
                  amount: 1,
                  status: 1,
                  pgSettled: 1,
                  clientRef: 1,
                  method: '$method.name',
                  methodType: '$method.type',
                  username: '$user.username',
                  userId: '$user._id',
                  createdAt: 1,
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((transactions) => {
        const success = response.initSuccess(200, true, transactions[0]);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async checkBca(trxId: string, res: FastifyReply) {
    try {
      await this.Transaction.aggregate([
        {
          $match: {
            _id: new Types.ObjectId(trxId),
          },
        },
        {
          $lookup: {
            from: 'fees',
            let: { methodId: '$method', userId: '$user' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$method', '$$methodId'] },
                      { $eq: ['$feeType', FeeType.Transaction] },
                      { $eq: ['$user', '$$userId'] },
                    ],
                  },
                },
              },
              {
                $lookup: {
                  from: 'providers',
                  let: { providerId: '$provider' },
                  pipeline: [
                    {
                      $match: {
                        $expr: { $eq: ['$_id', '$$providerId'] },
                      },
                    },
                    {
                      $lookup: {
                        from: 'providers',
                        localField: 'providerRoot',
                        foreignField: '_id',
                        as: 'providerRoot',
                      },
                    },
                    {
                      $unwind: {
                        path: '$providerRoot',
                        preserveNullAndEmptyArrays: true,
                      },
                    },
                  ],
                  as: 'provider',
                },
              },
              {
                $unwind: '$provider',
              },
            ],
            as: 'fee',
          },
        },
        {
          $unwind: '$fee',
        },
      ]).then(async (trxFound: any) => {
        if (trxFound.length) {
          const trx = trxFound[0];
          var keyDec: string;
          if (trx.fee.provider.key === 'root') {
            keyDec = decrypt(
              process.env.ENCRYPT_ALG,
              hash(
                'sha256',
                trx.fee.provider.providerRoot._id.valueOf(),
              ).substring(0, 32),
              hash(
                'sha256',
                trx.fee.provider.providerRoot.user.valueOf() +
                  trx.fee.provider.providerRoot.code,
              ).substring(0, 16),
              trx.fee.provider.providerRoot.key,
            );
          } else {
            keyDec = decrypt(
              process.env.ENCRYPT_ALG,
              hash('sha256', trx.fee.provider._id.valueOf()).substring(0, 32),
              hash(
                'sha256',
                trx.fee.provider.user.valueOf() + trx.fee.provider.code,
              ).substring(0, 16),
              trx.fee.provider.key,
            );
          }

          const key = JSON.parse(keyDec);

          const jwt = Buffer.from(
            `${key.storeId}:${key.username}:${key.password}:${key.pin}`,
            'utf-8',
          ).toString('base64');

          const resultPg = await this.providerService.checkStatusBcaVaMpi(
            jwt,
            trx.orderId,
            key.pin,
          );

          const success = response.initSuccess(200, true, resultPg);
          return res.status(200).send(success);
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Transaction not found'),
          );
          return res.status(200).send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.status(200).send(error);
    }
  }

  async getWithdraw(
    query: QueryDto,
    type: string,
    process: string,
    res: FastifyReply,
  ) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions: any = {
        withdrawId: { withdrawId: query.sortOrder === 'asc' ? 1 : -1 },
        orderId: { orderId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        name: { name: query.sortOrder === 'asc' ? 1 : -1 },
        accNumber: { accNumber: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        status: { status: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const withdrawQuery: any = {
        process,
        withdrawType: type,
        $or: [
          { withdrawId: { $regex: query.search.trim(), $options: 'i' } },
          { orderId: { $regex: query.search.trim(), $options: 'i' } },
          { name: { $regex: query.search.trim(), $options: 'i' } },
          { accNumber: { $regex: query.search.trim(), $options: 'i' } },
          { clientRef: { $regex: query.search.trim(), $options: 'i' } },
        ],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        withdrawQuery.status = query.filter.trim();
      }

      if (type === WithdrawType.Client) {
        sortOptions.clientRef = {
          clientRef: query.sortOrder === 'asc' ? 1 : -1,
        };
        withdrawQuery.$or.push({
          clientRef: { $regex: query.search.trim(), $options: 'i' },
        });
      }

      await this.Withdraw.find(withdrawQuery)
        .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
        .skip(skip)
        .limit(query.limit)
        .populate({
          path: 'bank',
          select: '-_id name type',
        })
        .populate({
          path: 'user',
          select: 'username',
        })
        .populate({
          path: 'processedBy',
          select: '-_id username',
        })
        .select(
          `_id withdrawId orderId clientRef name accNumber amount feee feeAdmin status createdAt processedBy ${
            type === WithdrawType.Client || type === WithdrawType.Partner
              ? 'user'
              : ''
          }`,
        )
        .then(async (withdraws) => {
          const total = await this.Withdraw.countDocuments(withdrawQuery);
          const success = response.initSuccess(200, true, {
            withdraws,
            total,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getWithdrawDetail(
    type: string,
    withdrawId: string,
    modeType: string,
    res: FastifyReply,
  ) {
    try {
      const mode = modeType ?? 'prod';
      if (mode === 'prod') {
        await this.Withdraw.findOne({
          withdrawType: type,
          _id: new Types.ObjectId(withdrawId),
        })
          .populate({
            path: 'bank',
            select: '-_id name img type',
          })
          .populate({
            path: 'user',
            select: '_id username',
          })
          .populate({
            path: 'processedBy',
            select: '_id username',
          })
          .populate({
            path: 'uplineFee.commission',
            select: 'amount user',
            populate: {
              path: 'user',
              select: 'username upline',
              populate: {
                path: 'upline',
                select: 'username',
              },
            },
          })
          .select('-process -withdrawType -__v -updatedAt')
          .then((withdraw) => {
            const success = response.initSuccess(200, true, withdraw);
            return res.send(success);
          });
      } else {
        await this.DevWithdraw.findOne({
          withdrawType: type,
          _id: new Types.ObjectId(withdrawId),
        })
          .populate({
            path: 'bank',
            select: '-_id name img type',
          })
          .populate({
            path: 'user',
            select: '_id username',
          })
          .select('-process -withdrawType -__v -updatedAt')
          .then((withdraw) => {
            const success = response.initSuccess(200, true, withdraw);
            return res.send(success);
          });
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getApprovalSignature(
    data: ApprovalDisburseDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );
      if (data.signature === signatureVerify) {
        const xTime = req.headers['x-timestamp'];
        const signature = encryptHmac(
          'sha512',
          user.id + xTime,
          hash('sha512', minifyJson(payload)).toLowerCase() +
            '|' +
            user.username +
            '|' +
            user.pass,
          'hex',
        );

        const success = response.initSuccess(200, true, signature);
        return res.send(success);
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async processApproval(
    data: ApprovalDisburseDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (data.code) {
        const { user, browser } = req.user;
        if (user.secret2Fa && user.isVerified) {
          const keyDec = decrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', user.id).substring(0, 32),
            hash('sha256', user.id + user.username).substring(0, 16),
            user.secret2Fa,
          );

          if (!authenticator.check(data.code, keyDec)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Invalid 2FA Code'),
            );
            return res.send(error);
          }

          const { signature, ...unsignedData } = data;
          const { code, ...payload } = unsignedData;
          const signatureVerify = encryptHmac(
            'sha256',
            browser.csrf,
            hash('sha256', minifyJson(unsignedData)).toLowerCase() +
              '|' +
              browser.browserId,
            'hex',
          );

          const updateBrowser = {
            user: user.id,
            $push: { ip: req.ip },
          };

          await this.Browser.findByIdAndUpdate(
            browser.id,
            {
              $set: updateBrowser,
              $unset: {
                csrf: undefined,
              },
            },
            { new: true, upsert: true },
          );
          if (data.signature === signatureVerify) {
            const xTime = req.headers['x-timestamp'];
            const xSig = req.headers['x-signature'];
            const xSignatureVerify = encryptHmac(
              'sha256',
              browser.csrf,
              encryptHmac(
                'sha512',
                user.id + xTime,
                hash('sha512', minifyJson(payload)).toLowerCase() +
                  '|' +
                  user.username +
                  '|' +
                  user.pass,
                'hex',
              ) +
                '|' +
                browser.browserId,
              'hex',
            );

            if (xSig === xSignatureVerify) {
              const processQuery: any = {
                process: WithdrawProcess.Process,
                withdrawType: WithdrawType.Client,
                status: WithdrawStatus.Pending,
              };
              if (payload.withdrawalIds[0] !== 'all') {
                processQuery._id = {
                  $in: payload.withdrawalIds,
                };
              }

              await this.Withdraw.find(processQuery)
                .populate('bank')
                .populate({
                  path: 'provider',
                  populate: {
                    path: 'providerRoot',
                  },
                })
                .then(async (withdraws: any) => {
                  if (withdraws.length) {
                    const url = 'transaction/withdraw/payment';
                    const paramX = `/${url}POST`;

                    for (const withdraw of withdraws) {
                      await this.Client.findOne({
                        user: withdraw.user,
                      }).then(async (client) => {
                        if (client) {
                          await this.Balance.findOne({
                            user: withdraw.user,
                          }).then(async (balance) => {
                            if (balance) {
                              await this.LogType.findOne({
                                type: LogTypes.AdminDisburse,
                              }).then(async (logType) => {
                                if (logType) {
                                  const newLog = new this.Log({
                                    message: `${
                                      user.username
                                    } approve disburse of ${
                                      client.clientName
                                    } amount ${toCurrency(
                                      withdraw.amount,
                                    )} with fee ${withdraw.fee}`,
                                    target: withdraw.id,
                                    ip: req.ip,
                                    type: logType.id,
                                    user: withdraw.user,
                                    admin: user.id,
                                  });

                                  await newLog.save();
                                }
                              });

                              const updateWithdraw: any = {
                                status: WithdrawStatus.Processing,
                                processedBy: user.id,
                                processedDate: new Date(),
                              };

                              await this.Withdraw.findByIdAndUpdate(
                                withdraw.id,
                                updateWithdraw,
                              );

                              var keyDec = '';
                              if (withdraw.provider.key === 'root') {
                                keyDec = decrypt(
                                  process.env.ENCRYPT_ALG,
                                  hash(
                                    'sha256',
                                    withdraw.provider.providerRoot.id.valueOf(),
                                  ).substring(0, 32),
                                  hash(
                                    'sha256',
                                    withdraw.provider.providerRoot.user.valueOf() +
                                      withdraw.provider.providerRoot.code,
                                  ).substring(0, 16),
                                  withdraw.provider.providerRoot.key,
                                );
                              } else {
                                keyDec = decrypt(
                                  process.env.ENCRYPT_ALG,
                                  hash(
                                    'sha256',
                                    withdraw.provider.id,
                                  ).substring(0, 32),
                                  hash(
                                    'sha256',
                                    withdraw.provider.user.valueOf() +
                                      withdraw.provider.code,
                                  ).substring(0, 16),
                                  withdraw.provider.key,
                                );
                              }
                              const key = JSON.parse(keyDec);

                              const paramY = `${withdraw.amount}${withdraw.accNumber}${withdraw.bank.code}${withdraw.orderId}${withdraw.inquiryReff}${key.clientId}`;

                              const sig = encryptHmac(
                                'sha256',
                                key.sigKey,
                                paramX +
                                  paramY
                                    .toLowerCase()
                                    .replace(/[^a-zA-Z0-9]/g, ''),
                                'hex',
                              );
                              const payloadPayment: any = {
                                amount: Number(withdraw.amount),
                                partner_reff: withdraw.orderId,
                                inquiry_reff: withdraw.inquiryReff,
                                accountnumber: withdraw.accNumber,
                                bankcode: withdraw.bank.code,
                                username: key.username,
                                pin: key.pin,
                                signature: sig,
                              };

                              if (withdraw.remark) {
                                payloadPayment.remark = withdraw.remark;
                              }

                              const header = {
                                'Content-Type': CT_APP_JSON,
                                'client-id': key.clientId,
                                'client-secret': key.clientSecret,
                              };

                              await fetch(process.env.PG_BASE_URL + url, {
                                method: 'POST',
                                body: JSON.stringify(payloadPayment),
                                headers: header,
                              }).then(async (responseFetch) => {
                                const responseData = await responseFetch.json();

                                if (responseData.status === PgType.Failed) {
                                  withdraw.error = responseData.response_desc;
                                  withdraw.status = WithdrawStatus.Failed;
                                  await withdraw.save();

                                  const updatedBalance =
                                    await this.Balance.findByIdAndUpdate(
                                      balance.id,
                                      {
                                        $inc: {
                                          balance: Number(
                                            withdraw.amount + withdraw.fee,
                                          ),
                                        },
                                      },
                                      { new: true },
                                    );

                                  const newBalanceLog = new this.BalanceLog({
                                    name: `system's return disburse`,
                                    balanceAmount:
                                      updatedBalance.balance -
                                      (withdraw.amount + withdraw.fee),
                                    balanceCredit: Number(
                                      withdraw.amount + withdraw.fee,
                                    ),
                                    type: BalanceLogType.Refund,
                                    balance: balance.id,
                                    withdraw: withdraw.id,
                                  });

                                  await newBalanceLog.save();

                                  const error = response.initError(
                                    200,
                                    false,
                                    new ErrorMessage(
                                      'Failed to process your disburse',
                                    ),
                                  );
                                  return res.send(error);
                                } else {
                                  withdraw.note =
                                    responseData.response_desc ?? '';
                                  await withdraw.save();

                                  const success = response.initSuccess(
                                    200,
                                    true,
                                    true,
                                  );
                                  return res.send(success);
                                }
                              });
                            } else {
                              const error = response.initError(
                                404,
                                false,
                                new ErrorMessage(
                                  'User balance not found for withdrawal - ' +
                                    withdraw.id,
                                ),
                              );
                              return res.send(error);
                            }
                          });
                        } else {
                          const error = response.initError(
                            404,
                            false,
                            new ErrorMessage(
                              'Client not found for withdrawal - ' +
                                withdraw.id,
                            ),
                          );
                          return res.send(error);
                        }
                      });
                    }

                    const success = response.initSuccess(200, true, true);
                    return res.send(success);
                  } else {
                    const error = response.initError(
                      404,
                      false,
                      new ErrorMessage('No data found'),
                    );
                    return res.send(error);
                  }
                });
            } else {
              const error = response.initError(
                403,
                false,
                new ErrorMessage('X-Signature invalid'),
              );
              return res.send(error);
            }
          } else {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Signature invalid'),
            );
            return res.send(error);
          }
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Please setup 2FA first'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Code must not be empty'),
        );
        return res.send(error);
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async rejectApproval(
    data: RejectDisburseDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (data.code) {
        const { user, browser } = req.user;
        if (user.secret2Fa && user.isVerified) {
          const keyDec = decrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', user.id).substring(0, 32),
            hash('sha256', user.id + user.username).substring(0, 16),
            user.secret2Fa,
          );

          if (!authenticator.check(data.code, keyDec)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Invalid 2FA Code'),
            );
            return res.send(error);
          }

          const { signature, ...payload } = data;
          const signatureVerify = encryptHmac(
            'sha256',
            browser.csrf,
            hash('sha256', minifyJson(payload)).toLowerCase() +
              '|' +
              browser.browserId,
            'hex',
          );

          const updateBrowser = {
            user: user.id,
            $push: { ip: req.ip },
          };

          await this.Browser.findByIdAndUpdate(
            browser.id,
            {
              $set: updateBrowser,
              $unset: {
                csrf: undefined,
              },
            },
            { new: true, upsert: true },
          );
          if (data.signature === signatureVerify) {
            const rejectQuery: any = {
              _id: payload.withdrawId,
              process: WithdrawProcess.Process,
              withdrawType: WithdrawType.Client,
              status: WithdrawStatus.Pending,
            };
            await this.Withdraw.findOne(rejectQuery)
              .populate('bank')
              .then(async (withdraw: any) => {
                await this.Client.findOne({
                  user: withdraw.user,
                }).then(async (client) => {
                  if (client) {
                    await this.Balance.findOne({
                      user: withdraw.user,
                    }).then(async (balance) => {
                      if (balance) {
                        await this.LogType.findOne({
                          type: LogTypes.AdminDisburse,
                        }).then(async (logType) => {
                          if (logType) {
                            const newLog = new this.Log({
                              message: `${user.username} reject disburse of ${
                                client.clientName
                              } amount ${toCurrency(withdraw.amount)}`,
                              target: withdraw.id,
                              ip: req.ip,
                              type: logType.id,
                              user: withdraw.user,
                              admin: user.id,
                            });

                            await newLog.save();
                          }
                        });

                        const userRoot = await this.User.findOne({
                          role: Role.Root,
                        }).exec();
                        const rootBalance = await this.Balance.findOne({
                          user: userRoot.id,
                        }).exec();
                        var rootCredit = withdraw.fee - withdraw.feeAdmin;

                        const updateWithdraw: any = {
                          process: WithdrawProcess.Process,
                          processedBy: user.id,
                          processedDate: new Date(),
                          error: payload.reason,
                          status: WithdrawStatus.Rejected,
                        };

                        await this.Balance.findByIdAndUpdate(rootBalance.id, {
                          $inc: {
                            pending: -Number(rootCredit),
                          },
                        });

                        await this.Balance.findByIdAndUpdate(balance.id, {
                          $inc: {
                            balance: Number(withdraw.amount),
                          },
                        });

                        const newBalanceLog = new this.BalanceLog({
                          name: `system's return disburse`,
                          balanceAmount: balance.balance,
                          balanceCredit: Number(withdraw.amount),
                          type: BalanceLogType.Refund,
                          balance: balance.id,
                          withdraw: withdraw.id,
                        });

                        await newBalanceLog.save();
                        await this.Withdraw.findByIdAndUpdate(
                          withdraw.id,
                          updateWithdraw,
                        );

                        const success = response.initSuccess(200, true, true);
                        return res.send(success);
                      } else {
                        const error = response.initError(
                          404,
                          false,
                          new ErrorMessage(
                            'User balance not found for withdrawal - ' +
                              withdraw.id,
                          ),
                        );
                        return res.send(error);
                      }
                    });
                  } else {
                    const error = response.initError(
                      404,
                      false,
                      new ErrorMessage('Client not found'),
                    );
                    return res.send(error);
                  }
                });
              });
          } else {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Signature invalid'),
            );
            return res.send(error);
          }
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Please setup 2FA first'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Code must not be empty'),
        );
        return res.send(error);
      }
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getReportFilter(type: string, res: FastifyReply) {
    try {
      // await this.Transaction.updateMany(
      //   {},
      //   {
      //     $set: {
      //       provider: new Types.ObjectId('64be51c19cdd12d88be97aa7'),
      //     },
      //   },
      // );
      await this.Fee.aggregate([
        {
          $lookup: {
            from: 'providers',
            localField: 'provider',
            foreignField: '_id',
            as: 'provider',
          },
        },
        {
          $unwind: '$provider',
        },
        {
          $match: {
            'provider.code': type,
            feeType: FeeType.Transaction,
          },
        },
        {
          $lookup: {
            from: 'methods',
            localField: 'method',
            foreignField: '_id',
            as: 'method',
          },
        },
        {
          $unwind: '$method',
        },
        {
          $group: {
            _id: '$method._id',
            name: { $first: '$method.name' },
          },
        },
      ]).then(async (method) => {
        await this.Bank.find({
          type: { $in: [BankType.Cash, BankType.Ewallet] },
        })
          .select('name')
          .then(async (bank) => {
            const success = response.initSuccess(200, true, {
              cashIn: method,
              cashOut: bank,
            });
            return res.send(success);
          });
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getReport(
    query: QueryDto,
    cashIn: string,
    cashOut: string,
    offset: string,
    type: string,
    res: FastifyReply,
  ) {
    try {
      const skip = (query.page - 1) * query.limit;
      const startDate = new Date(Number(query.dateStart));
      startDate.setHours(startDate.getHours() + Number(offset));
      const endDate = new Date(Number(query.dateEnd));
      endDate.setHours(endDate.getHours() + Number(offset));

      const trxQuery: any = {
        $match: {
          'user.role': { $in: [Role.User, Role.Client] },
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
          status: {
            $in: [
              TransactionStatusType.Settled,
              TransactionStatusType.Paid,
              TransactionStatusType.Processing,
            ],
          },
          'provider.code': type,
        },
      };

      const wdQuery: any = {
        $match: {
          'user.role': { $in: [Role.Partner, Role.Client] },
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
          process: WithdrawProcess.Process,
          status: WithdrawStatus.Success,
        },
      };

      if (cashIn !== 'all') {
        trxQuery.$match.method = new Types.ObjectId(cashIn.trim());
      }

      if (cashOut !== 'all') {
        if (
          cashOut === BankType.Bank ||
          cashOut === BankType.CC ||
          cashOut === BankType.Va
        ) {
          wdQuery.$match['bank.type'] = cashOut;
        } else {
          wdQuery.$match['bank._id'] = new Types.ObjectId(cashIn.trim());
        }
      }

      const trx = await this.Transaction.aggregate([
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: '$user',
        },
        {
          $lookup: {
            from: 'providers',
            localField: 'provider',
            foreignField: '_id',
            as: 'provider',
          },
        },
        {
          $unwind: '$provider',
        },
        trxQuery,
        {
          $addFields: {
            createdAtOffset:
              query.filter === 'daily'
                ? {
                    $dateAdd: {
                      startDate: '$createdAt',
                      unit: 'hour',
                      amount: Number(offset),
                    },
                  }
                : '',
          },
        },
        {
          $densify: {
            field: query.filter === 'daily' ? 'createdAtOffset' : 'createdAt',
            range: {
              step: 1,
              unit: query.filter === 'daily' ? 'day' : 'month',
              bounds: [startDate, endDate],
            },
          },
        },
        {
          $addFields: {
            totalPartner: {
              $reduce: {
                input: '$uplineFee',
                initialValue: 0,
                in: {
                  $add: ['$$value', '$$this.amount'],
                },
              },
            },
          },
        },
        {
          $group: {
            _id: {
              $dateTrunc: {
                date:
                  query.filter === 'daily' ? '$createdAtOffset' : '$createdAt',
                unit: query.filter === 'daily' ? 'day' : 'month',
              },
            },
            totalAmount: {
              $sum: {
                $cond: [{ $not: ['$amount'] }, 0, '$amount'],
              },
            },
            margin: {
              $sum: {
                $subtract: [
                  {
                    $cond: [{ $not: ['$fee'] }, 0, '$fee'],
                  },
                  {
                    $cond: [{ $not: ['$feeAdmin'] }, 0, '$feeAdmin'],
                  },
                ],
              },
            },
            partner: {
              $sum: '$totalPartner',
            },
            qty: {
              $sum: {
                $cond: [{ $not: ['$amount'] }, 0, 1],
              },
            },
          },
        },
        {
          $sort: {
            _id: query.sortOrder === 'desc' ? -1 : 1,
          },
        },
        { $skip: skip },
        { $limit: parseInt(query.limit.toString()) },
        {
          $project: {
            _id: 0,
            date: {
              $dateToString: {
                format: query.filter === 'daily' ? '%Y-%m-%d' : '%Y-%m',
                date: '$_id',
              },
            },
            totalAmount: 1,
            qty: 1,
            margin: 1,
            partner: 1,
          },
        },
      ]);

      const wd = await this.Withdraw.aggregate([
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: '$user',
        },
        {
          $lookup: {
            from: 'banks',
            localField: 'bank',
            foreignField: '_id',
            as: 'bank',
          },
        },
        {
          $unwind: '$bank',
        },
        wdQuery,
        {
          $addFields: {
            createdAtOffset:
              query.filter === 'daily'
                ? {
                    $dateAdd: {
                      startDate: '$createdAt',
                      unit: 'hour',
                      amount: Number(offset),
                    },
                  }
                : '',
          },
        },
        {
          $densify: {
            field: query.filter === 'daily' ? 'createdAtOffset' : 'createdAt',
            range: {
              step: 1,
              unit: query.filter === 'daily' ? 'day' : 'month',
              bounds: [startDate, endDate],
            },
          },
        },
        {
          $group: {
            _id: {
              $dateTrunc: {
                date:
                  query.filter === 'daily' ? '$createdAtOffset' : '$createdAt',
                unit: query.filter === 'daily' ? 'day' : 'month',
              },
            },
            totalAmount: {
              $sum: {
                $cond: [{ $not: ['$amount'] }, 0, '$amount'],
              },
            },
            margin: {
              $sum: {
                $subtract: [
                  {
                    $cond: [{ $not: ['$fee'] }, 0, '$fee'],
                  },
                  {
                    $cond: [{ $not: ['$feeAdmin'] }, 0, '$feeAdmin'],
                  },
                ],
              },
            },
            partner: {
              $sum: {
                $add: [
                  {
                    $cond: [
                      {
                        $not: [
                          {
                            $ifNull: [
                              { $arrayElemAt: ['$uplineFee', 0] },
                              null,
                            ],
                          },
                        ],
                      },
                      { $arrayElemAt: ['$uplineFee.amount', 0] },
                      0,
                    ],
                  },
                  {
                    $cond: [
                      {
                        $not: [
                          {
                            $ifNull: [
                              { $arrayElemAt: ['$uplineFee', 1] },
                              null,
                            ],
                          },
                        ],
                      },
                      { $arrayElemAt: ['$uplineFee.amount', 1] },
                      0,
                    ],
                  },
                  {
                    $cond: [
                      {
                        $not: [
                          {
                            $ifNull: [
                              { $arrayElemAt: ['$uplineFee', 2] },
                              null,
                            ],
                          },
                        ],
                      },
                      { $arrayElemAt: ['$uplineFee.amount', 2] },
                      0,
                    ],
                  },
                ],
              },
            },
            qty: {
              $sum: {
                $cond: [{ $not: ['$amount'] }, 0, 1],
              },
            },
          },
        },
        {
          $sort: {
            _id: query.sortOrder === 'desc' ? -1 : 1,
          },
        },
        { $skip: skip },
        { $limit: parseInt(query.limit.toString()) },
        {
          $project: {
            _id: 0,
            date: {
              $dateToString: {
                format: query.filter === 'daily' ? '%Y-%m-%d' : '%Y-%m',
                date: '$_id',
              },
            },
            totalAmount: 1,
            qty: 1,
            margin: 1,
            partner: 1,
          },
        },
      ]);
      const success = response.initSuccess(200, true, {
        cashIn: trx,
        cashOut: wd,
        total:
          query.filter === 'daily'
            ? Math.ceil(
                (endDate.valueOf() - startDate.valueOf()) / (1000 * 3600 * 24),
              )
            : getMonthDifference(startDate, endDate),
      });
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getLogs(
    query: QueryDto,
    logId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };

      const logQuery: any = {
        $match: {
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
        },
      };

      if (user.role !== Role.Super) {
        logQuery.$match.admin = new Types.ObjectId(user.id);
      }

      if (logId !== 'all') {
        logQuery.$match.type = new Types.ObjectId(logId);
      }

      await this.Log.aggregate([
        logQuery,
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: {
            path: '$user',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'users',
            localField: 'admin',
            foreignField: '_id',
            as: 'admin',
          },
        },
        {
          $unwind: {
            path: '$admin',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'logtypes',
            localField: 'type',
            foreignField: '_id',
            as: 'type',
          },
        },
        {
          $unwind: {
            path: '$type',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: query.search
            ? {
                $or: [
                  {
                    'user.username': {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    message: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    ip: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    'admin.username': {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                ],
              }
            : {},
        },
        {
          $facet: {
            results: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $project: {
                  _id: 0,
                  id: '$_id',
                  message: 1,
                  ip: 1,
                  type: 1,
                  user: {
                    username: 1,
                  },
                  admin: {
                    username: 1,
                  },
                  createdAt: 1,
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((logs) => {
        const success = response.initSuccess(
          200,
          true,
          logs.length ? logs[0] : [],
        );
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getBalanceLogs(
    query: QueryDto,
    logTypeName: string,
    res: FastifyReply,
  ) {
    try {
      await this.User.findOne({
        role: Role.Root,
      }).then(async (userRoot) => {
        await this.Balance.findOne({ user: userRoot.id }).then(
          async (balance) => {
            const skip = (query.page - 1) * query.limit;
            const sortOptions = {
              createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
              accessFrom: {},
            };

            if (logTypeName === BalanceLogType.In) {
              sortOptions.accessFrom['transaction.accessFrom'] =
                query.sortOrder === 'asc' ? 1 : -1;
            } else if (logTypeName === BalanceLogType.Out) {
              sortOptions.accessFrom['withdraw.accessFrom'] =
                query.sortOrder === 'asc' ? 1 : -1;
            }

            const balanceLogQuery: any = {
              $match: {
                balance: new Types.ObjectId(balance.id),
                createdAt: {
                  $gte: new Date(Number(query.dateStart)),
                  $lte: new Date(Number(query.dateEnd)),
                },
              },
            };

            if (logTypeName !== 'all') {
              balanceLogQuery.$match.type = logTypeName;
            }

            await this.BalanceLog.aggregate([
              balanceLogQuery,
              {
                $lookup: {
                  from: 'transactions',
                  localField: 'transaction',
                  foreignField: '_id',
                  as: 'transaction',
                },
              },
              {
                $unwind: {
                  path: '$transaction',
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $lookup: {
                  from: 'withdraws',
                  localField: 'withdraw',
                  foreignField: '_id',
                  as: 'withdraw',
                },
              },
              {
                $unwind: {
                  path: '$withdraw',
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $match: query.search
                  ? {
                      $or: [
                        {
                          name: {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                        {
                          'transaction.transactionId': {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                        {
                          'transaction.orderId': {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                        {
                          'transaction.refId': {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                        {
                          'transaction.clientRef': {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                        {
                          'transaction.accessFrom': {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                        {
                          'withdraw.withdrawId': {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                        {
                          'withdraw.orderId': {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                        {
                          'withdraw.inquiryReff': {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                        {
                          'withdraw.clientRef': {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                        {
                          'withdraw.accessFrom': {
                            $regex: new RegExp(query.search.trim(), 'i'),
                          },
                        },
                      ],
                    }
                  : {},
              },
              {
                $facet: {
                  results: [
                    {
                      $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
                    },
                    { $skip: skip },
                    { $limit: parseInt(query.limit.toString()) },
                    {
                      $project: {
                        _id: 0,
                        id: '$_id',
                        name: 1,
                        balanceAmount: 1,
                        balanceCredit: 1,
                        pgAmount: 1,
                        pgCredit: 1,
                        dfAmount: 1,
                        type: 1,
                        transaction: {
                          id: '$transaction._id',
                          accessFrom: '$transaction.accessFrom',
                          user: '$transaction.user',
                          isClient: {
                            $cond: [
                              { $ifNull: ['$transaction.clientRef', false] },
                              true,
                              false,
                            ],
                          },
                        },
                        withdraw: {
                          id: '$withdraw._id',
                          accessFrom: '$withdraw.accessFrom',
                        },
                        createdAt: 1,
                      },
                    },
                  ],
                  count: [{ $count: 'total' }],
                },
              },
              {
                $project: {
                  results: 1,
                  total: {
                    $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0],
                  }, // extract total from $count stage
                },
              },
            ]).then((logs) => {
              const success = response.initSuccess(
                200,
                true,
                logs.length ? logs[0] : [],
              );
              return res.send(success);
            });
          },
        );
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getMethod(res: FastifyReply) {
    try {
      this.Method.find().then((method) => {
        const success = response.initSuccess(200, true, method);
        return res.send(success);
      });
    } catch (err) {
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async createMethod(
    data: CreateMethodDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        data.name +
          '|' +
          data.code +
          '|' +
          data.type +
          '|' +
          data.path +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.Method.findOne({
          $or: [
            {
              name: {
                $regex: new RegExp(`^${data.name.trim()}$`, 'i'),
              },
            },
            {
              code: {
                $regex: new RegExp(`^${data.code.trim()}$`, 'i'),
              },
            },
          ],
        }).then(async (method) => {
          if (method) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Method already exist'),
            );
            return res.send(error);
          } else {
            await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
              async (logType) => {
                if (logType) {
                  const base64Data = data.img.split('base64,')[1];
                  const binaryData = Buffer.from(base64Data, 'base64');

                  const newMethod = new this.Method({
                    name: data.name,
                    code: data.code,
                    type: data.type,
                    path: data.path,
                  });

                  const saved = await newMethod.save();

                  const newLog = new this.Log({
                    message: `${user.username} create method ${saved.name}`,
                    target: saved.id,
                    ip: req.ip,
                    type: logType.id,
                    admin: user.id,
                  });

                  await newLog.save();

                  const path = './images/method/';
                  fs.mkdirSync(path, { recursive: true });
                  const imgPath =
                    path + saved.code.toLowerCase() + '-' + saved.id + '.webp';

                  await this.sharpService
                    .edit(binaryData)
                    .webp({ lossless: true })
                    .toFile(imgPath)
                    .then(async (_info) => {
                      saved.img = imgPath.substring(1);
                      await saved.save();

                      const success = response.initSuccess(200, true, true);
                      return res.send(success);
                    })
                    .catch(async () => {
                      await this.Method.findByIdAndDelete(saved.id);

                      const error = response.initError(
                        400,
                        false,
                        new ErrorMessage(
                          'Failed to save image, please choose another image',
                        ),
                      );
                      return res.send(error);
                    });
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Log data not found'),
                  );
                  return res.send(error);
                }
              },
            );
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateMethod(
    data: UpdateMethodDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        data.method + '|' + browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        if (data.name || data.code) {
          await this.Method.findOne({
            $or: [
              data.name
                ? {
                    name: {
                      $regex: new RegExp(`^${data.name.trim()}$`, 'i'),
                    },
                  }
                : {},
              data.code
                ? {
                    code: {
                      $regex: new RegExp(`^${data.code.trim()}$`, 'i'),
                    },
                  }
                : {},
            ],
          }).then(async (method) => {
            if (method) {
              const error = response.initError(
                403,
                false,
                new ErrorMessage('Method name or code already exist'),
              );
              return res.send(error);
            }
          });
        }
        await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
          async (logType) => {
            if (logType) {
              await this.Method.findById(data.method).then(async (method) => {
                if (method) {
                  if (data.name) {
                    const newLog = new this.Log({
                      message: `${user.username} update method ${method.name} system NAME to ${data.name}`,
                      target: method.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                    method.name = data.name;
                  }
                  if (data.code) {
                    const newLog = new this.Log({
                      message: `${user.username} update method ${method.name} system CODE to ${data.code}`,
                      target: method.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                    method.code = data.code;
                  }
                  if (data.type) {
                    const newLog = new this.Log({
                      message: `${user.username} update method ${method.name} system TYPE to ${data.type}`,
                      target: method.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                    method.type = data.type;
                  }
                  if (data.path) {
                    const newLog = new this.Log({
                      message: `${user.username} update method ${method.name} system PATH to ${data.path}`,
                      target: method.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                    method.path = data.path;
                  }
                  if (data.min) {
                    const newLog = new this.Log({
                      message: `${user.username} update method ${method.name} system MIN to ${data.min}`,
                      target: method.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                    method.min = data.min;
                  }
                  if (data.max) {
                    const newLog = new this.Log({
                      message: `${user.username} update method ${method.name} system MAX to ${data.max}`,
                      target: method.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                    method.max = data.max;
                  }
                  if (data.isActive !== undefined) {
                    const newLog = new this.Log({
                      message: `${user.username} update method ${
                        method.name
                      } root to ${data.isActive ? 'Active' : 'Inactive'}`,
                      target: method.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                    method.isActive = data.isActive;
                  }
                  if (data.img) {
                    const newLog = new this.Log({
                      message: `${user.username} update method ${method.name} system IMAGE`,
                      target: method.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                    const base64Data = data.img.replace(/^data:.+;base64,/, '');
                    const binaryData = Buffer.from(base64Data, 'base64');

                    const path = './images/method/';
                    fs.mkdirSync(path, { recursive: true });
                    const imgPath =
                      path +
                      method.code.toLowerCase() +
                      '-' +
                      method.id +
                      '.webp';

                    await this.sharpService
                      .edit(binaryData)
                      .webp({ lossless: true })
                      .toFile(imgPath)
                      .then((_info) => {
                        method.img = imgPath.substring(1);
                      })
                      .catch((err) => {
                        console.log(err);
                        const error = response.initError(
                          400,
                          false,
                          new ErrorMessage('Failed to save image'),
                        );
                        return res.send(error);
                      });
                  }

                  await method.save();
                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const error = response.initError(
                    403,
                    false,
                    new ErrorMessage('Method not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Log data not found'),
              );
              return res.send(error);
            }
          },
        );
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async deleteMethod(id: string, req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      await this.Method.findById(id).then(async (method) => {
        if (method) {
          await this.Fee.findOne({ method: method.id }).then(async (fee) => {
            fs.unlink(`.${method.img}`, async (err) => {
              if (err) {
                console.error(err);
                const error = response.initError(
                  500,
                  false,
                  new ErrorMessage('Cant delete Image'),
                );
                return res.send(error);
              } else {
                if (fee) {
                  await this.Fee.findByIdAndDelete(fee.id);
                }

                await this.Method.findByIdAndDelete(method.id);

                await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
                  async (logType) => {
                    if (logType) {
                      const newLog = new this.Log({
                        message: `${user.username} delete method ${method.name}`,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }
                    const success = response.initSuccess(200, true, true);
                    return res.send(success);
                  },
                );
              }
            });
          });
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Method not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getMethodFee(type: string, res: FastifyReply) {
    try {
      if (type === 'root') {
        await this.Fee.aggregate([
          {
            $match: {
              feeType: FeeType.Transaction,
            },
          },
          {
            $lookup: {
              from: 'users',
              localField: 'user',
              foreignField: '_id',
              as: 'user',
            },
          },
          { $unwind: '$user' },
          { $match: { 'user.role': Role.Root } },
          { $unset: 'user' },
          {
            $lookup: {
              from: 'providers',
              let: { providerId: { $toObjectId: '$provider' } },
              pipeline: [
                {
                  $lookup: {
                    from: 'users',
                    localField: 'user',
                    foreignField: '_id',
                    as: 'user',
                  },
                },
                {
                  $unwind: {
                    path: '$user',
                    preserveNullAndEmptyArrays: true,
                  },
                },
                {
                  $match: {
                    $expr: {
                      $and: [
                        { $eq: ['$_id', '$$providerId'] },
                        { $eq: ['$user.role', Role.Root] },
                      ],
                    },
                  },
                },
                {
                  $project: {
                    _id: 0,
                    providerId: '$_id',
                    name: 1,
                    merchant: 1,
                  },
                },
              ],
              as: 'provider',
            },
          },
          {
            $unwind: {
              path: '$provider',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $project: {
              feeType: 0,
              lp: 0,
              createdAt: 0,
              updatedAt: 0,
              __v: 0,
            },
          },
        ]).then(async (fee) => {
          await this.ValueType.find()
            .select('_id name')
            .then((valueType) => {
              const success = response.initSuccess(200, true, {
                fee,
                valueType,
              });
              return res.send(success);
            });
        });
      } else {
        await this.Fee.aggregate([
          {
            $match: {
              feeType: FeeType.Transaction,
            },
          },
          {
            $lookup: {
              from: 'users',
              localField: 'user',
              foreignField: '_id',
              as: 'user',
            },
          },
          { $unwind: '$user' },
          { $match: { 'user.role': Role.Root } },
          { $unset: 'user' },
          {
            $project: {
              method: 1,
              lp: 1,
              isActive: 1,
            },
          },
        ]).then(async (fee) => {
          const success = response.initSuccess(200, true, {
            fee,
          });
          return res.send(success);
        });
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateMethodFee(
    data: UpdateMethodFeeRootDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        data.method + '|' + browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.Method.findById(data.method).then(async (method) => {
          if (method) {
            await this.User.findOne({ role: Role.Root }).then(async (root) => {
              await this.Fee.findOne({
                method: method.id,
                user: root.id,
              }).then(async (fee) => {
                var feeId: string, providerName: string;
                if (fee) {
                  if (data.isRoot) {
                    if ((data.fixed || data.percentage) && data.type) {
                      if (data.fixed && data.percentage) {
                        fee.fixed = data.fixed;
                        fee.percentage = data.percentage;
                      } else if (data.fixed) {
                        fee.fixed = data.fixed;
                        fee.percentage = 0;
                      } else if (data.percentage) {
                        fee.fixed = 0;
                        fee.percentage = data.percentage;
                      }
                      fee.type = new Types.ObjectId(data.type);
                    }
                    if (data.isActive !== undefined) {
                      fee.isActive = data.isActive;
                    }
                    if (data.onClient !== undefined) {
                      fee.onClient = data.onClient;
                    }
                    if (data.delay) {
                      fee.delay = data.delay;
                    }
                    if (data.providerId) {
                      const provider: any = await this.Provider.findById(
                        data.providerId,
                      )
                        .populate('user')
                        .exec();
                      if (provider.user.role === Role.Root) {
                        fee.provider = new Types.ObjectId(data.providerId);
                        providerName = provider.name;
                      }
                    }
                  } else {
                    var temp = '';
                    if (data.fixed) {
                      temp = toCurrency(Number(data.fixed));
                    }
                    if (data.percentage) {
                      temp += `${data.percentage}%`;
                    }

                    fee.lp = temp;
                  }

                  await fee.save();
                  feeId = fee.id;
                } else {
                  if (data.isRoot) {
                    const newFee = new this.Fee({
                      delay: data.delay,
                      fixed: data.fixed,
                      percentage: data.percentage,
                      onClient:
                        data.onClient !== undefined ? data.onClient : true,
                      feeType: FeeType.Transaction,
                      method: method.id,
                      type: new Types.ObjectId(data.type),
                      user: root.id,
                      isActive:
                        data.isActive !== undefined ? data.isActive : true,
                    });

                    const saved = await newFee.save();
                    feeId = saved.id;

                    await this.User.find({
                      role: Role.Client,
                    }).then(async (clients) => {
                      if (clients.length) {
                        for (const client of clients) {
                          const existingFee = await this.Fee.findOne({
                            user: client.id,
                            method: method.id,
                            feeType: FeeType.Transaction,
                          });
                          if (!existingFee) {
                            const newClientFee = new this.Fee({
                              delay: data.delay,
                              fixed: data.fixed,
                              percentage: data.percentage,
                              onClient:
                                data.onClient !== undefined
                                  ? data.onClient
                                  : true,
                              feeType: FeeType.Transaction,
                              method: method.id,
                              type: new Types.ObjectId(data.type),
                              user: client.id,
                              isActive:
                                data.isActive !== undefined
                                  ? data.isActive
                                  : true,
                            });

                            await newClientFee.save();
                          }
                        }
                      }
                    });
                  } else {
                    var temp = '';
                    if (data.fixed) {
                      temp = toCurrency(Number(data.fixed));
                    }
                    if (data.percentage) {
                      temp += `${data.percentage}%`;
                    }

                    const newFee = new this.Fee({
                      lp: temp,
                      feeType: FeeType.Transaction,
                      method: method.id,
                      user: root.id,
                      isActive:
                        data.isActive !== undefined ? data.isActive : true,
                    });

                    const saved = await newFee.save();
                    feeId = saved.id;
                  }
                }

                await this.LogType.findOne({
                  type: LogTypes.AdminUpdate,
                }).then(async (logType) => {
                  if (logType) {
                    if ((data.fixed || data.percentage) && data.type) {
                      const newLog = new this.Log({
                        message: `${user.username} update ${method.name} ${
                          data.isRoot ? 'system' : 'landing page'
                        } to ${
                          data.fixed && data.percentage
                            ? `${data.fixed} + ${data.percentage}%`
                            : data.fixed ?? `${data.percentage}%`
                        }`,
                        target: feeId,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }
                    if (data.isActive !== undefined) {
                      const newLog = new this.Log({
                        message: `${user.username} update ${method.name} ${
                          data.isRoot ? 'system' : 'landing page'
                        } to ${data.isActive ? 'Active' : 'Inactive'}`,
                        target: feeId,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }
                    if (data.onClient !== undefined) {
                      const newLog = new this.Log({
                        message: `${user.username} update ${
                          method.name
                        } system to ${
                          data.onClient
                            ? 'Charged on us'
                            : 'Charged to customer'
                        }`,
                        target: feeId,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }
                    if (data.delay) {
                      const newLog = new this.Log({
                        message: `${user.username} update ${method.name} system to ${data.delay} day delay`,
                        target: feeId,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }
                    if (data.providerId && providerName) {
                      const newLog = new this.Log({
                        message: `${user.username} update ${method.name} system provider to ${providerName}`,
                        target: feeId,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();

                      // if (data.providerMerchant) {
                      //   const newLog = new this.Log({
                      //     message: `${user.username} update ROOT provider ${providerName} merchant`,
                      //     target: data.providerId,
                      //     ip: req.ip,
                      //     type: logType.id,
                      //     admin: user.id,
                      //   });

                      //   await newLog.save();
                      // }
                    }
                  }
                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                });
              });
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Method not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDisburseChannel(param: string, query: QueryDto, res: FastifyReply) {
    try {
      if (Object.values(BankType).includes(param as BankType)) {
        const skip = (query.page - 1) * query.limit;
        const sortOptions = {
          name: { name: query.sortOrder === 'asc' ? 1 : -1 },
          code: { code: query.sortOrder === 'asc' ? 1 : -1 },
          isActive: { isActive: query.sortOrder === 'asc' ? 1 : -1 },
        };
        const bankQuery = {
          type: param,
          $or: [
            { name: { $regex: query.search.trim(), $options: 'i' } },
            { code: { $regex: query.search.trim(), $options: 'i' } },
          ],
        };
        await this.Bank.find(bankQuery)
          .sort(sortOptions[query.sortBy] || sortOptions.name)
          .skip(skip)
          .limit(query.limit)
          .select('name code img isActive min max multiple')
          .then(async (results) => {
            const total = await this.Bank.countDocuments(bankQuery);
            const resultObj: any = {
              results,
              total,
            };
            if (param === BankType.Bank) {
              const userRoot = await this.User.findOne({
                role: Role.Root,
              });
              resultObj.valueType = await this.ValueType.find().select(
                '_id name',
              );
              resultObj.fee = await this.Fee.findOne({
                feeType: FeeType.Bank,
                user: userRoot.id,
              });
            }
            const success = response.initSuccess(200, true, resultObj);
            return res.send(success);
          });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Param invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateDisburseChannel(
    param: string,
    data: UpdateBankDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (Object.values(BankType).includes(param as BankType)) {
        const { user, browser } = req.user;
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };

        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (data.signature === signatureVerify) {
          await this.LogType.findOne({
            type: LogTypes.AdminUpdate,
          }).then(async (logType) => {
            if (logType) {
              if (data.bankId === BankType.Bank) {
                if ((data.fixed || data.percentage) && data.type) {
                  const update: any = {};

                  if (data.min) {
                    update.min = data.min;
                    const newLog = new this.Log({
                      message: `${user.username} update Bank Disburse system MIN to ${data.min}`,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                  }

                  if (data.max) {
                    update.max = data.max;
                    const newLog = new this.Log({
                      message: `${user.username} update Bank Disburse system MAX to ${data.max}`,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                  }

                  await this.Bank.updateMany(
                    {
                      type: param,
                    },
                    update,
                  );

                  const userRoot = await this.User.findOne({
                    role: Role.Root,
                  });
                  await this.Fee.findOne({
                    feeType: FeeType.Bank,
                    user: userRoot.id,
                  }).then(async (fee) => {
                    var feeId = '';
                    if (fee) {
                      if (data.fixed && data.percentage) {
                        fee.percentage = data.percentage;
                        fee.fixed = data.fixed;
                      } else if (data.fixed) {
                        fee.fixed = data.fixed;
                        fee.percentage = 0;
                      } else if (data.percentage) {
                        fee.percentage = data.percentage;
                        fee.fixed = 0;
                      }
                      fee.type = new Types.ObjectId(data.type);
                      await fee.save();
                      feeId = fee.id;
                    } else {
                      const newFee = new this.Fee({
                        fixed: data.fixed,
                        percentage: data.percentage,
                        feeType: FeeType.Bank,
                        type: new Types.ObjectId(data.type),
                        user: userRoot.id,
                      });

                      const feeSaved = await newFee.save();
                      feeId = feeSaved.id;
                    }
                    const newLog = new this.Log({
                      message: `${
                        user.username
                      } update Bank Disburse Fee system to ${
                        data.fixed && data.percentage
                          ? `${data.fixed} + ${data.percentage}%`
                          : data.fixed ?? `${data.percentage}%`
                      }`,
                      target: feeId,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                  });

                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                }
              } else {
                await this.Bank.findOne({
                  _id: new Types.ObjectId(data.bankId),
                  type: param,
                }).then(async (bank) => {
                  if (bank) {
                    if (data.name) {
                      bank.name = data.name;
                      const newLog = new this.Log({
                        message: `${user.username} update ${bank.name} NAME to ${data.name}`,
                        target: bank.id,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }

                    if (data.min) {
                      bank.min = data.min;
                      const newLog = new this.Log({
                        message: `${user.username} update ${bank.name} system MIN to ${data.min}`,
                        target: bank.id,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }

                    if (data.max) {
                      bank.max = data.max;
                      const newLog = new this.Log({
                        message: `${user.username} update ${bank.name} system MAX to ${data.max}`,
                        target: bank.id,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }

                    if (data.multiple) {
                      bank.multiple = data.multiple;
                      const newLog = new this.Log({
                        message: `${user.username} update ${bank.name} system MULTIPLE to ${data.multiple}`,
                        target: bank.id,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }

                    if (data.isActive !== undefined) {
                      bank.isActive = data.isActive;
                      const newLog = new this.Log({
                        message: `${user.username} update ${
                          bank.name
                        } system to ${data.isActive ? 'Active' : 'Inactive'}`,
                        target: bank.id,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }

                    await bank.save();

                    const success = response.initSuccess(200, true, true);
                    return res.send(success);
                  } else {
                    const error = response.initError(
                      404,
                      false,
                      new ErrorMessage('Bank not found'),
                    );
                    return res.send(error);
                  }
                });
              }
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Log not found'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Param invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async deleteDisburseChannel(
    param: string,
    data: UpdateBankDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (Object.values(BankType).includes(param as BankType)) {
        const { user, browser } = req.user;
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };

        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (data.signature === signatureVerify) {
          await this.Bank.findOne({
            _id: new Types.ObjectId(data.bankId),
            type: param,
          }).then(async (bank) => {
            if (bank) {
              await this.LogType.findOne({
                type: LogTypes.AdminUpdate,
              }).then(async (logType) => {
                if (logType) {
                  await this.Bank.findByIdAndDelete(bank.id);

                  const newLog = new this.Log({
                    message: `${user.username} DELETE ${bank.name} system`,
                    target: bank.id,
                    ip: req.ip,
                    type: logType.id,
                    admin: user.id,
                  });

                  await newLog.save();

                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Log not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Bank not found'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Param invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async actionDisburseChannelBank(
    data: ActionBankDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.Bank.findById(data.bankId).then(async (bank) => {
          if (bank && bank.type === BankType.Bank) {
            await this.Bank.findOne({
              code: bank.code,
              type:
                data.moveTo === BankActionType.VA ? BankType.Va : BankType.CC,
            }).then(async (bankFound) => {
              if (bankFound) {
                const error = response.initError(
                  403,
                  false,
                  new ErrorMessage('Already exist'),
                );
                return res.send(error);
              } else {
                await this.LogType.findOne({
                  type: LogTypes.AdminUpdate,
                }).then(async (logType) => {
                  if (logType) {
                    const newBank = new this.Bank({
                      name: bank.name,
                      code: bank.code,
                      img: bank.img,
                      type:
                        data.moveTo === BankActionType.VA
                          ? BankType.Va
                          : BankType.CC,
                    });

                    const saved = await newBank.save();

                    const newLog = new this.Log({
                      message: `${user.username} add ${bank.name} to ${
                        data.moveTo === BankActionType.VA
                          ? BankType.Va.toUpperCase()
                          : BankType.CC.toUpperCase()
                      } list`,
                      target: saved.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();

                    const success = response.initSuccess(200, true, true);
                    return res.send(success);
                  } else {
                    const error = response.initError(
                      404,
                      false,
                      new ErrorMessage('Log not found'),
                    );
                    return res.send(error);
                  }
                });
              }
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Bank not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async addDisburseChannelCash(
    data: AddDisburseCashDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.Method.findOne({
          _id: new Types.ObjectId(data.retailId),
          type: MethodType.Retail,
        }).then(async (retail) => {
          if (retail) {
            await this.Bank.findOne({
              code: retail.code,
              type: BankType.Cash,
            }).then(async (bankFound) => {
              if (bankFound) {
                const error = response.initError(
                  403,
                  false,
                  new ErrorMessage('Already exist'),
                );
                return res.send(error);
              } else {
                await this.LogType.findOne({
                  type: LogTypes.AdminUpdate,
                }).then(async (logType) => {
                  if (logType) {
                    if (
                      data.min % data.multiple === 0 &&
                      data.max % data.multiple === 0
                    ) {
                      const newBank = new this.Bank({
                        name: retail.name,
                        code: retail.code,
                        img: retail.img,
                        min: data.min,
                        max: data.max,
                        multiple: data.multiple,
                        type: BankType.Cash,
                      });

                      const saved = await newBank.save();

                      const newLog = new this.Log({
                        message: `${user.username} add new CASH CHANNEL ${newBank.name}`,
                        target: saved.id,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();

                      const success = response.initSuccess(200, true, true);
                      return res.send(success);
                    } else {
                      const error = response.initError(
                        403,
                        false,
                        new ErrorMessage(
                          'Min and Max value must be a multiple of the Multiple value.',
                        ),
                      );
                      return res.send(error);
                    }
                  } else {
                    const error = response.initError(
                      404,
                      false,
                      new ErrorMessage('Log not found'),
                    );
                    return res.send(error);
                  }
                });
              }
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Bank not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getProduct(res: FastifyReply) {
    try {
      this.Category.aggregate([
        {
          $match: {
            isActive: true,
          },
        },
        {
          $lookup: {
            from: 'brands',
            let: { catId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $eq: ['$category', '$$catId'],
                  },
                  isActive: true,
                },
              },
              {
                $lookup: {
                  from: 'brandtypes',
                  let: { brandId: '$_id' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $eq: ['$brand', '$$brandId'],
                        },
                        isActive: true,
                      },
                    },
                    {
                      $addFields: {
                        brandTypeId: '$_id',
                      },
                    },
                    {
                      $project: {
                        _id: 0,
                        brand: 0,
                        createdAt: 0,
                        updatedAt: 0,
                        __v: 0,
                      },
                    },
                  ],
                  as: 'brandTypes',
                },
              },
              {
                $addFields: {
                  brandId: '$_id',
                },
              },
              {
                $project: {
                  _id: 0,
                  category: 0,
                  createdAt: 0,
                  updatedAt: 0,
                  __v: 0,
                },
              },
            ],
            as: 'brands',
          },
        },
      ]).then(async (product) => {
        const success = response.initSuccess(200, true, product);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateBrand(
    data: UpdateBrandDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        data.brandId + '|' + browser.browserId,
        'hex',
      );
      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
          async (logType) => {
            if (logType) {
              await this.Brand.findById(data.brandId).then(async (brand) => {
                if (brand) {
                  if (data.img) {
                    const newLog = new this.Log({
                      message: `${user.username} update Brand ${brand.brandName} system IMAGE`,
                      target: brand.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                    const base64Data = data.img.replace(/^data:.+;base64,/, '');
                    const binaryData = Buffer.from(base64Data, 'base64');

                    const path = './images/brand/';
                    fs.mkdirSync(path, { recursive: true });
                    const imgPath =
                      path +
                      generateRandomNumber(10) +
                      '-' +
                      brand.id +
                      '.webp';

                    await this.sharpService
                      .edit(binaryData)
                      .webp({ lossless: true })
                      .toFile(imgPath)
                      .then((_info) => {
                        brand.brandImg = imgPath.substring(1);
                      })
                      .catch((err) => {
                        const error = response.initError(
                          400,
                          false,
                          new ErrorMessage('Failed to save image'),
                        );
                        return res.send(error);
                      });

                    await brand.save();
                  }
                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Brand not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Method not found'),
              );
              return res.send(error);
            }
          },
        );
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateBrandType(
    data: UpdateBrandTypeDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        data.form + '|' + data.brandTypeId + '|' + browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
          async (logType) => {
            if (logType) {
              await this.BrandType.findById(data.brandTypeId)
                .populate('brand')
                .then(async (brandType) => {
                  if (brandType) {
                    brandType.form = data.form;
                    const newLog = new this.Log({
                      message: `${user.username} update Brand Type ${brandType.name} of ${brandType.brand['brandName']} system FORM`,
                      target: brandType.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                    if (data.servers) {
                      brandType.servers = data.servers;
                      const newLog = new this.Log({
                        message: `${user.username} update Brand Type ${brandType.name} of ${brandType.brand['brandName']} system SERVERS`,
                        target: brandType.id,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }
                    if (data.code) {
                      brandType.code = data.code;
                      const newLog = new this.Log({
                        message: `${user.username} update Brand Type ${brandType.name} of ${brandType.brand['brandName']} system CODE`,
                        target: brandType.id,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    }
                    await brandType.save();
                    const success = response.initSuccess(200, true, true);
                    return res.send(success);
                  } else {
                    const error = response.initError(
                      404,
                      false,
                      new ErrorMessage('Brand not found'),
                    );
                    return res.send(error);
                  }
                });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Method not found'),
              );
              return res.send(error);
            }
          },
        );
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async get2FaStatus(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      const success = response.initSuccess(200, true, user.isVerified ?? false);
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async get2FaSetup(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      if (user.secret2Fa && user.isVerified) {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('2FA has already been set up'),
        );
        return res.send(error);
      } else {
        const secret = authenticator.generateSecret();
        const otpAuth = authenticator.keyuri(user.username, 'NiagaPay', secret);

        const keyEnc = encrypt(
          process.env.ENCRYPT_ALG,
          hash('sha256', user.id).substring(0, 32),
          hash('sha256', user.id + user.username).substring(0, 16),
          secret,
        );

        user.secret2Fa = keyEnc;
        await user.save();

        const success = response.initSuccess(200, true, {
          auth: otpAuth,
          secret: secret,
        });
        return res.send(success);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async get2FaVerify(
    data: Verify2FaDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        if (user.secret2Fa && !user.isVerified) {
          const keyDec = decrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', user.id).substring(0, 32),
            hash('sha256', user.id + user.username).substring(0, 16),
            user.secret2Fa,
          );

          if (!authenticator.check(data.code, keyDec)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Invalid 2FA Code'),
            );
            return res.send(error);
          }

          await this.LogType.findOne({
            type: LogTypes.AdminUpdate,
          }).then(async (logType) => {
            if (logType) {
              const newLog = new this.Log({
                message: `${user.username} verify 2FA setup`,
                ip: req.ip,
                type: logType.id,
                admin: user.id,
              });

              await newLog.save();
            }
          });

          user.isVerified = true;
          await user.save();

          const success = response.initSuccess(200, true, true);
          return res.send(success);
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Data mismatch!'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature Invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClient(query: QueryDto, res: FastifyReply) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        clientId: { 'client.clientId': query.sortOrder === 'asc' ? 1 : -1 },
        phone: { phone: query.sortOrder === 'asc' ? 1 : -1 },
        username: { username: query.sortOrder === 'asc' ? 1 : -1 },
        company: { company: query.sortOrder === 'asc' ? 1 : -1 },
        email: { email: query.sortOrder === 'asc' ? 1 : -1 },
        name: { 'client.name': query.sortOrder === 'asc' ? 1 : -1 },
        balance: { 'balance.balance': query.sortOrder === 'asc' ? 1 : -1 },
        pending: { 'balance.pending': query.sortOrder === 'asc' ? 1 : -1 },
        lastActiveDate: { lastActiveDate: query.sortOrder === 'asc' ? 1 : -1 },
      };
      await this.User.aggregate([
        {
          $match: { role: Role.Client, isDeleted: false },
        },
        {
          $lookup: {
            from: 'clients',
            localField: '_id',
            foreignField: 'user',
            as: 'client',
          },
        },
        {
          $unwind: {
            path: '$client',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: query.search
            ? {
                $or: [
                  {
                    username: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    company: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    email: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    phone: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    'client.clientId': {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    'client.clientName': {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                ],
              }
            : {},
        },
        {
          $facet: {
            results: [
              {
                $lookup: {
                  from: 'transactions',
                  let: { userId: '$_id' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $and: [
                            { $eq: ['$user', '$$userId'] },
                            { status: TransactionStatusType.Paid },
                          ],
                        },
                      },
                    },
                    {
                      $sort: { paidTime: -1 },
                    },
                    {
                      $limit: 1,
                    },
                    {
                      $project: { paidTime: 1 },
                    },
                  ],
                  as: 'transaction',
                },
              },
              {
                $unwind: {
                  path: '$transaction',
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $lookup: {
                  from: 'withdraws',
                  let: { userId: '$_id' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $and: [
                            { $eq: ['$user', '$$userId'] },
                            { status: TransactionStatusType.Paid },
                          ],
                        },
                      },
                    },
                    {
                      $sort: { processedDate: -1 },
                    },
                    {
                      $limit: 1,
                    },
                    {
                      $project: { processedDate: 1 },
                    },
                  ],
                  as: 'withdraw',
                },
              },
              {
                $unwind: {
                  path: '$withdraw',
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $addFields: {
                  lastActiveDate: {
                    $let: {
                      vars: {
                        lastTransaction: {
                          $ifNull: ['$transaction.paidTime', null],
                        },
                        lastWithdrawal: {
                          $ifNull: ['$withdraw.processedDate', null],
                        },
                      },
                      in: {
                        $cond: {
                          if: {
                            $or: [
                              { $eq: ['$$lastTransaction', null] },
                              { $eq: ['$$lastWithdrawal', null] },
                            ],
                          },
                          then: '$createdAt',
                          else: {
                            $cond: {
                              if: {
                                $gte: ['$$lastTransaction', '$$lastWithdrawal'],
                              },
                              then: '$$lastTransaction',
                              else: '$$lastWithdrawal',
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              {
                $lookup: {
                  from: 'balances',
                  localField: '_id',
                  foreignField: 'user',
                  as: 'balance',
                },
              },
              {
                $unwind: {
                  path: '$balance',
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $sort: sortOptions[query.sortBy] || sortOptions.name,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $project: {
                  _id: '$_id',
                  username: 1,
                  company: 1,
                  email: 1,
                  phone: 1,
                  isBlocked: 1,
                  balance: '$balance.balance',
                  pending: '$balance.pending',
                  clientName: '$client.clientName',
                  clientId: '$client.clientId',
                  lastActiveDate: 1,
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((user) => {
        const success = response.initSuccess(200, true, user[0]);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async createClient(
    data: CreateClientDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.User.findOne({
          $or: [
            {
              username: { $regex: new RegExp(data.username.trim(), 'i') },
            },
            {
              email: { $regex: new RegExp(data.email.trim(), 'i') },
            },
            {
              phone: { $regex: new RegExp(data.phone.trim(), 'i') },
            },
          ],
        }).then(async (userFound) => {
          if (userFound) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Username exist'),
            );
            return res.send(error);
          } else {
            const newUser = new this.User({
              username: data.username,
              company: data.company,
              email: data.email,
              phone: data.phone,
              pass: await encryptPass(data.pass),
              role: Role.Client,
            });

            if (data.partnerId) {
              newUser.upline = new Types.ObjectId(data.partnerId);
            }

            const savedUser = await newUser.save();

            const uuid = crypto.randomUUID();
            const buffer = Buffer.from(uuid.replace(/-/g, ''), 'hex');
            const clientId = buffer
              .toString('base64')
              .replace(/\+/g, '0')
              .replace(/\//g, '0')
              .replace(/=/g, '');

            const newClient = new this.Client({
              clientName: data.clientName,
              clientId: clientId,
              user: savedUser.id,
              limit: data.limit,
            });

            const savedClient = await newClient.save();

            const newDevClient = new this.DevClient({
              clientName: data.clientName,
              clientId: clientId,
              user: savedUser.id,
              limit: 50000000,
            });

            await newDevClient.save();

            const newBalance = new this.Balance({
              user: savedUser.id,
            });

            await newBalance.save();

            const newDevBalance = new this.DevBalance({
              user: savedUser.id,
            });

            await newDevBalance.save();

            await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
              async (logType) => {
                if (logType) {
                  const newLog = new this.Log({
                    message: `${user.username} create new client ${data.clientName}`,
                    target: savedClient.id,
                    ip: req.ip,
                    type: logType.id,
                    user: savedUser.id,
                    admin: user.id,
                  });

                  await newLog.save();
                }

                await this.User.findOne({
                  role: Role.Root,
                }).then(async (root) => {
                  await this.Fee.find({
                    user: root.id,
                    feeType: FeeType.Transaction,
                  }).then(async (fees) => {
                    for (const fee of fees) {
                      const newFee = new this.Fee({
                        feeType: FeeType.Transaction,
                        method: fee.method,
                        type: fee.type,
                        user: savedUser.id,
                        delay: fee.delay,
                        provider: fee.provider,
                      });

                      if (fee.percentage) {
                        newFee.percentage = fee.percentage;
                      }
                      if (fee.fixed) {
                        newFee.fixed = fee.fixed;
                      }

                      await newFee.save();
                      // if (fee.feeType === FeeType.Ewallet) {
                      //   const newFee = new this.Fee({
                      //     feeType: FeeType.Ewallet,
                      //     bank: fee.bank,
                      //     type: fee.type,
                      //     user: savedUser.id,
                      //   });

                      //   if (fee.percentage) {
                      //     newFee.percentage = fee.percentage;
                      //   }
                      //   if (fee.fixed) {
                      //     newFee.fixed = fee.fixed;
                      //   }

                      //   await newFee.save();
                      // } else if (fee.feeType === FeeType.Bank) {
                      //   const newFee = new this.Fee({
                      //     feeType: FeeType.Bank,
                      //     type: fee.type,
                      //     user: savedUser.id,
                      //   });

                      //   if (fee.percentage) {
                      //     newFee.percentage = fee.percentage;
                      //   }
                      //   if (fee.fixed) {
                      //     newFee.fixed = fee.fixed;
                      //   }

                      //   await newFee.save();
                      // } else {
                      //   const newFee = new this.Fee({
                      //     feeType: FeeType.Transaction,
                      //     method: fee.method,
                      //     type: fee.type,
                      //     user: savedUser.id,
                      //   });

                      //   if (fee.percentage) {
                      //     newFee.percentage = fee.percentage;
                      //   }
                      //   if (fee.fixed) {
                      //     newFee.fixed = fee.fixed;
                      //   }

                      //   await newFee.save();
                      // }
                    }
                  });
                });

                const success = response.initSuccess(200, true, {
                  username: data.username,
                  pass: data.pass,
                  clientName: data.clientName,
                  clientId: clientId,
                });
                return res.send(success);
              },
            );
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientOverview(id: string, res: FastifyReply) {
    try {
      const todayStart = new Date();
      todayStart.setDate(todayStart.getDate() - 1);
      todayStart.setHours(17, 0, 0, 0);
      const todayEnd = new Date();
      todayEnd.setHours(16, 59, 59, 999);

      await this.User.aggregate([
        {
          $match: {
            $expr: {
              $eq: ['$_id', { $toObjectId: id }],
            },
            isDeleted: false,
          },
        },
        // lookup the transactions collection and filter by 'Paid' status
        {
          $lookup: {
            from: 'transactions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      {
                        $eq: ['$transactionType', TransactionType.Transaction],
                      },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'transaction',
          },
        },
        {
          $unwind: {
            path: '$transaction',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'transactions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      {
                        $eq: ['$transactionType', TransactionType.Topup],
                      },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'topup',
          },
        },
        {
          $unwind: {
            path: '$topup',
            preserveNullAndEmptyArrays: true,
          },
        },
        // lookup the withdraw collection and filter by 'Paid' and 'Pending' status
        {
          $lookup: {
            from: 'withdraws',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      { $eq: ['$process', WithdrawProcess.Process] },
                      { $eq: ['$withdrawType', WithdrawType.Client] },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'withdraw',
          },
        },
        {
          $unwind: {
            path: '$withdraw',
            preserveNullAndEmptyArrays: true,
          },
        },
        // lookup the balance collection and filter by user
        {
          $lookup: {
            from: 'balances',
            let: { userId: '$_id' },
            pipeline: [
              { $match: { $expr: { $eq: ['$user', '$$userId'] } } },
              {
                $project: {
                  _id: 0,
                  balance: 1,
                  pending: 1,
                  freeze: 1,
                  debt: 1,
                },
              },
            ],
            as: 'balance',
          },
        },
        {
          $unwind: {
            path: '$balance',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'clients',
            let: { userId: '$_id' },
            pipeline: [{ $match: { $expr: { $eq: ['$user', '$$userId'] } } }],
            as: 'client',
          },
        },
        {
          $unwind: {
            path: '$client',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'devclients',
            let: { userId: '$_id' },
            pipeline: [{ $match: { $expr: { $eq: ['$user', '$$userId'] } } }],
            as: 'devclient',
          },
        },
        {
          $unwind: {
            path: '$devclient',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'users',
            let: { userId: '$upline' },
            pipeline: [{ $match: { $expr: { $eq: ['$_id', '$$userId'] } } }],
            as: 'upline',
          },
        },
        {
          $unwind: {
            path: '$upline',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 1,
            username: 1,
            company: 1,
            email: 1,
            phone: 1,
            isBlocked: 1,
            isVerified: 1,
            createdAt: 1,
            updatedAt: 1,
            transaction: {
              $let: {
                vars: {
                  transactionData: {
                    $ifNull: ['$transaction', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$transactionData', null] },
                    then: null,
                    else: '$$transactionData',
                  },
                },
              },
            },
            topup: {
              $let: {
                vars: {
                  topupData: {
                    $ifNull: ['$topup', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$topupData', null] },
                    then: null,
                    else: '$$topupData',
                  },
                },
              },
            },
            withdraw: {
              $let: {
                vars: {
                  withdrawData: {
                    $ifNull: ['$withdraw', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$withdrawData', null] },
                    then: null,
                    else: '$$withdrawData',
                  },
                },
              },
            },
            balance: {
              $let: {
                vars: {
                  balanceData: {
                    $ifNull: ['$balance', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$balanceData', null] },
                    then: null,
                    else: '$$balanceData',
                  },
                },
              },
            },
            client: {
              clientId: 1,
              clientName: 1,
              paymentClientName: 1,
              paymentCustName: 1,
              limit: 1,
            },
            prod: {
              isKey: {
                $let: {
                  vars: {
                    secret: {
                      $ifNull: ['$client.clientSecret', false],
                    },
                    signature: {
                      $ifNull: ['$client.signatureKey', false],
                    },
                  },
                  in: {
                    $and: ['$$secret', '$$signature'],
                  },
                },
              },
              isCallback: {
                $let: {
                  vars: {
                    callbackTrx: {
                      $ifNull: ['$client.callbackTrx', null],
                    },
                    callbackWd: {
                      $ifNull: ['$client.callbackWd', null],
                    },
                    callbackTopup: {
                      $ifNull: ['$client.callbackTopup', null],
                    },
                    key: {
                      $ifNull: ['$client.callbackKey', false],
                    },
                  },
                  in: {
                    $and: [
                      '$$callbackTrx',
                      '$$callbackWd',
                      '$$callbackTopup',
                      '$$key',
                    ],
                  },
                },
              },
              ip: '$client.ip',
              callbackTrx: '$client.callbackTrx',
              callbackWd: '$client.callbackWd',
              callbackTopup: '$client.callbackTopup',
            },
            dev: {
              isKey: {
                $let: {
                  vars: {
                    secret: {
                      $ifNull: ['$devclient.clientSecret', false],
                    },
                    signature: {
                      $ifNull: ['$devclient.signatureKey', false],
                    },
                  },
                  in: {
                    $and: ['$$secret', '$$signature'],
                  },
                },
              },
              isCallback: {
                $let: {
                  vars: {
                    callbackTrx: {
                      $ifNull: ['$devclient.callbackTrx', null],
                    },
                    callbackWd: {
                      $ifNull: ['$devclient.callbackWd', null],
                    },
                    callbackTopup: {
                      $ifNull: ['$devclient.callbackTopup', null],
                    },
                    key: {
                      $ifNull: ['$devclient.callbackKey', false],
                    },
                  },
                  in: {
                    $and: [
                      '$$callbackTrx',
                      '$$callbackWd',
                      '$$callbackTopup',
                      '$$key',
                    ],
                  },
                },
              },
              ip: '$devclient.ip',
              callbackTrx: '$devclient.callbackTrx',
              callbackWd: '$devclient.callbackWd',
              callbackTopup: '$devclient.callbackTopup',
            },
            upline: {
              username: 1,
              isBlocked: 1,
              isDeleted: 1,
            },
          },
        },
      ]).then((user) => {
        if (user.length) {
          const success = response.initSuccess(200, true, user[0]);
          return res.send(success);
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Client not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientTopup(
    query: QueryDto,
    id: string,
    type: string,
    res: FastifyReply,
  ) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        transactionId: { transactionId: query.sortOrder === 'asc' ? 1 : -1 },
        refId: { refId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const transactionQuery: any = {
        user: new Types.ObjectId(id),
        transactionType: TransactionType.Topup,
        $or: [
          { transactionId: { $regex: query.search.trim(), $options: 'i' } },
          { refId: { $regex: query.search.trim(), $options: 'i' } },
          { clientRef: { $regex: query.search.trim(), $options: 'i' } },
        ],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        transactionQuery.status = query.filter.trim();
      }
      const modeType = type ?? 'prod';
      if (modeType === 'prod') {
        await this.Transaction.find(transactionQuery)
          .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
          .skip(skip)
          .limit(query.limit)
          .populate({
            path: 'method',
            select: '-_id name img type',
          })
          .select(
            '_id transactionId payment url refId amount feeAdmin status createdAt clientRef',
          )
          .then(async (transactions) => {
            const total = await this.Transaction.countDocuments(
              transactionQuery,
            );
            const success = response.initSuccess(200, true, {
              transactions,
              total,
            });
            return res.send(success);
          });
      } else {
        await this.DevTransaction.find(transactionQuery)
          .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
          .skip(skip)
          .limit(query.limit)
          .populate({
            path: 'method',
            select: '-_id name img type',
          })
          .select(
            '_id transactionId payment url refId amount feeAdmin status createdAt clientRef',
          )
          .then(async (transactions) => {
            const total = await this.DevTransaction.countDocuments(
              transactionQuery,
            );
            const success = response.initSuccess(200, true, {
              transactions,
              total,
            });
            return res.send(success);
          });
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientTopupDetail(
    id: string,
    transId: string,
    type: string,
    res: FastifyReply,
  ) {
    try {
      const modeType = type ?? 'prod';
      if (modeType === 'prod') {
        await this.Transaction.findOne({
          transactionType: TransactionType.Topup,
          user: new Types.ObjectId(id),
          _id: new Types.ObjectId(transId),
        })
          .populate({
            path: 'method',
            select: '-_id name img type',
          })
          .populate({
            path: 'user',
            select: '_id username',
          })
          .populate({
            path: 'uplineFee.commission',
            select: 'amount user',
            populate: {
              path: 'user',
              select: 'username upline',
              populate: {
                path: 'upline',
                select: 'username',
              },
            },
          })
          .select('-__v -updatedAt')
          .then((transaction) => {
            const success = response.initSuccess(200, true, transaction);
            return res.send(success);
          });
      } else {
        await this.DevTransaction.findOne({
          transactionType: TransactionType.Topup,
          user: new Types.ObjectId(id),
          _id: new Types.ObjectId(transId),
        })
          .populate({
            path: 'method',
            select: '-_id name img type',
          })
          .populate({
            path: 'user',
            select: '_id username',
          })

          .select('-__v -updatedAt')
          .then((transaction) => {
            const success = response.initSuccess(200, true, transaction);
            return res.send(success);
          });
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientTransaction(
    query: QueryDto,
    id: string,
    type: string,
    res: FastifyReply,
  ) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        transactionId: { transactionId: query.sortOrder === 'asc' ? 1 : -1 },
        refId: { refId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
        paidTime: { paidTime: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const transactionQuery: any = {
        user: new Types.ObjectId(id),
        transactionType: TransactionType.Transaction,
        $or: [
          { transactionId: { $regex: query.search.trim(), $options: 'i' } },
          { refId: { $regex: query.search.trim(), $options: 'i' } },
          { clientRef: { $regex: query.search.trim(), $options: 'i' } },
        ],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        transactionQuery.status = query.filter.trim();
      }
      const modeType = type ?? 'prod';
      if (modeType === 'prod') {
        await this.Transaction.find(transactionQuery)
          .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
          .skip(skip)
          .limit(query.limit)
          .populate({
            path: 'method',
            select: '-_id name img type',
          })
          .select(
            '_id transactionId payment url refId amount fee feeAdmin status createdAt clientRef paidTime',
          )
          .then(async (transactions) => {
            const total = await this.Transaction.countDocuments(
              transactionQuery,
            );
            const success = response.initSuccess(200, true, {
              transactions,
              total,
            });
            return res.send(success);
          });
      } else {
        await this.DevTransaction.find(transactionQuery)
          .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
          .skip(skip)
          .limit(query.limit)
          .populate({
            path: 'method',
            select: '-_id name img type',
          })
          .select(
            '_id transactionId payment url refId amount feeAdmin status createdAt clientRef paidTime',
          )
          .then(async (transactions) => {
            const total = await this.DevTransaction.countDocuments(
              transactionQuery,
            );
            const success = response.initSuccess(200, true, {
              transactions,
              total,
            });
            return res.send(success);
          });
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientTransactionDetail(
    id: string,
    transId: string,
    type: string,
    res: FastifyReply,
  ) {
    try {
      const modeType = type ?? 'prod';
      if (modeType === 'prod') {
        await this.Transaction.findOne({
          transactionType: TransactionType.Transaction,
          user: new Types.ObjectId(id),
          _id: new Types.ObjectId(transId),
        })
          .populate({
            path: 'method',
            select: '-_id name img type',
          })
          .populate({
            path: 'user',
            select: '_id username',
          })
          .populate({
            path: 'uplineFee.commission',
            select: 'amount user',
            populate: {
              path: 'user',
              select: 'username upline',
              populate: {
                path: 'upline',
                select: 'username',
              },
            },
          })
          .select('-__v -updatedAt')
          .then((transaction) => {
            const success = response.initSuccess(200, true, transaction);
            return res.send(success);
          });
      } else {
        await this.DevTransaction.findOne({
          transactionType: TransactionType.Transaction,
          user: new Types.ObjectId(id),
          _id: new Types.ObjectId(transId),
        })
          .populate({
            path: 'method',
            select: '-_id name img type',
          })
          .populate({
            path: 'user',
            select: '_id username',
          })

          .select('-__v -updatedAt')
          .then((transaction) => {
            const success = response.initSuccess(200, true, transaction);
            return res.send(success);
          });
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateClientTransactionDetail(
    data: UpdateTransactionDto,
    id: string,
    transId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.Transaction.findOne({
          transactionType: TransactionType.Transaction,
          user: new Types.ObjectId(id),
          _id: new Types.ObjectId(transId),
        })
          .populate({
            path: 'method',
            select: '-_id name img',
          })
          .populate({
            path: 'user',
            select: '_id username',
          })
          .populate({
            path: 'uplineFee.commission',
            select: 'amount user',
            populate: {
              path: 'user',
              select: 'username upline',
              populate: {
                path: 'upline',
                select: 'username',
              },
            },
          })
          .select('-payment -__v -updatedAt')
          .then(async (transaction) => {
            if (transaction) {
              transaction.amount = data.amount;
              transaction.status = TransactionStatusType.Pending;
              await transaction.save();
              const success = response.initSuccess(200, true, true);
              return res.send(success);
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Transaction not found'),
              );
              return res.send(error);
            }
          });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientWithdraw(
    query: QueryDto,
    id: string,
    type: string,
    process: string,
    res: FastifyReply,
  ) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        withdrawId: { withdrawId: query.sortOrder === 'asc' ? 1 : -1 },
        orderId: { orderId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        name: { name: query.sortOrder === 'asc' ? 1 : -1 },
        accNumber: { accNumber: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        status: { status: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const withdrawQuery: any = {
        user: new Types.ObjectId(id),
        process,
        withdrawType: WithdrawType.Client,
        $or: [
          { withdrawId: { $regex: query.search.trim(), $options: 'i' } },
          { orderId: { $regex: query.search.trim(), $options: 'i' } },
          { clientRef: { $regex: query.search.trim(), $options: 'i' } },
          { name: { $regex: query.search.trim(), $options: 'i' } },
          { accNumber: { $regex: query.search.trim(), $options: 'i' } },
        ],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        withdrawQuery.status = query.filter.trim();
      }
      const modeType = type ?? 'prod';
      if (modeType === 'prod') {
        await this.Withdraw.find(withdrawQuery)
          .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
          .skip(skip)
          .limit(query.limit)
          .populate({
            path: 'bank',
            select: '-_id name type',
          })
          .populate({
            path: 'processedBy',
            select: '-_id username',
          })
          .select(
            '_id withdrawId orderId clientRef name accNumber amount feeAdmin status createdAt processedBy',
          )
          .then(async (withdraws) => {
            const total = await this.Withdraw.countDocuments(withdrawQuery);
            const success = response.initSuccess(200, true, {
              withdraws,
              total,
            });
            return res.send(success);
          });
      } else {
        await this.DevWithdraw.find(withdrawQuery)
          .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
          .skip(skip)
          .limit(query.limit)
          .populate({
            path: 'bank',
            select: '-_id name type',
          })
          .select(
            '_id withdrawId orderId clientRef name accNumber amount feeAdmin status createdAt',
          )
          .then(async (withdraws) => {
            const total = await this.DevWithdraw.countDocuments(withdrawQuery);
            const success = response.initSuccess(200, true, {
              withdraws,
              total,
            });
            return res.send(success);
          });
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientTree(id: string, res: FastifyReply) {
    try {
      await this.User.findById(id)
        .populate({
          path: 'upline',
          select: '_id isBlocked isDeleted username',
          populate: {
            path: 'upline',
            select: '_id isBlocked isDeleted username',
            populate: {
              path: 'upline',
              select: '_id isBlocked isDeleted username',
            },
          },
        })
        .select('_id isBlocked isDeleted username')
        .then((user: any) => {
          if (user) {
            const success = response.initSuccess(200, true, user);
            return res.send(success);
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('User not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientMethodFee(id: string, res: FastifyReply) {
    try {
      await this.Fee.aggregate([
        {
          $match: {
            feeType: FeeType.Transaction,
            user: new Types.ObjectId(id),
          },
        },
        {
          $lookup: {
            from: 'providers',
            let: { providerId: { $toObjectId: '$provider' } },
            pipeline: [
              {
                $match: {
                  $expr: { $eq: ['$_id', '$$providerId'] },
                },
              },
              {
                $project: {
                  _id: 0,
                  providerId: '$_id',
                  name: 1,
                  merchant: 1,
                },
              },
            ],
            as: 'provider',
          },
        },
        {
          $unwind: {
            path: '$provider',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            feeType: 0,
            createdAt: 0,
            updatedAt: 0,
            user: 0,
            __v: 0,
          },
        },
      ]).then(async (fee) => {
        await this.ValueType.find()
          .select('_id name')
          .then((valueType) => {
            const success = response.initSuccess(200, true, {
              fee: fee,
              valueType: valueType,
            });
            return res.send(success);
          });
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateClientMethodFee(
    data: UpdateMethodFeeDto,
    id: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        data.method + '|' + browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.User.findById(id).then(async (client) => {
          if (client) {
            await this.Method.findById(data.method).then(async (method) => {
              if (method) {
                await this.Fee.findOne({
                  user: client.id,
                  method: method.id,
                }).then(async (fee) => {
                  var feeId: string, providerName: string;
                  if (fee) {
                    if ((data.fixed || data.percentage) && data.type) {
                      if (data.fixed && data.percentage) {
                        fee.percentage = data.percentage;
                        fee.fixed = data.fixed;
                      } else if (data.fixed) {
                        fee.fixed = data.fixed;
                        fee.percentage = 0;
                      } else if (data.percentage) {
                        fee.percentage = data.percentage;
                        fee.fixed = 0;
                      }
                      fee.type = new Types.ObjectId(data.type);
                    }
                    if (data.isActive !== undefined) {
                      fee.isActive = data.isActive;
                    }
                    if (data.onClient !== undefined) {
                      fee.onClient = data.onClient;
                    }
                    if (data.delay) {
                      fee.delay = data.delay;
                    }

                    if (data.providerId) {
                      const provider: any = await this.Provider.findById(
                        data.providerId,
                      ).exec();
                      fee.provider = new Types.ObjectId(data.providerId);
                      providerName = provider.name;

                      // if (data.providerMerchant) {
                      //   provider.merchant = data.providerMerchant;

                      //   await provider.save();
                      // }
                    }

                    await fee.save();
                    feeId = fee.id;
                  } else {
                    const newFee = new this.Fee({
                      delay: data.delay,
                      fixed: data.fixed,
                      percentage: data.percentage,
                      onClient:
                        data.onClient !== undefined ? data.onClient : true,
                      feeType: FeeType.Transaction,
                      method: method.id,
                      type: new Types.ObjectId(data.type),
                      user: client.id,
                      isActive:
                        data.isActive !== undefined ? data.isActive : true,
                    });

                    const saved = await newFee.save();
                    feeId = saved.id;
                  }

                  await this.LogType.findOne({
                    type: LogTypes.AdminUpdate,
                  }).then(async (logType) => {
                    if (logType) {
                      await this.Client.findOne({
                        user: client.id,
                      }).then(async (clientData) => {
                        if ((data.fixed || data.percentage) && data.type) {
                          const newLog = new this.Log({
                            message: `${user.username} update ${
                              method.name
                            } of ${clientData.clientName} to ${
                              data.fixed && data.percentage
                                ? `${data.fixed} + ${data.percentage}%`
                                : data.fixed ?? `${data.percentage}%`
                            }`,
                            target: feeId,
                            ip: req.ip,
                            type: logType.id,
                            user: client.id,
                            admin: user.id,
                          });

                          await newLog.save();
                        }
                        if (data.isActive !== undefined) {
                          const newLog = new this.Log({
                            message: `${user.username} update ${
                              method.name
                            } of ${clientData.clientName} to ${
                              data.isActive ? 'Active' : 'Inactive'
                            }`,
                            target: feeId,
                            ip: req.ip,
                            type: logType.id,
                            user: client.id,
                            admin: user.id,
                          });

                          await newLog.save();
                        }
                        if (data.onClient !== undefined) {
                          const newLog = new this.Log({
                            message: `${user.username} update ${
                              method.name
                            } of ${clientData.clientName} to ${
                              data.onClient
                                ? 'Charged to client'
                                : 'Charged to customer'
                            }`,
                            target: feeId,
                            ip: req.ip,
                            type: logType.id,
                            user: client.id,
                            admin: user.id,
                          });

                          await newLog.save();
                        }
                        if (data.delay) {
                          const newLog = new this.Log({
                            message: `${user.username} update ${method.name} of ${clientData.clientName} to ${data.delay} day delay`,
                            target: feeId,
                            ip: req.ip,
                            type: logType.id,
                            user: client.id,
                            admin: user.id,
                          });

                          await newLog.save();
                        }

                        if (data.providerId && providerName) {
                          const newLog = new this.Log({
                            message: `${user.username} update ${method.name} of ${clientData.clientName} provider to ${providerName}`,
                            target: feeId,
                            ip: req.ip,
                            type: logType.id,
                            user: client.id,
                            admin: user.id,
                          });

                          await newLog.save();

                          // if (data.providerMerchant) {
                          //   const newLog = new this.Log({
                          //     message: `${user.username} update ${clientData.clientName} provider ${providerName} merchant`,
                          //     target: data.providerId,
                          //     ip: req.ip,
                          //     type: logType.id,
                          //     user: client.id,
                          //     admin: user.id,
                          //   });

                          //   await newLog.save();
                          // }
                        }
                      });
                    }

                    const success = response.initSuccess(200, true, true);
                    return res.send(success);
                  });
                });
              } else {
                const error = response.initError(
                  404,
                  false,
                  new ErrorMessage('Method not found'),
                );
                return res.send(error);
              }
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateClientMethodUplineFee(
    data: UpdateMethodUplineFeeDto,
    id: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.User.findById(id).then(async (client) => {
          if (client) {
            await this.Method.findById(data.method).then(async (method) => {
              if (method) {
                await this.Fee.findOne({
                  user: client.id,
                  method: method.id,
                }).then(async (fee) => {
                  var feeId: string;
                  if (fee) {
                    const uplineFee = searchArray(
                      fee.uplineFee,
                      null,
                      null,
                      'id',
                      data.id.toString(),
                    );
                    if (uplineFee.length) {
                      if ((data.fixed || data.percentage) && data.type) {
                        if (data.fixed && data.percentage) {
                          uplineFee[0].percentage = data.percentage;
                          uplineFee[0].fixed = data.fixed;
                        } else if (data.fixed) {
                          uplineFee[0].fixed = data.fixed;
                          uplineFee[0].percentage = 0;
                        } else if (data.percentage) {
                          uplineFee[0].percentage = data.percentage;
                          uplineFee[0].fixed = 0;
                        }
                        uplineFee[0].type = new Types.ObjectId(data.type);
                      }
                    } else {
                      const newUplineFee = {
                        id: data.id,
                        type: new Types.ObjectId(data.type),
                        fixed: data.fixed,
                        percentage: data.percentage,
                      };

                      fee.uplineFee.push(newUplineFee);
                      fee.uplineFee.sort((a, b) => {
                        if (a.id < b.id) return -1;
                        if (a.id > b.id) return 1;
                        return 0;
                      });
                    }
                    await fee.save();
                    feeId = fee.id;
                  } else {
                    const newFee = new this.Fee({
                      delay: 0,
                      fixed: data.fixed,
                      percentage: data.percentage,
                      feeType: FeeType.Transaction,
                      method: method.id,
                      type: new Types.ObjectId(data.type),
                      user: client.id,
                      uplineFee: [
                        {
                          id: data.id,
                          type: new Types.ObjectId(data.type),
                          fixed: data.fixed,
                          percentage: data.percentage,
                        },
                      ],
                    });

                    const saved = await newFee.save();
                    feeId = saved.id;
                  }

                  await this.LogType.findOne({
                    type: LogTypes.AdminUpdate,
                  }).then(async (logType) => {
                    if (logType) {
                      await this.Client.findOne({
                        user: client.id,
                      }).then(async (clientData) => {
                        if ((data.fixed || data.percentage) && data.type) {
                          const newLog = new this.Log({
                            message: `${user.username} update ${
                              method.name
                            } of ${clientData.clientName} UPLINE FEE ${
                              data.id
                            } to ${
                              data.fixed && data.percentage
                                ? `${data.fixed} + ${data.percentage}%`
                                : data.fixed ?? `${data.percentage}%`
                            }`,
                            target: feeId,
                            ip: req.ip,
                            type: logType.id,
                            user: client.id,
                            admin: user.id,
                          });

                          await newLog.save();
                        }
                      });
                    }

                    const success = response.initSuccess(200, true, true);
                    return res.send(success);
                  });
                });
              } else {
                const error = response.initError(
                  404,
                  false,
                  new ErrorMessage('Method not found'),
                );
                return res.send(error);
              }
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientBankFee(id: string, type: string, res: FastifyReply) {
    try {
      await this.ValueType.find()
        .select('_id name')
        .then(async (valueType) => {
          var resArr = [];
          if (
            type === BankType.Bank ||
            type === BankType.CC ||
            type === BankType.Va
          ) {
            await this.Fee.findOne({
              feeType: type,
              user: new Types.ObjectId(id),
            })
              .populate({
                path: 'provider',
                select: '-_id name merchant',
              })
              .select('-user -feeType -createdAt -updatedAt -__v')
              .then(async (bank) => {
                resArr.push({
                  id: type,
                  name: `${
                    type === BankType.Bank
                      ? 'Bank'
                      : type === BankType.CC
                      ? 'Credit Card'
                      : 'Virtual Account'
                  } Fee`,
                  isActive: true,
                  fee: bank,
                });
              });
          } else {
            await this.Bank.aggregate([
              {
                $match: { type },
              },
              {
                $lookup: {
                  from: 'fees',
                  let: { bankId: '$_id' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $and: [
                            { $eq: ['$bank', '$$bankId'] },
                            { $eq: ['$user', { $toObjectId: id }] },
                          ],
                        },
                      },
                    },
                    {
                      $lookup: {
                        from: 'providers',
                        let: { providerId: { $toObjectId: '$provider' } },
                        pipeline: [
                          {
                            $match: {
                              $expr: { $eq: ['$_id', '$$providerId'] },
                            },
                          },
                          {
                            $project: {
                              _id: 0,
                              providerId: '$_id',
                              name: 1,
                              merchant: 1,
                            },
                          },
                        ],
                        as: 'provider',
                      },
                    },
                    {
                      $unwind: {
                        path: '$provider',
                        preserveNullAndEmptyArrays: true,
                      },
                    },
                    {
                      $project: {
                        bank: 0,
                        user: 0,
                        feeType: 0,
                        createdAt: 0,
                        updatedAt: 0,
                        __v: 0,
                      },
                    },
                  ],
                  as: 'fee',
                },
              },
              {
                $unwind: {
                  path: '$fee',
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $project: {
                  _id: 0,
                  id: '$_id',
                  name: 1,
                  isActive: 1,
                  fee: 1,
                },
              },
            ]).then(async (banks) => {
              resArr = banks;
            });
          }

          const success = response.initSuccess(200, true, {
            data: resArr,
            valueType,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateClientBankFee(
    data: UpdateBankFeeDto,
    id: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        data.bank + '|' + browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.User.findById(id).then(async (client) => {
          if (client) {
            var fee: FeeDocument, bankName: string, type: BankType;
            if (
              data.bank === BankType.Bank ||
              data.bank === BankType.Va ||
              data.bank === BankType.CC
            ) {
              bankName =
                data.bank === BankType.Bank
                  ? 'Bank'
                  : data.bank === BankType.CC
                  ? 'Credit Card'
                  : 'Virtual Account';
              type = data.bank;
              fee = await this.Fee.findOne({
                feeType: data.bank,
                user: client.id,
              });
            } else {
              await this.Bank.findById(data.bank).then(async (bank) => {
                if (bank) {
                  bankName = bank.name;
                  type = bank.type as BankType;
                  fee = await this.Fee.findOne({
                    bank: bank.id,
                    user: client.id,
                  });
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Method not found'),
                  );
                  return res.send(error);
                }
              });
            }

            var feeId: string, providerName: string;
            if (fee) {
              if ((data.fixed || data.percentage) && data.type) {
                if (data.fixed && data.percentage) {
                  fee.percentage = data.percentage;
                  fee.fixed = data.fixed;
                } else if (data.fixed) {
                  fee.percentage = 0;
                  fee.fixed = data.fixed;
                } else if (data.percentage) {
                  fee.percentage = data.percentage;
                  fee.fixed = 0;
                }
                fee.type = new Types.ObjectId(data.type);
              }
              if (data.isActive !== undefined) {
                fee.isActive = data.isActive;
              }
              if (data.onClient !== undefined) {
                fee.onClient = data.onClient;
              }

              if (data.providerId) {
                const provider: any = await this.Provider.findById(
                  data.providerId,
                ).exec();
                fee.provider = new Types.ObjectId(data.providerId);
                providerName = provider.name;

                // if (data.providerMerchant) {
                //   provider.merchant = data.providerMerchant;

                //   await provider.save();
                // }
              }

              await fee.save();
              feeId = fee.id;
            } else {
              const newFee = new this.Fee({
                fixed: data.fixed,
                percentage: data.percentage,
                onClient: data.onClient !== undefined ? data.onClient : true,
                type: new Types.ObjectId(data.type),
                user: client.id,
                isActive: data.isActive !== undefined ? data.isActive : true,
                feeType: type,
              });
              if (type === BankType.Cash || type === BankType.Ewallet) {
                newFee.bank = new Types.ObjectId(data.bank);
              }

              const saved = await newFee.save();
              feeId = saved.id;
            }

            await this.LogType.findOne({
              type: LogTypes.AdminUpdate,
            }).then(async (logType) => {
              if (logType) {
                await this.Client.findOne({
                  user: client.id,
                }).then(async (clientData) => {
                  if ((data.fixed || data.percentage) && data.type) {
                    const newLog = new this.Log({
                      message: `${user.username} update ${bankName} of ${
                        clientData.clientName
                      } fee disburse to ${
                        data.fixed && data.percentage
                          ? `${data.fixed} + ${data.percentage}%`
                          : data.fixed ?? `${data.percentage}%`
                      }`,
                      target: feeId,
                      ip: req.ip,
                      type: logType.id,
                      user: client.id,
                      admin: user.id,
                    });

                    await newLog.save();
                  }
                  if (data.isActive !== undefined) {
                    const newLog = new this.Log({
                      message: `${user.username} update ${bankName} of ${
                        clientData.clientName
                      } disburse to ${data.isActive ? 'Active' : 'Inactive'}`,
                      target: feeId,
                      ip: req.ip,
                      type: logType.id,
                      user: client.id,
                      admin: user.id,
                    });

                    await newLog.save();
                  }
                  if (data.onClient !== undefined) {
                    const newLog = new this.Log({
                      message: `${user.username} update ${bankName} of ${
                        clientData.clientName
                      } disburse to ${
                        data.onClient
                          ? 'Charged to client'
                          : 'Charged to customer'
                      }`,
                      target: feeId,
                      ip: req.ip,
                      type: logType.id,
                      user: client.id,
                      admin: user.id,
                    });

                    await newLog.save();
                  }

                  if (data.providerId && providerName) {
                    const newLog = new this.Log({
                      message: `${user.username} update ${bankName} of ${clientData.clientName} provider to ${providerName}`,
                      target: feeId,
                      ip: req.ip,
                      type: logType.id,
                      user: client.id,
                      admin: user.id,
                    });

                    await newLog.save();

                    // if (data.providerMerchant) {
                    //   const newLog = new this.Log({
                    //     message: `${user.username} update ${clientData.clientName} provider ${providerName} merchant`,
                    //     target: data.providerId,
                    //     ip: req.ip,
                    //     type: logType.id,
                    //     user: client.id,
                    //     admin: user.id,
                    //   });

                    //   await newLog.save();
                    // }
                  }
                });
              }

              const success = response.initSuccess(200, true, true);
              return res.send(success);
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateClientBankUplineFee(
    data: UpdateBankUplineFeeDto,
    id: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.User.findById(id).then(async (client) => {
          if (client) {
            var fee: FeeDocument, bankName: string, type: BankType;
            if (
              data.bank === BankType.Bank ||
              data.bank === BankType.Va ||
              data.bank === BankType.CC
            ) {
              bankName =
                data.bank === BankType.Bank
                  ? 'Bank'
                  : data.bank === BankType.CC
                  ? 'Credit Card'
                  : 'Virtual Account';
              type = data.bank;
              fee = await this.Fee.findOne({
                feeType: data.bank,
                user: client.id,
              });
            } else {
              await this.Bank.findById(data.bank).then(async (bank) => {
                if (bank) {
                  bankName = bank.name;
                  type = bank.type as BankType;
                  fee = await this.Fee.findOne({
                    bank: bank.id,
                    user: client.id,
                  });
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Method not found'),
                  );
                  return res.send(error);
                }
              });
            }

            var feeId: string;
            if (fee) {
              const uplineFee = searchArray(
                fee.uplineFee,
                null,
                null,
                'id',
                data.id.toString(),
              );
              if (uplineFee.length) {
                if ((data.fixed || data.percentage) && data.type) {
                  if (data.fixed && data.percentage) {
                    uplineFee[0].percentage = data.percentage;
                    uplineFee[0].fixed = data.fixed;
                  } else if (data.fixed) {
                    uplineFee[0].fixed = data.fixed;
                    uplineFee[0].percentage = 0;
                  } else if (data.percentage) {
                    uplineFee[0].percentage = data.percentage;
                    uplineFee[0].fixed = 0;
                  }
                  uplineFee[0].type = new Types.ObjectId(data.type);
                }
              } else {
                const newUplineFee = {
                  id: data.id,
                  type: new Types.ObjectId(data.type),
                  fixed: data.fixed,
                  percentage: data.percentage,
                };

                fee.uplineFee.push(newUplineFee);
                fee.uplineFee.sort((a, b) => {
                  if (a.id < b.id) return -1;
                  if (a.id > b.id) return 1;
                  return 0;
                });
              }

              await fee.save();
              feeId = fee.id;
            } else {
              const newFee = new this.Fee({
                fixed: data.fixed,
                percentage: data.percentage,
                type: new Types.ObjectId(data.type),
                user: client.id,
                uplineFee: [
                  {
                    id: data.id,
                    type: new Types.ObjectId(data.type),
                    fixed: data.fixed,
                    percentage: data.percentage,
                  },
                ],
                feeType: type,
              });
              if (type === BankType.Cash || type === BankType.Ewallet) {
                newFee.bank = new Types.ObjectId(data.bank);
              }

              const saved = await newFee.save();
              feeId = saved.id;
            }

            await this.LogType.findOne({
              type: LogTypes.AdminUpdate,
            }).then(async (logType) => {
              if (logType) {
                await this.Client.findOne({
                  user: client.id,
                }).then(async (clientData) => {
                  if ((data.fixed || data.percentage) && data.type) {
                    const newLog = new this.Log({
                      message: `${user.username} update ${bankName} of ${
                        clientData.clientName
                      } UPLINE FEE ${data.id} disburse to ${
                        data.fixed && data.percentage
                          ? `${data.fixed} + ${data.percentage}%`
                          : data.fixed ?? `${data.percentage}%`
                      }`,
                      target: feeId,
                      ip: req.ip,
                      type: logType.id,
                      user: client.id,
                      admin: user.id,
                    });

                    await newLog.save();
                  }
                });
              }

              const success = response.initSuccess(200, true, true);
              return res.send(success);
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientProviderList(id: string, res: FastifyReply) {
    try {
      await this.Provider.aggregate([
        {
          $match: {
            isActive: true,
            user: new Types.ObjectId(id),
          },
        },
        {
          $sort: {
            name: -1,
          },
        },
        {
          $project: {
            code: 1,
            name: 1,
            isKey: {
              $let: {
                vars: {
                  keyData: {
                    $ifNull: ['$key', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$keyData', null] },
                    then: false,
                    else: true,
                  },
                },
              },
            },
          },
        },
      ]).then((provider) => {
        const success = response.initSuccess(200, true, provider);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientProviderKey(
    id: string,
    data: GetProviderKeyDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        if (user.secret2Fa && user.isVerified) {
          const keyDec = decrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', user.id).substring(0, 32),
            hash('sha256', user.id + user.username).substring(0, 16),
            user.secret2Fa,
          );

          if (!authenticator.check(data.otp, keyDec)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Invalid 2FA Code'),
            );
            return res.send(error);
          }

          await this.Provider.findOne({
            _id: new Types.ObjectId(payload.providerId),
            user: new Types.ObjectId(id),
            isActive: true,
          }).then((provider) => {
            if (provider && provider.key) {
              var key = '';
              if (provider.key === 'root') {
                key = 'root';
              } else {
                key = decrypt(
                  process.env.ENCRYPT_ALG,
                  hash('sha256', provider.id).substring(0, 32),
                  hash('sha256', id + provider.code).substring(0, 16),
                  provider.key,
                );
              }

              const success = response.initSuccess(200, true, {
                key,
                providerRootId: provider.providerRoot,
              });
              return res.send(success);
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Provider not found'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Please setup 2FA first'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature Invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async addClientProvider(
    id: string,
    data: AddProviderDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (
        Object.values(ProviderCodeType).includes(data.code as ProviderCodeType)
      ) {
        const { user, browser } = req.user;
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };

        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (data.signature === signatureVerify) {
          await this.User.findById(id).then(async (client) => {
            if (client) {
              await this.Client.findOne({
                user: client.id,
              }).then(async (clientData) => {
                if (clientData) {
                  await this.LogType.findOne({
                    type: LogTypes.AdminUpdate,
                  }).then(async (logType) => {
                    if (logType) {
                      await this.Provider.findOne({
                        user: client.id,
                        isActive: true,
                        name: {
                          $regex: new RegExp(data.name, 'i'),
                        },
                      }).then(async (providerFound) => {
                        if (providerFound) {
                          const error = response.initError(
                            403,
                            false,
                            new ErrorMessage('Name already exist'),
                          );
                          return res.send(error);
                        } else {
                          const newProvider = new this.Provider({
                            code: data.code,
                            name: data.name,
                            user: client.id,
                          });
                          await newProvider.save();

                          const newLog = new this.Log({
                            message: `${user.username} add client ${clientData.clientName} provider ${data.name}`,
                            ip: req.ip,
                            type: logType.id,
                            user: client.id,
                            admin: user.id,
                          });
                          await newLog.save();

                          const success = response.initSuccess(200, true, true);
                          return res.send(success);
                        }
                      });
                    } else {
                      const error = response.initError(
                        404,
                        false,
                        new ErrorMessage('Log not found'),
                      );
                      return res.send(error);
                    }
                  });
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Client Data not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Client not found'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          404,
          false,
          new ErrorMessage(`${data.code} not exist`),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateClientProvider(
    id: string,
    data: UpdateProviderDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.User.findById(id).then(async (client) => {
          if (client) {
            await this.Client.findOne({
              user: client.id,
            }).then(async (clientData) => {
              if (clientData) {
                await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
                  async (logType) => {
                    if (logType) {
                      await this.Provider.findOne({
                        user: client.id,
                        _id: new Types.ObjectId(data.providerId),
                      }).then(async (providerFound) => {
                        if (providerFound) {
                          if (data.name) {
                            providerFound.name = data.name;
                            const newLog = new this.Log({
                              message: `${user.username} update client ${clientData.clientName} provider name to ${data.name}`,
                              target: providerFound.id,
                              ip: req.ip,
                              type: logType.id,
                              user: client.id,
                              admin: user.id,
                            });

                            await newLog.save();
                          }
                          if (data.key === 'root') {
                            providerFound.key = 'root';
                            providerFound.providerRoot = new Types.ObjectId(
                              data.providerRootId,
                            );
                            const newLog = new this.Log({
                              message: `${user.username} update client ${clientData.clientName} provider key`,
                              target: providerFound.id,
                              ip: req.ip,
                              type: logType.id,
                              user: client.id,
                              admin: user.id,
                            });

                            await newLog.save();
                          } else if (data.key) {
                            const keyEnc = encrypt(
                              process.env.ENCRYPT_ALG,
                              hash('sha256', providerFound.id).substring(0, 32),
                              hash(
                                'sha256',
                                client.id + providerFound.code,
                              ).substring(0, 16),
                              data.key,
                            );
                            providerFound.key = keyEnc;
                            const newLog = new this.Log({
                              message: `${user.username} update client ${clientData.clientName} provider key`,
                              target: providerFound.id,
                              ip: req.ip,
                              type: logType.id,
                              user: client.id,
                              admin: user.id,
                            });

                            await newLog.save();
                          }

                          await providerFound.save();
                          const success = response.initSuccess(200, true, true);
                          return res.send(success);
                        } else {
                          const error = response.initError(
                            404,
                            false,
                            new ErrorMessage('Provider not found'),
                          );
                          return res.send(error);
                        }
                      });
                    } else {
                      const error = response.initError(
                        404,
                        false,
                        new ErrorMessage('Log not found'),
                      );
                      return res.send(error);
                    }
                  },
                );
              } else {
                const error = response.initError(
                  404,
                  false,
                  new ErrorMessage('Client Data not found'),
                );
                return res.send(error);
              }
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async deleteClientProvider(
    id: string,
    data: UpdateProviderDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.User.findById(id).then(async (client) => {
          if (client) {
            await this.Client.findOne({
              user: client.id,
            }).then(async (clientData) => {
              if (clientData) {
                await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
                  async (logType) => {
                    if (logType) {
                      await this.Provider.findOne({
                        user: client.id,
                        _id: new Types.ObjectId(data.providerId),
                      }).then(async (providerFound) => {
                        if (providerFound) {
                          providerFound.isActive = false;
                          const newLog = new this.Log({
                            message: `${user.username} delete client ${clientData.clientName} provider ${providerFound.name}`,
                            target: providerFound.id,
                            ip: req.ip,
                            type: logType.id,
                            user: client.id,
                            admin: user.id,
                          });

                          await newLog.save();

                          await this.Fee.updateMany(
                            {
                              provider: providerFound.id,
                            },
                            {
                              $unset: {
                                provider: 1,
                              },
                            },
                          );

                          await providerFound.save();
                          const success = response.initSuccess(200, true, true);
                          return res.send(success);
                        } else {
                          const error = response.initError(
                            404,
                            false,
                            new ErrorMessage('Provider not found'),
                          );
                          return res.send(error);
                        }
                      });
                    } else {
                      const error = response.initError(
                        404,
                        false,
                        new ErrorMessage('Log not found'),
                      );
                      return res.send(error);
                    }
                  },
                );
              } else {
                const error = response.initError(
                  404,
                  false,
                  new ErrorMessage('Client Data not found'),
                );
                return res.send(error);
              }
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientWhitelistBank(id: string, res: FastifyReply) {
    try {
      await this.BankAccount.find({
        user: new Types.ObjectId(id),
      })
        .populate({
          path: 'bank',
          select: '-_id name img',
        })
        .select('-user -updatedAt')
        .sort({ name: 1 })
        .then((bankAccount) => {
          const success = response.initSuccess(200, true, bankAccount);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async checkClientCallback(
    type: string,
    clientId: string,
    id: string,
    modeType: string,
    res: FastifyReply,
  ) {
    try {
      if (modeType === 'prod') {
        await this.Callback.findOne({
          user: clientId,
          type,
          [type]: id,
        }).then((logs) => {
          const success = response.initSuccess(200, true, logs.id);
          return res.send(success);
        });
      } else {
        await this.DevCallback.findOne({
          user: clientId,
          type,
          [type]: id,
        }).then((logs) => {
          const success = response.initSuccess(200, true, logs.id);
          return res.send(success);
        });
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientCallbackHistory(
    query: QueryDto,
    type: string,
    clientId: string,
    modeType: string,
    res: FastifyReply,
  ) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        attempt: { attempt: query.sortOrder === 'asc' ? 1 : -1 },
        isSent: { isSent: query.sortOrder === 'asc' ? 1 : -1 },
        last: { last: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };

      const callbackQuery: any = {
        $match: {
          type,
          user: new Types.ObjectId(clientId),
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
        },
      };

      if (query.filter !== 'all') {
        callbackQuery.$match.isSent = query.filter;
      }

      const callbackLookup: any = {
        $lookup: {},
      };
      const callbackSearch: any = {
        $match: {},
      };
      const callbackProject: any = {
        $project: {
          _id: 0,
          id: '$_id',
          isSent: 1,
          callbackUrl: 1,
          attempt: 1,
          last: 1,
          clientRef: 'data.clientRef',
          createdAt: 1,
        },
      };

      if (type === CallbackType.Withdraw) {
        callbackLookup.$lookup = {
          from: 'withdraws',
          localField: 'withdraw',
          foreignField: '_id',
          as: 'data',
        };

        callbackProject.$project.withdrawId = '$data.withdrawId';

        if (query.search) {
          callbackSearch.$match = {
            $or: [
              {
                'data.withdrawId': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
              {
                'data.clientRef': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
            ],
          };
        }
      } else {
        callbackLookup.$lookup = {
          from: 'transactions',
          localField:
            type === CallbackType.Transaction ? 'transaction' : 'topup',
          foreignField: '_id',
          as: 'data',
        };

        callbackProject.$project.transactionId = '$data.transactionId';

        if (query.search) {
          callbackSearch.$match = {
            $or: [
              {
                'data.transactionId': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
              {
                'data.clientRef': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
            ],
          };
        }
      }

      const logs =
        modeType === 'prod'
          ? await this.Callback.aggregate([
              callbackQuery,
              callbackLookup,
              {
                $unwind: {
                  path: '$data',
                  preserveNullAndEmptyArrays: true,
                },
              },
              callbackSearch,
              {
                $facet: {
                  results: [
                    {
                      $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
                    },
                    { $skip: skip },
                    { $limit: parseInt(query.limit.toString()) },
                    callbackProject,
                  ],
                  count: [{ $count: 'total' }],
                },
              },
              {
                $project: {
                  results: 1,
                  total: {
                    $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0],
                  }, // extract total from $count stage
                },
              },
            ])
          : await this.DevCallback.aggregate([
              callbackQuery,
              callbackLookup,
              {
                $unwind: {
                  path: '$data',
                  preserveNullAndEmptyArrays: true,
                },
              },
              callbackSearch,
              {
                $facet: {
                  results: [
                    {
                      $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
                    },
                    { $skip: skip },
                    { $limit: parseInt(query.limit.toString()) },
                    callbackProject,
                  ],
                  count: [{ $count: 'total' }],
                },
              },
              {
                $project: {
                  results: 1,
                  total: {
                    $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0],
                  }, // extract total from $count stage
                },
              },
            ]);

      const success = response.initSuccess(
        200,
        true,
        logs.length ? logs[0] : [],
      );
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientCallbackHistoryDetail(
    type: string,
    clientId: string,
    id: string,
    modeType: string,
    res: FastifyReply,
  ) {
    try {
      if (modeType === 'prod') {
        await this.Callback.findOne({
          type,
          user: clientId,
          _id: id,
        })
          .populate({
            path: 'transaction',
            select: 'transactionId clientRef',
          })
          .populate({
            path: 'withdraw',
            select: 'withdrawId clientRef',
          })
          .populate({
            path: 'topup',
            select: 'transactionId clientRef',
          })
          .then((callback) => {
            const success = response.initSuccess(200, true, callback);
            return res.send(success);
          });
      } else {
        await this.DevCallback.findOne({
          type,
          user: clientId,
          _id: id,
        })
          .populate({
            path: 'transaction',
            select: 'transactionId clientRef',
          })
          .populate({
            path: 'withdraw',
            select: 'withdrawId clientRef',
          })
          .populate({
            path: 'topup',
            select: 'transactionId clientRef',
          })
          .then((callback) => {
            const success = response.initSuccess(200, true, callback);
            return res.send(success);
          });
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async sendClientCallback(
    type: string,
    clientId: string,
    id: string,
    modeType: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (modeType === 'prod') {
        const { user } = req.user;
        await this.Callback.findOne({
          type,
          user: clientId,
          _id: id,
        }).then(async (callback) => {
          await this.Client.findOne({
            user: callback.user,
          }).then(async (client) => {
            if (client) {
              const callbackKey = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', client.id).substring(0, 32),
                hash(
                  'sha256',
                  callback.user.valueOf() + client.clientId,
                ).substring(0, 16),
                client.callbackKey,
              );

              const sig = encryptHmac(
                'sha512',
                callbackKey,
                minifyJson(JSON.parse(callback.payload)).toLowerCase(),
                'hex',
              );

              var resData: string, sent: boolean;
              await sendCallback(
                callback.callbackUrl,
                JSON.parse(callback.payload),
                sig,
              )
                .then((responseData) => {
                  resData = responseData;
                  sent = true;
                })
                .catch((error) => {
                  resData = error;
                  sent = false;
                });

              callback.isSent = sent;
              if (sent) {
                callback.res = resData;
              } else {
                callback.error = resData;
              }
              callback.attempt = callback.attempt + 1;
              callback.last = new Date();

              await callback.save();

              await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
                async (logType) => {
                  if (logType) {
                    const newLog = new this.Log({
                      message: `${user.username} send callback to client: ${
                        client.clientName
                      } of ${type} id: ${
                        callback.transaction ??
                        callback.topup ??
                        callback.withdraw
                      }`,
                      target: callback.id,
                      ip: req.ip,
                      type: logType.id,
                      user: callback.user,
                      admin: user.id,
                    });

                    await newLog.save();
                  }

                  const success = response.initSuccess(200, true, sent);
                  return res.send(success);
                },
              );
            }
          });
          const success = response.initSuccess(200, true, callback);
          return res.send(success);
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Dev no need resend callback'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientReportFilter(
    type: string,
    clientId: string,
    res: FastifyReply,
  ) {
    try {
      await this.Fee.aggregate([
        {
          $lookup: {
            from: 'providers',
            localField: 'provider',
            foreignField: '_id',
            as: 'provider',
          },
        },
        {
          $unwind: '$provider',
        },
        {
          $match: {
            'provider.code': type,
            feeType: FeeType.Transaction,
            user: new Types.ObjectId(clientId),
          },
        },
        {
          $lookup: {
            from: 'methods',
            localField: 'method',
            foreignField: '_id',
            as: 'method',
          },
        },
        {
          $unwind: '$method',
        },
        {
          $group: {
            _id: '$method._id',
            name: { $first: '$method.name' },
          },
        },
      ]).then(async (method) => {
        await this.Bank.find({
          type: { $in: [BankType.Cash, BankType.Ewallet] },
        })
          .select('name')
          .then(async (bank) => {
            const success = response.initSuccess(200, true, {
              cashIn: method,
              cashOut: bank,
            });
            return res.send(success);
          });
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientReport(
    query: QueryDto,
    cashIn: string,
    cashOut: string,
    offset: string,
    type: string,
    clientId: string,
    res: FastifyReply,
  ) {
    try {
      const skip = (query.page - 1) * query.limit;
      const startDate = new Date(Number(query.dateStart));
      startDate.setHours(startDate.getHours() + Number(offset));
      const endDate = new Date(Number(query.dateEnd));
      endDate.setHours(endDate.getHours() + Number(offset));

      const trxQuery: any = {
        $match: {
          user: new Types.ObjectId(clientId),
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
          status: {
            $in: [
              TransactionStatusType.Settled,
              TransactionStatusType.Paid,
              TransactionStatusType.Processing,
            ],
          },
          'provider.code': type,
        },
      };

      const wdQuery: any = {
        $match: {
          user: new Types.ObjectId(clientId),
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
          process: WithdrawProcess.Process,
          status: WithdrawStatus.Success,
        },
      };

      if (cashIn !== 'all') {
        trxQuery.$match.method = new Types.ObjectId(cashIn.trim());
      }

      if (cashOut !== 'all') {
        if (
          cashOut === BankType.Bank ||
          cashOut === BankType.CC ||
          cashOut === BankType.Va
        ) {
          wdQuery.$match['bank.type'] = cashOut;
        } else {
          wdQuery.$match['bank._id'] = new Types.ObjectId(cashIn.trim());
        }
      }

      const trx = await this.Transaction.aggregate([
        {
          $lookup: {
            from: 'providers',
            localField: 'provider',
            foreignField: '_id',
            as: 'provider',
          },
        },
        {
          $unwind: '$provider',
        },
        trxQuery,
        {
          $densify: {
            field: 'createdAt',
            range: {
              step: 1,
              unit: query.filter === 'daily' ? 'day' : 'month',
              bounds: [startDate, endDate],
            },
          },
        },
        {
          $addFields: {
            totalPartner: {
              $reduce: {
                input: '$uplineFee',
                initialValue: 0,
                in: {
                  $add: ['$$value', '$$this.amount'],
                },
              },
            },
          },
        },
        {
          $group: {
            _id: {
              $dateTrunc: {
                date: '$createdAt',
                unit: query.filter === 'daily' ? 'day' : 'month',
              },
            },
            totalAmount: {
              $sum: {
                $cond: [{ $not: ['$amount'] }, 0, '$amount'],
              },
            },
            margin: {
              $sum: {
                $subtract: [
                  {
                    $cond: [{ $not: ['$fee'] }, 0, '$fee'],
                  },
                  {
                    $cond: [{ $not: ['$feeAdmin'] }, 0, '$feeAdmin'],
                  },
                ],
              },
            },
            partner: {
              $sum: '$totalPartner',
            },
            qty: {
              $sum: {
                $cond: [{ $not: ['$amount'] }, 0, 1],
              },
            },
          },
        },
        {
          $sort: {
            _id: query.sortOrder === 'desc' ? -1 : 1,
          },
        },
        { $skip: skip },
        { $limit: parseInt(query.limit.toString()) },
        {
          $project: {
            _id: 0,
            date: {
              $dateToString: {
                format: query.filter === 'daily' ? '%Y-%m-%d' : '%Y-%m',
                date: '$_id',
              },
            },
            totalAmount: 1,
            qty: 1,
            margin: 1,
            partner: 1,
          },
        },
      ]);

      const wd = await this.Withdraw.aggregate([
        {
          $lookup: {
            from: 'banks',
            localField: 'bank',
            foreignField: '_id',
            as: 'bank',
          },
        },
        {
          $unwind: '$bank',
        },
        wdQuery,
        {
          $densify: {
            field: 'createdAt',
            range: {
              step: 1,
              unit: query.filter === 'daily' ? 'day' : 'month',
              bounds: [startDate, endDate],
            },
          },
        },
        {
          $group: {
            _id: {
              $dateTrunc: {
                date: '$createdAt',
                unit: query.filter === 'daily' ? 'day' : 'month',
              },
            },
            totalAmount: {
              $sum: {
                $cond: [{ $not: ['$amount'] }, 0, '$amount'],
              },
            },
            margin: {
              $sum: {
                $subtract: [
                  {
                    $cond: [{ $not: ['$fee'] }, 0, '$fee'],
                  },
                  {
                    $cond: [{ $not: ['$feeAdmin'] }, 0, '$feeAdmin'],
                  },
                ],
              },
            },
            partner: {
              $sum: {
                $add: [
                  {
                    $cond: [
                      {
                        $not: [
                          {
                            $ifNull: [
                              { $arrayElemAt: ['$uplineFee', 0] },
                              null,
                            ],
                          },
                        ],
                      },
                      { $arrayElemAt: ['$uplineFee.amount', 0] },
                      0,
                    ],
                  },
                  {
                    $cond: [
                      {
                        $not: [
                          {
                            $ifNull: [
                              { $arrayElemAt: ['$uplineFee', 1] },
                              null,
                            ],
                          },
                        ],
                      },
                      { $arrayElemAt: ['$uplineFee.amount', 1] },
                      0,
                    ],
                  },
                  {
                    $cond: [
                      {
                        $not: [
                          {
                            $ifNull: [
                              { $arrayElemAt: ['$uplineFee', 2] },
                              null,
                            ],
                          },
                        ],
                      },
                      { $arrayElemAt: ['$uplineFee.amount', 2] },
                      0,
                    ],
                  },
                ],
              },
            },
            qty: {
              $sum: {
                $cond: [{ $not: ['$amount'] }, 0, 1],
              },
            },
          },
        },
        {
          $sort: {
            _id: query.sortOrder === 'desc' ? -1 : 1,
          },
        },
        { $skip: skip },
        { $limit: parseInt(query.limit.toString()) },
        {
          $project: {
            _id: 0,
            date: {
              $dateToString: {
                format: query.filter === 'daily' ? '%Y-%m-%d' : '%Y-%m',
                date: '$_id',
              },
            },
            totalAmount: 1,
            qty: 1,
            margin: 1,
            partner: 1,
          },
        },
      ]);
      const success = response.initSuccess(200, true, {
        cashIn: trx,
        cashOut: wd,
        total:
          query.filter === 'daily'
            ? Math.ceil(
                (endDate.valueOf() - startDate.valueOf()) / (1000 * 3600 * 24),
              )
            : getMonthDifference(startDate, endDate),
      });
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientLogs(
    query: QueryDto,
    logId: string,
    userId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };

      const logQuery: any = {
        $match: {
          user: new Types.ObjectId(userId),
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
        },
      };

      if (user.role !== Role.Super) {
        logQuery.$match.admin = new Types.ObjectId(user.id);
      }

      if (logId !== 'all') {
        await this.LogType.findById(logId).then((logType) => {
          if (logType) {
            logQuery.$match.type = new Types.ObjectId(logType.id);
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Log Type not found'),
            );
            return res.send(error);
          }
        });
      }

      await this.Log.aggregate([
        logQuery,
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: {
            path: '$user',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'users',
            localField: 'admin',
            foreignField: '_id',
            as: 'admin',
          },
        },
        {
          $unwind: {
            path: '$admin',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'logtypes',
            localField: 'type',
            foreignField: '_id',
            as: 'type',
          },
        },
        {
          $unwind: {
            path: '$type',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: query.search
            ? {
                $or: [
                  {
                    'user.username': {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    message: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    ip: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    'admin.username': {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                ],
              }
            : {},
        },
        {
          $facet: {
            results: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $project: {
                  _id: 0,
                  id: '$_id',
                  message: 1,
                  ip: 1,
                  type: 1,
                  user: {
                    username: 1,
                  },
                  admin: {
                    username: 1,
                  },
                  createdAt: 1,
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((logs) => {
        const success = response.initSuccess(
          200,
          true,
          logs.length ? logs[0] : [],
        );
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientBalanceLogs(
    query: QueryDto,
    logTypeName: string,
    userId: string,
    res: FastifyReply,
  ) {
    try {
      await this.Balance.findOne({
        user: userId,
      }).then(async (balance) => {
        const skip = (query.page - 1) * query.limit;
        const sortOptions = {
          createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
          accessFrom: {
            'transaction.accessFrom': query.sortOrder === 'asc' ? 1 : -1,
            'withdraw.accessFrom': query.sortOrder === 'asc' ? 1 : -1,
          },
        };

        const balanceLogQuery: any = {
          $match: {
            balance: new Types.ObjectId(balance.id),
            createdAt: {
              $gte: new Date(Number(query.dateStart)),
              $lte: new Date(Number(query.dateEnd)),
            },
          },
        };

        if (logTypeName !== 'all') {
          balanceLogQuery.$match.type = logTypeName;
        }

        await this.BalanceLog.aggregate([
          balanceLogQuery,
          {
            $lookup: {
              from: 'transactions',
              let: { trxId: { $toObjectId: '$transaction' } },
              pipeline: [
                {
                  $match: { $expr: { $eq: ['$_id', '$$trxId'] } },
                },
                {
                  $lookup: {
                    from: 'methods',
                    localField: 'method',
                    foreignField: '_id',
                    as: 'method',
                  },
                },
                {
                  $unwind: {
                    path: '$method',
                    preserveNullAndEmptyArrays: true,
                  },
                },
              ],
              as: 'transaction',
            },
          },
          {
            $unwind: {
              path: '$transaction',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: 'withdraws',
              let: { wdId: { $toObjectId: '$withdraw' } },
              pipeline: [
                {
                  $match: { $expr: { $eq: ['$_id', '$$wdId'] } },
                },
                {
                  $lookup: {
                    from: 'banks',
                    localField: 'bank',
                    foreignField: '_id',
                    as: 'bank',
                  },
                },
                {
                  $unwind: {
                    path: '$bank',
                    preserveNullAndEmptyArrays: true,
                  },
                },
              ],
              as: 'withdraw',
            },
          },
          {
            $unwind: {
              path: '$withdraw',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $match: query.search
              ? {
                  $or: [
                    {
                      name: {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.transactionId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.orderId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.refId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.clientRef': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.accessFrom': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.withdrawId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.orderId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.inquiryReff': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.clientRef': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.accessFrom': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                  ],
                }
              : {},
          },
          {
            $facet: {
              results: [
                {
                  $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
                },
                { $skip: skip },
                { $limit: parseInt(query.limit.toString()) },
                {
                  $project: {
                    _id: 0,
                    id: '$_id',
                    name: 1,
                    balanceAmount: 1,
                    balanceCredit: 1,
                    type: 1,
                    transaction: {
                      id: '$transaction._id',
                      methodName: '$transaction.method.name',
                      methodType: '$transaction.method.type',
                      transactionId: '$transaction.transactionId',
                      clientRef: '$transaction.clientRef',
                      paidTime: '$transaction.paidTime',
                      accessFrom: '$transaction.accessFrom',
                    },
                    withdraw: {
                      id: '$withdraw._id',
                      bankName: '$withdraw.bank.name',
                      bankType: '$withdraw.bank.type',
                      withdrawId: '$withdraw.withdrawId',
                      clientRef: '$withdraw.clientRef',
                      accessFrom: '$withdraw.accessFrom',
                      paidDate: '$withdraw.paidDate',
                    },
                    createdAt: 1,
                  },
                },
              ],
              count: [{ $count: 'total' }],
            },
          },
          {
            $project: {
              results: 1,
              total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
            },
          },
        ]).then((logs) => {
          const success = response.initSuccess(
            200,
            true,
            logs.length ? logs[0] : [],
          );
          return res.send(success);
        });
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async actionClient(
    data: ActionClientDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
          async (logType) => {
            if (logType) {
              await this.User.aggregate([
                {
                  $match: {
                    $expr: { $eq: ['$_id', { $toObjectId: data.userId }] },
                  },
                },
                {
                  $lookup: {
                    from: 'clients',
                    localField: '_id',
                    foreignField: 'user',
                    as: 'client',
                  },
                },
                {
                  $unwind: {
                    path: '$client',
                    preserveNullAndEmptyArrays: true,
                  },
                },
                {
                  $lookup: {
                    from: 'balances',
                    localField: '_id',
                    foreignField: 'user',
                    as: 'balance',
                  },
                },
                {
                  $unwind: {
                    path: '$balance',
                    preserveNullAndEmptyArrays: true,
                  },
                },
              ]).then(async (clients) => {
                if (clients.length) {
                  const client = clients[0];
                  var newLog: LogDocument;
                  var successMessage = '';
                  switch (data.action) {
                    case ActionClientType.SetUpline:
                      await this.User.findById(data.partnerId).then(
                        async (partner) => {
                          if (partner && partner.role === Role.Partner) {
                            const updateUpline = {
                              upline: new Types.ObjectId(data.partnerId),
                            };

                            await this.User.findByIdAndUpdate(
                              client._id,
                              updateUpline,
                            );

                            await this.Commission.findOne({
                              user: partner.id,
                            }).then(async (commission) => {
                              if (!commission) {
                                const newCommission = new this.Commission({
                                  clientTrx: 0,
                                  clientTrxQty: 0,
                                  partnerTrx: 0,
                                  partnerTrxQty: 0,
                                  clientWd: 0,
                                  clientWdQty: 0,
                                  partnerWd: 0,
                                  partnerWdQty: 0,
                                  user: partner.id,
                                });

                                await newCommission.save();
                              }
                            });

                            await this.Commission.findOne({
                              upline: partner.id,
                              downline: data.userId,
                            }).then(async (commission) => {
                              if (!commission) {
                                const newCommission = new this.Commission({
                                  upline: partner.id,
                                  downline: new Types.ObjectId(data.userId),
                                  amountTrx: 0,
                                  amountTrxQty: 0,
                                  amountWd: 0,
                                  amountWdQty: 0,
                                });

                                await newCommission.save();
                              }
                            });

                            newLog = new this.Log({
                              message: `${user.username} update client ${client.client.clientName} UPLINE to ${partner.username}`,
                              ip: req.ip,
                              type: logType.id,
                              user: new Types.ObjectId(client._id),
                              admin: user.id,
                            });
                            successMessage = `Success update upline to ${partner.username}`;
                          } else {
                            const error = response.initError(
                              404,
                              false,
                              new ErrorMessage('Partner not found'),
                            );
                            return res.send(error);
                          }
                        },
                      );
                      break;
                    case ActionClientType.SetLimit:
                      const updateLimit = {
                        limit: data.limit,
                      };

                      await this.Client.findByIdAndUpdate(
                        client.client._id,
                        updateLimit,
                      );

                      newLog = new this.Log({
                        message: `${user.username} update client ${
                          client.client.clientName
                        } LIMIT to ${data.limit.toLocaleString('de-DE')}`,
                        target: client.client._id,
                        ip: req.ip,
                        type: logType.id,
                        user: new Types.ObjectId(client._id),
                        admin: user.id,
                      });
                      successMessage = `Success change limit to ${data.limit.toLocaleString(
                        'de-DE',
                      )}`;
                      break;
                    case ActionClientType.SetPaymentName:
                      const updatePaymentName = {
                        paymentClientName: data.clientName,
                        paymentCustName: data.custName,
                      };

                      await this.Client.findByIdAndUpdate(
                        client.client._id,
                        updatePaymentName,
                      );

                      newLog = new this.Log({
                        message: `${user.username} update client ${
                          client.client.clientName
                        } Payment Name to ${data.clientName ?? ''} and ${
                          data.custName ?? ''
                        }`,
                        target: client.client._id,
                        ip: req.ip,
                        type: logType.id,
                        user: new Types.ObjectId(client._id),
                        admin: user.id,
                      });
                      successMessage = `Success change payment name to  ${
                        data.clientName ?? ''
                      } and ${data.custName ?? ''}`;
                      break;
                    case ActionClientType.FreezeBalance:
                      if (data.freeze > 0) {
                        if (client.balance.balance >= data.freeze) {
                          const updateBalance = {
                            $inc: {
                              balance: -Number(data.freeze),
                              freeze: Number(data.freeze),
                            },
                          };

                          await this.Balance.findByIdAndUpdate(
                            client.balance._id,
                            updateBalance,
                          );

                          const newBalanceLog = new this.BalanceLog({
                            name: `Freezing balance ${toCurrency(data.freeze)}`,
                            balanceAmount: client.balance.balance,
                            balanceCredit: Number(data.freeze),
                            type: BalanceLogType.Issue,
                            balance: client.balance._id,
                          });

                          await newBalanceLog.save();

                          newLog = new this.Log({
                            message: `${user.username} FREEZE client ${
                              client.client.clientName
                            } balance with amount ${data.freeze.toLocaleString(
                              'de-DE',
                            )}`,
                            target: client.balance._id,
                            ip: req.ip,
                            type: logType.id,
                            user: new Types.ObjectId(client._id),
                            admin: user.id,
                          });
                          successMessage = `Success freeze balance ${data.freeze.toLocaleString(
                            'de-DE',
                          )}`;
                          break;
                        } else {
                          const error = response.initError(
                            400,
                            false,
                            new ErrorMessage(
                              'Freeze amount is more than balance',
                            ),
                          );
                          return res.send(error);
                        }
                      } else {
                        const error = response.initError(
                          400,
                          false,
                          new ErrorMessage('Freeze amount cannot lower than 0'),
                        );
                        return res.send(error);
                      }
                    case ActionClientType.ReturnBalance:
                      if (data.return > 0) {
                        if (client.balance.freeze >= data.return) {
                          const updateBalance = {
                            $inc: {
                              freeze: -Number(data.return),
                              balance: Number(data.return),
                            },
                          };

                          await this.Balance.findByIdAndUpdate(
                            client.balance._id,
                            updateBalance,
                          );

                          const newBalanceLog = new this.BalanceLog({
                            name: `Returning Freezed balance ${toCurrency(
                              data.return,
                            )}`,
                            balanceAmount: client.balance.balance,
                            balanceCredit: Number(data.return),
                            type: BalanceLogType.Refund,
                            balance: client.balance._id,
                          });

                          await newBalanceLog.save();

                          newLog = new this.Log({
                            message: `${user.username} RETURN client ${
                              client.client.clientName
                            } balance with amount ${data.return.toLocaleString(
                              'de-DE',
                            )}`,
                            target: client.balance._id,
                            ip: req.ip,
                            type: logType.id,
                            user: new Types.ObjectId(client._id),
                            admin: user.id,
                          });

                          successMessage = `Success return balance ${data.return.toLocaleString(
                            'de-DE',
                          )}`;
                          break;
                        } else {
                          const error = response.initError(
                            400,
                            false,
                            new ErrorMessage(
                              'Return amount is more than freeze',
                            ),
                          );
                          return res.send(error);
                        }
                      } else {
                        const error = response.initError(
                          400,
                          false,
                          new ErrorMessage('Return amount cannot lower than 0'),
                        );
                        return res.send(error);
                      }
                    case ActionClientType.Reset2Fa:
                      const reset2Fa = {
                        isVerified: false,
                      };

                      await this.User.findByIdAndUpdate(client._id, {
                        $set: reset2Fa,
                        $unset: {
                          secretTotp: undefined,
                        },
                      });

                      newLog = new this.Log({
                        message: `${user.username} RESET 2FA client ${client.client.clientName}`,
                        ip: req.ip,
                        type: logType.id,
                        user: new Types.ObjectId(client._id),
                        admin: user.id,
                      });

                      successMessage = `Success reset 2FA client ${client.client.clientName}`;
                      break;
                    case ActionClientType.Block:
                      const blockUser = {
                        isBlocked: true,
                      };

                      await this.User.findByIdAndUpdate(client._id, blockUser);

                      newLog = new this.Log({
                        message: `${user.username} BLOCK client ${client.client.clientName}`,
                        ip: req.ip,
                        type: logType.id,
                        user: new Types.ObjectId(client._id),
                        admin: user.id,
                      });

                      successMessage = `Success block client ${client.client.clientName}`;
                      break;
                    case ActionClientType.Unblock:
                      const unblockUser = {
                        isBlocked: false,
                      };

                      await this.User.findByIdAndUpdate(
                        client._id,
                        unblockUser,
                      );

                      newLog = new this.Log({
                        message: `${user.username} UNBLOCK client ${client.client.clientName}`,
                        ip: req.ip,
                        type: logType.id,
                        user: new Types.ObjectId(client._id),
                        admin: user.id,
                      });

                      successMessage = `Success unblock client ${client.client.clientName}`;
                      break;
                    case ActionClientType.Delete:
                      const deleteUser = {
                        isDeleted: true,
                      };

                      await this.User.findByIdAndUpdate(client._id, deleteUser);

                      newLog = new this.Log({
                        message: `${user.username} DELETE client ${client.client.clientName}`,
                        ip: req.ip,
                        type: logType.id,
                        user: new Types.ObjectId(client._id),
                        admin: user.id,
                      });

                      successMessage = `Success delete client ${client.client.clientName}`;
                      break;
                    default:
                      const error = response.initError(
                        404,
                        false,
                        new ErrorMessage('Action not found'),
                      );
                      return res.send(error);
                  }
                  await newLog.save();

                  const success = response.initSuccess(
                    200,
                    true,
                    successMessage,
                  );
                  return res.send(success);
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Client not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Log not found'),
              );
              return res.send(error);
            }
          },
        );
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getPartner(query: QueryDto, res: FastifyReply) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        username: { username: query.sortOrder === 'asc' ? 1 : -1 },
        balance: { 'balance.balance': query.sortOrder === 'asc' ? 1 : -1 },
        debt: { 'balance.debt': query.sortOrder === 'asc' ? 1 : -1 },
        freeze: { 'balance.freeze': query.sortOrder === 'asc' ? 1 : -1 },
        phone: { phone: query.sortOrder === 'asc' ? 1 : -1 },
        email: { email: query.sortOrder === 'asc' ? 1 : -1 },
      };
      await this.User.aggregate([
        {
          $match: {
            $and: [
              { role: Role.Partner, isDeleted: false },
              query.search
                ? {
                    $or: [
                      {
                        username: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        email: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        phone: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                    ],
                  }
                : {},
            ],
          },
        },
        {
          $facet: {
            results: [
              {
                $lookup: {
                  from: 'balances',
                  localField: '_id',
                  foreignField: 'user',
                  as: 'balance',
                },
              },
              {
                $unwind: {
                  path: '$balance',
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $sort: sortOptions[query.sortBy] || sortOptions.username,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $project: {
                  id: '$_id',
                  _id: 0,
                  username: 1,
                  email: 1,
                  phone: 1,
                  isBlocked: 1,
                  balance: '$balance.balance',
                  debt: '$balance.debt',
                  freeze: '$balance.freeze',
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((user) => {
        const success = response.initSuccess(200, true, user[0]);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async searchPartner(val: string, res: FastifyReply) {
    try {
      await this.User.find({
        role: Role.Partner,
        username: {
          $regex: new RegExp(val.trim(), 'i'),
        },
        isDeleted: false,
      })
        .select('username isBlocked')
        .then((partner) => {
          const success = response.initSuccess(200, true, partner);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async createPartner(
    data: CreatePartnerDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.User.findOne({
          $or: [
            {
              username: { $regex: new RegExp(data.username.trim(), 'i') },
            },
            {
              email: { $regex: new RegExp(data.email.trim(), 'i') },
            },
            {
              phone: { $regex: new RegExp(data.phone.trim(), 'i') },
            },
          ],
        }).then(async (userFound) => {
          if (userFound) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Username exist'),
            );
            return res.send(error);
          } else {
            const newUser = new this.User({
              username: data.username,
              email: data.email,
              phone: data.phone,
              pass: await encryptPass(data.pass),
              role: Role.Partner,
            });

            const savedUser = await newUser.save();

            const newBalance = new this.Balance({
              user: savedUser.id,
            });

            await newBalance.save();

            await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
              async (logType) => {
                if (logType) {
                  const newLog = new this.Log({
                    message: `${user.username} create new partner ${data.username}`,
                    ip: req.ip,
                    type: logType.id,
                    user: savedUser.id,
                    admin: user.id,
                  });

                  await newLog.save();
                }

                const success = response.initSuccess(200, true, {
                  username: data.username,
                  pass: data.pass,
                });
                return res.send(success);
              },
            );
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getPartnerOverview(id: string, res: FastifyReply) {
    try {
      const todayStart = new Date();
      todayStart.setDate(todayStart.getDate() - 1);
      todayStart.setHours(17, 0, 0, 0);
      const todayEnd = new Date();
      todayEnd.setHours(16, 59, 59, 999);

      await this.User.aggregate([
        {
          $match: {
            $expr: {
              $eq: ['$_id', { $toObjectId: id }],
            },
            isDeleted: false,
          },
        },
        // lookup the balance collection and filter by user
        {
          $lookup: {
            from: 'balances',
            let: { userId: '$_id' },
            pipeline: [
              { $match: { $expr: { $eq: ['$user', '$$userId'] } } },
              { $project: { _id: 0, balance: 1, freeze: 1, debt: 1 } },
            ],
            as: 'balance',
          },
        },
        {
          $unwind: {
            path: '$balance',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'users',
            let: { userId: '$upline' },
            pipeline: [
              { $match: { $expr: { $eq: ['$_id', '$$userId'] } } },
              { $project: { _id: 0, username: 1, isBlocked: 1, isDeleted: 1 } },
            ],
            as: 'upline',
          },
        },
        {
          $unwind: {
            path: '$upline',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'commissions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $facet: {
                  today: [
                    {
                      $match: {
                        $expr: { $eq: ['$user', '$$userId'] },
                        isActive: true,
                      },
                    },
                    {
                      $project: {
                        _id: 0,
                        partnerTrx: 1,
                        partnerTrxQty: 1,
                        clientTrx: 1,
                        clientTrxQty: 1,
                        partnerWd: 1,
                        partnerWdQty: 1,
                        clientWd: 1,
                        clientWdQty: 1,
                      },
                    },
                  ],
                  undisbursed: [
                    {
                      $match: {
                        $expr: { $eq: ['$user', '$$userId'] },
                        isActive: false,
                        isDisbursed: false,
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        partnerTrx: { $sum: '$partnerTrx' },
                        partnerTrxQty: { $sum: '$partnerTrxQty' },
                        clientTrx: { $sum: '$clientTrx' },
                        clientTrxQty: { $sum: '$clientTrxQty' },
                        partnerWd: { $sum: '$partnerWd' },
                        partnerWdQty: { $sum: '$partnerWdQty' },
                        clientWd: { $sum: '$clientWd' },
                        clientWdQty: { $sum: '$clientWdQty' },
                      },
                    },
                    {
                      $project: {
                        _id: 0,
                        partnerTrx: 1,
                        partnerTrxQty: 1,
                        clientTrx: 1,
                        clientTrxQty: 1,
                        partnerWd: 1,
                        partnerWdQty: 1,
                        clientWd: 1,
                        clientWdQty: 1,
                      },
                    },
                  ],
                  disbursed: [
                    {
                      $match: {
                        $expr: { $eq: ['$user', '$$userId'] },
                        isActive: false,
                        isDisbursed: true,
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        partnerTrx: { $sum: '$partnerTrx' },
                        partnerTrxQty: { $sum: '$partnerTrxQty' },
                        clientTrx: { $sum: '$clientTrx' },
                        clientTrxQty: { $sum: '$clientTrxQty' },
                        partnerWd: { $sum: '$partnerWd' },
                        partnerWdQty: { $sum: '$partnerWdQty' },
                        clientWd: { $sum: '$clientWd' },
                        clientWdQty: { $sum: '$clientWdQty' },
                      },
                    },
                    {
                      $project: {
                        _id: 0,
                        partnerTrx: 1,
                        partnerTrxQty: 1,
                        clientTrx: 1,
                        clientTrxQty: 1,
                        partnerWd: 1,
                        partnerWdQty: 1,
                        clientWd: 1,
                        clientWdQty: 1,
                      },
                    },
                  ],
                  all: [
                    {
                      $match: {
                        $expr: { $eq: ['$user', '$$userId'] },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        partnerTrx: { $sum: '$partnerTrx' },
                        partnerTrxQty: { $sum: '$partnerTrxQty' },
                        clientTrx: { $sum: '$clientTrx' },
                        clientTrxQty: { $sum: '$clientTrxQty' },
                        partnerWd: { $sum: '$partnerWd' },
                        partnerWdQty: { $sum: '$partnerWdQty' },
                        clientWd: { $sum: '$clientWd' },
                        clientWdQty: { $sum: '$clientWdQty' },
                      },
                    },
                    {
                      $project: {
                        _id: 0,
                        partnerTrx: 1,
                        partnerTrxQty: 1,
                        clientTrx: 1,
                        clientTrxQty: 1,
                        partnerWd: 1,
                        partnerWdQty: 1,
                        clientWd: 1,
                        clientWdQty: 1,
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  today: { $arrayElemAt: ['$today', 0] },
                  undisbursed: { $arrayElemAt: ['$undisbursed', 0] },
                  disbursed: { $arrayElemAt: ['$disbursed', 0] },
                  all: { $arrayElemAt: ['$all', 0] },
                },
              },
            ],
            as: 'commission',
          },
        },
        {
          $unwind: {
            path: '$commission',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'withdraws',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      { $eq: ['$process', WithdrawProcess.Process] },
                      { $eq: ['$withdrawType', WithdrawType.Partner] },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'withdraw',
          },
        },
        {
          $unwind: {
            path: '$withdraw',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 1,
            username: 1,
            email: 1,
            phone: 1,
            upline: 1,
            isBlocked: 1,
            createdAt: 1,
            updatedAt: 1,
            commission: 1,
            withdraw: {
              $let: {
                vars: {
                  withdrawData: {
                    $ifNull: ['$withdraw', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$withdrawData', null] },
                    then: null,
                    else: '$$withdrawData',
                  },
                },
              },
            },
            balance: {
              $let: {
                vars: {
                  balanceData: {
                    $ifNull: ['$balance', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$balanceData', null] },
                    then: null,
                    else: '$$balanceData',
                  },
                },
              },
            },
          },
        },
      ]).then((user) => {
        if (user.length) {
          const success = response.initSuccess(200, true, user[0]);
          return res.send(success);
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Partner not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getPartnerClient(query: QueryDto, id: string, res: FastifyReply) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        username: { username: query.sortOrder === 'asc' ? 1 : -1 },
        amountTrx: { amountTrx: query.sortOrder === 'asc' ? 1 : -1 },
        amountWd: { amountWd: query.sortOrder === 'asc' ? 1 : -1 },
        status: { status: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      await this.User.aggregate([
        {
          $match: {
            $and: [
              {
                $expr: {
                  $eq: ['$upline', { $toObjectId: id }],
                },
              },
              { role: Role.Client },
              { isDeleted: false },
              query.search
                ? {
                    username: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  }
                : {},
            ],
          },
        },
        {
          $sort: sortOptions[query.sortBy] || sortOptions.username,
        },
        { $skip: skip },
        { $limit: parseInt(query.limit.toString()) },
        {
          $lookup: {
            from: 'commissions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      {
                        $eq: ['$downline', '$$userId'],
                      },
                      {
                        $eq: ['$upline', { $toObjectId: id }],
                      },
                    ],
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  amountTrx: 1,
                  amountTrxQty: 1,
                  amountWd: 1,
                  amountWdQty: 1,
                },
              },
            ],
            as: 'commission',
          },
        },
        {
          $unwind: {
            path: '$commission',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 0,
            id: '$_id',
            username: 1,
            isBlocked: 1,
            createdAt: 1,
            amountTrx: '$commission.amountTrx',
            amountTrxQty: '$commission.amountTrxQty',
            amountWd: '$commission.amountWd',
            amountWdQty: '$commission.amountWdQty',
          },
        },
      ]).then((users) => {
        const success = response.initSuccess(200, true, users);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getPartnerTeam(query: QueryDto, id: string, res: FastifyReply) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        username: { username: query.sortOrder === 'asc' ? 1 : -1 },
        amountTrx: { amountTrx: query.sortOrder === 'asc' ? 1 : -1 },
        amountWd: { amountWd: query.sortOrder === 'asc' ? 1 : -1 },
        status: { status: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      await this.User.aggregate([
        {
          $match: {
            $and: [
              {
                $expr: {
                  $eq: ['$upline', { $toObjectId: id }],
                },
              },
              { role: Role.Partner },
              { isDeleted: false },
              query.search
                ? {
                    username: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  }
                : {},
            ],
          },
        },
        {
          $sort: sortOptions[query.sortBy] || sortOptions.username,
        },
        { $skip: skip },
        { $limit: parseInt(query.limit.toString()) },
        {
          $lookup: {
            from: 'commissions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      {
                        $eq: ['$downline', '$$userId'],
                      },
                      {
                        $eq: ['$upline', { $toObjectId: id }],
                      },
                    ],
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  amountTrx: 1,
                  amountTrxQty: 1,
                  amountWd: 1,
                  amountWdQty: 1,
                },
              },
            ],
            as: 'commission',
          },
        },
        {
          $unwind: {
            path: '$commission',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 0,
            id: '$_id',
            username: 1,
            isBlocked: 1,
            createdAt: 1,
            amountTrx: '$commission.amountTrx',
            amountTrxQty: '$commission.amountTrxQty',
            amountWd: '$commission.amountWd',
            amountWdQty: '$commission.amountWdQty',
          },
        },
      ]).then((users) => {
        const success = response.initSuccess(200, true, users);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getPartnerWithdraw(
    query: QueryDto,
    id: string,
    process: string,
    res: FastifyReply,
  ) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        withdrawId: { withdrawId: query.sortOrder === 'asc' ? 1 : -1 },
        orderId: { orderId: query.sortOrder === 'asc' ? 1 : -1 },
        name: { name: query.sortOrder === 'asc' ? 1 : -1 },
        accNumber: { accNumber: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        status: { status: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const withdrawQuery: any = {
        user: new Types.ObjectId(id),
        process,
        withdrawType: WithdrawType.Partner,
        $or: [
          { withdrawId: { $regex: query.search.trim(), $options: 'i' } },
          { orderId: { $regex: query.search.trim(), $options: 'i' } },
          { name: { $regex: query.search.trim(), $options: 'i' } },
          { accNumber: { $regex: query.search.trim(), $options: 'i' } },
        ],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        withdrawQuery.status = query.filter.trim();
      }

      await this.Withdraw.find(withdrawQuery)
        .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
        .skip(skip)
        .limit(query.limit)
        .populate({
          path: 'bank',
          select: '-_id name',
        })
        .populate({
          path: 'processedBy',
          select: '-_id username',
        })
        .select(
          '_id withdrawId orderId name accNumber amount feeAdmin status createdAt processedBy',
        )
        .then(async (withdraws) => {
          const total = await this.Withdraw.countDocuments(withdrawQuery);
          const success = response.initSuccess(200, true, {
            withdraws,
            total,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getPartnerCommission(query: QueryDto, id: string, res: FastifyReply) {
    try {
      const queryData: any = {
        user: new Types.ObjectId(id),
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };
      await this.Commission.find(queryData)
        .select('-isActive -updatedAt -__v -user')
        .then((commission) => {
          const success = response.initSuccess(200, true, commission);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getPartnerLogs(
    query: QueryDto,
    logId: string,
    userId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const logQuery: any = {
        $match: {
          user: new Types.ObjectId(userId),
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
        },
      };

      if (user.role !== Role.Super) {
        logQuery.$match.admin = new Types.ObjectId(user.id);
      }

      if (logId !== 'all') {
        await this.LogType.findById(logId).then(async (logType) => {
          if (logType) {
            if (
              ![
                LogTypes.ClientDisburse,
                LogTypes.ClientTopup,
                LogTypes.ClientUpdate,
              ].includes(logType.type as LogTypes)
            ) {
              logQuery.$match.type = new Types.ObjectId(logType.id);
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Log type not valid'),
              );
              return res.send(error);
            }
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Log type not found'),
            );
            return res.send(error);
          }
        });
      }
      await this.Log.aggregate([
        logQuery,
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: {
            path: '$user',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'users',
            localField: 'admin',
            foreignField: '_id',
            as: 'admin',
          },
        },
        {
          $unwind: {
            path: '$admin',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'logtypes',
            localField: 'type',
            foreignField: '_id',
            as: 'type',
          },
        },
        {
          $unwind: {
            path: '$type',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: query.search
            ? {
                $or: [
                  {
                    'user.username': {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    message: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    ip: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    'admin.username': {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                ],
              }
            : {},
        },
        {
          $facet: {
            results: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $project: {
                  _id: 0,
                  id: '$_id',
                  message: 1,
                  ip: 1,
                  type: 1,
                  user: {
                    username: 1,
                  },
                  admin: {
                    username: 1,
                  },
                  createdAt: 1,
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((logs) => {
        const success = response.initSuccess(
          200,
          true,
          logs.length ? logs[0] : [],
        );
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getPartnerBalanceLogs(
    query: QueryDto,
    logTypeName: string,
    userId: string,
    res: FastifyReply,
  ) {
    try {
      await this.Balance.findOne({ user: userId }).then(async (balance) => {
        const skip = (query.page - 1) * query.limit;
        const sortOptions = {
          createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
          accessFrom: {},
        };

        if (logTypeName === BalanceLogType.In) {
          sortOptions.accessFrom['transaction.accessFrom'] =
            query.sortOrder === 'asc' ? 1 : -1;
        } else if (logTypeName === BalanceLogType.Out) {
          sortOptions.accessFrom['withdraw.accessFrom'] =
            query.sortOrder === 'asc' ? 1 : -1;
        }

        const balanceLogQuery: any = {
          $match: {
            balance: new Types.ObjectId(balance.id),
            createdAt: {
              $gte: new Date(Number(query.dateStart)),
              $lte: new Date(Number(query.dateEnd)),
            },
          },
        };

        if (logTypeName !== 'all') {
          balanceLogQuery.$match.type = logTypeName;
        }
        await this.BalanceLog.aggregate([
          balanceLogQuery,
          {
            $lookup: {
              from: 'transactions',
              localField: 'transaction',
              foreignField: '_id',
              as: 'transaction',
            },
          },
          {
            $unwind: {
              path: '$transaction',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: 'withdraws',
              localField: 'withdraw',
              foreignField: '_id',
              as: 'withdraw',
            },
          },
          {
            $unwind: {
              path: '$withdraw',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $match: query.search
              ? {
                  $or: [
                    {
                      name: {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.transactionId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.orderId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.refId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.clientRef': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.accessFrom': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.withdrawId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.orderId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.inquiryReff': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.clientRef': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.accessFrom': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                  ],
                }
              : {},
          },
          {
            $facet: {
              results: [
                {
                  $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
                },
                { $skip: skip },
                { $limit: parseInt(query.limit.toString()) },
                {
                  $project: {
                    _id: 0,
                    id: '$_id',
                    name: 1,
                    balanceAmount: 1,
                    balanceCredit: 1,
                    type: 1,
                    transaction: {
                      id: '$transaction._id',
                      accessFrom: '$transaction.accessFrom',
                    },
                    withdraw: {
                      id: '$withdraw._id',
                      accessFrom: '$withdraw.accessFrom',
                    },
                    createdAt: 1,
                  },
                },
              ],
              count: [{ $count: 'total' }],
            },
          },
          {
            $project: {
              results: 1,
              total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
            },
          },
        ]).then((logs) => {
          const success = response.initSuccess(
            200,
            true,
            logs.length ? logs[0] : [],
          );
          return res.send(success);
        });
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async actionPartner(
    data: ActionPartnerDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
          async (logType) => {
            if (logType) {
              await this.User.aggregate([
                {
                  $match: {
                    $expr: { $eq: ['$_id', { $toObjectId: data.userId }] },
                  },
                },
                {
                  $lookup: {
                    from: 'balances',
                    localField: '_id',
                    foreignField: 'user',
                    as: 'balance',
                  },
                },
                {
                  $unwind: {
                    path: '$balance',
                    preserveNullAndEmptyArrays: true,
                  },
                },
              ]).then(async (partners) => {
                if (partners.length) {
                  const partner = partners[0];
                  var newLog: LogDocument;
                  var successMessage = '';
                  switch (data.action) {
                    case ActionClientType.SetUpline:
                      await this.User.findById(data.partnerId).then(
                        async (partnerData) => {
                          if (
                            partnerData &&
                            partnerData.role === Role.Partner
                          ) {
                            const updateUpline = {
                              upline: partnerData.id,
                            };

                            await this.User.findByIdAndUpdate(
                              partner._id,
                              updateUpline,
                            );

                            await this.Commission.findOne({
                              user: partnerData.id,
                            }).then(async (commission) => {
                              if (!commission) {
                                const newCommission = new this.Commission({
                                  clientTrx: 0,
                                  clientTrxQty: 0,
                                  partnerTrx: 0,
                                  partnerTrxQty: 0,
                                  clientWd: 0,
                                  clientWdQty: 0,
                                  partnerWd: 0,
                                  partnerWdQty: 0,
                                  user: partnerData.id,
                                });

                                await newCommission.save();
                              }
                            });

                            await this.Commission.findOne({
                              upline: partnerData.id,
                              downline: partner._id,
                            }).then(async (commission) => {
                              if (!commission) {
                                const newCommission = new this.Commission({
                                  amountTrx: 0,
                                  amountTrxQty: 0,
                                  amountWd: 0,
                                  amountWdQty: 0,
                                  upline: partnerData.id,
                                  downline: new Types.ObjectId(partner._id),
                                });

                                await newCommission.save();
                              }
                            });

                            newLog = new this.Log({
                              message: `${user.username} update partner ${partner.username} UPLINE to ${partnerData.username}`,
                              ip: req.ip,
                              type: logType.id,
                              user: new Types.ObjectId(partner._id),
                              admin: user.id,
                            });

                            successMessage = `Success update upline to ${partnerData.username}`;
                          } else {
                            const error = response.initError(
                              404,
                              false,
                              new ErrorMessage('Partner not found'),
                            );
                            return res.send(error);
                          }
                        },
                      );
                      break;
                    case ActionClientType.FreezeBalance:
                      if (data.freeze > 0) {
                        if (partner.balance.balance >= data.freeze) {
                          const updateBalance = {
                            $inc: {
                              balance: -Number(data.freeze),
                              freeze: Number(data.freeze),
                            },
                          };

                          await this.Balance.findByIdAndUpdate(
                            partner.balance._id,
                            updateBalance,
                          );

                          const newBalanceLog = new this.BalanceLog({
                            name: `Freezing balance ${toCurrency(data.freeze)}`,
                            balanceAmount: partner.balance.balance,
                            balanceCredit: Number(data.freeze),
                            type: BalanceLogType.Issue,
                            balance: partner.balance._id,
                          });

                          await newBalanceLog.save();

                          newLog = new this.Log({
                            message: `${user.username} FREEZE partner ${
                              partner.username
                            } balance with amount ${data.freeze.toLocaleString(
                              'de-DE',
                            )}`,
                            target: partner.balance._id,
                            ip: req.ip,
                            type: logType.id,
                            user: new Types.ObjectId(partner._id),
                            admin: user.id,
                          });

                          successMessage = `Success freeze balance ${data.freeze.toLocaleString(
                            'de-DE',
                          )}`;
                          break;
                        } else {
                          const error = response.initError(
                            400,
                            false,
                            new ErrorMessage(
                              'Freeze amount is more than balance',
                            ),
                          );
                          return res.send(error);
                        }
                      } else {
                        const error = response.initError(
                          400,
                          false,
                          new ErrorMessage('Freeze amount cannot lower than 0'),
                        );
                        return res.send(error);
                      }
                    case ActionClientType.ReturnBalance:
                      if (data.return > 0) {
                        if (partner.balance.freeze >= data.return) {
                          const updateBalance = {
                            $inc: {
                              freeze: -Number(data.return),
                              balance: Number(data.return),
                            },
                          };

                          await this.Balance.findByIdAndUpdate(
                            partner.balance._id,
                            updateBalance,
                          );

                          const newBalanceLog = new this.BalanceLog({
                            name: `Returning Freezed balance ${toCurrency(
                              data.return,
                            )}`,
                            balanceAmount: partner.balance.balance,
                            balanceCredit: Number(data.return),
                            type: BalanceLogType.Refund,
                            balance: partner.balance._id,
                          });

                          await newBalanceLog.save();

                          newLog = new this.Log({
                            message: `${user.username} RETURN partner ${
                              partner.username
                            } balance with amount ${data.return.toLocaleString(
                              'de-DE',
                            )}`,
                            target: partner.balance._id,
                            ip: req.ip,
                            type: logType.id,
                            user: new Types.ObjectId(partner._id),
                            admin: user.id,
                          });

                          successMessage = `Success return balance ${data.return.toLocaleString(
                            'de-DE',
                          )}`;
                          break;
                        } else {
                          const error = response.initError(
                            400,
                            false,
                            new ErrorMessage(
                              'Return amount is more than freeze',
                            ),
                          );
                          return res.send(error);
                        }
                      } else {
                        const error = response.initError(
                          400,
                          false,
                          new ErrorMessage('Return amount cannot lower than 0'),
                        );
                        return res.send(error);
                      }
                    case ActionClientType.Block:
                      const blockUser = {
                        isBlocked: true,
                      };

                      await this.User.findByIdAndUpdate(partner._id, blockUser);

                      newLog = new this.Log({
                        message: `${user.username} BLOCK partner ${partner.username}`,
                        ip: req.ip,
                        type: logType.id,
                        user: new Types.ObjectId(partner._id),
                        admin: user.id,
                      });

                      successMessage = `Success block partner ${partner.username}`;
                      break;
                    case ActionClientType.Unblock:
                      const unblockUser = {
                        isBlocked: false,
                      };

                      await this.User.findByIdAndUpdate(
                        partner._id,
                        unblockUser,
                      );

                      newLog = new this.Log({
                        message: `${user.username} UNBLOCK partner ${partner.username}`,
                        ip: req.ip,
                        type: logType.id,
                        user: new Types.ObjectId(partner._id),
                        admin: user.id,
                      });

                      successMessage = `Success unblock partner ${partner.username}`;
                      break;
                    case ActionClientType.Delete:
                      const deleteUser = {
                        isDeleted: true,
                      };

                      await this.User.findByIdAndUpdate(
                        partner._id,
                        deleteUser,
                      );

                      newLog = new this.Log({
                        message: `${user.username} DELETE partner ${partner.username}`,
                        ip: req.ip,
                        type: logType.id,
                        user: new Types.ObjectId(partner._id),
                        admin: user.id,
                      });

                      successMessage = `Success delete partner ${partner.username}`;
                      break;
                    default:
                      const error = response.initError(
                        404,
                        false,
                        new ErrorMessage('Action not found'),
                      );
                      return res.send(error);
                  }
                  await newLog.save();

                  const success = response.initSuccess(
                    200,
                    true,
                    successMessage,
                  );
                  return res.send(success);
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Partner not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Log not found'),
              );
              return res.send(error);
            }
          },
        );
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getUser(query: QueryDto, res: FastifyReply) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        email: { email: query.sortOrder === 'desc' ? -1 : 1 },
        createdAt: { createdAt: query.sortOrder === 'desc' ? -1 : 1 },
        balance: { balance: query.sortOrder === 'desc' ? -1 : 1 },
      };
      await this.User.aggregate([
        {
          $match: {
            $and: [
              { role: Role.User, isDeleted: false },
              query.search
                ? {
                    $or: [
                      {
                        email: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                      {
                        username: {
                          $regex: new RegExp(query.search.trim(), 'i'),
                        },
                      },
                    ],
                  }
                : {},
            ],
          },
        },
        {
          $facet: {
            results: [
              {
                $lookup: {
                  from: 'balances',
                  localField: '_id',
                  foreignField: 'user',
                  as: 'balance',
                },
              },
              {
                $unwind: {
                  path: '$balance',
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $sort: sortOptions[query.sortBy] || { balance: -1 },
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $project: {
                  id: '$_id',
                  _id: 0,
                  username: 1,
                  email: 1,
                  isBlocked: 1,
                  balance: '$balance.balance',
                  createdAt: 1,
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((user) => {
        const success = response.initSuccess(200, true, user[0]);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getUserOverview(id: string, res: FastifyReply) {
    try {
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const todayEnd = new Date();
      todayEnd.setHours(23, 59, 59, 999);

      await this.User.aggregate([
        {
          $match: {
            $expr: {
              $eq: ['$_id', { $toObjectId: id }],
            },
            isDeleted: false,
          },
        },
        // lookup the transactions collection and filter by 'Paid' status
        {
          $lookup: {
            from: 'transactions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      {
                        $eq: ['$transactionType', TransactionType.Transaction],
                      },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'transaction',
          },
        },
        {
          $unwind: {
            path: '$transaction',
            preserveNullAndEmptyArrays: true,
          },
        },
        // lookup the balance collection and filter by user
        {
          $lookup: {
            from: 'balances',
            let: { userId: '$_id' },
            pipeline: [
              { $match: { $expr: { $eq: ['$user', '$$userId'] } } },
              { $project: { _id: 0, balance: 1 } },
            ],
            as: 'balance',
          },
        },
        {
          $unwind: {
            path: '$balance',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 0,
            username: 1,
            email: 1,
            isBlocked: 1,
            createdAt: 1,
            transaction: {
              $let: {
                vars: {
                  transactionData: {
                    $ifNull: ['$transaction', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$transactionData', null] },
                    then: null,
                    else: '$$transactionData',
                  },
                },
              },
            },
            balance: '$balance.balance',
          },
        },
      ]).then((user) => {
        if (user.length) {
          const success = response.initSuccess(200, true, user[0]);
          return res.send(success);
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Client not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getUserTransaction(id: string, res: FastifyReply) {
    try {
      await this.Transaction.find({
        user: new Types.ObjectId(id),
        transactionType: TransactionType.Transaction,
      })
        .sort({ createdAt: -1 })
        .populate({
          path: 'product',
          select: '-_id name price',
        })
        .select('amount status createdAt paidTime')
        .then((transaction) => {
          const success = response.initSuccess(200, true, transaction);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getUserTransactionDetail(
    id: string,
    transId: string,
    res: FastifyReply,
  ) {
    try {
      this.Transaction.aggregate([
        {
          $match: {
            $expr: {
              $and: [
                { $eq: ['$_id', { $toObjectId: transId }] },
                { $eq: ['$user', { $toObjectId: id }] },
              ],
            },
          },
        },
        {
          $lookup: {
            from: 'methods',
            let: { methodId: '$method' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $eq: ['$_id', { $toObjectId: '$$methodId' }],
                  },
                },
              },
              { $project: { _id: 0, name: 1, img: 1, type: 1 } },
            ],
            as: 'method',
          },
        },
        {
          $unwind: '$method',
        },
        {
          $lookup: {
            from: 'products',
            let: { productId: '$product' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $eq: ['$_id', '$$productId'],
                  },
                },
              },
              {
                $lookup: {
                  from: 'brandtypes',
                  let: { brandTypeId: '$brandType' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $eq: ['$_id', '$$brandTypeId'],
                        },
                      },
                    },
                    {
                      $lookup: {
                        from: 'brands',
                        let: { brandId: '$brand' },
                        pipeline: [
                          {
                            $match: {
                              $expr: {
                                $eq: ['$_id', '$$brandId'],
                              },
                            },
                          },
                          { $project: { _id: 0, brandName: 1, brandImg: 1 } },
                        ],
                        as: 'brand',
                      },
                    },
                  ],
                  as: 'brandType',
                },
              },
              {
                $project: { name: 1, price: 1, code: 1, brandType: 1 },
              },
            ],
            as: 'product',
          },
        },
        {
          $unwind: '$product',
        },
        {
          $unwind: '$product.brandType',
        },
        {
          $unwind: '$product.brandType.brand',
        },
        {
          $addFields: {
            brand: '$product.brandType.brand',
          },
        },
        {
          $lookup: {
            from: 'balancelogs',
            let: { transactionId: '$_id' },
            pipeline: [
              {
                $lookup: {
                  from: 'balances',
                  let: { userId: { $toObjectId: id } },
                  pipeline: [
                    {
                      $match: {
                        $expr: { $eq: ['$user', '$$userId'] },
                      },
                    },
                  ],
                  as: 'balanceUser',
                },
              },
              {
                $unwind: '$balanceUser',
              },
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$transaction', '$$transactionId'] },
                      {
                        $eq: ['$balance', { $toObjectId: '$balanceUser._id' }],
                      },
                    ],
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  balance: 0,
                  transaction: 0,
                  updatedAt: 0,
                  balanceUser: 0,
                  __v: 0,
                },
              },
              {
                $sort: { createdAt: -1 },
              },
            ],
            as: 'logs',
          },
        },
        {
          $project: {
            _id: 1,
            form: 1,
            email: 1,
            orderId: 1,
            transactionId: 1,
            refId: 1,
            amount: 1,
            fee: 1,
            feeAdmin: 1,
            usedBalance: 1,
            phone: 1,
            payment: 1,
            url: 1,
            exp: 1,
            status: 1,
            paidRef: 1,
            paidTime: 1,
            serialNumber: 1,
            error: 1,
            dfTrxId: 1,
            dfSn: 1,
            createdAt: 1,
            updatedAt: 1,
            method: 1,
            brand: 1,
            logs: 1,
            product: { name: 1, price: 1, code: 1 },
          },
        },
      ]).then((transactions) => {
        if (transactions.length) {
          const success = response.initSuccess(200, true, transactions[0]);
          return res.send(success);
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Transaction not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getProviderList(query: QueryDto, type: string, res: FastifyReply) {
    try {
      const userRoot = await this.User.findOne({
        role: Role.Root,
      }).exec();

      const filter: any = {
        isActive: true,
        user:
          type === 'root'
            ? new Types.ObjectId(userRoot.id)
            : { $ne: new Types.ObjectId(userRoot.id) },
      };
      const project: any = {
        code: 1,
        name: 1,
        isKey: {
          $let: {
            vars: {
              keyData: {
                $ifNull: ['$key', null],
              },
            },
            in: {
              $cond: {
                if: { $eq: ['$$keyData', null] },
                then: false,
                else: true,
              },
            },
          },
        },
      };

      if (query.search) {
        filter.name = {
          $regex: new RegExp(query.search.trim(), 'i'),
        };
      }

      const aggregate: any = [
        {
          $match: filter,
        },
        {
          $sort: {
            name: -1,
          },
        },
      ];

      if (type !== 'root') {
        project.owner = {
          username: '$user.username',
          userId: '$user._id',
        };

        aggregate.push({
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        });

        aggregate.push({
          $unwind: '$user',
        });
      }

      aggregate.push({
        $project: project,
      });

      // if (type === 'root') {
      //   filter.user = new Types.ObjectId(userRoot.id);
      // } else {
      //   filter.user = { $ne: new Types.ObjectId(userRoot.id) };

      // }

      await this.Provider.aggregate(aggregate).then((provider) => {
        const success = response.initSuccess(200, true, provider);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getProviderKey(
    data: GetProviderKeyDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        if (user.secret2Fa && user.isVerified) {
          const keyDec = decrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', user.id).substring(0, 32),
            hash('sha256', user.id + user.username).substring(0, 16),
            user.secret2Fa,
          );

          if (!authenticator.check(data.otp, keyDec)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Invalid 2FA Code'),
            );
            return res.send(error);
          }

          const userRoot = await this.User.findOne({
            role: Role.Root,
          }).exec();
          await this.Provider.findOne({
            _id: payload.providerId,
            user: userRoot.id,
            isActive: true,
          }).then((provider) => {
            if (provider && provider.key) {
              const keyDec2 = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', provider.id).substring(0, 32),
                hash('sha256', userRoot.id + provider.code).substring(0, 16),
                provider.key,
              );

              const success = response.initSuccess(200, true, {
                key: keyDec2,
                storeId: provider.storeId,
              });
              return res.send(success);
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Provider not found'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Please setup 2FA first'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature Invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async addProvider(
    data: AddProviderDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (
        Object.values(ProviderCodeType).includes(data.code as ProviderCodeType)
      ) {
        const { user, browser } = req.user;
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };

        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (data.signature === signatureVerify) {
          await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
            async (logType) => {
              if (logType) {
                const userRoot = await this.User.findOne({
                  role: Role.Root,
                }).exec();
                await this.Provider.findOne({
                  user: userRoot.id,
                  isActive: true,
                  name: {
                    $regex: new RegExp(data.name, 'i'),
                  },
                }).then(async (providerFound) => {
                  if (providerFound) {
                    const error = response.initError(
                      403,
                      false,
                      new ErrorMessage('Name already exist'),
                    );
                    return res.send(error);
                  } else {
                    const newProvider = new this.Provider({
                      code: data.code,
                      name: data.name,
                      user: userRoot.id,
                    });
                    await newProvider.save();

                    const newLog = new this.Log({
                      message: `${user.username} add ROOT provider ${data.name}`,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });
                    await newLog.save();

                    const success = response.initSuccess(200, true, true);
                    return res.send(success);
                  }
                });
              } else {
                const error = response.initError(
                  404,
                  false,
                  new ErrorMessage('Log not found'),
                );
                return res.send(error);
              }
            },
          );
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          404,
          false,
          new ErrorMessage(`${data.code} not exist`),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateProvider(
    data: UpdateProviderDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
          async (logType) => {
            if (logType) {
              const userRoot = await this.User.findOne({
                role: Role.Root,
              }).exec();
              await this.Provider.findOne({
                user: userRoot.id,
                _id: new Types.ObjectId(data.providerId),
              }).then(async (providerFound) => {
                if (providerFound) {
                  if (data.name) {
                    providerFound.name = data.name;
                    const newLog = new this.Log({
                      message: `${user.username} update ROOT provider name to ${data.name}`,
                      target: providerFound.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                  }
                  if (data.storeId) {
                    providerFound.storeId = data.storeId;
                    const newLog = new this.Log({
                      message: `${user.username} update ROOT provider store ID to ${data.storeId}`,
                      target: providerFound.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                  }
                  if (data.key) {
                    const keyEnc = encrypt(
                      process.env.ENCRYPT_ALG,
                      hash('sha256', providerFound.id).substring(0, 32),
                      hash(
                        'sha256',
                        userRoot.id + providerFound.code,
                      ).substring(0, 16),
                      data.key,
                    );
                    providerFound.key = keyEnc;
                    const newLog = new this.Log({
                      message: `${user.username} update ROOT provider key`,
                      target: providerFound.id,
                      ip: req.ip,
                      type: logType.id,
                      admin: user.id,
                    });

                    await newLog.save();
                  }

                  await providerFound.save();
                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Provider not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Log not found'),
              );
              return res.send(error);
            }
          },
        );
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async deleteProvider(
    data: UpdateProviderDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
          async (logType) => {
            if (logType) {
              const userRoot = await this.User.findOne({
                role: Role.Root,
              }).exec();
              await this.Provider.findOne({
                user: userRoot.id,
                _id: new Types.ObjectId(data.providerId),
              }).then(async (providerFound) => {
                if (providerFound) {
                  providerFound.isActive = false;
                  const newLog = new this.Log({
                    message: `${user.username} delete ROOT provider ${providerFound.name}`,
                    target: providerFound.id,
                    ip: req.ip,
                    type: logType.id,
                    admin: user.id,
                  });

                  await newLog.save();

                  await this.Fee.updateMany(
                    {
                      provider: providerFound.id,
                    },
                    {
                      $unset: {
                        provider: 1,
                      },
                    },
                  );

                  await providerFound.save();
                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Provider not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Log not found'),
              );
              return res.send(error);
            }
          },
        );
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getProviderProvince(providerId: string, res: FastifyReply) {
    try {
      await this.Provider.findById(providerId)
        .populate('providerRoot')
        .then(async (provider: any) => {
          if (provider && provider.key) {
            var providerKey = '';
            if (provider.key === 'root') {
              providerKey = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', provider.providerRoot.id).substring(0, 32),
                hash(
                  'sha256',
                  provider.providerRoot.user + provider.providerRoot.code,
                ).substring(0, 16),
                provider.providerRoot.key,
              );
            } else {
              providerKey = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', provider.id).substring(0, 32),
                hash('sha256', provider.user + provider.code).substring(0, 16),
                provider.key,
              );
            }

            const key = JSON.parse(providerKey);

            const accessToken = await this.providerService.getBncAccessToken(
              key.clientId,
            );

            const province = await this.providerService.getBncProvince(
              key.clientId,
              accessToken,
            );

            const success = response.initSuccess(200, true, province);
            return res.send(success);
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Provider not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getProviderCity(
    providerId: string,
    provinceId: string,
    res: FastifyReply,
  ) {
    try {
      await this.Provider.findById(providerId)
        .populate('providerRoot')
        .then(async (provider: any) => {
          if (provider && provider.key) {
            var providerKey = '';
            if (provider.key === 'root') {
              providerKey = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', provider.providerRoot.id).substring(0, 32),
                hash(
                  'sha256',
                  provider.providerRoot.user + provider.providerRoot.code,
                ).substring(0, 16),
                provider.providerRoot.key,
              );
            } else {
              providerKey = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', provider.id).substring(0, 32),
                hash('sha256', provider.user + provider.code).substring(0, 16),
                provider.key,
              );
            }

            const key = JSON.parse(providerKey);

            const accessToken = await this.providerService.getBncAccessToken(
              key.clientId,
            );

            const city = await this.providerService.getBncCity(
              key.clientId,
              accessToken,
              provinceId,
            );

            const success = response.initSuccess(200, true, city);
            return res.send(success);
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Provider not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getProviderDistrict(
    providerId: string,
    cityId: string,
    res: FastifyReply,
  ) {
    try {
      await this.Provider.findById(providerId)
        .populate('providerRoot')
        .then(async (provider: any) => {
          if (provider && provider.key) {
            var providerKey = '';
            if (provider.key === 'root') {
              providerKey = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', provider.providerRoot.id).substring(0, 32),
                hash(
                  'sha256',
                  provider.providerRoot.user + provider.providerRoot.code,
                ).substring(0, 16),
                provider.providerRoot.key,
              );
            } else {
              providerKey = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', provider.id).substring(0, 32),
                hash('sha256', provider.user + provider.code).substring(0, 16),
                provider.key,
              );
            }

            const key = JSON.parse(providerKey);

            const accessToken = await this.providerService.getBncAccessToken(
              key.clientId,
            );

            const district = await this.providerService.getBncDistrict(
              key.clientId,
              accessToken,
              cityId,
            );

            const success = response.initSuccess(200, true, district);
            return res.send(success);
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Provider not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getProviderPost(
    providerId: string,
    districtId: string,
    res: FastifyReply,
  ) {
    try {
      await this.Provider.findById(providerId)
        .populate('providerRoot')
        .then(async (provider: any) => {
          if (provider && provider.key) {
            var providerKey = '';
            if (provider.key === 'root') {
              providerKey = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', provider.providerRoot.id).substring(0, 32),
                hash(
                  'sha256',
                  provider.providerRoot.user + provider.providerRoot.code,
                ).substring(0, 16),
                provider.providerRoot.key,
              );
            } else {
              providerKey = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', provider.id).substring(0, 32),
                hash('sha256', provider.user + provider.code).substring(0, 16),
                provider.key,
              );
            }

            const key = JSON.parse(providerKey);

            const accessToken = await this.providerService.getBncAccessToken(
              key.clientId,
            );

            const postal = await this.providerService.getBncPostal(
              key.clientId,
              accessToken,
              districtId,
            );

            const success = response.initSuccess(200, true, postal);
            return res.send(success);
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Provider not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async providerMerchantUploadImg(
    type: string,
    data: MerchantUploadImgDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (Object.values(ProviderImgType).includes(type as ProviderImgType)) {
        const { user, browser } = req.user;
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };

        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (data.signature === signatureVerify) {
          var userId = '';
          if (payload.userId === 'root') {
            const userRoot = await this.User.findOne({
              role: Role.Root,
            }).exec();
            userId = userRoot.id;
          } else {
            userId = payload.userId;
          }
          await this.User.findById(userId).then(async (userFound) => {
            if (userFound) {
              const base64Data = payload.img.split('base64,')[1];
              const binaryData = Buffer.from(base64Data, 'base64');
              const path = `./images/kyb/${userFound.id}/`;
              fs.mkdirSync(path, { recursive: true });
              const imgPath = path + type + '.png';
              try {
                await this.sharpService.edit(binaryData).png().toFile(imgPath);

                const success = response.initSuccess(200, true, true);
                return res.send(success);
              } catch (err) {
                console.log(err);
                const success = response.initSuccess(200, false, false);
                return res.send(success);
              }
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('User not found'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Type invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async providerMerchantRegisterBnc(
    type: number,
    data: MerchantRegisterBnc1Dto | MerchantRegisterBncDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
          async (logType) => {
            if (logType) {
              await this.Provider.findById(data.providerId)
                .populate('providerRoot')
                .then(async (provider: any) => {
                  if (provider && provider.key) {
                    var providerKey = '';
                    if (provider.key === 'root') {
                      providerKey = decrypt(
                        process.env.ENCRYPT_ALG,
                        hash('sha256', provider.providerRoot.id).substring(
                          0,
                          32,
                        ),
                        hash(
                          'sha256',
                          provider.providerRoot.user +
                            provider.providerRoot.code,
                        ).substring(0, 16),
                        provider.providerRoot.key,
                      );
                    } else {
                      providerKey = decrypt(
                        process.env.ENCRYPT_ALG,
                        hash('sha256', provider.id).substring(0, 32),
                        hash('sha256', provider.user + provider.code).substring(
                          0,
                          16,
                        ),
                        provider.key,
                      );
                    }

                    const key = JSON.parse(providerKey);

                    const accessToken =
                      await this.providerService.getBncAccessToken(
                        key.clientId,
                      );

                    const registerId = generateRandomNumber(20);
                    const registerMerchantId = generateRandomNumber(30);

                    const payload: any = {
                      applicationCode: registerId,
                      merchantIdentity: '2',
                      subjectInfo: {
                        parentMerchantId: key.merchantId,
                        merchantExternalMid: registerMerchantId,
                        merchantType: `${type}`,
                        merchantName: data.merchantName,
                        provinceId: data.provinceId,
                        provinceName: data.provinceName,
                        cityId: data.cityId,
                        cityName: data.cityName,
                        cityIdShort: data.cityIdShort,
                        districtId: data.districtId,
                        districtName: data.districtName,
                        postcodeId: data.postcodeId,
                        merchantAddress: data.merchantAddress,
                        ktpNumber: data.ktpNumber,
                        npwpNumber: data.npwpNumber,
                      },
                      businessInfo: {
                        businessShortname: data.businessShortName,
                      },
                      settlementInfo: {
                        mcc: data.mcc,
                        terminalNumber: data.terminalNumber,
                        criteria: data.criteria,
                        qualifications: '',
                      },
                      settlementAccountInfo: {
                        accountName: 'qiaobu',
                        accountBank: 'BNC',
                        accountNumber: '5859459100032159',
                        contactName: 'QIAOBU',
                        contactPhoneNo: data.phone,
                        email: data.email,
                      },
                      additionInfo: {},
                    };

                    if (type === 1) {
                      const payloadData = data as MerchantRegisterBnc1Dto;
                      payload.subjectInfo.licenseNumber =
                        payloadData.licenseNumber;
                      payload.subjectInfo.nibNumber = payloadData.nibNumber;
                    }

                    const path = `./images/kyb/${data.userId}/`;
                    const validEnum =
                      type === 1
                        ? Object.values(ProviderImgType).filter(
                            (value) => value !== ProviderImgType.Env,
                          )
                        : type === 2
                        ? Object.values(ProviderImgType).filter(
                            (value) =>
                              value === ProviderImgType.Ktp ||
                              value === ProviderImgType.Npwp ||
                              value === ProviderImgType.Env,
                          )
                        : [];

                    for (const item of validEnum) {
                      const imgPath = path + item + '.png';
                      if (fs.existsSync(imgPath)) {
                        const uploadMediaId =
                          await this.providerService.uploadBncImg(
                            imgPath,
                            key.clientId,
                            accessToken,
                          );

                        if (uploadMediaId) {
                          if (item === ProviderImgType.Ktp) {
                            payload.subjectInfo.ktpCopy = uploadMediaId;
                          } else if (item === ProviderImgType.Npwp) {
                            payload.subjectInfo.npwpCopy = uploadMediaId;
                          } else if (item === ProviderImgType.License) {
                            payload.subjectInfo.licenseCopy = uploadMediaId;
                          } else if (item === ProviderImgType.Nib) {
                            payload.subjectInfo.nibCopy = uploadMediaId;
                          } else if (item === ProviderImgType.CertInc) {
                            payload.additionInfo.certificateIncorporation =
                              uploadMediaId;
                          } else if (item === ProviderImgType.Cert40) {
                            payload.additionInfo.certificateNo40 =
                              uploadMediaId;
                          } else if (item === ProviderImgType.CertLA) {
                            payload.additionInfo.certificateLastAmendment =
                              uploadMediaId;
                          } else if (item === ProviderImgType.CertDA) {
                            payload.additionInfo.certificateDeedAmendment =
                              uploadMediaId;
                          } else if (item === ProviderImgType.CertAA) {
                            payload.additionInfo.certificateAmendmentAct =
                              uploadMediaId;
                          } else if (item === ProviderImgType.CertEst) {
                            payload.additionInfo.certificateEstablishment =
                              uploadMediaId;
                          } else if (item === ProviderImgType.Sppkp) {
                            payload.additionInfo.sppkpCopy = uploadMediaId;
                          } else {
                            payload.additionInfo.environmentCopy =
                              uploadMediaId;
                          }
                        } else {
                          const error = response.initError(
                            403,
                            false,
                            new ErrorMessage(`Failed to upload ${item} Image`),
                          );
                          return res.send(error);
                        }
                      } else {
                        const error = response.initError(
                          404,
                          false,
                          new ErrorMessage(`${item} Image not found`),
                        );
                        return res.send(error);
                      }
                    }

                    const result: any =
                      await this.providerService.registerMerchantBnc(
                        key.clientId,
                        accessToken,
                        payload,
                      );

                    if (result) {
                      provider.storeData = JSON.stringify(payload);
                      provider.storeId = result.storeId;
                      provider.auditStatus = result.auditStatus;
                      provider.traceId = result.additionalInfo.traceId;
                      provider.applicationCode = result.applicationCode;
                      await provider.save();

                      const success = response.initSuccess(200, true, true);
                      return res.send(success);
                    } else {
                      const success = response.initSuccess(200, false, false);
                      return res.send(success);
                    }
                  } else {
                    const error = response.initError(
                      404,
                      false,
                      new ErrorMessage('Provider not found'),
                    );
                    return res.send(error);
                  }
                });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Log not found'),
              );
              return res.send(error);
            }
          },
        );
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async providerMerchantRegisterBncTest(
    data: TestImgDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      await this.Provider.findById('64c1346587ff37b3dd2d6325')
        .populate('providerRoot')
        .then(async (provider: any) => {
          if (provider && provider.key) {
            // var providerKey = '';
            const providerKey = decrypt(
              process.env.ENCRYPT_ALG,
              hash('sha256', provider.id).substring(0, 32),
              hash('sha256', provider.user + provider.code).substring(0, 16),
              provider.key,
            );

            const key = JSON.parse(providerKey);

            const accessToken = await this.providerService.getBncAccessToken(
              key.clientId,
            );

            const postal = await this.providerService.uploadBncImg(
              key.clientId,
              accessToken,
              data.img,
            );

            const success = response.initSuccess(200, true, postal);
            return res.send(success);
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Provider not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async assistUserTransaction(
    data: AssistTransactionDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.Transaction.findById(data.transactionId)
          .populate('product')
          .then(async (transaction: any) => {
            if (
              transaction &&
              transaction.status === TransactionStatusType.Assist
            ) {
              const payload = {
                username: process.env.DF_USERNAME,
                buyer_sku_code: transaction.product.code,
                customer_no: transaction.form,
                ref_id: transaction.transactionId,
                sign: hash(
                  'md5',
                  `${process.env.DF_USERNAME}${process.env.DF_PROD_KEY}${transaction.transactionId}`,
                ),
              };
              const header = {
                'Content-Type': CT_APP_JSON,
              };
              await fetch(process.env.DF_BASE_URL + 'transaction', {
                method: 'POST',
                body: JSON.stringify(payload),
                headers: header,
              }).then(async (responseFetch) => {
                const responseData = await responseFetch.json();
                const updateTransaction: any = {
                  paidRef: 'balance',
                  paidTime: new Date(),
                  serialNumber: 'b' + generateRandomNumber(10),
                };

                if (
                  responseData.data.status === 'Sukses' &&
                  responseData.data.rc === '00'
                ) {
                  updateTransaction.status = TransactionStatusType.Paid;
                  updateTransaction.dfTrxId = responseData.data.trx_id;
                  updateTransaction.dfSn = responseData.data.sn;
                } else if (responseData.data.status === 'Gagal') {
                  if (
                    responseData.data.rc === '01' ||
                    responseData.data.rc === '44' ||
                    responseData.data.rc === '53' ||
                    responseData.data.rc === '55' ||
                    responseData.data.rc === '56' ||
                    responseData.data.rc === '58' ||
                    responseData.data.rc === '62' ||
                    responseData.data.rc === '63' ||
                    responseData.data.rc === '64' ||
                    responseData.data.rc === '65' ||
                    responseData.data.rc === '66' ||
                    responseData.data.rc === '67' ||
                    responseData.data.rc === '68' ||
                    responseData.data.rc === '70' ||
                    responseData.data.rc === '71' ||
                    responseData.data.rc === '80' ||
                    responseData.data.rc === '99'
                  ) {
                    updateTransaction.status = TransactionStatusType.Assist;
                  } else {
                    updateTransaction.status = TransactionStatusType.Failed;

                    await this.Balance.findOne({
                      user: transaction.user,
                    }).then(async (balance) => {
                      if (balance) {
                        await this.Balance.findByIdAndUpdate(balance.id, {
                          $inc: {
                            balance: Number(transaction.product.price),
                          },
                        });

                        const newBalanceLog = new this.BalanceLog({
                          name:
                            'Refund used balance: ' + transaction.product.name,
                          balanceAmount: balance.balance,
                          balanceCredit: transaction.product.price,
                          type: BalanceLogType.Refund,
                          balance: balance.id,
                          transaction: transaction.id,
                        });

                        await newBalanceLog.save();
                      } else {
                      }
                    });
                    updateTransaction.error = responseData.data.message;
                  }
                }
                await this.Transaction.findByIdAndUpdate(
                  transaction.id,
                  updateTransaction,
                );

                await this.LogType.findOne({ type: LogTypes.AdminUpdate }).then(
                  async (logType) => {
                    if (logType) {
                      const newLog = new this.Log({
                        message: `${user.username} ASSIST user transaction ${transaction.product.name}`,
                        target: transaction.id,
                        ip: req.ip,
                        type: logType.id,
                        admin: user.id,
                      });

                      await newLog.save();
                    } else {
                      const error = response.initError(
                        404,
                        false,
                        new ErrorMessage('Log data not found'),
                      );
                      return res.send(error);
                    }
                  },
                );

                const success = response.initSuccess(200, true, true);
                return res.send(success);
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Transaction data not found'),
              );
              return res.send(error);
            }
          });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  // async showKey(userId: string, res: FastifyReply) {
  //   this.Client.findOne({
  //     userId: userId,
  //   }).then((client) => {
  //     const alg = process.env.ENCRYPT_ALG;
  //     const keyDec = decrypt(
  //       alg,
  //       crypto
  //         .createHash('sha256')
  //         .update(client.id)
  //         .digest('hex')
  //         .substring(0, 32),
  //       crypto
  //         .createHash('sha256')
  //         .update(client.userId + client.clientId)
  //         .digest('hex')
  //         .substring(0, 16),
  //       client.key,
  //     );

  //     const cbKeyDec = decrypt(
  //       alg,
  //       crypto
  //         .createHash('sha256')
  //         .update(client.key)
  //         .digest('hex')
  //         .substring(0, 32),
  //       crypto
  //         .createHash('sha256')
  //         .update(client.userId + client.clientId + client.id)
  //         .digest('hex')
  //         .substring(0, 16),
  //       client.callbackKey,
  //     );

  //     const success = response.initSuccess(200, true, {
  //       key: keyDec,
  //       cbKey: cbKeyDec,
  //     });
  //     return res.send(success);
  //   });
  // }

  // async create(createAdminDto: CreateAdminDto, res: FastifyReply) {
  //   const newUser = new this.User({
  //     name: createAdminDto.name,
  //     email: createAdminDto.email,
  //     username: createAdminDto.username,
  //   });
  //   const newUserSaved = await newUser.save();

  //   const uuid = crypto.randomUUID();
  //   const buffer = Buffer.from(uuid.replace(/-/g, ''), 'hex');
  //   const clientId = buffer
  //     .toString('base64')
  //     .replace(/\+/g, '0')
  //     .replace(/\//g, '0')
  //     .replace(/=/g, '');

  //   const newClient = new this.Client({
  //     userId: newUserSaved.id,
  //     clientId: clientId,
  //   });
  //   const newClientSaved = await newClient.save();

  //   const length = 32;
  //   const keyBytes = crypto.randomBytes(Math.ceil((length * 3) / 4));
  //   const resultKey = keyBytes
  //     .toString('base64')
  //     .replace(/\+/g, '0')
  //     .replace(/\//g, '0')
  //     .replace(/=/g, '');

  //   const cbKeyBytes = crypto.randomBytes(Math.ceil((length * 3) / 4));
  //   const resultCbKey = cbKeyBytes
  //     .toString('base64')
  //     .replace(/\+/g, '0')
  //     .replace(/\//g, '0')
  //     .replace(/=/g, '');

  //   const alg = process.env.ENCRYPT_ALG;
  //   const keyEnc = encrypt(
  //     alg,
  //     crypto
  //       .createHash('sha256')
  //       .update(newClientSaved.id)
  //       .digest('hex')
  //       .substring(0, 32),
  //     crypto
  //       .createHash('sha256')
  //       .update(newUserSaved.id + clientId)
  //       .digest('hex')
  //       .substring(0, 16),
  //     resultKey,
  //   );

  //   const cbKeyEnc = encrypt(
  //     alg,
  //     crypto.createHash('sha256').update(keyEnc).digest('hex').substring(0, 32),
  //     crypto
  //       .createHash('sha256')
  //       .update(newUserSaved.id + clientId + newClientSaved.id)
  //       .digest('hex')
  //       .substring(0, 16),
  //     resultCbKey,
  //   );

  //   await this.Client.findByIdAndUpdate(
  //     newClientSaved.id,
  //     {
  //       $set: {
  //         key: keyEnc,
  //         callback: 'https://zuppo.me/api/v1/callback/petikas',
  //         redirect: 'https://zuppo.me',
  //         callbackKey: cbKeyEnc,
  //       },
  //     },
  //     { new: true, upsert: true },
  //   );

  //   const success = response.initSuccess(200, true, {
  //     clientId: clientId,
  //     key: resultKey,
  //     cbKey: resultCbKey,
  //   });
  //   return res.send(success);
  // }

  // async createWallet(userId: string, res: FastifyReply) {
  //   try {
  //     this.User.findById(userId).then((user) => {
  //       this.Wallet.findOne({ userId: userId }).then(async (wallet) => {
  //         if (wallet) {
  //           const error = response.initError(
  //             200,
  //             false,
  //             new ErrorMessage('Wallet already created'),
  //           );
  //           return res.send(error);
  //         } else {
  //           const gvUsername = user.username + user.id;
  //           const orderId =
  //             'CW-' +
  //             user.id.substr(18) +
  //             crypto.randomBytes(20).toString('hex').substring(35);
  //           const signature = crypto
  //             .createHash('md5')
  //             .update(
  //               process.env.GV_MERCHANT_ID +
  //                 crypto
  //                   .createHash('md5')
  //                   .update(
  //                     orderId +
  //                       gvUsername +
  //                       user.name +
  //                       user.email +
  //                       process.env.GV_MERCHANT_KEY,
  //                   )
  //                   .digest('hex'),
  //             )
  //             .digest('hex');

  //           const body = new URLSearchParams();
  //           body.append('signature', signature);
  //           body.append('merchant_id', process.env.GV_MERCHANT_ID);
  //           body.append('custom', orderId);
  //           body.append('username', gvUsername);
  //           body.append('name', user.name);
  //           body.append('email', user.email);

  //           const gvFetch = await fetch(
  //             process.env.GV_BASE_URL + 'auth/direct_register',
  //             {
  //               method: 'POST',
  //               body: body.toString(),
  //               headers: {
  //                 'Content-Type': 'application/x-www-form-urlencoded',
  //               },
  //             },
  //           );
  //           const result = await gvFetch.json();
  //           const resCode = result['respondcode'];
  //           const resData = result['responddata'];
  //           console.log(result);

  //           if (resCode === '00') {
  //             this.Client.findOne({
  //               userId: user.id,
  //             }).then(async (client) => {
  //               const newWallet = new this.Wallet({
  //                 userId: user.id,
  //                 orderIdUser: resData.custom,
  //                 key: encrypt(
  //                   process.env.ENCRYPT_ALG,
  //                   crypto
  //                     .createHash('sha256')
  //                     .update(client.key)
  //                     .digest('hex')
  //                     .substring(0, 32),
  //                   crypto
  //                     .createHash('sha256')
  //                     .update(user.id + client.clientId + client.id)
  //                     .digest('hex')
  //                     .substring(0, 16),
  //                   resData.gv_connect_key,
  //                 ),
  //                 userBcaVa: resData.bca_va,
  //                 userBniVa: resData.bni_va,
  //                 userPermataVa: resData.permata_va,
  //                 userBersamaVa: resData.bersama_va,
  //                 userCimbVa: resData.cimb_va,
  //               });
  //               const newWalletSaved = await newWallet.save();
  //               const success = response.initSuccess(200, true, newWalletSaved);
  //               return res.send(success);
  //             });
  //           }
  //         }
  //       });
  //     });
  //   } catch (err) {
  //     console.log(err);
  //   }
  // }

  // async verifyWallet(userId: string, data: VerifyWalletDto, res: FastifyReply) {
  //   try {
  //     this.User.findById(userId).then(async (user) => {
  //       this.Client.findOne({ userId: userId }).then((client) => {
  //         if (client) {
  //           this.Wallet.findOne({ userId: userId }).then(async (wallet) => {
  //             if (wallet) {
  //               if (wallet.status !== 'basic') {
  //                 const orderId =
  //                   'CA-' +
  //                   user.id.substr(18) +
  //                   crypto.randomBytes(20).toString('hex').substring(35);

  //                 const gvUsername = user.username + user.id;
  //                 const type =
  //                   wallet.status === 'merchant' ? 'Merchant' : 'User';

  //                 const signature = crypto
  //                   .createHash('md5')
  //                   .update(
  //                     process.env.GV_MERCHANT_ID +
  //                       crypto
  //                         .createHash('md5')
  //                         .update(
  //                           orderId +
  //                             type +
  //                             gvUsername +
  //                             process.env.GV_MERCHANT_KEY,
  //                         )
  //                         .digest('hex'),
  //                   )
  //                   .digest('hex');

  //                 const body = new URLSearchParams();
  //                 body.append('signature', signature);
  //                 body.append('merchant_id', process.env.GV_MERCHANT_ID);
  //                 body.append('custom', orderId);
  //                 body.append('type', type);
  //                 body.append('username', gvUsername);

  //                 const gvFetch = await fetch(
  //                   process.env.GV_BASE_URL + 'auth/inquiryAccount',
  //                   {
  //                     method: 'POST',
  //                     body: body.toString(),
  //                     headers: {
  //                       'Content-Type': 'application/x-www-form-urlencoded',
  //                     },
  //                   },
  //                 );
  //                 const result = await gvFetch.json();
  //                 const resCode = result['respondcode'];
  //                 const resData = result['responddata'];
  //                 console.log(result);

  //                 if (resCode === '00') {
  //                   const error = response.initError(
  //                     200,
  //                     false,
  //                     new ErrorMessage(
  //                       type === 'Merchant'
  //                         ? 'Already a merchant'
  //                         : 'Already verified',
  //                     ),
  //                   );
  //                   return res.send(error);
  //                 } else {
  //                   const error = response.initError(
  //                     200,
  //                     false,
  //                     new ErrorMessage(
  //                       result['respondmsg'] +
  //                         ' ' +
  //                         (resData ? JSON.stringify(resData) : ''),
  //                     ),
  //                   );
  //                   return res.send(error);
  //                 }
  //               } else {
  //                 const gvKey = decrypt(
  //                   process.env.ENCRYPT_ALG,
  //                   crypto
  //                     .createHash('sha256')
  //                     .update(client.key)
  //                     .digest('hex')
  //                     .substring(0, 32),
  //                   crypto
  //                     .createHash('sha256')
  //                     .update(user.id + client.clientId + client.id)
  //                     .digest('hex')
  //                     .substring(0, 16),
  //                   wallet.key,
  //                 );

  //                 const orderId =
  //                   'VW-' +
  //                   user.id.substr(18) +
  //                   crypto.randomBytes(20).toString('hex').substring(35);

  //                 const signature = crypto
  //                   .createHash('md5')
  //                   .update(
  //                     process.env.GV_MERCHANT_ID +
  //                       crypto
  //                         .createHash('md5')
  //                         .update(orderId + gvKey + process.env.GV_MERCHANT_KEY)
  //                         .digest('hex'),
  //                   )
  //                   .digest('hex');

  //                 const body = new URLSearchParams();
  //                 body.append('signature', signature);
  //                 body.append('merchant_id', process.env.GV_MERCHANT_ID);
  //                 body.append('custom', orderId);
  //                 body.append('gv_connect_key', gvKey);
  //                 body.append('full_name', data.fullName);
  //                 body.append('mother_name', data.motherName);
  //                 body.append('birth_place', data.birthPlace);
  //                 body.append('birth_date', data.birthDate);
  //                 body.append('idtype', '1');
  //                 body.append('card_number', data.cardNumber);
  //                 body.append('address', data.address);
  //                 body.append('gender', data.gender);
  //                 body.append('nationality', 'ID');
  //                 body.append('phone_number', data.phone);
  //                 body.append('signature_img', data.signatureImg);
  //                 body.append('selfie_img', data.selfieImg);
  //                 body.append('card_img', data.cardImg);
  //                 body.append('id_pekerjaan', data.occupation);
  //                 body.append('alamat', data.addressCode);

  //                 const gvFetch = await fetch(
  //                   process.env.GV_BASE_URL + 'auth/upgrade_kyc',
  //                   {
  //                     method: 'POST',
  //                     body: body.toString(),
  //                     headers: {
  //                       'Content-Type': 'application/x-www-form-urlencoded',
  //                     },
  //                   },
  //                 );
  //                 const result = await gvFetch.json();
  //                 const resCode = result['respondcode'];
  //                 const resData = result['responddata'];
  //                 console.log(result);

  //                 if (resCode === '00') {
  //                   await this.Wallet.findByIdAndUpdate(
  //                     wallet.id,
  //                     {
  //                       $set: {
  //                         status: 'verified',
  //                       },
  //                     },
  //                     { new: true, upsert: true },
  //                   );

  //                   const success = response.initSuccess(200, true, {
  //                     status: 'Success',
  //                   });
  //                   return res.send(success);
  //                 } else {
  //                   const error = response.initError(
  //                     200,
  //                     false,
  //                     new ErrorMessage(
  //                       result['respondmsg'] +
  //                         ' ' +
  //                         (resData ? JSON.stringify(resData) : ''),
  //                     ),
  //                   );
  //                   return res.send(error);
  //                 }
  //               }
  //             } else {
  //               const error = response.initError(
  //                 404,
  //                 false,
  //                 new ErrorMessage('Wallet not found'),
  //               );
  //               return res.send(error);
  //             }
  //           });
  //         } else {
  //           const error = response.initError(
  //             404,
  //             false,
  //             new ErrorMessage('Client not found'),
  //           );
  //           return res.send(error);
  //         }
  //       });
  //     });
  //   } catch (err) {
  //     console.log(err);
  //   }
  // }

  // async upgradeMerchant(
  //   userId: string,
  //   data: UpgradeMerchantDto,
  //   res: FastifyReply,
  // ) {
  //   try {
  //     console.log('masukk');
  //     this.User.findById(userId).then(async (user) => {
  //       this.Client.findOne({ userId: userId }).then((client) => {
  //         if (client) {
  //           this.Wallet.findOne({ userId: userId }).then(async (wallet) => {
  //             if (wallet) {
  //               if (wallet.status !== 'verified') {
  //                 const orderId =
  //                   'CA-' +
  //                   user.id.substr(18) +
  //                   crypto.randomBytes(20).toString('hex').substring(35);

  //                 const gvUsername = user.username + user.id;
  //                 const type =
  //                   wallet.status === 'merchant' ? 'Merchant' : 'User';

  //                 const signature = crypto
  //                   .createHash('md5')
  //                   .update(
  //                     process.env.GV_MERCHANT_ID +
  //                       crypto
  //                         .createHash('md5')
  //                         .update(
  //                           orderId +
  //                             type +
  //                             gvUsername +
  //                             process.env.GV_MERCHANT_KEY,
  //                         )
  //                         .digest('hex'),
  //                   )
  //                   .digest('hex');

  //                 const body = new URLSearchParams();
  //                 body.append('signature', signature);
  //                 body.append('merchant_id', process.env.GV_MERCHANT_ID);
  //                 body.append('custom', orderId);
  //                 body.append('type', type);
  //                 body.append('username', gvUsername);

  //                 const gvFetch = await fetch(
  //                   process.env.GV_BASE_URL + 'auth/inquiryAccount',
  //                   {
  //                     method: 'POST',
  //                     body: body.toString(),
  //                     headers: {
  //                       'Content-Type': 'application/x-www-form-urlencoded',
  //                     },
  //                   },
  //                 );
  //                 const result = await gvFetch.json();
  //                 const resCode = result['respondcode'];
  //                 const resData = result['responddata'];
  //                 console.log(result);

  //                 if (resCode === '00') {
  //                   const error = response.initError(
  //                     200,
  //                     false,
  //                     new ErrorMessage(
  //                       type === 'Merchant'
  //                         ? 'Already a merchant'
  //                         : 'Already verified',
  //                     ),
  //                   );
  //                   return res.send(error);
  //                 } else {
  //                   const error = response.initError(
  //                     200,
  //                     false,
  //                     new ErrorMessage(
  //                       result['respondmsg'] +
  //                         ' ' +
  //                         (resData ? JSON.stringify(resData) : ''),
  //                     ),
  //                   );
  //                   return res.send(error);
  //                 }
  //               } else {
  //                 const gvKey = decrypt(
  //                   process.env.ENCRYPT_ALG,
  //                   crypto
  //                     .createHash('sha256')
  //                     .update(client.key)
  //                     .digest('hex')
  //                     .substring(0, 32),
  //                   crypto
  //                     .createHash('sha256')
  //                     .update(user.id + client.clientId + client.id)
  //                     .digest('hex')
  //                     .substring(0, 16),
  //                   wallet.key,
  //                 );

  //                 const gvUsername = 'Merchant-' + user.username + user.id;
  //                 const orderId =
  //                   'UM-' +
  //                   user.id.substr(18) +
  //                   crypto.randomBytes(20).toString('hex').substring(35);

  //                 const signature = crypto
  //                   .createHash('md5')
  //                   .update(
  //                     process.env.GV_MERCHANT_ID +
  //                       crypto
  //                         .createHash('md5')
  //                         .update(orderId + gvKey + process.env.GV_MERCHANT_KEY)
  //                         .digest('hex'),
  //                   )
  //                   .digest('hex');

  //                 const body = new URLSearchParams();
  //                 body.append('signature', signature);
  //                 body.append('merchant_id', process.env.GV_MERCHANT_ID);
  //                 body.append('custom', orderId);
  //                 body.append('gv_connect_key', gvKey);
  //                 body.append('bussiness_username', gvUsername);
  //                 body.append('bussiness_name', data.businessName);
  //                 body.append('bussiness_email', user.email);
  //                 body.append('province', '31');
  //                 body.append('city', '3174');
  //                 body.append('sub_district', '317408');
  //                 body.append('village', '3174081001');
  //                 body.append('postal_code', '12780');
  //                 body.append('address', data.businessAddress);
  //                 body.append('phone_number', '085782401874');
  //                 body.append('mcc', data.mcc.toString());
  //                 body.append('criteria', data.criteria);
  //                 body.append('type_of_bussiness', data.businessType);
  //                 body.append(
  //                   'month_start_bussiness_operational',
  //                   data.businessMonth.toString(),
  //                 );
  //                 body.append(
  //                   'year_start_bussiness_operational',
  //                   data.businessYear.toString(),
  //                 );
  //                 body.append('status_own_bussiness_place', 'Milik Sendiri');
  //                 body.append('bussiness_location', 'Lainnya');
  //                 body.append('bussiness_place_img', data.businessImg);
  //                 body.append('logo_img', data.logoImg);

  //                 const gvFetch = await fetch(
  //                   process.env.GV_BASE_URL + 'auth/upgrade_merchant',
  //                   {
  //                     method: 'POST',
  //                     body: body.toString(),
  //                     headers: {
  //                       'Content-Type': 'application/x-www-form-urlencoded',
  //                     },
  //                   },
  //                 );
  //                 const result = await gvFetch.json();
  //                 const resCode = result['respondcode'];
  //                 const resData = result['responddata'];
  //                 console.log(result);

  //                 if (resCode === '00') {
  //                   const update = {
  //                     status: 'merchant',
  //                     orderIdMerchant: resData.custom,
  //                     businessId: resData.bussiness_id,
  //                     businessName: resData.bussiness_name,
  //                     businessUsername: resData.bussiness_username,
  //                     mdr: resData.mdr,
  //                     qris: resData.data_qr,
  //                     merchantBcaVa: resData.bca_va,
  //                     merchantBniVa: resData.bni_va,
  //                     merchantPermataVa: resData.permata_va,
  //                     merchantBersamaVa: resData.bersama_va,
  //                     merchantCimbVa: resData.cimb_va,
  //                   };

  //                   await this.Wallet.findByIdAndUpdate(
  //                     wallet.id,
  //                     {
  //                       $set: update,
  //                     },
  //                     { new: true, upsert: true },
  //                   );

  //                   const success = response.initSuccess(200, true, {
  //                     status: 'Success',
  //                   });
  //                   return res.send(success);
  //                 } else {
  //                   const error = response.initError(
  //                     200,
  //                     false,
  //                     new ErrorMessage(
  //                       result['respondmsg'] +
  //                         ' ' +
  //                         (resData ? JSON.stringify(resData) : ''),
  //                     ),
  //                   );
  //                   return res.send(error);
  //                 }
  //               }
  //             } else {
  //               const error = response.initError(
  //                 404,
  //                 false,
  //                 new ErrorMessage('Wallet not found'),
  //               );
  //               return res.send(error);
  //             }
  //           });
  //         } else {
  //           const error = response.initError(
  //             404,
  //             false,
  //             new ErrorMessage('Client not found'),
  //           );
  //           return res.send(error);
  //         }
  //       });
  //     });
  //   } catch (err) {
  //     console.log(err);
  //   }
  // }
}
