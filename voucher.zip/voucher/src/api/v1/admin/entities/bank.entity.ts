import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { BankType } from 'src/common/config/enum';

export type BankDocument = HydratedDocument<Bank>;

@Schema({ timestamps: true })
export class Bank {
  @Prop()
  name: string;

  @Prop()
  code: string;

  @Prop()
  img: string;

  @Prop({ enum: BankType })
  type: string;

  @Prop()
  min: number;

  @Prop()
  max: number;

  @Prop()
  multiple: number;

  @Prop({ default: true })
  isActive: boolean;
}

export const BankSchema = SchemaFactory.createForClass(Bank);
