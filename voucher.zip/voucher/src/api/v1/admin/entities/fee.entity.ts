import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';
import { FeeType } from 'src/common/config/enum';

export type FeeDocument = HydratedDocument<Fee>;

@Schema({ timestamps: true })
export class Fee {
  @Prop({ default: 0 })
  delay: number;

  @Prop()
  fixed: number;

  @Prop()
  percentage: number;

  @Prop({ default: true })
  onClient: boolean;

  @Prop({ enum: FeeType })
  feeType: string;

  @Prop()
  lp: string;

  @Prop([
    {
      _id: false,
      id: { type: Number },
      type: { type: SchemaTypes.ObjectId, ref: 'ValueType' },
      fixed: { type: Number },
      percentage: { type: Number },
    },
  ])
  uplineFee: Record<string, any>[];

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Bank' })
  bank: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Method' })
  method: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'ValueType' })
  type: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Provider' })
  provider: Types.ObjectId;

  @Prop({ default: true })
  isActive: boolean;
}

export const FeeSchema = SchemaFactory.createForClass(Fee);
