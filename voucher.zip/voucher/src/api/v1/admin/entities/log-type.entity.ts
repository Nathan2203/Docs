import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { LogType as LogTypes } from 'src/common/config/enum';

export type LogTypeDocument = HydratedDocument<LogType>;

@Schema({ timestamps: true })
export class LogType {
  @Prop({ enum: LogTypes })
  type: string;
}

export const LogTypeSchema = SchemaFactory.createForClass(LogType);
