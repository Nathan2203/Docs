import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';

export type LogDocument = HydratedDocument<Log>;

@Schema({ timestamps: true })
export class Log {
  @Prop()
  message: string;

  @Prop()
  target: string;

  @Prop()
  ip: string;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'LogType' })
  type: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  admin: Types.ObjectId;
}

export const LogSchema = SchemaFactory.createForClass(Log);
