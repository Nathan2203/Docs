import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';
import { ProviderCodeType } from 'src/common/config/enum';

export type ProviderDocument = HydratedDocument<Provider>;

@Schema({ timestamps: true })
export class Provider {
  @Prop({ enum: ProviderCodeType })
  code: string;

  @Prop()
  name: string;

  @Prop()
  key: string;

  @Prop()
  storeId: string;

  @Prop()
  storeData: string;

  @Prop()
  auditStatus: string;

  @Prop()
  rejectReason: string;

  @Prop()
  callbackPayload: string;

  @Prop()
  traceId: string;

  @Prop()
  applicationCode: string;

  @Prop({ default: true })
  isActive: boolean;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'Provider' })
  providerRoot: Types.ObjectId;
}

export const ProviderSchema = SchemaFactory.createForClass(Provider);
