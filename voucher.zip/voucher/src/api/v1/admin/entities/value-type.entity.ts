import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { ValueType as ValueTypes } from 'src/common/config/enum';

export type ValueTypeDocument = HydratedDocument<ValueType>;

@Schema({ timestamps: true })
export class ValueType {
  @Prop({ enum: ValueTypes })
  name: string;
}

export const ValueTypeSchema = SchemaFactory.createForClass(ValueType);
