import { IsEnum, IsNotEmpty, IsString } from 'class-validator';
import { BankActionType } from 'src/common/config/enum';

export class ActionBankDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsEnum(BankActionType)
  @IsNotEmpty({ message: 'Move To must not be empty' })
  moveTo: BankActionType;

  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  bankId: string;
}
