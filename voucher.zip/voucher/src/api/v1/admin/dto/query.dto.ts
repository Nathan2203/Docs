import { Transform } from 'class-transformer';
import { IsNumber, IsOptional, IsString } from 'class-validator';
import { toNumber } from 'src/common/helper/cast.helper';

export class QueryDto {
  @Transform(({ value }) => toNumber(value, { default: 1, min: 1 }))
  @IsNumber()
  @IsOptional()
  public page: number = 1;

  @Transform(({ value }) => toNumber(value, { default: 10, min: 10 }))
  @IsNumber()
  @IsOptional()
  public limit: number = 10;

  @IsString()
  @IsOptional()
  public filter: string;

  @IsString()
  @IsOptional()
  public sortBy: string;

  @IsString()
  @IsOptional()
  public sortOrder: string;

  @IsString()
  @IsOptional()
  public search: string;

  @IsString()
  @IsOptional()
  public dateStart: string;

  @IsString()
  @IsOptional()
  public dateEnd: string;
}
