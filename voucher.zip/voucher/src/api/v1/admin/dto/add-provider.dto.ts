import { IsNotEmpty, IsString } from 'class-validator';

export class AddProviderDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'Code must not be empty' })
  code: string;

  @IsString()
  @IsNotEmpty({ message: 'Name must not be empty' })
  name: string;
}
