import { ApiProperty } from '@nestjs/swagger';
import {
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Min,
} from 'class-validator';
import { ActionClientType } from 'src/common/config/enum';

export class ActionClientDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @ApiProperty({ enum: ActionClientType })
  @IsEnum(ActionClientType)
  @IsNotEmpty({ message: 'Action must not be empty' })
  action: ActionClientType;

  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsString()
  @IsOptional()
  partnerId: string;

  @IsNumber()
  @IsOptional()
  limit: number;

  @IsNumber()
  @IsOptional()
  @Min(0, { message: 'Amount cannot be smaller than 0' })
  freeze: number;

  @IsNumber()
  @IsOptional()
  @Min(0, { message: 'Amount cannot be smaller than 0' })
  return: number;

  @IsString()
  @IsOptional()
  clientName: string;

  @IsString()
  @IsOptional()
  custName: string;
}
