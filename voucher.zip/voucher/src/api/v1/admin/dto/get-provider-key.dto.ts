import { IsNotEmpty, IsString } from 'class-validator';

export class GetProviderKeyDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'Provider ID must not be empty' })
  providerId: string;

  @IsString()
  @IsNotEmpty({ message: 'OTP must not be empty' })
  otp: string;
}
