import { IsNotEmpty, IsString } from 'class-validator';

export class AssistTransactionDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'Transaction ID must not be empty' })
  transactionId: string;
}
