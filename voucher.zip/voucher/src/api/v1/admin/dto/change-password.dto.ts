import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class ChangePasswordDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'Old Password must not be empty' })
  old: string;

  @IsString()
  @IsNotEmpty({ message: 'New Password must not be empty' })
  new: string;

  @IsString()
  @IsOptional()
  code: string;
}
