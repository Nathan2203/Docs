import {
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Min,
} from 'class-validator';

export class ProcessDisburseDto {
  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsString()
  @IsNotEmpty({ message: 'Bank ID must not be empty' })
  bankId: string;

  @IsString()
  @IsNotEmpty({ message: 'Provider ID must not be empty' })
  providerId: string;

  @IsNumber()
  @IsNotEmpty({ message: 'Amount must not be empty' })
  @Min(0, { message: 'Amount cannot be smaller than 0' })
  amount: number;

  @IsString()
  @IsNotEmpty({ message: 'Account must not be empty' })
  account: string;

  @IsString()
  @IsNotEmpty({ message: 'Name must not be empty' })
  name: string;

  @IsString()
  @IsOptional()
  code: string;

  @IsString()
  @IsNotEmpty({ message: 'Type must not be empty' })
  type: string;

  @IsString()
  @IsOptional()
  user: string;

  @IsString()
  @IsOptional()
  remark: string;
}
