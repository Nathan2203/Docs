import { IsNotEmpty, IsString } from 'class-validator';

export class TestImgDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  img: string;
}
