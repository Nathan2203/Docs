import { IsNotEmpty, IsString } from 'class-validator';

export class UpdateBrandDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'Brand ID must not be empty' })
  brandId: string;

  @IsString()
  @IsNotEmpty({ message: 'Image must not be empty' })
  img: string;
}
