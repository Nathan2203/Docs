import { IsNotEmpty, IsString } from 'class-validator';

export class CreateAdminDto {
  @IsString()
  @IsNotEmpty({ message: 'Role must not be empty' })
  role: string;

  @IsString()
  @IsNotEmpty({ message: 'Username must not be empty' })
  username: string;

  @IsString()
  @IsNotEmpty({ message: 'Pass must not be empty' })
  pass: string;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;
}
