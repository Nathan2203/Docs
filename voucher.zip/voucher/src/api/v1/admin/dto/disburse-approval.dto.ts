import {
  ArrayMinSize,
  IsArray,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';

export class ApprovalDisburseDto {
  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsArray()
  @ArrayMinSize(1, { message: 'withdrawal IDs must not be empty' })
  withdrawalIds: string[];

  @IsString()
  @IsOptional()
  code: string;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;
}
