import { IsNotEmpty, IsString } from 'class-validator';
import { MerchantRegisterBncDto } from './merchant-register-bnc.dto';

export class MerchantRegisterBnc1Dto extends MerchantRegisterBncDto {
  @IsString()
  @IsNotEmpty({ message: 'License Number must not be empty' })
  licenseNumber: string;

  @IsString()
  @IsNotEmpty({ message: 'NIB Number must not be empty' })
  nibNumber: string;

  @IsString()
  @IsNotEmpty({ message: 'Certificate Incorporation must not be empty' })
  certificateIncorporation: string;

  @IsString()
  @IsNotEmpty({ message: 'Certificate No 40 must not be empty' })
  certificateNo40: string;

  @IsString()
  @IsNotEmpty({
    message: 'Certificate Last Amendment must not be empty',
  })
  certificateLastAmendment: string;

  @IsString()
  @IsNotEmpty({ message: 'Certificate Deed Amendment must not be empty' })
  certificateDeedAmendment: string;

  @IsString()
  @IsNotEmpty({ message: 'Certificate Amendment Act must not be empty' })
  certificateAmendmentAct: string;

  @IsString()
  @IsNotEmpty({
    message: 'Certificate Establishment must not be empty',
  })
  certificateEstablishment: string;

  @IsString()
  @IsNotEmpty({ message: 'SPPKP Copy must not be empty' })
  sppkpCopy: string;
}
