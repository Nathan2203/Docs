import { IsNotEmpty, IsString } from 'class-validator';

export class RejectDisburseDto {
  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsString()
  @IsNotEmpty({ message: 'Withdraw ID must not be empty' })
  withdrawId: string;

  @IsString()
  @IsNotEmpty({ message: 'Code must not be empty' })
  code: string;

  @IsString()
  @IsNotEmpty({ message: 'Reason must not be empty' })
  reason: string;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;
}
