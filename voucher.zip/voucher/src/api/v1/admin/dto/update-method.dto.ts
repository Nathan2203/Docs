import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class UpdateMethodDto {
  @IsString()
  @IsOptional()
  name: string;

  @IsString()
  @IsOptional()
  code: string;

  @IsString()
  @IsOptional()
  type: string;

  @IsString()
  @IsOptional()
  img: string;

  @IsString()
  @IsOptional()
  path: string;

  @IsNumber()
  @IsOptional()
  min: number;

  @IsNumber()
  @IsOptional()
  max: number;

  @IsBoolean()
  @IsOptional()
  isActive: boolean;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'Method must not be empty' })
  method: string;
}
