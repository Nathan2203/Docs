import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class UpdateTransactionDto {
  @IsNumber()
  @IsNotEmpty({ message: 'Amount must not be empty' })
  amount: number;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: '2FA Code must not be empty' })
  code: string;
}
