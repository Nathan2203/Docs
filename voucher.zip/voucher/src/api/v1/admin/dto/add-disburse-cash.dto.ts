import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class AddDisburseCashDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'Retail ID must not be empty' })
  retailId: string;

  @IsNumber()
  @IsNotEmpty({ message: 'Min must not be empty' })
  min: number;

  @IsNumber()
  @IsNotEmpty({ message: 'Max must not be empty' })
  max: number;

  @IsNumber()
  @IsNotEmpty({ message: 'Multiple must not be empty' })
  multiple: number;
}
