import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class UpdateProviderDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'Provider ID must not be empty' })
  providerId: string;

  @IsString()
  @IsOptional()
  name: string;

  @IsString()
  @IsOptional()
  key: string;

  @IsString()
  @IsOptional()
  storeId: string;

  @IsString()
  @IsOptional()
  providerRootId: string;
}
