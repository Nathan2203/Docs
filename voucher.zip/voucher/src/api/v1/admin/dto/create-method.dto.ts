import { IsNotEmpty, IsString } from 'class-validator';

export class CreateMethodDto {
  @IsString()
  @IsNotEmpty({ message: 'Method name must not be empty' })
  name: string;

  @IsString()
  @IsNotEmpty({ message: 'Method code must not be empty' })
  code: string;

  @IsString()
  @IsNotEmpty({ message: 'Type must not be empty' })
  type: string;

  @IsString()
  @IsNotEmpty({ message: 'Image must not be empty' })
  img: string;

  @IsString()
  @IsNotEmpty({ message: 'Path must not be empty' })
  path: string;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;
}
