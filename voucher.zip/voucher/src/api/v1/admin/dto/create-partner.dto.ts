import { IsNotEmpty, IsString } from 'class-validator';

export class CreatePartnerDto {
  @IsString()
  @IsNotEmpty({ message: 'Username must not be empty' })
  username: string;

  @IsString()
  @IsNotEmpty({ message: 'Email must not be empty' })
  email: string;

  @IsString()
  @IsNotEmpty({ message: 'Phone must not be empty' })
  phone: string;

  @IsString()
  @IsNotEmpty({ message: 'Password must not be empty' })
  pass: string;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;
}
