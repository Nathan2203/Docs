import { IsNotEmpty, IsString } from 'class-validator';
import { BaseUpdateFeeDto } from './base-update-fee.dto';

export class UpdateMethodFeeDto extends BaseUpdateFeeDto {
  @IsString()
  @IsNotEmpty({ message: 'Method must not be empty' })
  method: string;
}
