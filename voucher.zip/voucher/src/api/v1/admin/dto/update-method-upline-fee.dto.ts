import { IsNotEmpty, IsString } from 'class-validator';
import { BaseUpdateUplineFeeDto } from './base-update-upline-fee';

export class UpdateMethodUplineFeeDto extends BaseUpdateUplineFeeDto {
  @IsString()
  @IsNotEmpty({ message: 'Method must not be empty' })
  method: string;
}
