import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class CreateClientDto {
  @IsString()
  @IsNotEmpty({ message: 'Client Name must not be empty' })
  clientName: string;

  @IsString()
  @IsNotEmpty({ message: 'Company Name must not be empty' })
  company: string;

  @IsString()
  @IsNotEmpty({ message: 'Username must not be empty' })
  username: string;

  @IsString()
  @IsNotEmpty({ message: 'Email must not be empty' })
  email: string;

  @IsString()
  @IsNotEmpty({ message: 'Phone must not be empty' })
  phone: string;

  @IsString()
  @IsNotEmpty({ message: 'Password must not be empty' })
  pass: string;

  @IsNumber()
  @IsNotEmpty({ message: 'Limit must not be empty' })
  limit: number;

  @IsString()
  @IsOptional()
  partnerId: string;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;
}
