import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class BaseUpdateUplineFeeDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsNumber()
  @IsNotEmpty({ message: 'ID must not be empty' })
  id: number;

  @IsNumber()
  @IsOptional()
  fixed: number;

  @IsNumber()
  @IsOptional()
  percentage: number;

  @IsString()
  @IsOptional()
  type: string;
}
