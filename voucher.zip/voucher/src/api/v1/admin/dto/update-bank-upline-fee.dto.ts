import { IsNotEmpty, IsString } from 'class-validator';
import { BaseUpdateUplineFeeDto } from './base-update-upline-fee';

export class UpdateBankUplineFeeDto extends BaseUpdateUplineFeeDto {
  @IsString()
  @IsNotEmpty({ message: 'Bank must not be empty' })
  bank: string;
}
