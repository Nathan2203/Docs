import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class BaseUpdateFeeDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsNumber()
  @IsOptional()
  fixed: number;

  @IsNumber()
  @IsOptional()
  percentage: number;

  @IsString()
  @IsOptional()
  type: string;

  @IsBoolean()
  @IsOptional()
  isActive: boolean;

  @IsBoolean()
  @IsOptional()
  onClient: boolean;

  @IsNumber()
  @IsOptional()
  delay: number;

  @IsString()
  @IsOptional()
  providerId: string;
}
