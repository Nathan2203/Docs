import { IsNotEmpty, IsString } from 'class-validator';

export class MerchantRegisterBncDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'Provider ID must not be empty' })
  providerId: string;

  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsString()
  @IsNotEmpty({ message: 'Merchant Name must not be empty' })
  merchantName: string;

  @IsString()
  @IsNotEmpty({ message: 'Province ID must not be empty' })
  provinceId: string;

  @IsString()
  @IsNotEmpty({ message: 'Province Name must not be empty' })
  provinceName: string;

  @IsString()
  @IsNotEmpty({ message: 'City ID must not be empty' })
  cityId: string;

  @IsString()
  @IsNotEmpty({ message: 'City Name must not be empty' })
  cityName: string;

  @IsString()
  @IsNotEmpty({ message: 'City ID Short must not be empty' })
  cityIdShort: string;

  @IsString()
  @IsNotEmpty({ message: 'District ID must not be empty' })
  districtId: string;

  @IsString()
  @IsNotEmpty({ message: 'District Name must not be empty' })
  districtName: string;

  @IsString()
  @IsNotEmpty({ message: 'Postcode ID must not be empty' })
  postcodeId: string;

  @IsString()
  @IsNotEmpty({ message: 'Merchant Address must not be empty' })
  merchantAddress: string;

  @IsString()
  @IsNotEmpty({ message: 'KTP Number must not be empty' })
  ktpNumber: string;

  @IsString()
  @IsNotEmpty({ message: 'NPWP Number must not be empty' })
  npwpNumber: string;

  @IsString()
  @IsNotEmpty({ message: 'Business Short Name must not be empty' })
  businessShortName: string;

  @IsString()
  @IsNotEmpty({ message: 'MCC must not be empty' })
  mcc: string;

  @IsString()
  @IsNotEmpty({ message: 'Terminal Number must not be empty' })
  terminalNumber: string;

  @IsString()
  @IsNotEmpty({ message: 'Criteria must not be empty' })
  criteria: string;

  @IsString()
  @IsNotEmpty({ message: 'Phone must not be empty' })
  phone: string;

  @IsString()
  @IsNotEmpty({ message: 'Email must not be empty' })
  email: string;
}
