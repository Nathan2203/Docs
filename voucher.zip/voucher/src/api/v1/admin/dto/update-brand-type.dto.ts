import {
  IsArray,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class UpdateBrandTypeDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'Brand Type ID must not be empty' })
  brandTypeId: string;

  @IsString()
  @IsNotEmpty({ message: 'Form must not be empty' })
  form: string;

  @IsArray()
  @IsOptional()
  servers: [string];

  @IsNumber()
  @IsOptional()
  code: number;
}
