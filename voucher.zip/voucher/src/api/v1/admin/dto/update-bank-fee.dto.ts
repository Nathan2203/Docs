import { IsNotEmpty, IsString } from 'class-validator';
import { BaseUpdateFeeDto } from './base-update-fee.dto';

export class UpdateBankFeeDto extends BaseUpdateFeeDto {
  @IsString()
  @IsNotEmpty({ message: 'Bank must not be empty' })
  bank: string;
}
