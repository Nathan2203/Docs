import { IsBoolean, IsNotEmpty } from 'class-validator';
import { UpdateMethodFeeDto } from './update-method-fee.dto';

export class UpdateMethodFeeRootDto extends UpdateMethodFeeDto {
  @IsBoolean()
  @IsNotEmpty({ message: 'Is Root must not be empty' })
  isRoot: boolean;
}
