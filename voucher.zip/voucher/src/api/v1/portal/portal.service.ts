import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { FastifyReply } from 'fastify';
import { Model, Types } from 'mongoose';
import * as crypto from 'crypto';
import fetch from 'node-fetch';
import { authenticator } from 'otplib';

import {
  BankType,
  FeeType,
  PgType,
  TransactionType,
  WithdrawProcess,
  WithdrawStatus,
  WithdrawType,
  ValueType as VType,
  BalanceLogType,
  LogType as LogTypes,
  MethodType,
  TransactionStatusType,
  CallbackType,
  ProviderCodeType,
} from 'src/common/config/enum';
import { FastifyUserRequest } from 'src/common/interface/fastify-user.interface';
import { encryptHmac } from 'src/common/helper/encryptKey';
import { encrypt } from 'src/common/helper/encryptKeyIv';
import { hash } from 'src/common/helper/hash';
import { minifyJson } from 'src/common/helper/minifyJson';
import { decrypt } from 'src/common/helper/decryptKeyIv';
import { generateRandomNumber } from 'src/common/helper/generateRandomNumber';
import { CT_APP_JSON, EMAIL_NOT_PROVIDED } from 'src/common/config/constants';
import { toCurrency } from 'src/common/helper/cast.helper';

import { Bank, BankDocument } from '../admin/entities/bank.entity';
import { Fee, FeeDocument } from '../admin/entities/fee.entity';
import { LogType, LogTypeDocument } from '../admin/entities/log-type.entity';
import { Log, LogDocument } from '../admin/entities/log.entity';
import {
  ValueType,
  ValueTypeDocument,
} from '../admin/entities/value-type.entity';
import { Client, ClientDocument } from '../open/entities/client.entity';
import { Method, MethodDocument } from '../public/entities/method.entity';
import { Balance, BalanceDocument } from '../user/entities/balance.entity';
import {
  Transaction,
  TransactionDocument,
} from '../user/entities/transaction.entity';
import { User, UserDocument } from '../user/entities/user.entity';
import { Withdraw, WithdrawDocument } from '../user/entities/withdraw.entity';
import {
  DevClient,
  DevClientDocument,
} from '../open/entities/dev-client.entity';
import { Browser, BrowserDocument } from '../user/entities/browser.entity';
import {
  BankAccount,
  BankAccountDocument,
} from '../open/entities/bank-account.entity';
import {
  DevTransaction,
  DevTransactionDocument,
} from '../open/entities/dev-transaction.entity';
import {
  DevWithdraw,
  DevWithdrawDocument,
} from '../open/entities/dev-withdraw.entity';

import { UpdateIpWlDto } from './dto/update-ip-wl.dto';
import { Verify2FaDto } from '../admin/dto/verify-2fa.dto';
import { QueryDto } from '../admin/dto/query.dto';
import { ActionTransactionDto } from './dto/action-transaction.dto';
import { ActionDevTransactionDto } from './dto/action-dev-transaction.dto';
import { ActionWithdrawDto } from './dto/action-withdraw.dto';
import { ActionDevWithdrawDto } from './dto/action-dev-withdraw.dto';
import { UpdatePaymentChannelDto } from './dto/update-payment-channel.dto';
import { CheckBankAccountDto } from './dto/check-bank-account.dto';
import { DeleteBankAccountDto } from './dto/delete-bank-account.dto';
import { DisburseDto } from './dto/disburse.dto';

import { SOPResponse, SOPErrorMessage as ErrorMessage } from 'src/common/api';
import {
  Commission,
  CommissionDocument,
} from '../partner/entities/commission.entity';
import {
  BalanceLog,
  BalanceLogDocument,
} from '../user/entities/balance-log.entity';
import { TopupDto } from './dto/topup.dto';
import { Session, SessionDocument } from '../user/entities/session.entity';
import sendCallback from 'src/common/util/sendCallback';
import {
  Callback,
  CallbackDocument,
} from '../callback/entities/callback.entity';
import {
  DevCallback,
  DevCallbackDocument,
} from '../callback/entities/dev-callback.entity';
import { ChangePasswordDto } from '../admin/dto/change-password.dto';
import { encryptPass } from 'src/common/helper/encryptPass';
import { ProviderService } from 'src/core/provider/provider.service';
import sendWaNotif from 'src/common/util/sendWaNotif';
const response = new SOPResponse();

@Injectable()
export class PortalService {
  constructor(
    private readonly providerService: ProviderService,
    @InjectModel(Browser.name) private readonly Browser: Model<BrowserDocument>,
    @InjectModel(Session.name) private readonly Session: Model<SessionDocument>,
    @InjectModel(Client.name) private readonly Client: Model<ClientDocument>,
    @InjectModel(DevClient.name)
    private readonly DevClient: Model<DevClientDocument>,
    @InjectModel(User.name) private readonly User: Model<UserDocument>,
    @InjectModel(Method.name) private readonly Method: Model<MethodDocument>,
    @InjectModel(Bank.name) private readonly Bank: Model<BankDocument>,
    @InjectModel(Fee.name) private readonly Fee: Model<FeeDocument>,
    @InjectModel(Transaction.name)
    private readonly Transaction: Model<TransactionDocument>,
    @InjectModel(DevTransaction.name)
    private readonly DevTransaction: Model<DevTransactionDocument>,
    @InjectModel(Withdraw.name)
    private readonly Withdraw: Model<WithdrawDocument>,
    @InjectModel(DevWithdraw.name)
    private readonly DevWithdraw: Model<DevWithdrawDocument>,
    @InjectModel(Balance.name)
    private readonly Balance: Model<BalanceDocument>,
    @InjectModel(BalanceLog.name)
    private readonly BalanceLog: Model<BalanceLogDocument>,
    @InjectModel(ValueType.name)
    private readonly ValueType: Model<ValueTypeDocument>,
    @InjectModel(LogType.name)
    private readonly LogType: Model<LogTypeDocument>,
    @InjectModel(Log.name)
    private readonly Log: Model<LogDocument>,
    @InjectModel(BankAccount.name)
    private readonly BankAccount: Model<BankAccountDocument>,
    @InjectModel(Commission.name)
    private readonly Commission: Model<CommissionDocument>,
    @InjectModel(Callback.name)
    private readonly Callback: Model<CallbackDocument>,
    @InjectModel(DevCallback.name)
    private readonly DevCallback: Model<DevCallbackDocument>,
  ) {}

  async getOverview(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      const todayStart = new Date();
      todayStart.setDate(todayStart.getDate() - 1);
      todayStart.setHours(17, 0, 0, 0);
      const todayEnd = new Date();
      todayEnd.setHours(16, 59, 59, 999);

      await this.User.aggregate([
        {
          $match: {
            $expr: {
              $eq: ['$_id', { $toObjectId: user.id }],
            },
          },
        },
        // lookup the transactions collection and filter by 'Paid' status
        {
          $lookup: {
            from: 'transactions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      {
                        $eq: ['$transactionType', TransactionType.Transaction],
                      },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'transaction',
          },
        },
        {
          $unwind: {
            path: '$transaction',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'transactions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      {
                        $eq: ['$transactionType', TransactionType.Topup],
                      },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'topup',
          },
        },
        {
          $unwind: {
            path: '$topup',
            preserveNullAndEmptyArrays: true,
          },
        },
        // lookup the withdraw collection and filter by 'Paid' and 'Pending' status
        {
          $lookup: {
            from: 'withdraws',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      { $eq: ['$process', WithdrawProcess.Process] },
                      { $eq: ['$withdrawType', WithdrawType.Client] },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'withdraw',
          },
        },
        {
          $unwind: {
            path: '$withdraw',
            preserveNullAndEmptyArrays: true,
          },
        },
        // lookup the balance collection and filter by user
        {
          $lookup: {
            from: 'balances',
            let: { userId: '$_id' },
            pipeline: [
              { $match: { $expr: { $eq: ['$user', '$$userId'] } } },
              {
                $project: {
                  _id: 0,
                  balance: 1,
                  pending: 1,
                  freeze: 1,
                  debt: 1,
                },
              },
            ],
            as: 'balance',
          },
        },
        {
          $unwind: {
            path: '$balance',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'clients',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: { $eq: ['$user', '$$userId'] },
                },
              },
            ],
            as: 'client',
          },
        },
        {
          $unwind: {
            path: '$client',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 1,
            username: 1,
            email: 1,
            phone: 1,
            isVerified: 1,
            createdAt: 1,
            updatedAt: 1,
            transaction: {
              $let: {
                vars: {
                  transactionData: {
                    $ifNull: ['$transaction', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$transactionData', null] },
                    then: null,
                    else: '$$transactionData',
                  },
                },
              },
            },
            topup: {
              $let: {
                vars: {
                  topupData: {
                    $ifNull: ['$topup', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$topupData', null] },
                    then: null,
                    else: '$$topupData',
                  },
                },
              },
            },
            withdraw: {
              $let: {
                vars: {
                  withdrawData: {
                    $ifNull: ['$withdraw', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$withdrawData', null] },
                    then: null,
                    else: '$$withdrawData',
                  },
                },
              },
            },
            balance: {
              $let: {
                vars: {
                  balanceData: {
                    $ifNull: ['$balance', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$balanceData', null] },
                    then: null,
                    else: '$$balanceData',
                  },
                },
              },
            },
            client: {
              clientName: 1,
              limit: 1,
              isKey: {
                $let: {
                  vars: {
                    secret: { $ifNull: ['$client.clientSecret', false] },
                    signature: { $ifNull: ['$client.signatureKey', false] },
                  },
                  in: {
                    $and: ['$$secret', '$$signature'],
                  },
                },
              },
              isCallback: {
                $let: {
                  vars: {
                    callbackTrx: {
                      $ifNull: ['$client.callbackTrx', null],
                    },
                    callbackWd: {
                      $ifNull: ['$client.callbackWd', null],
                    },
                    callbackTopup: {
                      $ifNull: ['$client.callbackTopup', null],
                    },
                    key: {
                      $ifNull: ['$client.callbackKey', false],
                    },
                  },
                  in: {
                    $and: [
                      '$$callbackTrx',
                      '$$callbackWd',
                      '$$callbackTopup',
                      '$$key',
                    ],
                  },
                },
              },
            },
          },
        },
      ]).then((user) => {
        if (user && user.length) {
          const success = response.initSuccess(200, true, user[0]);
          return res.send(success);
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('User data not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async doLogout(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      await this.Session.findOne({ user: user.id }).then(
        async (sessionFind) => {
          const updateSession = {
            sessionToken: undefined,
            sessionExpires: undefined,
            refreshToken: undefined,
            refreshExpires: undefined,
            lastActivityDate: new Date(),
          };

          await this.Session.findByIdAndUpdate(
            sessionFind.id,
            { $set: updateSession },
            { new: true, upsert: true },
          );

          await this.LogType.findOne({
            type: LogTypes.Logout,
          }).then(async (logType) => {
            if (logType) {
              const newLog = new this.Log({
                message: `${user.username} Logout`,
                ip: req.ip,
                type: logType.id,
                user: user.id,
              });

              await newLog.save();
            }
          });

          const success = response.initSuccess(200, true, true);
          return res.send(success);
        },
      );
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async changePassword(
    data: ChangePasswordDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (data.old !== data.new) {
        const { user, browser } = req.user;
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };
        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (data.signature === signatureVerify) {
          if (user.secret2Fa && user.isVerified && !data.code) {
            if (data.code) {
              const keyDec = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', user.id).substring(0, 32),
                hash('sha256', user.id + user.username).substring(0, 16),
                user.secret2Fa,
              );

              if (!authenticator.check(data.code, keyDec)) {
                const error = response.initError(
                  403,
                  false,
                  new ErrorMessage('Invalid 2FA Code'),
                );
                return res.send(error);
              }
            } else {
              const error = response.initError(
                403,
                false,
                new ErrorMessage('2FA code must not be empty'),
              );
              return res.send(error);
            }
          }
          if (!user.comparePass(data.old)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Invalid Old Password'),
            );
            return res.send(error);
          } else {
            await this.User.findByIdAndUpdate(user.id, {
              pass: await encryptPass(data.new),
            });

            const success = response.initSuccess(200, true, true);
            return res.send(success);
          }
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage("New password can't be same with the old one"),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async topup(data: TopupDto, req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.Method.aggregate([
          {
            $match: {
              $expr: {
                $eq: ['$_id', { $toObjectId: data.method }],
              },
              isActive: true,
            },
          },
          {
            $lookup: {
              from: 'fees',
              let: { methodId: '$_id' },
              pipeline: [
                {
                  $match: {
                    $expr: {
                      $and: [
                        { $eq: ['$method', '$$methodId'] },
                        { $eq: ['$feeType', FeeType.Transaction] },
                        { $eq: ['$user', { $toObjectId: user.id }] },
                      ],
                    },
                  },
                },
                {
                  $lookup: {
                    from: 'users',
                    localField: 'user',
                    foreignField: '_id',
                    as: 'user',
                  },
                },
                {
                  $unwind: '$user',
                },
                {
                  $lookup: {
                    from: 'providers',
                    let: { providerId: '$provider' },
                    pipeline: [
                      {
                        $match: {
                          $expr: { $eq: ['$_id', '$$providerId'] },
                        },
                      },
                      {
                        $lookup: {
                          from: 'providers',
                          localField: 'providerRoot',
                          foreignField: '_id',
                          as: 'providerRoot',
                        },
                      },
                      {
                        $unwind: {
                          path: '$providerRoot',
                          preserveNullAndEmptyArrays: true,
                        },
                      },
                    ],
                    as: 'provider',
                  },
                },
                {
                  $unwind: '$provider',
                },
              ],
              as: 'fee',
            },
          },
          {
            $unwind: '$fee',
          },
          {
            $lookup: {
              from: 'valuetypes',
              localField: 'fee.type',
              foreignField: '_id',
              as: 'fee.type',
            },
          },
          {
            $unwind: '$fee.type',
          },
        ]).then(async (methods) => {
          if (methods.length) {
            const method = methods[0];
            if (
              method.fee.isActive &&
              method.fee.provider &&
              method.fee.provider.key
            ) {
              if (payload.amount < method.min) {
                const error = response.initError(
                  403,
                  false,
                  new ErrorMessage(`Minimal amount ${toCurrency(method.min)}`),
                );
                return res.send(error);
              } else if (payload.amount > method.max) {
                const error = response.initError(
                  403,
                  false,
                  new ErrorMessage(`Maximal amount ${toCurrency(method.max)}`),
                );
                return res.send(error);
              } else {
                var keyDec: string;
                if (method.fee.provider.key === 'root') {
                  keyDec = decrypt(
                    process.env.ENCRYPT_ALG,
                    hash(
                      'sha256',
                      method.fee.provider.providerRoot._id.valueOf(),
                    ).substring(0, 32),
                    hash(
                      'sha256',
                      method.fee.provider.providerRoot.user.valueOf() +
                        method.fee.provider.providerRoot.code,
                    ).substring(0, 16),
                    method.fee.provider.providerRoot.key,
                  );
                } else {
                  keyDec = decrypt(
                    process.env.ENCRYPT_ALG,
                    hash('sha256', method.fee.provider._id.valueOf()).substring(
                      0,
                      32,
                    ),
                    hash(
                      'sha256',
                      method.fee.provider.user.valueOf() +
                        method.fee.provider.code,
                    ).substring(0, 16),
                    method.fee.provider.key,
                  );
                }

                let feeAmount: number;
                switch (method.fee.type.name) {
                  case VType.Percentage:
                    feeAmount = Math.floor(
                      (payload.amount * method.fee.percentage) / 100,
                    );
                    break;
                  case VType.Fixed:
                    feeAmount = method.fee.fixed;
                    break;
                  default:
                    feeAmount = Math.floor(
                      (payload.amount * method.fee.percentage) / 100 +
                        method.fee.fixed,
                    );
                    break;
                }

                await this.LogType.findOne({
                  type: LogTypes.ClientTopup,
                }).then(async (logType) => {
                  if (logType) {
                    const newLog = new this.Log({
                      message: `${user.username} topup ${payload.amount} with fee ${feeAmount}`,
                      ip: req.ip,
                      type: logType.id,
                      user: user.id,
                    });

                    await newLog.save();
                  }
                });

                const clientData = await this.Client.findOne({
                  user: user.id,
                });

                const orderId = generateRandomNumber(
                  method.fee.provider.code === ProviderCodeType.Mpi ? 20 : 50,
                );
                const key = JSON.parse(keyDec);
                const amount = method.fee.onClient
                  ? payload.amount
                  : payload.amount + feeAmount;

                if (
                  method.fee.provider.code === ProviderCodeType.Bnc &&
                  method.type === MethodType.Qris
                ) {
                  const accessToken =
                    await this.providerService.getBncAccessToken(key.clientId);

                  const expWib = new Date();
                  expWib.setMinutes(expWib.getMinutes() + 30);

                  const payloadPg = {
                    partnerReferenceNo: orderId,
                    amount: {
                      value: `${amount}`,
                      currency: 'IDR',
                    },
                    merchantId: key.merchantId,
                    storeId:
                      method.fee.provider.auditStatus === '2'
                        ? method.fee.provider.storeId
                        : method.fee.providerRoot.storeId,
                    terminalId: 'A01',
                    validityPeriod: '1800',
                    additionalInfo: {
                      qrType: '12',
                      tipType: '00',
                    },
                  };

                  const resultPg = await this.providerService.generateQrisBnc(
                    key.clientId,
                    accessToken,
                    payloadPg,
                  );

                  const transactionId =
                    'T' +
                    hash('sha256', generateRandomNumber(5) + expWib.getTime());

                  const newTransaction = new this.Transaction({
                    transactionId,
                    orderId,
                    refId: '',
                    amount,
                    fee: feeAmount,
                    feeAdmin: 0,
                    exp: expWib.getTime(),
                    method: new Types.ObjectId(method._id),
                    user: user.id,
                    ip: req.ip,
                    provider: method.fee.provider._id,
                    transactionType: TransactionType.Topup,
                  });

                  var result: SOPResponse;
                  if (resultPg) {
                    newTransaction.status = TransactionStatusType.Pending;
                    newTransaction.payment = resultPg.qrContent;
                    newTransaction.refId = resultPg.referenceNo;

                    result = response.initSuccess(200, true, transactionId);
                  } else {
                    newTransaction.status = TransactionStatusType.Failed;

                    result = response.initSuccess(200, false, transactionId);
                  }
                  await newTransaction.save();
                  return res.status(200).send(result);
                } else if (
                  method.type === MethodType.Va &&
                  method.name === 'BCA'
                ) {
                  const expWib = new Date();
                  expWib.setHours(expWib.getHours() + 12);

                  const transactionId =
                    'T' +
                    hash('sha256', generateRandomNumber(5) + expWib.getTime());

                  const newTransaction = new this.Transaction({
                    transactionId,
                    orderId,
                    refId: '',
                    amount,
                    fee: feeAmount,
                    exp: expWib.getTime(),
                    method: new Types.ObjectId(method._id),
                    user: user.id,
                    ip: req.ip,
                    provider: method.fee.provider._id,
                    transactionType: TransactionType.Topup,
                  });

                  if (method.fee.provider.code === ProviderCodeType.Mpi) {
                    const jwt = Buffer.from(
                      `${key.storeId}:${key.username}:${key.password}:${key.pin}`,
                      'utf-8',
                    ).toString('base64');

                    const payloadPg = {
                      amount: amount,
                      idtrx: orderId,
                      email: EMAIL_NOT_PROVIDED,
                      firstName: 'Payment',
                      lastName:
                        clientData.paymentClientName === 'root'
                          ? clientData.clientName
                          : clientData.paymentClientName,
                      phoneNumber: '08170025687',
                      merchantName: 'MPS VABCA',
                    };

                    const resultPg =
                      await this.providerService.generateBcaVaMpi(
                        jwt,
                        payloadPg,
                        key.pin,
                      );

                    var result: SOPResponse;
                    if (resultPg) {
                      newTransaction.status = TransactionStatusType.Pending;
                      newTransaction.payment = resultPg.va;
                      newTransaction.url = resultPg.url;
                      newTransaction.refId = resultPg.refId;

                      result = response.initSuccess(200, true, transactionId);
                    } else {
                      newTransaction.status = TransactionStatusType.Failed;

                      result = response.initSuccess(200, false, transactionId);
                    }
                    await newTransaction.save();
                    return res.status(200).send(result);
                  } else {
                    const error = response.initError(
                      403,
                      false,
                      new ErrorMessage(`Bank not supported`),
                    );
                    return res.status(200).send(error);
                  }
                } else {
                  const exp = new Date();
                  exp.setDate(exp.getDate() + 1);
                  exp.setHours(exp.getHours() + 7);
                  const dateString = exp
                    .toLocaleString('en-US', {
                      year: 'numeric',
                      month: '2-digit',
                      day: '2-digit',
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit',
                    })
                    .replace(/\/|,|:| /g, '');
                  const formattedDate = `${dateString.slice(
                    4,
                    8,
                  )}${dateString.slice(0, 2)}${dateString.slice(
                    2,
                    4,
                  )}${dateString.slice(8, 14)}`;
                  const customerId = exp.getTime();

                  const reqMethod = 'POST';
                  const paramX = `${method.path}${reqMethod}`;
                  var paramY: string;
                  if (
                    method.type === MethodType.Va ||
                    method.type === MethodType.Retail
                  ) {
                    paramY = `${amount}${formattedDate}${
                      method.code
                    }${orderId}${customerId}${
                      clientData.paymentClientName === 'root'
                        ? clientData.clientName
                        : clientData.paymentClientName
                    }${EMAIL_NOT_PROVIDED}${key.clientId}`;
                  } else if (method.type === MethodType.Qris) {
                    paramY = `${amount}${formattedDate}${orderId}${customerId}${
                      clientData.paymentClientName === 'root'
                        ? clientData.clientName
                        : clientData.paymentClientName
                    }${EMAIL_NOT_PROVIDED}${key.clientId}`;
                  } else if (method.type === MethodType.Ewallet) {
                    if (data.phone) {
                      paramY = `${amount}${formattedDate}${
                        method.code
                      }${orderId}${customerId}${
                        clientData.paymentClientName === 'root'
                          ? clientData.clientName
                          : clientData.paymentClientName
                      }${EMAIL_NOT_PROVIDED}${data.phone}${key.clientId}`;
                    } else {
                      const error = response.initError(
                        403,
                        false,
                        new ErrorMessage('Phone is required'),
                      );
                      return res.send(error);
                    }
                  } else {
                    const error = response.initError(
                      404,
                      false,
                      new ErrorMessage('Method type not found'),
                    );
                    return res.send(error);
                  }

                  const sig = encryptHmac(
                    'sha256',
                    key.sigKey,
                    paramX + paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
                    'hex',
                  );

                  const payloadPg: any = {
                    expired: formattedDate,
                    amount: Number(amount),
                    customer_id: Number(customerId),
                    partner_reff: orderId,
                    customer_email: EMAIL_NOT_PROVIDED,
                    username: key.username,
                    pin: key.pin,
                    customer_name: `${
                      clientData.paymentClientName === 'root'
                        ? clientData.clientName
                        : clientData.paymentClientName
                    }`,
                    signature: sig,
                  };
                  if (method.type === MethodType.Va) {
                    payloadPg.bank_code = method.code;
                  } else if (
                    method.type === MethodType.Ewallet ||
                    method.type === MethodType.Retail
                  ) {
                    payloadPg.retail_code = method.code;
                    if (method.type === MethodType.Ewallet) {
                      payloadPg.ewallet_phone = data.phone;
                      payloadPg.bill_title = 'NiagaPay';
                      payloadPg.customer_phone = data.phone;
                    } else {
                      payloadPg.customer_phone = '081234567890';
                    }
                  }
                  const header = {
                    'Content-Type': CT_APP_JSON,
                    'client-id': key.clientId,
                    'client-secret': key.clientSecret,
                  };
                  await fetch(
                    process.env.PG_BASE_URL + method.path.substring(1),
                    {
                      method: reqMethod,
                      body: JSON.stringify(payloadPg),
                      headers: header,
                    },
                  )
                    .then(async (responseFetch) => {
                      const responseData = await responseFetch.json();
                      // console.log(responseData);

                      const transactionId =
                        'CTP' +
                        browser.browserId
                          .replace(/[^a-zA-Z0-9]/g, '')
                          .substring(0, 5) +
                        generateRandomNumber(5) +
                        exp.getTime();

                      const newTransaction = new this.Transaction({
                        transactionId,
                        orderId,
                        refId: responseData.partner_reff2,
                        amount,
                        fee: feeAmount,
                        feeAdmin: responseData.feeadmin,
                        phone: data.phone,
                        payment:
                          responseData.virtual_account ??
                          responseData.payment_code ??
                          responseData.qris_text,
                        url: responseData.url_payment,
                        exp,
                        method: new Types.ObjectId(method._id),
                        user: user.id,
                        ip: req.ip,
                        provider: method.fee.provider._id,
                        transactionType: TransactionType.Topup,
                      });

                      var result: SOPResponse;
                      if (
                        responseData.status === PgType.Success &&
                        responseData.response_code === PgType.SuccessCode
                      ) {
                        newTransaction.status = TransactionStatusType.Pending;

                        result = response.initSuccess(200, true, transactionId);
                      } else {
                        newTransaction.status = TransactionStatusType.Failed;

                        result = response.initSuccess(
                          200,
                          false,
                          transactionId,
                        );
                      }

                      await newTransaction.save();
                      return res.send(result);
                    })
                    .catch((err) => {
                      console.log(err);
                      const error = response.initError(
                        500,
                        false,
                        new ErrorMessage(
                          "There's an error on the server, please wait :)",
                        ),
                      );
                      return res.send(error);
                    });
                }
              }
            } else {
              const error = response.initError(
                403,
                false,
                new ErrorMessage('Payment method not allowed'),
              );
              return res.send(error);
            }
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Payment method not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getTopupInvoice(
    transId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      await this.Transaction.findOne({
        user: new Types.ObjectId(user.id),
        transactionId: transId,
      })
        .populate({
          path: 'method',
          select: '-_id name img type',
        })
        .populate({
          path: 'user',
          select: '_id username',
        })
        .select(
          '-uplineFee -ip -feeAdmin -accessFrom -refId -orderId -pgSettled -__v -provider -updatedAt',
        )
        .then((transaction) => {
          const success = response.initSuccess(200, true, transaction);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getTopupStatus(id: string, req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      this.Transaction.findOne({
        user: new Types.ObjectId(user.id),
        transactionId: id,
      })
        .select('status')
        .then((transaction) => {
          if (transaction) {
            const success = response.initSuccess(200, true, transaction.status);
            return res.send(success);
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Transaction not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDisburseFee(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      await this.Fee.findOne({
        feeType: FeeType.Bank,
        user: new Types.ObjectId(user.id),
      })
        .populate('type', 'name')
        .select('fixed percentage type')
        .then(async (feeFound) => {
          if (feeFound) {
            const success = response.initSuccess(200, true, feeFound);
            return res.send(success);
          } else {
            const error = response.initError(
              200,
              false,
              new ErrorMessage('Fee not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async disburseInquiry(
    payload: DisburseDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const xTime = req.headers['x-timestamp'];
      const xSig = req.headers['x-signature'];
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === xSig) {
        if (user.secret2Fa && user.isVerified) {
          await this.Client.findOne({
            user: user.id,
          }).then(async (client) => {
            if (client) {
              if (payload.amount > client.limit) {
                const error = response.initError(
                  400,
                  false,
                  new ErrorMessage(
                    `Transfer amount can exceed limit ${client.limit}`,
                  ),
                );
                return res.send(error);
              } else {
                await this.BankAccount.findOne({
                  _id: new Types.ObjectId(payload.bankAccountId),
                  user: user.id,
                })
                  .populate('bank')
                  .then(async (bankAccount: any) => {
                    if (bankAccount) {
                      if (payload.amount < bankAccount.bank.min) {
                        const error = response.initError(
                          403,
                          false,
                          new ErrorMessage(
                            'Minimum amount is ' +
                              toCurrency(bankAccount.bank.min),
                          ),
                        );
                        return res.send(error);
                      } else if (payload.amount > bankAccount.bank.max) {
                        const error = response.initError(
                          403,
                          false,
                          new ErrorMessage(
                            'Maximum amount is ' +
                              toCurrency(bankAccount.bank.max),
                          ),
                        );
                        return res.send(error);
                      } else {
                        await this.Balance.findOne({
                          user: user.id,
                        }).then(async (balanceFound) => {
                          if (balanceFound) {
                            var fee = 0;
                            var keyDec = '',
                              providerId = '';
                            await this.Fee.findOne({
                              feeType: FeeType.Bank,
                              user: user.id,
                            })
                              .populate('type')
                              .populate({
                                path: 'provider',
                                populate: {
                                  path: 'providerRoot',
                                },
                              })
                              .then((feeFound: any) => {
                                if (feeFound) {
                                  switch (feeFound.type.name) {
                                    case VType.Percentage:
                                      fee = Math.floor(
                                        (payload.amount * feeFound.percentage) /
                                          100,
                                      );
                                      break;
                                    case VType.Fixed:
                                      fee = feeFound.fixed;
                                      break;
                                    default:
                                      fee = Math.floor(
                                        (payload.amount * feeFound.percentage) /
                                          100 +
                                          feeFound.fixed,
                                      );
                                      break;
                                  }

                                  if (feeFound.provider.key === 'root') {
                                    keyDec = decrypt(
                                      process.env.ENCRYPT_ALG,
                                      hash(
                                        'sha256',
                                        feeFound.provider.providerRoot.id.valueOf(),
                                      ).substring(0, 32),
                                      hash(
                                        'sha256',
                                        feeFound.provider.providerRoot.user.valueOf() +
                                          feeFound.provider.providerRoot.code,
                                      ).substring(0, 16),
                                      feeFound.provider.providerRoot.key,
                                    );
                                  } else {
                                    keyDec = decrypt(
                                      process.env.ENCRYPT_ALG,
                                      hash(
                                        'sha256',
                                        feeFound.provider.id,
                                      ).substring(0, 32),
                                      hash(
                                        'sha256',
                                        feeFound.provider.user.valueOf() +
                                          feeFound.provider.code,
                                      ).substring(0, 16),
                                      feeFound.provider.key,
                                    );
                                  }
                                  providerId = feeFound.provider.id;
                                } else {
                                  const error = response.initError(
                                    404,
                                    false,
                                    new ErrorMessage('Fee not found'),
                                  );
                                  return res.send(error);
                                }
                              });
                            if (balanceFound.balance < payload.amount + fee) {
                              const error = response.initError(
                                403,
                                false,
                                new ErrorMessage('Balance is not enough'),
                              );
                              return res.send(error);
                            } else {
                              const key = JSON.parse(keyDec);

                              const amount = payload.amount;
                              const orderId = generateRandomNumber(50);
                              const url = 'transaction/withdraw/inquiry';
                              const paramX = `/${url}POST`;
                              const paramY = `${amount}${bankAccount.account}${bankAccount.bank.code}${orderId}${key.clientId}`;

                              const sig = encryptHmac(
                                'sha256',
                                key.sigKey,
                                paramX +
                                  paramY
                                    .toLowerCase()
                                    .replace(/[^a-zA-Z0-9]/g, ''),
                                'hex',
                              );
                              const payloadCheck: any = {
                                amount: Number(amount),
                                partner_reff: orderId,
                                accountnumber: bankAccount.account,
                                bankcode: bankAccount.bank.code,
                                username: key.username,
                                pin: key.pin,
                                signature: sig,
                              };

                              const header = {
                                'client-id': key.clientId,
                                'client-secret': key.clientSecret,
                              };
                              await fetch(process.env.PG_BASE_URL + url, {
                                method: 'POST',
                                body: JSON.stringify(payloadCheck),
                                headers: header,
                              }).then(async (responseFetch) => {
                                const responseData = await responseFetch.json();
                                if (
                                  responseData.status === PgType.Success &&
                                  responseData.response_code ===
                                    PgType.SuccessCode
                                ) {
                                  if (
                                    responseData.accountname ===
                                    bankAccount.name
                                  ) {
                                    const withdrawId =
                                      'D' +
                                      hash(
                                        'sha256',
                                        generateRandomNumber(5) + xTime,
                                      );
                                    const signature = encryptHmac(
                                      'sha512',
                                      xTime + user.username + user.pass,
                                      'POST' +
                                        '/disburse/process'.toString() +
                                        hash(
                                          'sha512',
                                          minifyJson(payload),
                                        ).toLowerCase() +
                                        '|' +
                                        browser.id +
                                        '|' +
                                        user.id +
                                        '|' +
                                        withdrawId +
                                        '|' +
                                        responseData.inquiry_reff,
                                      'hex',
                                    );

                                    const newWithdraw = new this.Withdraw({
                                      withdrawId,
                                      orderId,
                                      amount,
                                      fee,
                                      feeAdmin: responseData.additionalfee,
                                      name: responseData.accountname,
                                      accNumber: bankAccount.account,
                                      inquiryReff: responseData.inquiry_reff,
                                      withdrawType: WithdrawType.Client,
                                      inquiryBy: user.id,
                                      bank: new Types.ObjectId(
                                        bankAccount.bank._id,
                                      ),
                                      bankAccount: new Types.ObjectId(
                                        bankAccount._id,
                                      ),
                                      user: user.id,
                                      ip: req.ip,
                                      provider: providerId,
                                    });

                                    if (payload.remark) {
                                      newWithdraw.remark = payload.remark;
                                    }

                                    await newWithdraw.save();
                                    const success = response.initSuccess(
                                      200,
                                      true,
                                      {
                                        signature,
                                        withdrawId,
                                        amount,
                                        fee,
                                        name: responseData.accountname,
                                        account: bankAccount.account,
                                        bank: bankAccount.bank.name,
                                      },
                                    );
                                    return res.send(success);
                                  }
                                } else {
                                  const error = response.initError(
                                    404,
                                    false,
                                    new ErrorMessage('Bank account not found'),
                                  );
                                  return res.send(error);
                                }
                              });
                            }
                          } else {
                            const error = response.initError(
                              404,
                              false,
                              new ErrorMessage('Balance not found'),
                            );
                            return res.send(error);
                          }
                        });
                      }
                    } else {
                      const error = response.initError(
                        404,
                        false,
                        new ErrorMessage('Bank Account not found'),
                      );
                      return res.send(error);
                    }
                  });
              }
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Client data not found'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Please setup 2FA first'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async disburseProcess(
    withdrawId: string,
    data: DisburseDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (data.code) {
        const { user, browser } = req.user;
        if (user.secret2Fa && user.isVerified) {
          const keyDec = decrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', user.id).substring(0, 32),
            hash('sha256', user.id + user.username).substring(0, 16),
            user.secret2Fa,
          );

          if (!authenticator.check(data.code, keyDec)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Invalid 2FA Code'),
            );
            return res.send(error);
          }

          await this.Withdraw.findOne({
            withdrawId,
            process: WithdrawProcess.Inquiry,
          })
            .populate('bank')
            .then(async (withdraw: any) => {
              if (withdraw) {
                const xTime = req.headers['x-timestamp'];
                const xSig = req.headers['x-signature'];
                const { code: _, ...payload } = data;
                const signature = encryptHmac(
                  'sha512',
                  xTime + user.username + user.pass,
                  'POST' +
                    '/disburse/process'.toString() +
                    hash('sha512', minifyJson(payload)).toLowerCase() +
                    '|' +
                    browser.id +
                    '|' +
                    user.id +
                    '|' +
                    withdraw.withdrawId +
                    '|' +
                    withdraw.inquiryReff,
                  'hex',
                );
                const signatureVerify = encryptHmac(
                  'sha256',
                  browser.csrf,
                  signature + '|' + browser.browserId,
                  'hex',
                );

                const updateBrowser = {
                  user: user.id,
                  $push: { ip: req.ip },
                };

                await this.Browser.findByIdAndUpdate(
                  browser.id,
                  {
                    $set: updateBrowser,
                    $unset: {
                      csrf: undefined,
                    },
                  },
                  { new: true, upsert: true },
                );

                if (signatureVerify === xSig) {
                  await this.Balance.findOne({
                    user: withdraw.user,
                  })
                    .populate('user')
                    .then(async (balanceFound: any) => {
                      if (balanceFound) {
                        if (
                          balanceFound.balance <
                          payload.amount + withdraw.fee
                        ) {
                          const error = response.initError(
                            403,
                            false,
                            new ErrorMessage('Balance is not enough'),
                          );
                          return res.send(error);
                        } else {
                          await this.Client.findOne({
                            user: withdraw.user,
                          }).then(async (client) => {
                            if (client) {
                              await this.Fee.findOne({
                                user: client.user,
                                feeType: FeeType.Bank,
                              })
                                .populate({
                                  path: 'provider',
                                  populate: {
                                    path: 'providerRoot',
                                  },
                                })
                                .then(async (fee: any) => {
                                  if (fee) {
                                    const updateWithdraw: any = {
                                      status:
                                        withdraw.amount >= client.limit
                                          ? WithdrawStatus.Pending
                                          : WithdrawStatus.Processing,
                                      process: WithdrawProcess.Process,
                                      processedBy: user.id,
                                      processedDate: new Date(),
                                    };

                                    await this.Balance.findByIdAndUpdate(
                                      balanceFound.id,
                                      {
                                        $inc: {
                                          balance: -Number(
                                            withdraw.amount + withdraw.fee,
                                          ),
                                        },
                                      },
                                    );

                                    const newBalanceLog = new this.BalanceLog({
                                      name: `Transfer process with amount ${toCurrency(
                                        withdraw.amount,
                                      )} and fee ${toCurrency(withdraw.fee)}`,
                                      balanceAmount: balanceFound.balance,
                                      balanceCredit: Number(
                                        withdraw.amount + withdraw.fee,
                                      ),
                                      type: BalanceLogType.Out,
                                      balance: balanceFound.id,
                                      withdraw: withdraw.id,
                                    });

                                    await newBalanceLog.save();

                                    await this.LogType.findOne({
                                      type: LogTypes.ClientDisburse,
                                    }).then(async (logType) => {
                                      if (logType) {
                                        const newLog = new this.Log({
                                          message: `${user.username} disburse ${withdraw.amount} with fee ${withdraw.fee}`,
                                          ip: req.ip,
                                          type: logType.id,
                                          user: user.id,
                                        });

                                        await newLog.save();
                                      }
                                    });

                                    await this.Withdraw.findByIdAndUpdate(
                                      withdraw.id,
                                      updateWithdraw,
                                    );

                                    if (withdraw.amount < client.limit) {
                                      var keyDec = '';
                                      if (fee.provider.key === 'root') {
                                        keyDec = decrypt(
                                          process.env.ENCRYPT_ALG,
                                          hash(
                                            'sha256',
                                            fee.provider.providerRoot.id.valueOf(),
                                          ).substring(0, 32),
                                          hash(
                                            'sha256',
                                            fee.provider.providerRoot.user.valueOf() +
                                              fee.provider.providerRoot.code,
                                          ).substring(0, 16),
                                          fee.provider.providerRoot.key,
                                        );
                                      } else {
                                        keyDec = decrypt(
                                          process.env.ENCRYPT_ALG,
                                          hash(
                                            'sha256',
                                            fee.provider.id,
                                          ).substring(0, 32),
                                          hash(
                                            'sha256',
                                            fee.provider.user.valueOf() +
                                              fee.provider.code,
                                          ).substring(0, 16),
                                          fee.provider.key,
                                        );
                                      }
                                      const key = JSON.parse(keyDec);

                                      const url =
                                        'transaction/withdraw/payment';
                                      const paramX = `/${url}POST`;
                                      const paramY = `${withdraw.amount}${withdraw.accNumber}${withdraw.bank.code}${withdraw.orderId}${withdraw.inquiryReff}${key.clientId}`;

                                      const sig = encryptHmac(
                                        'sha256',
                                        key.sigKey,
                                        paramX +
                                          paramY
                                            .toLowerCase()
                                            .replace(/[^a-zA-Z0-9]/g, ''),
                                        'hex',
                                      );
                                      const payloadPayment: any = {
                                        amount: Number(withdraw.amount),
                                        partner_reff: withdraw.orderId,
                                        inquiry_reff: withdraw.inquiryReff,
                                        accountnumber: withdraw.accNumber,
                                        bankcode: withdraw.bank.code,
                                        username: key.username,
                                        pin: key.pin,
                                        signature: sig,
                                      };

                                      if (withdraw.remark) {
                                        payloadPayment.remark = withdraw.remark;
                                      }

                                      const header = {
                                        'Content-Type': CT_APP_JSON,
                                        'client-id': key.clientId,
                                        'client-secret': key.clientSecret,
                                      };
                                      await fetch(
                                        process.env.PG_BASE_URL + url,
                                        {
                                          method: 'POST',
                                          body: JSON.stringify(payloadPayment),
                                          headers: header,
                                        },
                                      )
                                        .then(async (responseFetch) => {
                                          const responseData =
                                            await responseFetch.json();

                                          if (
                                            responseData.status ===
                                            PgType.Failed
                                          ) {
                                            withdraw.error =
                                              responseData.response_desc;
                                            withdraw.status =
                                              WithdrawStatus.Failed;
                                            await withdraw.save();

                                            const updatedBalance =
                                              await this.Balance.findByIdAndUpdate(
                                                balanceFound.id,
                                                {
                                                  $inc: {
                                                    balance: Number(
                                                      withdraw.amount +
                                                        withdraw.fee,
                                                    ),
                                                  },
                                                },
                                                { new: true },
                                              );

                                            const newBalanceLog =
                                              new this.BalanceLog({
                                                name: `system's return disburse`,
                                                balanceAmount:
                                                  updatedBalance.balance -
                                                  (withdraw.amount +
                                                    withdraw.fee),
                                                balanceCredit: Number(
                                                  withdraw.amount +
                                                    withdraw.fee,
                                                ),
                                                type: BalanceLogType.Refund,
                                                balance: balanceFound.id,
                                                withdraw: withdraw.id,
                                              });

                                            await newBalanceLog.save();

                                            const error = response.initError(
                                              200,
                                              false,
                                              new ErrorMessage(
                                                'Failed to process your disburse',
                                              ),
                                            );
                                            return res.send(error);
                                          } else {
                                            withdraw.note =
                                              responseData.response_desc ?? '';
                                            await withdraw.save();

                                            const success =
                                              response.initSuccess(
                                                200,
                                                true,
                                                true,
                                              );
                                            return res.send(success);
                                          }
                                        })
                                        .catch((err) => {
                                          console.log(err);
                                          const success = response.initSuccess(
                                            200,
                                            true,
                                            true,
                                          );
                                          return res.send(success);
                                        });
                                    } else {
                                      sendWaNotif(
                                        withdraw.withdrawId,
                                        user.username,
                                        toCurrency(withdraw.amount),
                                      );

                                      const success = response.initSuccess(
                                        200,
                                        true,
                                        true,
                                      );
                                      return res.send(success);
                                    }
                                  } else {
                                    const error = response.initError(
                                      404,
                                      false,
                                      new ErrorMessage('Fee not found'),
                                    );
                                    return res.send(error);
                                  }
                                });
                            } else {
                              const error = response.initError(
                                404,
                                false,
                                new ErrorMessage('Client not found'),
                              );
                              return res.send(error);
                            }
                          });
                        }
                      } else {
                        const error = response.initError(
                          404,
                          false,
                          new ErrorMessage('Balance not found'),
                        );
                        return res.send(error);
                      }
                    });
                } else {
                  const error = response.initError(
                    403,
                    false,
                    new ErrorMessage('Signature invalid'),
                  );
                  return res.send(error);
                }
              } else {
                const error = response.initError(
                  404,
                  false,
                  new ErrorMessage('Withdraw data not found'),
                );
                return res.send(error);
              }
            });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Please setup 2FA first'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Code must not be empty'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getTransaction(
    query: QueryDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        transactionId: { transactionId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const transactionQuery: any = {
        user: new Types.ObjectId(user.id),
        transactionType: TransactionType.Transaction,
        $or: [
          { transactionId: { $regex: query.search.trim(), $options: 'i' } },
          { clientRef: { $regex: query.search.trim(), $options: 'i' } },
        ],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        transactionQuery.status = query.filter.trim();
      }
      await this.Transaction.find(transactionQuery)
        .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
        .skip(skip)
        .limit(query.limit)
        .populate({
          path: 'method',
          select: '-_id name type',
        })
        .select(
          '_id transactionId payment url amount fee status createdAt clientRef',
        )
        .then(async (transactions) => {
          const total = await this.Transaction.countDocuments(transactionQuery);
          const success = response.initSuccess(200, true, {
            transactions,
            total,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getTransactionDetail(
    transId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      await this.Transaction.findOne({
        user: new Types.ObjectId(user.id),
        _id: new Types.ObjectId(transId),
      })
        .populate({
          path: 'method',
          select: '-_id name img type',
        })
        .populate({
          path: 'user',
          select: '_id username',
        })
        .select(
          '-ip -uplineFee -feeAdmin -accessFrom -orderId -refId -pgSettled -__v -provider -updatedAt',
        )
        .then((transaction) => {
          const success = response.initSuccess(200, true, transaction);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async actionTransaction(
    data: ActionTransactionDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.Transaction.findOne({
          _id: new Types.ObjectId(data.transactionId),
          user: user.id,
        })
          .populate('method')
          .then(async (transaction: any) => {
            if (transaction) {
              await this.Client.findOne({
                user: user.id,
              }).then(async (client) => {
                if (client) {
                  await this.LogType.findOne({
                    type: LogTypes.ClientUpdate,
                  }).then(async (logType) => {
                    if (logType) {
                      const newLog = new this.Log({
                        message: `${user.username} send callback transaction id: ${transaction.transactionId}`,
                        target: transaction.id,
                        ip: req.ip,
                        type: logType.id,
                        user: user.id,
                      });

                      await newLog.save();
                    }
                  });

                  if (client.callbackTrx) {
                    const resObj: any = {
                      amount: transaction.amount,
                      fee: transaction.fee,
                      expired: new Date(transaction.exp).getTime(),
                      method: transaction.method.code,
                      methodName: transaction.method.name,
                      customerName: transaction.clientCustName,
                      ref1: transaction.clientRef,
                      ref2: transaction.transactionId,
                      status: transaction.status,
                      desc: `Your ${
                        transaction.method.type === MethodType.Va
                          ? 'Virtual Account'
                          : transaction.method.type === MethodType.Retail
                          ? 'Retail'
                          : transaction.method.type === MethodType.Qris
                          ? 'QRIS'
                          : transaction.method.type === MethodType.Ewallet
                          ? 'Ewallet'
                          : ''
                      } Transaction is ${
                        transaction.status === TransactionStatusType.Paid
                          ? 'Paid'
                          : transaction.status === TransactionStatusType.Settled
                          ? 'Settled to your balance'
                          : transaction.status === TransactionStatusType.Failed
                          ? 'Failed'
                          : 'Expired'
                      }`,
                    };

                    if (transaction.method.type === MethodType.Ewallet) {
                      resObj.phone = transaction.phone;
                    }

                    if (
                      transaction.status === TransactionStatusType.Paid ||
                      transaction.status === TransactionStatusType.Settled
                    ) {
                      resObj.paidTime = new Date(
                        transaction.paidTime,
                      ).getTime();
                      resObj.serialNumber = transaction.serialNumber;
                      if (
                        transaction.status === TransactionStatusType.Settled
                      ) {
                        resObj.settleTime = new Date(
                          transaction.clientSettleDate,
                        ).getTime();
                      }
                    }

                    const callbackKey = decrypt(
                      process.env.ENCRYPT_ALG,
                      hash('sha256', client.id).substring(0, 32),
                      hash('sha256', user.id + client.clientId).substring(
                        0,
                        16,
                      ),
                      client.callbackKey,
                    );

                    const sig = encryptHmac(
                      'sha512',
                      callbackKey,
                      minifyJson(resObj).toLowerCase(),
                      'hex',
                    );

                    await this.Callback.findOne({
                      transaction: transaction.id,
                      user: user.id,
                    }).then(async (transactionCb) => {
                      var res: string, sent: boolean;
                      await sendCallback(client.callbackTrx, resObj, sig)
                        .then((responseData) => {
                          res = responseData;
                          sent = true;
                        })
                        .catch((error) => {
                          res = error;
                          sent = false;
                        });

                      if (transactionCb) {
                        transactionCb.isSent = sent;
                        transactionCb.payload = JSON.stringify(resObj);
                        transactionCb.callbackUrl = client.callbackTrx;
                        if (sent) {
                          transactionCb.res = res;
                        } else {
                          transactionCb.error = res;
                        }
                        transactionCb.attempt = transactionCb.attempt + 1;
                        transactionCb.last = new Date();

                        await transactionCb.save();
                      } else {
                        const newCallback = new this.Callback({
                          isSent: sent,
                          payload: JSON.stringify(resObj),
                          callbackUrl: client.callbackTrx,
                          last: new Date(),
                          type: CallbackType.Transaction,
                          transaction: transaction.id,
                          user: user.id,
                        });

                        if (sent) {
                          newCallback.res = res;
                        } else {
                          newCallback.error = res;
                        }

                        await newCallback.save();
                      }
                    });
                  }

                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Client not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Transaction not found'),
              );
              return res.send(error);
            }
          });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getWithdraw(
    query: QueryDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        withdrawId: { withdrawId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        name: { name: query.sortOrder === 'asc' ? 1 : -1 },
        accNumber: { accNumber: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        status: { status: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const withdrawQuery: any = {
        user: new Types.ObjectId(user.id),
        withdrawType: WithdrawType.Client,
        $or: [
          { withdrawId: { $regex: query.search.trim(), $options: 'i' } },
          { clientRef: { $regex: query.search.trim(), $options: 'i' } },
          { name: { $regex: query.search.trim(), $options: 'i' } },
          { accNumber: { $regex: query.search.trim(), $options: 'i' } },
        ],
        process: WithdrawProcess.Process,
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        withdrawQuery.status = query.filter.trim();
      }
      await this.Withdraw.find(withdrawQuery)
        .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
        .skip(skip)
        .limit(query.limit)
        .populate({
          path: 'bank',
          select: '-_id name',
        })
        .select(
          '_id withdrawId clientRef name accNumber amount fee status createdAt',
        )
        .then(async (withdraws) => {
          const total = await this.Withdraw.countDocuments(withdrawQuery);
          const success = response.initSuccess(200, true, {
            withdraws,
            total,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getWithdrawDetail(
    withdrawId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      await this.Withdraw.findOne({
        user: new Types.ObjectId(user.id),
        _id: new Types.ObjectId(withdrawId),
      })
        .populate({
          path: 'bank',
          select: '-_id name img',
        })
        .populate({
          path: 'processedBy',
          select: '-_id username',
        })
        .select(
          '-process -ip -pgSettled -orderId -inquiryReff -user -accessFrom -bankAccount -callbackSent -inquiryBy -note -feeAdmin -withdrawType -__v -updatedAt -processedBy -uplineFee -provider',
        )
        .then((withdraw) => {
          const success = response.initSuccess(200, true, withdraw);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async actionWithdraw(
    data: ActionWithdrawDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.Withdraw.findOne({
          _id: new Types.ObjectId(data.withdrawId),
          user: user.id,
        })
          .populate('bank')
          .then(async (withdraw: any) => {
            if (withdraw) {
              await this.Client.findOne({
                user: user.id,
              }).then(async (client) => {
                if (client) {
                  await this.LogType.findOne({
                    type: LogTypes.ClientUpdate,
                  }).then(async (logType) => {
                    if (logType) {
                      const newLog = new this.Log({
                        message: `${user.username} send callback transfer id: ${withdraw.withdrawId}`,
                        target: withdraw.id,
                        ip: req.ip,
                        type: logType.id,
                        user: user.id,
                      });

                      await newLog.save();
                    }
                  });

                  if (client.callbackWd) {
                    const resObj: any = {
                      amount: withdraw.amount,
                      fee: withdraw.fee,
                      channelName: withdraw.bank.name,
                      accountNumber:
                        withdraw.bank.type === BankType.Cash
                          ? ''
                          : withdraw.accNumber,
                      name:
                        withdraw.bank.type === BankType.Cash
                          ? `Cash Transfer ${withdraw.bank.name}`
                          : withdraw.name,
                      ref1: withdraw.clientRef,
                      ref2: withdraw.withdrawId,
                      status: withdraw.status,
                      desc: `${
                        withdraw.status === WithdrawStatus.Success
                          ? 'Success'
                          : withdraw.status === WithdrawStatus.Pending
                          ? 'Pending'
                          : withdraw.status === WithdrawStatus.Processing
                          ? 'Processing'
                          : withdraw.status === WithdrawStatus.Failed
                          ? 'Failed'
                          : 'Rejected'
                      } transfer to ${withdraw.name}-${withdraw.accNumber}`,
                    };

                    if (withdraw.bank.type === BankType.Cash) {
                      resObj.note = withdraw.note;
                      resObj.expired = new Date(withdraw.exp).getTime();
                    }

                    if (withdraw.status === WithdrawStatus.Success) {
                      resObj.paidDate = new Date(withdraw.paidDate).getTime();
                    }

                    const callbackKey = decrypt(
                      process.env.ENCRYPT_ALG,
                      hash('sha256', client.id).substring(0, 32),
                      hash('sha256', user.id + client.clientId).substring(
                        0,
                        16,
                      ),
                      client.callbackKey,
                    );

                    const sig = encryptHmac(
                      'sha512',
                      callbackKey,
                      minifyJson(resObj).toLowerCase(),
                      'hex',
                    );

                    await this.Callback.findOne({
                      withdraw: withdraw.id,
                      user: user.id,
                    }).then(async (withdrawCb) => {
                      var res: string, sent: boolean;
                      await sendCallback(client.callbackWd, resObj, sig)
                        .then((responseData) => {
                          res = responseData;
                          sent = true;
                        })
                        .catch((error) => {
                          res = error;
                          sent = false;
                        });

                      if (withdrawCb) {
                        withdrawCb.isSent = sent;
                        withdrawCb.payload = JSON.stringify(resObj);
                        withdrawCb.callbackUrl = client.callbackWd;
                        if (sent) {
                          withdrawCb.res = res;
                        } else {
                          withdrawCb.error = res;
                        }
                        withdrawCb.attempt = withdrawCb.attempt + 1;
                        withdrawCb.last = new Date();

                        await withdrawCb.save();
                      } else {
                        const newCallback = new this.Callback({
                          isSent: sent,
                          payload: JSON.stringify(resObj),
                          callbackUrl: client.callbackWd,
                          last: new Date(),
                          type: CallbackType.Withdraw,
                          withdraw: withdraw.id,
                          user: user.id,
                        });

                        if (sent) {
                          newCallback.res = res;
                        } else {
                          newCallback.error = res;
                        }

                        await newCallback.save();
                      }
                    });
                  }

                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Client not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Withdraw not found'),
              );
              return res.send(error);
            }
          });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getTopup(query: QueryDto, req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        transactionId: { transactionId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const transactionQuery: any = {
        user: new Types.ObjectId(user.id),
        transactionType: TransactionType.Topup,
        $or: [
          { transactionId: { $regex: query.search.trim(), $options: 'i' } },
          { clientRef: { $regex: query.search.trim(), $options: 'i' } },
        ],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        transactionQuery.status = query.filter.trim();
      }
      await this.Transaction.find(transactionQuery)
        .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
        .skip(skip)
        .limit(query.limit)
        .populate({
          path: 'method',
          select: '-_id name type',
        })
        .select(
          '_id transactionId payment url amount fee status createdAt clientRef',
        )
        .then(async (transactions) => {
          const total = await this.Transaction.countDocuments(transactionQuery);
          const success = response.initSuccess(200, true, {
            transactions,
            total,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getTopupDetail(
    transId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      await this.Transaction.findOne({
        user: new Types.ObjectId(user.id),
        _id: new Types.ObjectId(transId),
      })
        .populate({
          path: 'method',
          select: '-_id name img type',
        })
        .populate({
          path: 'user',
          select: '_id username',
        })
        .select(
          '-uplineFee -ip -feeAdmin -accessFrom -refId -orderId -pgSettled -__v -provider -updatedAt',
        )
        .then((transaction) => {
          const success = response.initSuccess(200, true, transaction);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async actionTopup(
    data: ActionTransactionDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.Transaction.findOne({
          _id: new Types.ObjectId(data.transactionId),
          user: user.id,
        })
          .populate('method')
          .then(async (transaction: any) => {
            if (transaction) {
              await this.Client.findOne({
                user: user.id,
              }).then(async (client) => {
                if (client) {
                  await this.LogType.findOne({
                    type: LogTypes.ClientUpdate,
                  }).then(async (logType) => {
                    if (logType) {
                      const newLog = new this.Log({
                        message: `${user.username} send callback topup id: ${transaction.transactionId}`,
                        target: transaction.id,
                        ip: req.ip,
                        type: logType.id,
                        user: user.id,
                      });

                      await newLog.save();
                    }
                  });

                  if (client.callbackTopup) {
                    const resObj: any = {
                      amount: transaction.amount,
                      fee: transaction.fee,
                      expired: new Date(transaction.exp).getTime(),
                      method: transaction.method.code,
                      methodName: transaction.method.name,
                      customerName: transaction.clientCustName,
                      ref1: transaction.clientRef,
                      ref2: transaction.transactionId,
                      status: transaction.status,
                      desc: `Your ${
                        transaction.method.type === MethodType.Va
                          ? 'Virtual Account'
                          : transaction.method.type === MethodType.Retail
                          ? 'Retail'
                          : transaction.method.type === MethodType.Qris
                          ? 'QRIS'
                          : transaction.method.type === MethodType.Ewallet
                          ? 'Ewallet'
                          : ''
                      } Topup is ${
                        transaction.status === TransactionStatusType.Paid
                          ? 'Paid'
                          : transaction.status === TransactionStatusType.Settled
                          ? 'Settled to your balance'
                          : transaction.status === TransactionStatusType.Failed
                          ? 'Failed'
                          : 'Expired'
                      }`,
                    };

                    if (transaction.method.type === MethodType.Ewallet) {
                      resObj.phone = transaction.phone;
                    }

                    if (
                      transaction.status === TransactionStatusType.Paid ||
                      transaction.status === TransactionStatusType.Settled
                    ) {
                      resObj.paidTime = new Date(
                        transaction.paidTime,
                      ).getTime();
                      resObj.serialNumber = transaction.serialNumber;
                      if (
                        transaction.status === TransactionStatusType.Settled
                      ) {
                        resObj.settleTime = new Date(
                          transaction.clientSettleDate,
                        ).getTime();
                      }
                    }

                    const callbackKey = decrypt(
                      process.env.ENCRYPT_ALG,
                      hash('sha256', client.id).substring(0, 32),
                      hash('sha256', user.id + client.clientId).substring(
                        0,
                        16,
                      ),
                      client.callbackKey,
                    );

                    const sig = encryptHmac(
                      'sha512',
                      callbackKey,
                      minifyJson(resObj).toLowerCase(),
                      'hex',
                    );

                    await this.Callback.findOne({
                      topup: transaction.id,
                      user: user.id,
                    }).then(async (topupCb) => {
                      var res: string, sent: boolean;
                      await sendCallback(client.callbackTopup, resObj, sig)
                        .then((responseData) => {
                          res = responseData;
                          sent = true;
                        })
                        .catch((error) => {
                          res = error;
                          sent = false;
                        });

                      if (topupCb) {
                        topupCb.isSent = sent;
                        topupCb.payload = JSON.stringify(resObj);
                        topupCb.callbackUrl = client.callbackTopup;
                        if (sent) {
                          topupCb.res = res;
                        } else {
                          topupCb.error = res;
                        }
                        topupCb.attempt = topupCb.attempt + 1;
                        topupCb.last = new Date();

                        await topupCb.save();
                      } else {
                        const newCallback = new this.Callback({
                          isSent: sent,
                          payload: JSON.stringify(resObj),
                          callbackUrl: client.callbackTopup,
                          last: new Date(),
                          type: CallbackType.Topup,
                          topup: transaction.id,
                          user: user.id,
                        });

                        if (sent) {
                          newCallback.res = res;
                        } else {
                          newCallback.error = res;
                        }

                        await newCallback.save();
                      }
                    });
                  }

                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Client not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Transaction not found'),
              );
              return res.send(error);
            }
          });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async checkCallback(
    type: string,
    id: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      await this.Callback.findOne({
        user: user.id,
        type,
        [type]: id,
      }).then((logs) => {
        const success = response.initSuccess(200, true, logs.id);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getCallbackHistory(
    query: QueryDto,
    type: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        attempt: { attempt: query.sortOrder === 'asc' ? 1 : -1 },
        isSent: { isSent: query.sortOrder === 'asc' ? 1 : -1 },
        last: { last: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };

      const callbackQuery: any = {
        $match: {
          type,
          user: new Types.ObjectId(user.id),
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
        },
      };

      if (query.filter !== 'all') {
        callbackQuery.$match.isSent = query.filter;
      }

      const callbackLookup: any = {
        $lookup: {},
      };
      const callbackSearch: any = {
        $match: {},
      };
      const callbackProject: any = {
        $project: {
          _id: 0,
          id: '$_id',
          isSent: 1,
          callbackUrl: 1,
          attempt: 1,
          last: 1,
          clientRef: '$data.clientRef',
          createdAt: 1,
        },
      };

      if (type === CallbackType.Withdraw) {
        callbackLookup.$lookup = {
          from: 'withdraws',
          localField: 'withdraw',
          foreignField: '_id',
          as: 'data',
        };

        callbackProject.$project.withdrawId = '$data.withdrawId';

        if (query.search) {
          callbackSearch.$match = {
            $or: [
              {
                'data.withdrawId': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
              {
                'data.clientRef': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
            ],
          };
        }
      } else {
        callbackLookup.$lookup = {
          from: 'transactions',
          localField:
            type === CallbackType.Transaction ? 'transaction' : 'topup',
          foreignField: '_id',
          as: 'data',
        };

        callbackProject.$project.transactionId = '$data.transactionId';

        if (query.search) {
          callbackSearch.$match = {
            $or: [
              {
                'data.transactionId': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
              {
                'data.clientRef': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
            ],
          };
        }
      }

      await this.Callback.aggregate([
        callbackQuery,
        callbackLookup,
        {
          $unwind: {
            path: '$data',
            preserveNullAndEmptyArrays: true,
          },
        },
        callbackSearch,
        {
          $facet: {
            results: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              callbackProject,
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((logs) => {
        const success = response.initSuccess(
          200,
          true,
          logs.length ? logs[0] : [],
        );
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getCallbackHistoryDetail(
    type: string,
    id: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      await this.Callback.findOne({
        type,
        user: user.id,
        _id: id,
      })
        .populate({
          path: 'transaction',
          select: 'transactionId clientRef',
        })
        .populate({
          path: 'withdraw',
          select: 'withdrawId clientRef',
        })
        .populate({
          path: 'topup',
          select: 'transactionId clientRef',
        })
        .then((callback) => {
          const success = response.initSuccess(200, true, callback);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async resendCallback(
    type: string,
    id: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      await this.Callback.findOne({
        type,
        user: user.id,
        _id: id,
      }).then(async (callback) => {
        await this.Client.findOne({
          user: callback.user,
        }).then(async (client) => {
          if (client) {
            const callbackKey = decrypt(
              process.env.ENCRYPT_ALG,
              hash('sha256', client.id).substring(0, 32),
              hash('sha256', user.id + client.clientId).substring(0, 16),
              client.callbackKey,
            );

            const sig = encryptHmac(
              'sha512',
              callbackKey,
              minifyJson(JSON.parse(callback.payload)).toLowerCase(),
              'hex',
            );

            var resData: string, sent: boolean;
            await sendCallback(
              callback.callbackUrl,
              JSON.parse(callback.payload),
              sig,
            )
              .then((responseData) => {
                resData = responseData;
                sent = true;
              })
              .catch((error) => {
                resData = error;
                sent = false;
              });

            callback.isSent = sent;
            if (sent) {
              callback.res = resData;
            } else {
              callback.error = resData;
            }
            callback.attempt = callback.attempt + 1;
            callback.last = new Date();

            await callback.save();

            const success = response.initSuccess(200, true, sent);
            return res.send(success);
          }
        });
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getLogType(res: FastifyReply) {
    try {
      await this.LogType.find({
        type: { $nin: [LogTypes.AdminDisburse, LogTypes.AdminUpdate] },
      }).then((logTypes) => {
        const success = response.initSuccess(200, true, logTypes);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getBalanceLogType(res: FastifyReply) {
    try {
      const success = response.initSuccess(
        200,
        true,
        Object.values(BalanceLogType),
      );
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getLogs(
    query: QueryDto,
    logId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };

      const logQuery: any = {
        $match: {
          user: new Types.ObjectId(user.id),
          admin: { $exists: false },
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
        },
      };
      if (logId !== 'all') {
        await this.LogType.findById(logId).then(async (logType) => {
          if (logType) {
            if (
              ![LogTypes.AdminDisburse, LogTypes.AdminUpdate].includes(
                logType.type as LogTypes,
              )
            ) {
              logQuery.$match.type = new Types.ObjectId(logType.id);
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Log type not valid'),
              );
              return res.send(error);
            }
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Log type not found'),
            );
            return res.send(error);
          }
        });
      }

      await this.Log.aggregate([
        logQuery,
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: {
            path: '$user',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'logtypes',
            localField: 'type',
            foreignField: '_id',
            as: 'type',
          },
        },
        {
          $unwind: {
            path: '$type',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: query.search
            ? {
                $or: [
                  {
                    'user.username': {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    message: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    ip: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                ],
              }
            : {},
        },
        {
          $facet: {
            results: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $project: {
                  _id: 0,
                  id: '$_id',
                  message: 1,
                  ip: 1,
                  type: 1,
                  createdAt: 1,
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((logs) => {
        const success = response.initSuccess(
          200,
          true,
          logs.length ? logs[0] : [],
        );
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getBalanceLogs(
    query: QueryDto,
    logTypeName: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      await this.Balance.findOne({
        user: user.id,
      }).then(async (balance) => {
        const skip = (query.page - 1) * query.limit;
        const sortOptions = {
          createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
          accessFrom: {
            'transaction.accessFrom': query.sortOrder === 'asc' ? 1 : -1,
            'withdraw.accessFrom': query.sortOrder === 'asc' ? 1 : -1,
          },
        };

        const balanceLogQuery: any = {
          $match: {
            balance: new Types.ObjectId(balance.id),
            createdAt: {
              $gte: new Date(Number(query.dateStart)),
              $lte: new Date(Number(query.dateEnd)),
            },
          },
        };

        if (logTypeName !== 'all') {
          balanceLogQuery.$match.type = logTypeName;
        }

        await this.BalanceLog.aggregate([
          balanceLogQuery,
          {
            $lookup: {
              from: 'users',
              localField: 'user',
              foreignField: '_id',
              as: 'user',
            },
          },
          {
            $unwind: {
              path: '$user',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: 'transactions',
              let: { trxId: { $toObjectId: '$transaction' } },
              pipeline: [
                {
                  $match: { $expr: { $eq: ['$_id', '$$trxId'] } },
                },
                {
                  $lookup: {
                    from: 'methods',
                    localField: 'method',
                    foreignField: '_id',
                    as: 'method',
                  },
                },
                {
                  $unwind: {
                    path: '$method',
                    preserveNullAndEmptyArrays: true,
                  },
                },
              ],
              as: 'transaction',
            },
          },
          {
            $unwind: {
              path: '$transaction',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: 'withdraws',
              let: { wdId: { $toObjectId: '$withdraw' } },
              pipeline: [
                {
                  $match: { $expr: { $eq: ['$_id', '$$wdId'] } },
                },
                {
                  $lookup: {
                    from: 'banks',
                    localField: 'bank',
                    foreignField: '_id',
                    as: 'bank',
                  },
                },
                {
                  $unwind: {
                    path: '$bank',
                    preserveNullAndEmptyArrays: true,
                  },
                },
              ],
              as: 'withdraw',
            },
          },
          {
            $unwind: {
              path: '$withdraw',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $match: query.search
              ? {
                  $or: [
                    {
                      name: {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.transactionId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.clientRef': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.withdrawId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.clientRef': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.accessFrom': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                  ],
                }
              : {},
          },
          {
            $facet: {
              results: [
                {
                  $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
                },
                { $skip: skip },
                { $limit: parseInt(query.limit.toString()) },
                {
                  $project: {
                    _id: 0,
                    id: '$_id',
                    name: 1,
                    balanceAmount: 1,
                    balanceCredit: 1,
                    type: 1,
                    transaction: {
                      id: '$transaction._id',
                      methodName: '$transaction.method.name',
                      methodType: '$transaction.method.type',
                      transactionId: '$transaction.transactionId',
                      clientRef: '$transaction.clientRef',
                      paidTime: '$transaction.paidTime',
                    },
                    withdraw: {
                      id: '$withdraw._id',
                      bankName: '$withdraw.bank.name',
                      bankType: '$withdraw.bank.type',
                      withdrawId: '$withdraw.withdrawId',
                      clientRef: '$withdraw.clientRef',
                      paidDate: '$withdraw.paidDate',
                    },
                    createdAt: 1,
                  },
                },
              ],
              count: [{ $count: 'total' }],
            },
          },
          {
            $project: {
              results: 1,
              total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
            },
          },
        ]).then((logs) => {
          const success = response.initSuccess(
            200,
            true,
            logs.length ? logs[0] : [],
          );
          return res.send(success);
        });
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getSettingApiServer(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      await this.Client.findOne({
        user: user.id,
      })
        .select('clientId clientName clientSecret signatureKey ip')
        .then((client: any) => {
          if (client) {
            client.signatureKey = !!client.signatureKey;
            if (client.clientSecret) {
              const keyDec = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', client.id).substring(0, 32),
                hash('sha256', user.id + client.clientId).substring(0, 16),
                client.clientSecret,
              );
              client.clientSecret = keyDec;
            }
            const success = response.initSuccess(200, true, client);
            return res.send(success);
          } else {
            const error = response.initError(
              500,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getSettingApiServerGenerate(
    code: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      if (user.secret2Fa && user.isVerified) {
        const keyDec = decrypt(
          process.env.ENCRYPT_ALG,
          hash('sha256', user.id).substring(0, 32),
          hash('sha256', user.id + user.username).substring(0, 16),
          user.secret2Fa,
        );

        if (authenticator.check(code, keyDec)) {
          await this.Client.findOne({
            user: user.id,
          }).then(async (client) => {
            if (client) {
              const randomBytes = crypto.randomBytes(32).toString('hex');

              // Create the client secret key by hashing the client ID with the secret key
              const clientSecretKey = encryptHmac(
                'sha256',
                randomBytes,
                client.clientId,
                'hex',
              ).substring(0, 32);

              // Generate a random string
              const randomString = crypto.randomBytes(16).toString('hex');

              // Create the client signature key by combining the secret key, random string, and client ID
              const clientSignatureKey = encryptHmac(
                'sha256',
                randomBytes,
                clientSecretKey + randomString + client.clientId,
                'hex',
              ).substring(0, 64);

              // Encode the keys in Base64 and hexadecimal
              const clientSecretKeyBase64 = Buffer.from(
                clientSecretKey,
                'hex',
              ).toString('base64');
              const clientSignatureKeyBase64 = Buffer.from(
                clientSignatureKey,
                'hex',
              ).toString('base64');

              const keyEnc = encrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', client.id).substring(0, 32),
                hash('sha256', user.id + client.clientId).substring(0, 16),
                clientSecretKeyBase64,
              );

              const sigKeyEnc = encrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', keyEnc).substring(0, 32),
                hash('sha256', client.id + client.clientId + user.id).substring(
                  0,
                  16,
                ),
                clientSignatureKeyBase64,
              );

              await this.Client.findByIdAndUpdate(client.id, {
                clientSecret: keyEnc,
                signatureKey: sigKeyEnc,
              });

              await this.LogType.findOne({
                type: LogTypes.ClientUpdate,
              }).then(async (logType) => {
                if (logType) {
                  const newLog = new this.Log({
                    message: `${user.username} Generate secret and signature`,
                    ip: req.ip,
                    type: logType.id,
                    user: user.id,
                  });

                  await newLog.save();
                }
              });

              const success = response.initSuccess(200, true, {
                secret: clientSecretKeyBase64,
                signature: clientSignatureKeyBase64,
              });
              return res.send(success);
            } else {
              const error = response.initError(
                500,
                false,
                new ErrorMessage('Client not found'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Invalid 2FA Code'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Please setup 2FA first'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateSettingApiServerWl(
    data: UpdateIpWlDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      if (user.secret2Fa && user.isVerified) {
        const keyDec = decrypt(
          process.env.ENCRYPT_ALG,
          hash('sha256', user.id).substring(0, 32),
          hash('sha256', user.id + user.username).substring(0, 16),
          user.secret2Fa,
        );

        if (!authenticator.check(data.code, keyDec)) {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Invalid 2FA Code'),
          );
          return res.send(error);
        }

        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };
        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (signatureVerify === data.signature) {
          await this.Client.findOne({
            user: user.id,
          }).then(async (client: any) => {
            if (client) {
              const update: any = {};
              if (data.ip) {
                update.ip = data.ip;

                await this.LogType.findOne({
                  type: LogTypes.ClientUpdate,
                }).then(async (logType) => {
                  if (logType) {
                    const newLog = new this.Log({
                      message: `${user.username} update IP production: ${data.ip}`,
                      target: client.id,
                      ip: req.ip,
                      type: logType.id,
                      user: user.id,
                    });

                    await newLog.save();
                  }
                });
              }

              await this.Client.findByIdAndUpdate(client.id, update);

              const success = response.initSuccess(200, true, true);
              return res.send(success);
            } else {
              const error = response.initError(
                500,
                false,
                new ErrorMessage('Client not found'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Please setup 2FA first'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getSettingApiCallback(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      await this.Client.findOne({
        user: user.id,
      })
        .select('callbackTrx callbackWd callbackTopup callbackKey')
        .then((client: any) => {
          if (client) {
            client.callbackKey = !!client.callbackKey;
            const success = response.initSuccess(200, true, client);
            return res.send(success);
          } else {
            const error = response.initError(
              500,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getSettingApiCallbackGenerate(
    code: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      if (user.secret2Fa && user.isVerified) {
        const keyDec = decrypt(
          process.env.ENCRYPT_ALG,
          hash('sha256', user.id).substring(0, 32),
          hash('sha256', user.id + user.username).substring(0, 16),
          user.secret2Fa,
        );

        if (!authenticator.check(code, keyDec)) {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Invalid 2FA Code'),
          );
          return res.send(error);
        }
        await this.Client.findOne({
          user: user.id,
        }).then(async (client: any) => {
          if (client) {
            const randomBytes = crypto.randomBytes(32).toString('hex');

            // Create the client secret key by hashing the client ID with the secret key
            const clientSecretKey = encryptHmac(
              'sha256',
              randomBytes,
              client.clientId,
              'hex',
            ).substring(0, 32);

            // Generate a random string
            const randomString = crypto.randomBytes(16).toString('hex');

            // Create the client signature key by combining the secret key, random string, and client ID
            const clientCallbackKey = encryptHmac(
              'sha256',
              randomBytes,
              clientSecretKey + randomString + client.clientId,
              'hex',
            ).substring(0, 64);

            const clientCallbackKeyBase64 = Buffer.from(
              clientCallbackKey,
              'hex',
            ).toString('base64');

            const keyEnc = encrypt(
              process.env.ENCRYPT_ALG,
              hash('sha256', client.id).substring(0, 32),
              hash('sha256', user.id + client.clientId).substring(0, 16),
              clientCallbackKeyBase64,
            );

            await this.Client.findByIdAndUpdate(client.id, {
              callbackKey: keyEnc,
            });

            await this.LogType.findOne({
              type: LogTypes.ClientUpdate,
            }).then(async (logType) => {
              if (logType) {
                const newLog = new this.Log({
                  message: `${user.username} Generate callback signature`,
                  ip: req.ip,
                  type: logType.id,
                  user: user.id,
                });

                await newLog.save();
              }
            });

            const success = response.initSuccess(200, true, {
              key: clientCallbackKeyBase64,
            });
            return res.send(success);
          } else {
            const error = response.initError(
              500,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Please setup 2FA first'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateSettingApiCallbackUrl(
    data: UpdateIpWlDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      if (user.secret2Fa && user.isVerified) {
        const keyDec = decrypt(
          process.env.ENCRYPT_ALG,
          hash('sha256', user.id).substring(0, 32),
          hash('sha256', user.id + user.username).substring(0, 16),
          user.secret2Fa,
        );

        if (!authenticator.check(data.code, keyDec)) {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Invalid 2FA Code'),
          );
          return res.send(error);
        }
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };
        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (signatureVerify === data.signature) {
          const regex = /^(?:\w+:)?\/\/([^\s.]+\.\S{2}|localhost[:?\d]*)\S*$/;
          if (!regex.test(data.callbackTrx)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage(
                'Callback Payment url invalid, must begin with either HTTP:// or HTTPS://',
              ),
            );
            return res.send(error);
          } else if (!regex.test(data.callbackWd)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage(
                'Callback Transfer invalid, must begin with either HTTP:// or HTTPS://',
              ),
            );
            return res.send(error);
          } else if (!regex.test(data.callbackTopup)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage(
                'Callback Topup invalid, must begin with either HTTP:// or HTTPS://',
              ),
            );
            return res.send(error);
          } else {
            await this.Client.findOne({ user: user.id }).then(
              async (client) => {
                if (client) {
                  const update: any = {};
                  if (data.callbackTrx) {
                    update.callbackTrx = data.callbackTrx;
                    await this.LogType.findOne({
                      type: LogTypes.ClientUpdate,
                    }).then(async (logType) => {
                      if (logType) {
                        const newLog = new this.Log({
                          message: `${user.username} update Callback Payment URL production: ${data.callbackTrx}`,
                          target: client.id,
                          ip: req.ip,
                          type: logType.id,
                          user: user.id,
                        });

                        await newLog.save();
                      }
                    });
                  }
                  if (data.callbackWd) {
                    update.callbackWd = data.callbackWd;
                    await this.LogType.findOne({
                      type: LogTypes.ClientUpdate,
                    }).then(async (logType) => {
                      if (logType) {
                        const newLog = new this.Log({
                          message: `${user.username} update Callback Transfer URL production: ${data.callbackWd}`,
                          target: client.id,
                          ip: req.ip,
                          type: logType.id,
                          user: user.id,
                        });

                        await newLog.save();
                      }
                    });
                  }

                  if (data.callbackTopup) {
                    update.callbackTopup = data.callbackTopup;
                    await this.LogType.findOne({
                      type: LogTypes.ClientUpdate,
                    }).then(async (logType) => {
                      if (logType) {
                        const newLog = new this.Log({
                          message: `${user.username} update Callback Topup URL production: ${data.callbackTopup}`,
                          target: client.id,
                          ip: req.ip,
                          type: logType.id,
                          user: user.id,
                        });

                        await newLog.save();
                      }
                    });
                  }

                  await this.Client.findByIdAndUpdate(client.id, update);

                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const error = response.initError(
                    500,
                    false,
                    new ErrorMessage('Client not found'),
                  );
                  return res.send(error);
                }
              },
            );
          }
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Please setup 2FA first'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getSettingBankWl(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;

      await this.BankAccount.find({
        user: user.id,
        isDeleted: false,
      })
        .populate({
          path: 'bank',
          select: '-_id name img isActive min max',
        })
        .select('_id name account createdAt')
        .sort({ name: 1 })
        .then((bankAccount) => {
          const success = response.initSuccess(200, true, bankAccount);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getSettingBankList(res: FastifyReply) {
    try {
      await this.Bank.find({
        type: BankType.Bank,
      })
        .select('_id name img isActive')
        .then((banks) => {
          const success = response.initSuccess(200, true, banks);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getSettingBankCheck(
    data: CheckBankAccountDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };
      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.Bank.findById(data.bankId).then(async (bank) => {
          if (bank) {
            const amount = 10000;
            const orderId = generateRandomNumber(20);
            const url =
              bank.type === BankType.Bank
                ? 'transaction/withdraw/inquiry'
                : 'transaction/reload/inquiry';
            var keyDec = '';
            await this.Fee.findOne({
              feeType: FeeType.Bank,
              user: user.id,
            })
              .populate({
                path: 'provider',
                populate: {
                  path: 'providerRoot',
                },
              })
              .then((fee: any) => {
                if (fee.provider.key === 'root') {
                  keyDec = decrypt(
                    process.env.ENCRYPT_ALG,
                    hash(
                      'sha256',
                      fee.provider.providerRoot.id.valueOf(),
                    ).substring(0, 32),
                    hash(
                      'sha256',
                      fee.provider.providerRoot.user.valueOf() +
                        fee.provider.providerRoot.code,
                    ).substring(0, 16),
                    fee.provider.providerRoot.key,
                  );
                } else {
                  keyDec = decrypt(
                    process.env.ENCRYPT_ALG,
                    hash('sha256', fee.provider.id).substring(0, 32),
                    hash(
                      'sha256',
                      fee.provider.user.valueOf() + fee.provider.code,
                    ).substring(0, 16),
                    fee.provider.key,
                  );
                }
              });
            const key = JSON.parse(keyDec);
            const paramX = `/${url}POST`;
            const paramY = `${amount}${data.account}${bank.code}${orderId}${key.clientId}`;

            const sig = encryptHmac(
              'sha256',
              key.sigKey,
              paramX + paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
              'hex',
            );
            const payload: any = {
              amount: Number(amount),
              partner_reff: orderId,
              accountnumber: data.account,
              bankcode: bank.code,
              username: key.username,
              pin: key.pin,
              signature: sig,
            };

            const header = {
              'Content-Type': CT_APP_JSON,
              'client-id': key.clientId,
              'client-secret': key.clientSecret,
            };
            await fetch(process.env.PG_BASE_URL + url, {
              method: 'POST',
              body: JSON.stringify(payload),
              headers: header,
            }).then(async (responseFetch) => {
              const responseData = await responseFetch.json();
              if (
                responseData.status === PgType.Success &&
                responseData.response_code === PgType.SuccessCode
              ) {
                const success = response.initSuccess(
                  200,
                  true,
                  responseData.accountname,
                );
                return res.send(success);
              } else {
                const success = response.initSuccess(200, false, null);
                return res.send(success);
              }
            });
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Bank not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getSettingBankAdd(
    data: CheckBankAccountDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      if (user.secret2Fa && user.isVerified) {
        const keyDec = decrypt(
          process.env.ENCRYPT_ALG,
          hash('sha256', user.id).substring(0, 32),
          hash('sha256', user.id + user.username).substring(0, 16),
          user.secret2Fa,
        );

        if (!authenticator.check(data.code, keyDec)) {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Invalid 2FA Code'),
          );
          return res.send(error);
        }
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };
        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (data.signature === signatureVerify) {
          await this.Bank.findById(data.bankId).then(async (bank) => {
            if (bank) {
              const amount = 10000;
              const orderId = generateRandomNumber(20);
              const url =
                bank.type === BankType.Bank
                  ? 'transaction/withdraw/inquiry'
                  : 'transaction/reload/inquiry';
              var keyDec = '';
              await this.Fee.findOne({
                feeType: FeeType.Bank,
                user: user.id,
              })
                .populate({
                  path: 'provider',
                  populate: {
                    path: 'providerRoot',
                  },
                })
                .then((fee: any) => {
                  if (fee.provider.key === 'root') {
                    keyDec = decrypt(
                      process.env.ENCRYPT_ALG,
                      hash(
                        'sha256',
                        fee.provider.providerRoot.id.valueOf(),
                      ).substring(0, 32),
                      hash(
                        'sha256',
                        fee.provider.providerRoot.user.valueOf() +
                          fee.provider.providerRoot.code,
                      ).substring(0, 16),
                      fee.provider.providerRoot.key,
                    );
                  } else {
                    keyDec = decrypt(
                      process.env.ENCRYPT_ALG,
                      hash('sha256', fee.provider.id).substring(0, 32),
                      hash(
                        'sha256',
                        fee.provider.user.valueOf() + fee.provider.code,
                      ).substring(0, 16),
                      fee.provider.key,
                    );
                  }
                });
              const key = JSON.parse(keyDec);

              const paramX = `/${url}POST`;
              const paramY = `${amount}${data.account}${bank.code}${orderId}${key.clientId}`;

              const sig = encryptHmac(
                'sha256',
                key.sigKey,
                paramX + paramY.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
                'hex',
              );
              const payload: any = {
                amount: Number(amount),
                partner_reff: orderId,
                accountnumber: data.account,
                bankcode: bank.code,
                username: key.username,
                pin: key.pin,
                signature: sig,
              };

              const header = {
                'Content-Type': CT_APP_JSON,
                'client-id': key.clientId,
                'client-secret': key.clientSecret,
              };
              await fetch(process.env.PG_BASE_URL + url, {
                method: 'POST',
                body: JSON.stringify(payload),
                headers: header,
              }).then(async (responseFetch) => {
                const responseData = await responseFetch.json();
                if (
                  responseData.status === PgType.Success &&
                  responseData.response_code === PgType.SuccessCode
                ) {
                  const newBankAccount = new this.BankAccount({
                    name: responseData.accountname,
                    account: data.account,
                    ip: req.ip,
                    bank: bank.id,
                    user: user.id,
                  });

                  const saved = await newBankAccount.save();

                  await this.LogType.findOne({
                    type: LogTypes.ClientUpdate,
                  }).then(async (logType) => {
                    if (logType) {
                      const newLog = new this.Log({
                        message: `${user.username} Add new whitelist bank account ${responseData.accountname}-${data.account}`,
                        target: saved.id,
                        ip: req.ip,
                        type: logType.id,
                        user: user.id,
                      });

                      await newLog.save();
                    }
                  });

                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const success = response.initSuccess(200, false, null);
                  return res.send(success);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Bank not found'),
              );
              return res.send(error);
            }
          });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Please setup 2FA first'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getSettingBankDelete(
    data: DeleteBankAccountDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      if (user.secret2Fa && user.isVerified) {
        const keyDec = decrypt(
          process.env.ENCRYPT_ALG,
          hash('sha256', user.id).substring(0, 32),
          hash('sha256', user.id + user.username).substring(0, 16),
          user.secret2Fa,
        );

        if (!authenticator.check(data.code, keyDec)) {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Invalid 2FA Code'),
          );
          return res.send(error);
        }
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };
        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (data.signature === signatureVerify) {
          await this.BankAccount.findById(data.bankAccountId).then(
            async (bank) => {
              if (bank) {
                bank.isDeleted = true;
                await bank.save();

                await this.LogType.findOne({
                  type: LogTypes.ClientUpdate,
                }).then(async (logType) => {
                  if (logType) {
                    const newLog = new this.Log({
                      message: `${user.username} Delete whitelist bank account ${bank.name}-${bank.account}`,
                      target: bank.id,
                      ip: req.ip,
                      type: logType.id,
                      user: user.id,
                    });

                    await newLog.save();
                  }
                });

                const success = response.initSuccess(200, true, true);
                return res.send(success);
              } else {
                const error = response.initError(
                  404,
                  false,
                  new ErrorMessage('Bank Account not found'),
                );
                return res.send(error);
              }
            },
          );
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Please setup 2FA first'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getSettingPaymentChannel(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;

      await this.Method.aggregate([
        {
          $lookup: {
            from: 'fees',
            let: { methodId: '$_id' },
            pipeline: [
              {
                $lookup: {
                  from: 'valuetypes',
                  localField: 'type',
                  foreignField: '_id',
                  as: 'valueType',
                },
              },
              {
                $unwind: '$valueType',
              },
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$method', '$$methodId'] },
                      { $eq: ['$user', { $toObjectId: user.id }] },
                    ],
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  feeId: '$_id',
                  delay: 1,
                  fixed: 1,
                  percentage: 1,
                  isActive: 1,
                  onClient: 1,
                  valueType: 1,
                },
              },
            ],
            as: 'fee',
          },
        },
        {
          $unwind: {
            path: '$fee',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 0,
            methodId: '$_id',
            fee: 1,
            name: 1,
            img: 1,
            min: 1,
            max: 1,
            isActive: 1,
            type: 1,
          },
        },
      ]).then((method) => {
        const success = response.initSuccess(200, true, method);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateSettingPaymentChannel(
    data: UpdatePaymentChannelDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };
      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.Fee.findOne({
          _id: data.feeId,
          method: data.methodId,
          user: user.id,
        })
          .populate('method')
          .then(async (fee: any) => {
            if (fee) {
              fee.onClient = data.onClient;
              await fee.save();

              await this.LogType.findOne({
                type: LogTypes.ClientUpdate,
              }).then(async (logType) => {
                if (logType) {
                  const newLog = new this.Log({
                    message: `${user.username} ${fee.method.name} to ${
                      data.onClient
                        ? 'Charged to client'
                        : 'Charged to customer'
                    }`,
                    target: fee.id,
                    ip: req.ip,
                    type: logType.id,
                    user: user.id,
                  });

                  await newLog.save();
                }
              });

              const success = response.initSuccess(200, true, true);
              return res.send(success);
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Data not found'),
              );
              return res.send(error);
            }
          });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async get2FaStatus(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      const success = response.initSuccess(200, true, user.isVerified ?? false);
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async get2FaSetup(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      if (user.secret2Fa && user.isVerified) {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('2FA has already been set up'),
        );
        return res.send(error);
      } else {
        const secret = authenticator.generateSecret();
        const otpAuth = authenticator.keyuri(user.username, 'NiagaPay', secret);

        const keyEnc = encrypt(
          process.env.ENCRYPT_ALG,
          hash('sha256', user.id).substring(0, 32),
          hash('sha256', user.id + user.username).substring(0, 16),
          secret,
        );

        user.secret2Fa = keyEnc;
        await user.save();

        const success = response.initSuccess(200, true, {
          auth: otpAuth,
          secret: secret,
        });
        return res.send(success);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async get2FaVerify(
    data: Verify2FaDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        if (user.secret2Fa && !user.isVerified) {
          const keyDec = decrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', user.id).substring(0, 32),
            hash('sha256', user.id + user.username).substring(0, 16),
            user.secret2Fa,
          );

          if (!authenticator.check(data.code, keyDec)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Invalid 2FA Code'),
            );
            return res.send(error);
          }

          await this.LogType.findOne({
            type: LogTypes.ClientUpdate,
          }).then(async (logType) => {
            if (logType) {
              const newLog = new this.Log({
                message: `${user.username} verify 2FA setup`,
                ip: req.ip,
                type: logType.id,
                user: user.id,
              });

              await newLog.save();
            }
          });

          user.isVerified = true;
          await user.save();

          const success = response.initSuccess(200, true, true);
          return res.send(success);
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Data mismatch!'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature Invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  // DEV
  async getDevOverview(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      const todayStart = new Date();
      todayStart.setDate(todayStart.getDate() - 1);
      todayStart.setHours(17, 0, 0, 0);
      const todayEnd = new Date();
      todayEnd.setHours(16, 59, 59, 999);

      await this.User.aggregate([
        {
          $match: {
            $expr: {
              $eq: ['$_id', { $toObjectId: user.id }],
            },
          },
        },
        // lookup the transactions collection and filter by 'Paid' status
        {
          $lookup: {
            from: 'devtransactions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      {
                        $eq: ['$transactionType', TransactionType.Transaction],
                      },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'transaction',
          },
        },
        {
          $unwind: {
            path: '$transaction',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'devtransactions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      {
                        $eq: ['$transactionType', TransactionType.Topup],
                      },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'topup',
          },
        },
        {
          $unwind: {
            path: '$topup',
            preserveNullAndEmptyArrays: true,
          },
        },
        // lookup the withdraw collection and filter by 'Paid' and 'Pending' status
        {
          $lookup: {
            from: 'devwithdraws',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      { $eq: ['$process', WithdrawProcess.Process] },
                      { $eq: ['$withdrawType', WithdrawType.Client] },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'withdraw',
          },
        },
        {
          $unwind: {
            path: '$withdraw',
            preserveNullAndEmptyArrays: true,
          },
        },
        // lookup the balance collection and filter by user
        {
          $lookup: {
            from: 'devbalances',
            let: { userId: '$_id' },
            pipeline: [
              { $match: { $expr: { $eq: ['$user', '$$userId'] } } },
              {
                $project: {
                  _id: 0,
                  balance: 1,
                  pending: 1,
                },
              },
            ],
            as: 'balance',
          },
        },
        {
          $unwind: {
            path: '$balance',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'devclients',
            let: { userId: '$_id' },
            pipeline: [{ $match: { $expr: { $eq: ['$user', '$$userId'] } } }],
            as: 'client',
          },
        },
        {
          $unwind: {
            path: '$client',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 1,
            username: 1,
            isBlocked: 1,
            isVerified: 1,
            createdAt: 1,
            updatedAt: 1,
            transaction: {
              $let: {
                vars: {
                  transactionData: {
                    $ifNull: ['$transaction', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$transactionData', null] },
                    then: null,
                    else: '$$transactionData',
                  },
                },
              },
            },
            topup: {
              $let: {
                vars: {
                  topupData: {
                    $ifNull: ['$topup', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$topupData', null] },
                    then: null,
                    else: '$$topupData',
                  },
                },
              },
            },
            withdraw: {
              $let: {
                vars: {
                  withdrawData: {
                    $ifNull: ['$withdraw', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$withdrawData', null] },
                    then: null,
                    else: '$$withdrawData',
                  },
                },
              },
            },
            balance: {
              $let: {
                vars: {
                  balanceData: {
                    $ifNull: ['$balance', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$balanceData', null] },
                    then: null,
                    else: '$$balanceData',
                  },
                },
              },
            },
            client: {
              clientName: 1,
              limit: 1,
              isKey: {
                $let: {
                  vars: {
                    secret: {
                      $ifNull: ['$client.clientSecret', false],
                    },
                    signature: {
                      $ifNull: ['$client.signatureKey', false],
                    },
                  },
                  in: {
                    $and: ['$$secret', '$$signature'],
                  },
                },
              },
              isCallback: {
                $let: {
                  vars: {
                    callbackTrx: {
                      $ifNull: ['$client.callbackTrx', null],
                    },
                    callbackWd: {
                      $ifNull: ['$client.callbackWd', null],
                    },
                    callbackTopup: {
                      $ifNull: ['$client.callbackTopup', null],
                    },
                    key: {
                      $ifNull: ['$client.callbackKey', false],
                    },
                  },
                  in: {
                    $and: [
                      '$$callbackTrx',
                      '$$callbackWd',
                      '$$callbackTopup',
                      '$$key',
                    ],
                  },
                },
              },
            },
          },
        },
      ]).then((user) => {
        if (user && user.length) {
          const success = response.initSuccess(200, true, user[0]);
          return res.send(success);
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Client not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevTransaction(
    query: QueryDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        transactionId: { transactionId: query.sortOrder === 'asc' ? 1 : -1 },
        refId: { refId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const transactionQuery: any = {
        user: new Types.ObjectId(user.id),
        transactionType: TransactionType.Transaction,
        $or: [
          { transactionId: { $regex: query.search.trim(), $options: 'i' } },
          { refId: { $regex: query.search.trim(), $options: 'i' } },
          { clientRef: { $regex: query.search.trim(), $options: 'i' } },
        ],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        transactionQuery.status = query.filter.trim();
      }
      await this.DevTransaction.find(transactionQuery)
        .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
        .skip(skip)
        .limit(query.limit)
        .populate({
          path: 'method',
          select: '-_id name type',
        })
        .select(
          '_id transactionId payment url refId amount fee status createdAt clientRef',
        )
        .then(async (transactions) => {
          const total = await this.DevTransaction.countDocuments(
            transactionQuery,
          );
          const success = response.initSuccess(200, true, {
            transactions,
            total,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevTransactionDetail(
    transId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      await this.DevTransaction.findOne({
        user: new Types.ObjectId(user.id),
        _id: new Types.ObjectId(transId),
      })
        .populate({
          path: 'method',
          select: '-_id name img type',
        })
        .populate({
          path: 'user',
          select: '_id username',
        })
        .select('-payment -uplineFee -feeAdmin -pgSettled -__v -updatedAt')
        .then((transaction) => {
          const success = response.initSuccess(200, true, transaction);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async actionDevTransaction(
    data: ActionDevTransactionDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const validStatusTypes = Object.values(TransactionStatusType).filter(
        (value) =>
          value !== TransactionStatusType.Processing &&
          value !== TransactionStatusType.Pending &&
          value !== TransactionStatusType.Assist,
      );
      if (validStatusTypes.includes(data.status as TransactionStatusType)) {
        const { user, browser } = req.user;
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };

        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (data.signature === signatureVerify) {
          await this.DevTransaction.findOne({
            _id: new Types.ObjectId(data.transactionId),
            user: user.id,
          })
            .populate('method')
            .then(async (transaction: any) => {
              if (transaction) {
                await this.DevClient.findOne({
                  user: user.id,
                }).then(async (client) => {
                  if (client) {
                    const today = new Date();
                    const sn = 'testsn11991991';

                    if (client.callbackTrx) {
                      const resObj: any = {
                        amount: transaction.amount,
                        fee: transaction.fee,
                        expired: new Date(transaction.exp).getTime(),
                        method: transaction.method.code,
                        methodName: transaction.method.name,
                        customerName: transaction.clientCustName,
                        ref1: transaction.clientRef,
                        ref2: transaction.transactionId,
                        status: data.status,
                        desc: `Your ${
                          transaction.method.type === MethodType.Va
                            ? 'Virtual Account'
                            : transaction.method.type === MethodType.Retail
                            ? 'Retail'
                            : transaction.method.type === MethodType.Qris
                            ? 'QRIS'
                            : transaction.method.type === MethodType.Ewallet
                            ? 'Ewallet'
                            : ''
                        } Transaction is ${
                          data.status === TransactionStatusType.Paid
                            ? 'Paid'
                            : data.status === TransactionStatusType.Settled
                            ? 'Settled to your balance'
                            : data.status === TransactionStatusType.Failed
                            ? 'Failed'
                            : 'Expired'
                        }`,
                      };

                      if (transaction.method.type === MethodType.Ewallet) {
                        resObj.phone = transaction.phone;
                      }

                      if (
                        data.status === TransactionStatusType.Paid ||
                        data.status === TransactionStatusType.Settled
                      ) {
                        resObj.paidTime = today.getTime();
                        resObj.serialNumber = sn;
                        if (data.status === TransactionStatusType.Settled) {
                          resObj.settleTime = today.getTime();
                        }
                      }

                      const callbackKey = decrypt(
                        process.env.ENCRYPT_ALG,
                        hash('sha256', client.id).substring(0, 32),
                        hash('sha256', user.id + client.clientId).substring(
                          0,
                          16,
                        ),
                        client.callbackKey,
                      );

                      const sig = encryptHmac(
                        'sha512',
                        callbackKey,
                        minifyJson(resObj).toLowerCase(),
                        'hex',
                      );

                      await this.DevCallback.findOne({
                        transaction: transaction.id,
                        user: user.id,
                      }).then(async (transactionCb) => {
                        var res: string, sent: boolean;
                        await sendCallback(client.callbackTrx, resObj, sig)
                          .then((responseData) => {
                            res = responseData;
                            sent = true;
                          })
                          .catch((error) => {
                            res = error;
                            sent = false;
                          });

                        if (transactionCb) {
                          transactionCb.isSent = sent;
                          transactionCb.payload = JSON.stringify(resObj);
                          transactionCb.callbackUrl = client.callbackTrx;
                          if (sent) {
                            transactionCb.res = res;
                          } else {
                            transactionCb.error = res;
                          }
                          transactionCb.attempt = transactionCb.attempt + 1;
                          transactionCb.last = today;

                          await transactionCb.save();
                        } else {
                          const newDevCallback = new this.DevCallback({
                            isSent: sent,
                            payload: JSON.stringify(resObj),
                            callbackUrl: client.callbackTrx,
                            last: today,
                            type: CallbackType.Transaction,
                            transaction: transaction.id,
                            user: user.id,
                          });

                          if (sent) {
                            newDevCallback.res = res;
                          } else {
                            newDevCallback.error = res;
                          }

                          await newDevCallback.save();
                        }
                      });
                    }

                    transaction.status = data.status;
                    if (data.status === TransactionStatusType.Paid) {
                      transaction.paidDate = today;
                      transaction.serialNumber = sn;
                    } else if (data.status === TransactionStatusType.Settled) {
                      transaction.clientSettleDate = today;
                      transaction.clientSettled = true;
                    }
                    await transaction.save();
                    const success = response.initSuccess(200, true, true);
                    return res.send(success);
                  } else {
                    const error = response.initError(
                      404,
                      false,
                      new ErrorMessage('Client not found'),
                    );
                    return res.send(error);
                  }
                });
              } else {
                const error = response.initError(
                  404,
                  false,
                  new ErrorMessage('Transaction not found'),
                );
                return res.send(error);
              }
            });
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          404,
          false,
          new ErrorMessage('Status type not found'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevWithdraw(
    query: QueryDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        withdrawId: { withdrawId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        name: { name: query.sortOrder === 'asc' ? 1 : -1 },
        accNumber: { accNumber: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        status: { status: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const withdrawQuery: any = {
        user: new Types.ObjectId(user.id),
        withdrawType: WithdrawType.Client,
        $or: [
          { withdrawId: { $regex: query.search.trim(), $options: 'i' } },
          { clientRef: { $regex: query.search.trim(), $options: 'i' } },
          { name: { $regex: query.search.trim(), $options: 'i' } },
          { accNumber: { $regex: query.search.trim(), $options: 'i' } },
        ],
        process: WithdrawProcess.Process,
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        withdrawQuery.status = query.filter.trim();
      }
      await this.DevWithdraw.find(withdrawQuery)
        .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
        .skip(skip)
        .limit(query.limit)
        .populate({
          path: 'bank',
          select: '-_id name',
        })
        .select(
          '_id withdrawId clientRef name accNumber amount fee status createdAt',
        )
        .then(async (withdraws) => {
          const total = await this.DevWithdraw.countDocuments(withdrawQuery);
          const success = response.initSuccess(200, true, {
            withdraws,
            total,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevWithdrawDetail(
    withdrawId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      await this.DevWithdraw.findOne({
        user: new Types.ObjectId(user.id),
        _id: new Types.ObjectId(withdrawId),
      })
        .populate({
          path: 'bank',
          select: '-_id name img',
        })
        .populate({
          path: 'user',
          select: '_id username',
        })
        .select(
          '-process -withdrawType -__v -updatedAt -processedBy -uplineFee',
        )
        .then((withdraw) => {
          const success = response.initSuccess(200, true, withdraw);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async actionDevWithdraw(
    data: ActionDevWithdrawDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.DevWithdraw.findOne({
          _id: new Types.ObjectId(data.withdrawId),
          user: user.id,
        })
          .populate('bank')
          .then(async (withdraw: any) => {
            if (withdraw) {
              await this.DevClient.findOne({
                user: user.id,
              }).then(async (client) => {
                if (client) {
                  const today = new Date();

                  if (client.callbackWd) {
                    const resObj: any = {
                      amount: withdraw.amount,
                      fee: withdraw.fee,
                      channelName: withdraw.bank.name,
                      accountNumber:
                        withdraw.bank.type === BankType.Cash
                          ? ''
                          : withdraw.accNumber,
                      name:
                        withdraw.bank.type === BankType.Cash
                          ? `Cash Transfer ${withdraw.bank.name}`
                          : withdraw.name,
                      ref1: withdraw.clientRef,
                      ref2: withdraw.withdrawId,
                      status: data.status,
                      desc: `${
                        data.status === WithdrawStatus.Success
                          ? 'Success'
                          : data.status === WithdrawStatus.Pending
                          ? 'Pending'
                          : data.status === WithdrawStatus.Processing
                          ? 'Processing'
                          : data.status === WithdrawStatus.Failed
                          ? 'Failed'
                          : 'Rejected'
                      } transfer to ${withdraw.name}-${withdraw.accNumber}`,
                    };

                    if (withdraw.bank.type === BankType.Cash) {
                      resObj.note = withdraw.note;
                      resObj.expired = new Date(withdraw.exp).getTime();
                    }

                    if (data.status === WithdrawStatus.Success) {
                      resObj.paidDate = today.getTime();
                    }

                    const callbackKey = decrypt(
                      process.env.ENCRYPT_ALG,
                      hash('sha256', client.id).substring(0, 32),
                      hash('sha256', user.id + client.clientId).substring(
                        0,
                        16,
                      ),
                      client.callbackKey,
                    );

                    const sig = encryptHmac(
                      'sha512',
                      callbackKey,
                      minifyJson(resObj).toLowerCase(),
                      'hex',
                    );

                    await this.DevCallback.findOne({
                      withdraw: withdraw.id,
                      user: user.id,
                    }).then(async (withdrawCb) => {
                      var res: string, sent: boolean;
                      await sendCallback(client.callbackWd, resObj, sig)
                        .then((responseData) => {
                          res = responseData;
                          sent = true;
                        })
                        .catch((error) => {
                          res = error;
                          sent = false;
                        });

                      if (withdrawCb) {
                        withdrawCb.isSent = sent;
                        withdrawCb.payload = JSON.stringify(resObj);
                        withdrawCb.callbackUrl = client.callbackWd;
                        if (sent) {
                          withdrawCb.res = res;
                        } else {
                          withdrawCb.error = res;
                        }
                        withdrawCb.attempt = withdrawCb.attempt + 1;
                        withdrawCb.last = today;

                        await withdrawCb.save();
                      } else {
                        const newDevCallback = new this.DevCallback({
                          isSent: sent,
                          payload: JSON.stringify(resObj),
                          callbackUrl: client.callbackWd,
                          last: today,
                          type: CallbackType.Withdraw,
                          withdraw: withdraw.id,
                          user: user.id,
                        });

                        if (sent) {
                          newDevCallback.res = res;
                        } else {
                          newDevCallback.error = res;
                        }

                        await newDevCallback.save();
                      }
                    });
                  }
                  withdraw.status = data.status;
                  if (data.status === WithdrawStatus.Success) {
                    withdraw.paidDate = today;
                  }
                  await withdraw.save();
                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Client not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Withdraw not found'),
              );
              return res.send(error);
            }
          });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevTopup(
    query: QueryDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        transactionId: { transactionId: query.sortOrder === 'asc' ? 1 : -1 },
        clientRef: { clientRef: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const transactionQuery: any = {
        user: new Types.ObjectId(user.id),
        transactionType: TransactionType.Topup,
        $or: [
          { transactionId: { $regex: query.search.trim(), $options: 'i' } },
          { clientRef: { $regex: query.search.trim(), $options: 'i' } },
        ],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        transactionQuery.status = query.filter.trim();
      }
      await this.DevTransaction.find(transactionQuery)
        .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
        .skip(skip)
        .limit(query.limit)
        .populate({
          path: 'method',
          select: '-_id name type',
        })
        .select(
          '_id transactionId payment url amount fee status createdAt clientRef',
        )
        .then(async (transactions) => {
          const total = await this.DevTransaction.countDocuments(
            transactionQuery,
          );
          const success = response.initSuccess(200, true, {
            transactions,
            total,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevTopupDetail(
    transId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      await this.DevTransaction.findOne({
        user: new Types.ObjectId(user.id),
        _id: new Types.ObjectId(transId),
      })
        .populate({
          path: 'method',
          select: '-_id name img type',
        })
        .populate({
          path: 'user',
          select: '_id username',
        })
        .select('-uplineFee -feeAdmin -refId -pgSettled -__v -updatedAt')
        .then((transaction) => {
          const success = response.initSuccess(200, true, transaction);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async actionDevTopup(
    data: ActionDevTransactionDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };

      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (data.signature === signatureVerify) {
        await this.DevTransaction.findOne({
          _id: new Types.ObjectId(data.transactionId),
          user: user.id,
        })
          .populate('method')
          .then(async (transaction: any) => {
            if (transaction) {
              await this.DevClient.findOne({
                user: user.id,
              }).then(async (client) => {
                if (client) {
                  const today = new Date();
                  const sn = 'testsn11991991';

                  if (client.callbackTopup) {
                    const resObj: any = {
                      amount: transaction.amount,
                      fee: transaction.fee,
                      expired: new Date(transaction.exp).getTime(),
                      method: transaction.method.code,
                      methodName: transaction.method.name,
                      customerName: transaction.clientCustName,
                      ref1: transaction.clientRef,
                      ref2: transaction.transactionId,
                      status: data.status,
                      desc: `Your ${
                        transaction.method.type === MethodType.Va
                          ? 'Virtual Account'
                          : transaction.method.type === MethodType.Retail
                          ? 'Retail'
                          : transaction.method.type === MethodType.Qris
                          ? 'QRIS'
                          : transaction.method.type === MethodType.Ewallet
                          ? 'Ewallet'
                          : ''
                      } Topup is ${
                        data.status === TransactionStatusType.Paid
                          ? 'Paid'
                          : data.status === TransactionStatusType.Settled
                          ? 'Settled to your balance'
                          : data.status === TransactionStatusType.Failed
                          ? 'Failed'
                          : 'Expired'
                      }`,
                    };

                    if (transaction.method.type === MethodType.Ewallet) {
                      resObj.phone = transaction.phone;
                    }

                    if (
                      data.status === TransactionStatusType.Paid ||
                      data.status === TransactionStatusType.Settled
                    ) {
                      resObj.paidTime = today.getTime();
                      resObj.serialNumber = sn;
                      if (data.status === TransactionStatusType.Settled) {
                        resObj.settleTime = today.getTime();
                      }
                    }

                    const callbackKey = decrypt(
                      process.env.ENCRYPT_ALG,
                      hash('sha256', client.id).substring(0, 32),
                      hash('sha256', user.id + client.clientId).substring(
                        0,
                        16,
                      ),
                      client.callbackKey,
                    );

                    const sig = encryptHmac(
                      'sha512',
                      callbackKey,
                      minifyJson(resObj).toLowerCase(),
                      'hex',
                    );

                    await this.DevCallback.findOne({
                      topup: transaction.id,
                      user: user.id,
                    }).then(async (topupCb) => {
                      var res: string, sent: boolean;
                      await sendCallback(client.callbackTopup, resObj, sig)
                        .then((responseData) => {
                          res = responseData;
                          sent = true;
                        })
                        .catch((error) => {
                          res = error;
                          sent = false;
                        });

                      if (topupCb) {
                        topupCb.isSent = sent;
                        topupCb.payload = JSON.stringify(resObj);
                        topupCb.callbackUrl = client.callbackTopup;
                        if (sent) {
                          topupCb.res = res;
                        } else {
                          topupCb.error = res;
                        }
                        topupCb.attempt = topupCb.attempt + 1;
                        topupCb.last = today;

                        await topupCb.save();
                      } else {
                        const newDevCallback = new this.DevCallback({
                          isSent: sent,
                          payload: JSON.stringify(resObj),
                          callbackUrl: client.callbackTopup,
                          last: today,
                          type: CallbackType.Topup,
                          topup: transaction.id,
                          user: user.id,
                        });

                        if (sent) {
                          newDevCallback.res = res;
                        } else {
                          newDevCallback.error = res;
                        }

                        await newDevCallback.save();
                      }
                    });
                  }

                  transaction.status = data.status;
                  if (data.status === TransactionStatusType.Paid) {
                    transaction.paidDate = today;
                    transaction.serialNumber = sn;
                  } else if (data.status === TransactionStatusType.Settled) {
                    transaction.clientSettleDate = today;
                    transaction.clientSettled = true;
                  }
                  await transaction.save();
                  const success = response.initSuccess(200, true, true);
                  return res.send(success);
                } else {
                  const error = response.initError(
                    404,
                    false,
                    new ErrorMessage('Client not found'),
                  );
                  return res.send(error);
                }
              });
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Transaction not found'),
              );
              return res.send(error);
            }
          });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async checkDevCallback(
    type: string,
    id: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      await this.DevCallback.findOne({
        user: user.id,
        type,
        [type]: id,
      }).then((logs) => {
        const success = response.initSuccess(200, true, logs.id);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevCallbackHistory(
    query: QueryDto,
    type: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        attempt: { attempt: query.sortOrder === 'asc' ? 1 : -1 },
        isSent: { isSent: query.sortOrder === 'asc' ? 1 : -1 },
        last: { last: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };

      const callbackQuery: any = {
        $match: {
          type,
          user: new Types.ObjectId(user.id),
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
        },
      };

      if (query.filter !== 'all') {
        callbackQuery.$match.isSent = query.filter;
      }

      const callbackLookup: any = {
        $lookup: {},
      };
      const callbackSearch: any = {
        $match: {},
      };
      const callbackProject: any = {
        $project: {
          _id: 0,
          id: '$_id',
          isSent: 1,
          callbackUrl: 1,
          attempt: 1,
          last: 1,
          clientRef: 'data.clientRef',
          createdAt: 1,
        },
      };

      if (type === CallbackType.Withdraw) {
        callbackLookup.$lookup = {
          from: 'withdraws',
          localField: 'withdraw',
          foreignField: '_id',
          as: 'data',
        };

        callbackProject.$project.withdrawId = '$data.withdrawId';

        if (query.search) {
          callbackSearch.$match = {
            $or: [
              {
                'data.withdrawId': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
              {
                'data.clientRef': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
            ],
          };
        }
      } else {
        callbackLookup.$lookup = {
          from: 'transactions',
          localField:
            type === CallbackType.Transaction ? 'transaction' : 'topup',
          foreignField: '_id',
          as: 'data',
        };

        callbackProject.$project.transactionId = '$data.transactionId';

        if (query.search) {
          callbackSearch.$match = {
            $or: [
              {
                'data.transactionId': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
              {
                'data.clientRef': {
                  $regex: new RegExp(query.search.trim(), 'i'),
                },
              },
            ],
          };
        }
      }

      await this.DevCallback.aggregate([
        callbackQuery,
        callbackLookup,
        {
          $unwind: {
            path: '$data',
            preserveNullAndEmptyArrays: true,
          },
        },
        callbackSearch,
        {
          $facet: {
            results: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              callbackProject,
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((logs) => {
        const success = response.initSuccess(
          200,
          true,
          logs.length ? logs[0] : [],
        );
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevCallbackHistoryDetail(
    type: string,
    id: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      await this.DevCallback.findOne({
        type,
        user: user.id,
        _id: id,
      })
        .populate({
          path: 'transaction',
          select: 'transactionId clientRef',
        })
        .populate({
          path: 'withdraw',
          select: 'withdrawId clientRef',
        })
        .populate({
          path: 'topup',
          select: 'transactionId clientRef',
        })
        .then((callback) => {
          const success = response.initSuccess(200, true, callback);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async resendDevCallback(
    type: string,
    id: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      await this.DevCallback.findOne({
        type,
        user: user.id,
        _id: id,
      }).then(async (callback) => {
        await this.DevClient.findOne({
          user: callback.user,
        }).then(async (client) => {
          if (client) {
            const callbackKey = decrypt(
              process.env.ENCRYPT_ALG,
              hash('sha256', client.id).substring(0, 32),
              hash('sha256', user.id + client.clientId).substring(0, 16),
              client.callbackKey,
            );

            const sig = encryptHmac(
              'sha512',
              callbackKey,
              minifyJson(JSON.parse(callback.payload)).toLowerCase(),
              'hex',
            );

            var resData: string, sent: boolean;
            await sendCallback(
              callback.callbackUrl,
              JSON.parse(callback.payload),
              sig,
            )
              .then((responseData) => {
                resData = responseData;
                sent = true;
              })
              .catch((error) => {
                resData = error;
                sent = false;
              });

            callback.isSent = sent;
            if (sent) {
              callback.res = resData;
            } else {
              callback.error = resData;
            }
            callback.attempt = callback.attempt + 1;
            callback.last = new Date();

            await callback.save();

            const success = response.initSuccess(200, true, sent);
            return res.send(success);
          }
        });
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevSettingApiServer(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      await this.DevClient.findOne({
        user: user.id,
      })
        .select('clientId clientName clientSecret signatureKey ip')
        .then((client: any) => {
          if (client) {
            client.signatureKey = !!client.signatureKey;
            if (client.clientSecret) {
              const keyDec = decrypt(
                process.env.ENCRYPT_ALG,
                hash('sha256', client.id).substring(0, 32),
                hash('sha256', user.id + client.clientId).substring(0, 16),
                client.clientSecret,
              );
              client.clientSecret = keyDec;
            }
            const success = response.initSuccess(200, true, client);
            return res.send(success);
          } else {
            const error = response.initError(
              500,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevSettingApiServerGenerate(
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      await this.DevClient.findOne({
        user: user.id,
      }).then(async (client) => {
        if (client) {
          const randomBytes = crypto.randomBytes(32).toString('hex');

          // Create the client secret key by hashing the client ID with the secret key
          const clientSecretKey = encryptHmac(
            'sha256',
            randomBytes,
            client.clientId,
            'hex',
          ).substring(0, 32);

          // Generate a random string
          const randomString = crypto.randomBytes(16).toString('hex');

          // Create the client signature key by combining the secret key, random string, and client ID
          const clientSignatureKey = encryptHmac(
            'sha256',
            randomBytes,
            clientSecretKey + randomString + client.clientId,
            'hex',
          ).substring(0, 64);

          // Encode the keys in Base64 and hexadecimal
          const clientSecretKeyBase64 = Buffer.from(
            clientSecretKey,
            'hex',
          ).toString('base64');
          const clientSignatureKeyBase64 = Buffer.from(
            clientSignatureKey,
            'hex',
          ).toString('base64');

          const keyEnc = encrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', client.id).substring(0, 32),
            hash('sha256', user.id + client.clientId).substring(0, 16),
            clientSecretKeyBase64,
          );

          const sigKeyEnc = encrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', keyEnc).substring(0, 32),
            hash('sha256', client.id + client.clientId + user.id).substring(
              0,
              16,
            ),
            clientSignatureKeyBase64,
          );

          await this.DevClient.findByIdAndUpdate(client.id, {
            clientSecret: keyEnc,
            signatureKey: sigKeyEnc,
          });

          const success = response.initSuccess(200, true, {
            secret: clientSecretKeyBase64,
            signature: clientSignatureKeyBase64,
          });
          return res.send(success);
        } else {
          const error = response.initError(
            500,
            false,
            new ErrorMessage('Client not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateDevSettingApiServerWl(
    data: UpdateIpWlDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };
      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        await this.DevClient.findOne({
          user: user.id,
        }).then(async (client: any) => {
          if (client) {
            const update: any = {};
            if (data.ip) {
              update.ip = data.ip;
            }

            await this.DevClient.findByIdAndUpdate(client.id, update);

            const success = response.initSuccess(200, true, true);
            return res.send(success);
          } else {
            const error = response.initError(
              500,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevSettingApiCallback(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      await this.DevClient.findOne({
        user: user.id,
      })
        .select('callbackTrx callbackWd callbackTopup callbackKey')
        .then((client: any) => {
          if (client) {
            client.callbackKey = !!client.callbackKey;
            const success = response.initSuccess(200, true, client);
            return res.send(success);
          } else {
            const error = response.initError(
              500,
              false,
              new ErrorMessage('Client not found'),
            );
            return res.send(error);
          }
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getDevSettingApiCallbackGenerate(
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;

      await this.DevClient.findOne({
        user: user.id,
      }).then(async (client: any) => {
        if (client) {
          const randomBytes = crypto.randomBytes(32).toString('hex');

          // Create the client secret key by hashing the client ID with the secret key
          const clientSecretKey = encryptHmac(
            'sha256',
            randomBytes,
            client.clientId,
            'hex',
          ).substring(0, 32);

          // Generate a random string
          const randomString = crypto.randomBytes(16).toString('hex');

          // Create the client signature key by combining the secret key, random string, and client ID
          const clientCallbackKey = encryptHmac(
            'sha256',
            randomBytes,
            clientSecretKey + randomString + client.clientId,
            'hex',
          ).substring(0, 64);

          const clientCallbackKeyBase64 = Buffer.from(
            clientCallbackKey,
            'hex',
          ).toString('base64');

          const keyEnc = encrypt(
            process.env.ENCRYPT_ALG,
            hash('sha256', client.id).substring(0, 32),
            hash('sha256', user.id + client.clientId).substring(0, 16),
            clientCallbackKeyBase64,
          );

          await this.DevClient.findByIdAndUpdate(client.id, {
            callbackKey: keyEnc,
          });

          const success = response.initSuccess(200, true, {
            key: clientCallbackKeyBase64,
          });
          return res.send(success);
        } else {
          const error = response.initError(
            500,
            false,
            new ErrorMessage('Client not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async updateDevSettingApiCallbackUrl(
    data: UpdateIpWlDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user, browser } = req.user;
      const { signature: _, ...payload } = data;
      const signatureVerify = encryptHmac(
        'sha256',
        browser.csrf,
        hash('sha256', minifyJson(payload)).toLowerCase() +
          '|' +
          browser.browserId,
        'hex',
      );

      const updateBrowser = {
        user: user.id,
        $push: { ip: req.ip },
      };
      await this.Browser.findByIdAndUpdate(
        browser.id,
        {
          $set: updateBrowser,
          $unset: {
            csrf: undefined,
          },
        },
        { new: true, upsert: true },
      );

      if (signatureVerify === data.signature) {
        const regex = /^(?:\w+:)?\/\/([^\s.]+\.\S{2}|localhost[:?\d]*)\S*$/;
        if (!regex.test(data.callbackTrx)) {
          const error = response.initError(
            403,
            false,
            new ErrorMessage(
              'Callback Payment url invalid, must begin with either HTTP:// or HTTPS://',
            ),
          );
          return res.send(error);
        } else if (!regex.test(data.callbackWd)) {
          const error = response.initError(
            403,
            false,
            new ErrorMessage(
              'Callback Transfer invalid, must begin with either HTTP:// or HTTPS://',
            ),
          );
          return res.send(error);
        } else if (!regex.test(data.callbackTopup)) {
          const error = response.initError(
            403,
            false,
            new ErrorMessage(
              'Callback Topup invalid, must begin with either HTTP:// or HTTPS://',
            ),
          );
          return res.send(error);
        } else {
          await this.DevClient.findOne({
            user: user.id,
          }).then(async (client) => {
            if (client) {
              const update: any = {};
              if (data.callbackTrx) {
                update.callbackTrx = data.callbackTrx;
              }
              if (data.callbackWd) {
                update.callbackWd = data.callbackWd;
              }
              if (data.callbackTopup) {
                update.callbackTopup = data.callbackTopup;
              }

              await this.DevClient.findByIdAndUpdate(client.id, update);

              const success = response.initSuccess(200, true, true);
              return res.send(success);
            } else {
              const error = response.initError(
                500,
                false,
                new ErrorMessage('Client not found'),
              );
              return res.send(error);
            }
          });
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage('Signature invalid'),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }
}
