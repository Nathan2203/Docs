import {
  Controller,
  Get,
  UseGuards,
  Res,
  Req,
  Patch,
  Body,
  Post,
  Delete,
  Query,
  Param,
} from '@nestjs/common';
import { FastifyReply } from 'fastify';
import {
  ApiTags,
  ApiBearerAuth,
  ApiOperation,
  ApiSecurity,
} from '@nestjs/swagger';

import { PortalService } from './portal.service';
import { Role } from 'src/common/config/enum';
import { UserGuard } from 'src/common/middleware/user/user.guard';
import { Roles } from 'src/core/decorators/role.decorator';
import { FastifyUserRequest } from 'src/common/interface/fastify-user.interface';
import { ValidationPipe } from 'src/core/pipes/validation.pipe';
import { UpdateIpWlDto } from './dto/update-ip-wl.dto';
import { UpdatePaymentChannelDto } from './dto/update-payment-channel.dto';
import { CheckBankAccountDto } from './dto/check-bank-account.dto';
import { DeleteBankAccountDto } from './dto/delete-bank-account.dto';
import { Verify2FaDto } from '../admin/dto/verify-2fa.dto';
import { QueryDto } from '../admin/dto/query.dto';
import { ActionTransactionDto } from './dto/action-transaction.dto';
import { ActionDevTransactionDto } from './dto/action-dev-transaction.dto';
import { ActionWithdrawDto } from './dto/action-withdraw.dto';
import { ActionDevWithdrawDto } from './dto/action-dev-withdraw.dto';
import { DisburseDto } from './dto/disburse.dto';
import { TopupDto } from './dto/topup.dto';
import { ChangePasswordDto } from '../admin/dto/change-password.dto';

@ApiTags('Portal')
@Controller({ path: 'portal', version: '1' })
@ApiBearerAuth()
@ApiSecurity('session')
@ApiSecurity('browserId')
@Roles(Role.Client)
@UseGuards(UserGuard)
export class PortalController {
  constructor(private readonly portalService: PortalService) {}

  @Get('/overview')
  getOverview(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.portalService.getOverview(req, res);
  }

  @Get('/logout')
  doLogout(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.portalService.doLogout(req, res);
  }

  @Post('/change/password')
  changePassword(
    @Body(new ValidationPipe()) payload: ChangePasswordDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.changePassword(payload, req, res);
  }

  @Post('/topup')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  topup(
    @Body(new ValidationPipe()) payload: TopupDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.topup(payload, req, res);
  }

  @Get('/disburse/fee')
  getDisburseFee(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.portalService.getDisburseFee(req, res);
  }

  @Post('/disburse/inquiry')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  disburseInquiry(
    @Body(new ValidationPipe()) payload: DisburseDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.disburseInquiry(payload, req, res);
  }

  @Post('/disburse/process/:withdrawId')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, xSignatureInquiry + '|' + browserId) encoding hex",
  })
  disburseProcess(
    @Param('withdrawId') withdrawId: string,
    @Body(new ValidationPipe()) payload: DisburseDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.disburseProcess(withdrawId, payload, req, res);
  }

  @Get('/transaction')
  getTransaction(
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getTransaction(query, req, res);
  }

  @Get('/transaction/:transId')
  getTransactionDetail(
    @Param('transId') transId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getTransactionDetail(transId, req, res);
  }

  @Post('/transaction/action')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  actionTransaction(
    @Body(new ValidationPipe()) data: ActionTransactionDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.actionTransaction(data, req, res);
  }

  @Get('/withdraw')
  getWithdraw(
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getWithdraw(query, req, res);
  }

  @Get('/withdraw/:withdrawId')
  getWithdrawDetail(
    @Param('withdrawId') withdrawId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getWithdrawDetail(withdrawId, req, res);
  }

  @Post('/withdraw/action')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  actionWithdraw(
    @Body(new ValidationPipe()) data: ActionWithdrawDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.actionWithdraw(data, req, res);
  }

  @Get('/topup')
  getTopup(
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getTopup(query, req, res);
  }

  @Get('/topup/invoice/:topupId')
  getTopupInvoice(
    @Param('topupId') topupId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getTopupInvoice(topupId, req, res);
  }

  @Get('/topup/status/:transactionId')
  getTopupStatus(
    @Param('transactionId') transactionId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getTopupStatus(transactionId, req, res);
  }

  @Get('/topup/:topupId')
  getTopupDetail(
    @Param('topupId') topupId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getTopupDetail(topupId, req, res);
  }

  @Post('/topup/action')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  actionTopup(
    @Body(new ValidationPipe()) data: ActionTransactionDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.actionTopup(data, req, res);
  }

  @Get('/callback/check/:type/:id')
  checkCallback(
    @Param('type') type: string,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.checkCallback(type, id, req, res);
  }

  @Get('/callback/history/:type')
  getCallbackHistory(
    @Query() query: QueryDto,
    @Param('type') type: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getCallbackHistory(query, type, req, res);
  }

  @Get('/callback/history/:type/:id')
  getCallbackHistoryDetail(
    @Param('type') type: string,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getCallbackHistoryDetail(type, id, req, res);
  }

  @Get('/callback/resend/:type/:id')
  resendCallback(
    @Param('type') type: string,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.resendCallback(type, id, req, res);
  }

  @Get('/log/activity/type')
  getLogType(@Res() res: FastifyReply) {
    this.portalService.getLogType(res);
  }

  @Get('/log/balance/type')
  getBalanceLogType(@Res() res: FastifyReply) {
    this.portalService.getBalanceLogType(res);
  }

  @Get('/log/balance/:logTypeName')
  getBalanceLogs(
    @Query() query: QueryDto,
    @Param('logTypeName') logTypeName: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getBalanceLogs(query, logTypeName, req, res);
  }

  @Get('/log/activity/:logTypeId')
  getLogs(
    @Query() query: QueryDto,
    @Param('logTypeId') logTypeId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getLogs(query, logTypeId, req, res);
  }

  @Get('/setting/api/server')
  getSettingApiServer(
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getSettingApiServer(req, res);
  }

  @Get('/setting/api/server/generate/:code')
  getSettingApiServerGenerate(
    @Param('code') code: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getSettingApiServerGenerate(code, req, res);
  }

  @Patch('/setting/api/server/wl')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  updateSettingApiServerWl(
    @Body(new ValidationPipe()) data: UpdateIpWlDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.updateSettingApiServerWl(data, req, res);
  }

  @Get('/setting/api/callback')
  getSettingApiCallback(
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getSettingApiCallback(req, res);
  }

  @Get('/setting/api/callback/generate/:code')
  getSettingApiCallbackGenerate(
    @Param('code') code: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getSettingApiCallbackGenerate(code, req, res);
  }

  @Patch('/setting/api/callback/url')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  updateSettingApiCallbackUrl(
    @Body(new ValidationPipe()) data: UpdateIpWlDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.updateSettingApiCallbackUrl(data, req, res);
  }

  @Get('/setting/bank/wl')
  getSettingBankWl(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.portalService.getSettingBankWl(req, res);
  }

  @Get('/setting/bank/list')
  getSettingBankList(@Res() res: FastifyReply) {
    this.portalService.getSettingBankList(res);
  }

  @Post('/setting/bank/check')
  getSettingBankCheck(
    @Body(new ValidationPipe()) data: CheckBankAccountDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getSettingBankCheck(data, req, res);
  }

  @Post('/setting/bank/add')
  getSettingBankAdd(
    @Body(new ValidationPipe()) data: CheckBankAccountDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getSettingBankAdd(data, req, res);
  }

  @Delete('/setting/bank/wl')
  getSettingBankDelete(
    @Body(new ValidationPipe()) data: DeleteBankAccountDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getSettingBankDelete(data, req, res);
  }

  @Get('/setting/payment/channel')
  getSettingPaymentChannel(
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getSettingPaymentChannel(req, res);
  }

  @Patch('/setting/payment/channel')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  updateSettingPaymentChannel(
    @Body(new ValidationPipe()) data: UpdatePaymentChannelDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.updateSettingPaymentChannel(data, req, res);
  }

  @Get('/2fa/status')
  get2FaStatus(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.portalService.get2FaStatus(req, res);
  }

  @Get('/2fa/setup')
  get2FaSetup(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.portalService.get2FaSetup(req, res);
  }

  @Post('/2fa/verify')
  get2FaVerify(
    @Body(new ValidationPipe()) data: Verify2FaDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.get2FaVerify(data, req, res);
  }

  // DEV

  @Get('/dev/overview')
  getDevOverview(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.portalService.getDevOverview(req, res);
  }

  @Get('/dev/transaction')
  getDevTransaction(
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevTransaction(query, req, res);
  }

  @Get('/dev/transaction/:transId')
  getDevTransactionDetail(
    @Param('transId') transId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevTransactionDetail(transId, req, res);
  }

  @Post('/dev/transaction/action')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  actionDevTransaction(
    @Body(new ValidationPipe()) data: ActionDevTransactionDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.actionDevTransaction(data, req, res);
  }

  @Get('/dev/withdraw')
  getDevWithdraw(
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevWithdraw(query, req, res);
  }

  @Get('/dev/withdraw/:withdrawId')
  getDevWithdrawDetail(
    @Param('withdrawId') withdrawId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevWithdrawDetail(withdrawId, req, res);
  }

  @Post('/dev/withdraw/action')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  actionDevWithdraw(
    @Body(new ValidationPipe()) data: ActionDevWithdrawDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.actionDevWithdraw(data, req, res);
  }

  @Get('/dev/topup')
  getDevTopup(
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevTopup(query, req, res);
  }

  @Get('/dev/topup/:topupId')
  getDevTopupDetail(
    @Param('topupId') topupId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevTopupDetail(topupId, req, res);
  }

  @Post('/dev/topup/action')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  actionDevTopup(
    @Body(new ValidationPipe()) data: ActionDevTransactionDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.actionDevTopup(data, req, res);
  }

  @Get('/dev/callback/check/:type/:id')
  checkDevCallback(
    @Param('type') type: string,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.checkDevCallback(type, id, req, res);
  }

  @Get('/dev/callback/history/:type')
  getDevCallbackHistory(
    @Query() query: QueryDto,
    @Param('type') type: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevCallbackHistory(query, type, req, res);
  }

  @Get('/dev/callback/history/:type/:id')
  getDevCallbackHistoryDetail(
    @Param('type') type: string,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevCallbackHistoryDetail(type, id, req, res);
  }

  @Get('/dev/callback/resend/:type/:id')
  resendDevCallback(
    @Param('type') type: string,
    @Param('id') id: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.resendDevCallback(type, id, req, res);
  }

  @Get('/dev/setting/api/server')
  getDevSettingApiServer(
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevSettingApiServer(req, res);
  }

  @Get('/dev/setting/api/server/generate')
  getDevSettingApiServerGenerate(
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevSettingApiServerGenerate(req, res);
  }

  @Patch('/dev/setting/api/server/wl')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  updateDevSettingApiServerWl(
    @Body(new ValidationPipe()) data: UpdateIpWlDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.updateDevSettingApiServerWl(data, req, res);
  }

  @Get('/dev/setting/api/callback')
  getDevSettingApiCallback(
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevSettingApiCallback(req, res);
  }

  @Get('/dev/setting/api/callback/generate')
  getDevSettingApiCallbackGenerate(
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.getDevSettingApiCallbackGenerate(req, res);
  }

  @Patch('/dev/setting/api/callback/url')
  @ApiOperation({
    description:
      "For signature: HMAC_SHA256(csrf, Lowercase(HexEncode(SHA-256(minify(RequestBody))) + '|' + browserId) encoding hex",
  })
  updateDevSettingApiCallbackUrl(
    @Body(new ValidationPipe()) data: UpdateIpWlDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.portalService.updateDevSettingApiCallbackUrl(data, req, res);
  }
}
