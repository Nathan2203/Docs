import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';

import { PortalService } from './portal.service';
import { PortalController } from './portal.controller';
import { UserStrategy } from 'src/common/middleware/user/user.strategy';
import { UserGuard } from 'src/common/middleware/user/user.guard';

import { Bank, BankSchema } from '../admin/entities/bank.entity';
import { Fee, FeeSchema } from '../admin/entities/fee.entity';
import { LogType, LogTypeSchema } from '../admin/entities/log-type.entity';
import { Log, LogSchema } from '../admin/entities/log.entity';
import {
  ValueType,
  ValueTypeSchema,
} from '../admin/entities/value-type.entity';
import { Client, ClientSchema } from '../open/entities/client.entity';
import { Method, MethodSchema } from '../public/entities/method.entity';
import { Balance, BalanceSchema } from '../user/entities/balance.entity';
import { Browser, BrowserSchema } from '../user/entities/browser.entity';
import { Session, SessionSchema } from '../user/entities/session.entity';
import {
  Transaction,
  TransactionSchema,
} from '../user/entities/transaction.entity';
import { User, UserSchema } from '../user/entities/user.entity';
import { Withdraw, WithdrawSchema } from '../user/entities/withdraw.entity';
import { DevClient, DevClientSchema } from '../open/entities/dev-client.entity';
import {
  BankAccount,
  BankAccountSchema,
} from '../open/entities/bank-account.entity';
import {
  DevTransaction,
  DevTransactionSchema,
} from '../open/entities/dev-transaction.entity';
import {
  DevWithdraw,
  DevWithdrawSchema,
} from '../open/entities/dev-withdraw.entity';
import {
  BalanceLog,
  BalanceLogSchema,
} from '../user/entities/balance-log.entity';
import {
  Commission,
  CommissionSchema,
} from '../partner/entities/commission.entity';
import { Callback, CallbackSchema } from '../callback/entities/callback.entity';
import {
  DevCallback,
  DevCallbackSchema,
} from '../callback/entities/dev-callback.entity';
import { ProviderModule } from 'src/core/provider/provider.module';

@Module({
  imports: [
    ProviderModule,
    MongooseModule.forFeature([
      { name: Client.name, schema: ClientSchema },
      { name: DevClient.name, schema: DevClientSchema },
      { name: User.name, schema: UserSchema },
      { name: Method.name, schema: MethodSchema },
      { name: Bank.name, schema: BankSchema },
      { name: Fee.name, schema: FeeSchema },
      { name: Session.name, schema: SessionSchema },
      { name: Browser.name, schema: BrowserSchema },
      { name: Transaction.name, schema: TransactionSchema },
      { name: DevTransaction.name, schema: DevTransactionSchema },
      { name: Withdraw.name, schema: WithdrawSchema },
      { name: DevWithdraw.name, schema: DevWithdrawSchema },
      { name: Balance.name, schema: BalanceSchema },
      { name: BalanceLog.name, schema: BalanceLogSchema },
      { name: ValueType.name, schema: ValueTypeSchema },
      { name: Log.name, schema: LogSchema },
      { name: LogType.name, schema: LogTypeSchema },
      { name: BankAccount.name, schema: BankAccountSchema },
      { name: Commission.name, schema: CommissionSchema },
      { name: Callback.name, schema: CallbackSchema },
      { name: DevCallback.name, schema: DevCallbackSchema },
    ]),
  ],
  controllers: [PortalController],
  providers: [PortalService, UserStrategy, UserGuard],
})
export class PortalModule {}
