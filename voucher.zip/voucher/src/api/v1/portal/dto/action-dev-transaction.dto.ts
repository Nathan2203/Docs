import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty } from 'class-validator';
import { TransactionStatusType } from 'src/common/config/enum';
import { ActionTransactionDto } from './action-transaction.dto';

export class ActionDevTransactionDto extends ActionTransactionDto {
  @ApiProperty({ enum: TransactionStatusType })
  @IsEnum(TransactionStatusType)
  @IsNotEmpty({ message: 'Status must not be empty' })
  status: TransactionStatusType;
}
