import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class TopupDto {
  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;

  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsNotEmpty({ message: 'Amount must not be empty' })
  @IsNumber()
  amount: number;

  @IsString()
  @IsNotEmpty({ message: 'Method ID must not be empty' })
  method: string;

  @IsString()
  @IsOptional()
  phone: string;
}
