import { IsBoolean, IsNotEmpty, IsString } from 'class-validator';

export class UpdatePaymentChannelDto {
  @IsBoolean()
  @IsNotEmpty({ message: 'On Client must not be empty' })
  onClient: boolean;

  @IsString()
  @IsNotEmpty({ message: 'Method ID must not be empty' })
  methodId: string;

  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsString()
  @IsNotEmpty({ message: 'Fee ID must not be empty' })
  feeId: string;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;
}
