import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty } from 'class-validator';
import { WithdrawStatus } from 'src/common/config/enum';
import { ActionWithdrawDto } from './action-withdraw.dto';

export class ActionDevWithdrawDto extends ActionWithdrawDto {
  @ApiProperty({ enum: WithdrawStatus })
  @IsEnum(WithdrawStatus)
  @IsNotEmpty({ message: 'Status must not be empty' })
  status: WithdrawStatus;
}
