import { IsNotEmpty, IsString } from 'class-validator';

export class CheckBankAccountDto {
  @IsString()
  @IsNotEmpty({ message: 'Account must not be empty' })
  account: string;

  @IsString()
  @IsNotEmpty({ message: 'Bank ID must not be empty' })
  bankId: string;

  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsString()
  @IsNotEmpty({ message: 'Code must not be empty' })
  code: string;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;
}
