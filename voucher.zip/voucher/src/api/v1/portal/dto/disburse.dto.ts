import {
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Min,
} from 'class-validator';

export class DisburseDto {
  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsString()
  @IsNotEmpty({ message: 'Bank ID must not be empty' })
  bankAccountId: string;

  @IsNumber()
  @IsNotEmpty({ message: 'Amount must not be empty' })
  @Min(0, { message: 'Amount cannot be smaller than 0' })
  amount: number;

  @IsString()
  @IsOptional()
  code: string;

  @IsString()
  @IsOptional()
  remark: string;
}
