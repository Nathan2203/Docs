import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class UpdateIpWlDto {
  @IsString()
  @IsOptional()
  ip: string;

  @IsString()
  @IsOptional()
  callbackTrx: string;

  @IsString()
  @IsOptional()
  callbackWd: string;

  @IsString()
  @IsOptional()
  callbackTopup: string;

  @IsString()
  @IsNotEmpty({ message: 'Code must not be empty' })
  code: string;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;
}
