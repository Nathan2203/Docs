import { IsNotEmpty, IsString } from 'class-validator';

export class DeleteBankAccountDto {
  @IsString()
  @IsNotEmpty({ message: 'Bank Account ID must not be empty' })
  bankAccountId: string;

  @IsString()
  @IsNotEmpty({ message: 'User ID must not be empty' })
  userId: string;

  @IsString()
  @IsNotEmpty({ message: 'Code must not be empty' })
  code: string;

  @IsString()
  @IsNotEmpty({ message: 'Signature must not be empty' })
  signature: string;
}
