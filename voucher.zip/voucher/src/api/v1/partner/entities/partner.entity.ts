export class Partner {}
