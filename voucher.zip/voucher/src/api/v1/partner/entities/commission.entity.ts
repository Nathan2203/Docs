import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, SchemaTypes, Types } from 'mongoose';

export type CommissionDocument = HydratedDocument<Commission>;

@Schema({ timestamps: true })
export class Commission {
  @Prop()
  clientTrx: number;

  @Prop()
  clientTrxQty: number;

  @Prop()
  partnerTrx: number;

  @Prop()
  partnerTrxQty: number;

  @Prop()
  clientWd: number;

  @Prop()
  clientWdQty: number;

  @Prop()
  partnerWd: number;

  @Prop()
  partnerWdQty: number;

  @Prop()
  amountTrx: number;

  @Prop()
  amountTrxQty: number;

  @Prop()
  amountWd: number;

  @Prop()
  amountWdQty: number;

  @Prop()
  cutoff: number;

  @Prop({ default: true })
  isActive: boolean;

  @Prop({ default: false })
  isDisbursed: boolean;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  user: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  upline: Types.ObjectId;

  @Prop({ type: SchemaTypes.ObjectId, ref: 'User' })
  downline: Types.ObjectId;
}

export const CommissionSchema = SchemaFactory.createForClass(Commission);
