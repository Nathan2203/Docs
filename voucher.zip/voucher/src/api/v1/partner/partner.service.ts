import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { FastifyReply } from 'fastify';
import { Model, Types } from 'mongoose';

import { FastifyUserRequest } from 'src/common/interface/fastify-user.interface';
import {
  Role,
  TransactionType,
  WithdrawProcess,
  WithdrawType,
  LogType as LogTypes,
  BalanceLogType,
} from 'src/common/config/enum';

import { QueryDto } from '../admin/dto/query.dto';

import { User, UserDocument } from '../user/entities/user.entity';
import { Withdraw, WithdrawDocument } from '../user/entities/withdraw.entity';
import { Commission, CommissionDocument } from './entities/commission.entity';
import {
  Transaction,
  TransactionDocument,
} from '../user/entities/transaction.entity';
import { Session, SessionDocument } from '../user/entities/session.entity';

import { LogType, LogTypeDocument } from '../admin/entities/log-type.entity';
import { Log, LogDocument } from '../admin/entities/log.entity';
import {
  BalanceLog,
  BalanceLogDocument,
} from '../user/entities/balance-log.entity';

import { SOPResponse, SOPErrorMessage as ErrorMessage } from 'src/common/api';
import { Balance, BalanceDocument } from '../user/entities/balance.entity';
import { ChangePasswordDto } from '../admin/dto/change-password.dto';
import { encryptHmac } from 'src/common/helper/encryptKey';
import { hash } from 'src/common/helper/hash';
import { minifyJson } from 'src/common/helper/minifyJson';
import { Browser, BrowserDocument } from '../user/entities/browser.entity';
import { encryptPass } from 'src/common/helper/encryptPass';
const response = new SOPResponse();

@Injectable()
export class PartnerService {
  constructor(
    @InjectModel(Browser.name) private readonly Browser: Model<BrowserDocument>,
    @InjectModel(Session.name) private readonly Session: Model<SessionDocument>,
    @InjectModel(User.name) private readonly User: Model<UserDocument>,
    @InjectModel(Transaction.name)
    private readonly Transaction: Model<TransactionDocument>,
    @InjectModel(Withdraw.name)
    private readonly Withdraw: Model<WithdrawDocument>,
    @InjectModel(Commission.name)
    private readonly Commission: Model<CommissionDocument>,
    @InjectModel(LogType.name)
    private readonly LogType: Model<LogTypeDocument>,
    @InjectModel(Log.name)
    private readonly Log: Model<LogDocument>,
    @InjectModel(Balance.name)
    private readonly Balance: Model<BalanceDocument>,
    @InjectModel(BalanceLog.name)
    private readonly BalanceLog: Model<BalanceLogDocument>,
  ) {}

  async doLogout(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      await this.Session.findOne({ user: user.id }).then(
        async (sessionFind) => {
          const updateSession = {
            sessionToken: undefined,
            sessionExpires: undefined,
            refreshToken: undefined,
            refreshExpires: undefined,
            lastActivityDate: new Date(),
          };

          await this.Session.findByIdAndUpdate(
            sessionFind.id,
            { $set: updateSession },
            { new: true, upsert: true },
          );

          await this.LogType.findOne({
            type: LogTypes.Logout,
          }).then(async (logType) => {
            if (logType) {
              const newLog = new this.Log({
                message: `${user.username} Logout`,
                ip: req.ip,
                type: logType.id,
                user: user.id,
              });

              await newLog.save();
            }
          });

          const success = response.initSuccess(200, true, true);
          return res.send(success);
        },
      );
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async changePassword(
    data: ChangePasswordDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      if (data.old !== data.new) {
        const { user, browser } = req.user;
        const { signature: _, ...payload } = data;
        const signatureVerify = encryptHmac(
          'sha256',
          browser.csrf,
          hash('sha256', minifyJson(payload)).toLowerCase() +
            '|' +
            browser.browserId,
          'hex',
        );

        const updateBrowser = {
          user: user.id,
          $push: { ip: req.ip },
        };
        await this.Browser.findByIdAndUpdate(
          browser.id,
          {
            $set: updateBrowser,
            $unset: {
              csrf: undefined,
            },
          },
          { new: true, upsert: true },
        );

        if (data.signature === signatureVerify) {
          if (!user.comparePass(data.old)) {
            const error = response.initError(
              403,
              false,
              new ErrorMessage('Invalid Old Password'),
            );
            return res.send(error);
          } else {
            await this.User.findByIdAndUpdate(user.id, {
              pass: await encryptPass(data.new),
            });

            const success = response.initSuccess(200, true, true);
            return res.send(success);
          }
        } else {
          const error = response.initError(
            403,
            false,
            new ErrorMessage('Signature invalid'),
          );
          return res.send(error);
        }
      } else {
        const error = response.initError(
          403,
          false,
          new ErrorMessage("New password can't be same with the old one"),
        );
        return res.send(error);
      }
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getOverview(req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      const todayStart = new Date();
      todayStart.setDate(todayStart.getDate() - 1);
      todayStart.setHours(17, 0, 0, 0);
      const todayEnd = new Date();
      todayEnd.setHours(16, 59, 59, 999);

      await this.User.aggregate([
        {
          $match: {
            $expr: {
              $eq: ['$_id', { $toObjectId: user.id }],
            },
          },
        },
        // lookup the balance collection and filter by user
        {
          $lookup: {
            from: 'balances',
            let: { userId: '$_id' },
            pipeline: [
              { $match: { $expr: { $eq: ['$user', '$$userId'] } } },
              { $project: { _id: 0, balance: 1, freeze: 1, debt: 1 } },
            ],
            as: 'balance',
          },
        },
        {
          $unwind: {
            path: '$balance',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'commissions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $facet: {
                  today: [
                    {
                      $match: {
                        $expr: { $eq: ['$user', '$$userId'] },
                        isActive: true,
                      },
                    },
                    {
                      $project: {
                        _id: 0,
                        partnerTrx: 1,
                        partnerTrxQty: 1,
                        clientTrx: 1,
                        clientTrxQty: 1,
                        partnerWd: 1,
                        partnerWdQty: 1,
                        clientWd: 1,
                        clientWdQty: 1,
                      },
                    },
                  ],
                  all: [
                    {
                      $match: {
                        $expr: { $eq: ['$user', '$$userId'] },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        partnerTrx: { $sum: '$partnerTrx' },
                        partnerTrxQty: { $sum: '$partnerTrxQty' },
                        clientTrx: { $sum: '$clientTrx' },
                        clientTrxQty: { $sum: '$clientTrxQty' },
                        partnerWd: { $sum: '$partnerWd' },
                        partnerWdQty: { $sum: '$partnerWdQty' },
                        clientWd: { $sum: '$clientWd' },
                        clientWdQty: { $sum: '$clientWdQty' },
                      },
                    },
                    {
                      $project: {
                        _id: 0,
                        partnerTrx: 1,
                        partnerTrxQty: 1,
                        clientTrx: 1,
                        clientTrxQty: 1,
                        partnerWd: 1,
                        partnerWdQty: 1,
                        clientWd: 1,
                        clientWdQty: 1,
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  today: { $arrayElemAt: ['$today', 0] },
                  all: { $arrayElemAt: ['$all', 0] },
                },
              },
            ],
            as: 'commission',
          },
        },
        {
          $unwind: {
            path: '$commission',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'withdraws',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      { $eq: ['$process', WithdrawProcess.Process] },
                      { $eq: ['$withdrawType', WithdrawType.Partner] },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'withdraw',
          },
        },
        {
          $unwind: {
            path: '$withdraw',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 1,
            username: 1,
            email: 1,
            phone: 1,
            createdAt: 1,
            updatedAt: 1,
            commission: 1,
            withdraw: {
              $let: {
                vars: {
                  withdrawData: {
                    $ifNull: ['$withdraw', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$withdrawData', null] },
                    then: null,
                    else: '$$withdrawData',
                  },
                },
              },
            },
            balance: {
              $let: {
                vars: {
                  balanceData: {
                    $ifNull: ['$balance', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$balanceData', null] },
                    then: null,
                    else: '$$balanceData',
                  },
                },
              },
            },
          },
        },
      ]).then((user) => {
        if (user.length) {
          const success = response.initSuccess(200, true, user[0]);
          return res.send(success);
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Partner not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClient(query: QueryDto, req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        username: { username: query.sortOrder === 'asc' ? 1 : -1 },
        amountTrx: { amountTrx: query.sortOrder === 'asc' ? 1 : -1 },
        amountWd: { amountWd: query.sortOrder === 'asc' ? 1 : -1 },
        status: { status: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      await this.User.aggregate([
        {
          $match: {
            $and: [
              {
                $expr: {
                  $eq: ['$upline', { $toObjectId: user.id }],
                },
              },
              { role: Role.Client },
              { isDeleted: false },
              query.search
                ? {
                    username: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  }
                : {},
            ],
          },
        },
        {
          $facet: {
            data: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.username,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $lookup: {
                  from: 'commissions',
                  let: { userId: '$_id' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $and: [
                            {
                              $eq: ['$downline', '$$userId'],
                            },
                            {
                              $eq: ['$upline', { $toObjectId: user.id }],
                            },
                          ],
                        },
                      },
                    },
                    {
                      $project: {
                        _id: 0,
                        amountTrx: 1,
                        amountTrxQty: 1,
                        amountWd: 1,
                        amountWdQty: 1,
                      },
                    },
                  ],
                  as: 'commission',
                },
              },
              {
                $unwind: {
                  path: '$commission',
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $project: {
                  _id: 0,
                  id: '$_id',
                  username: 1,
                  isBlocked: 1,
                  createdAt: 1,
                  amountTrx: '$commission.amountTrx',
                  amountTrxQty: '$commission.amountTrxQty',
                  amountWd: '$commission.amountWd',
                  amountWdQty: '$commission.amountWdQty',
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            data: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((users) => {
        const success = response.initSuccess(200, true, users[0]);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientOverview(id: string, res: FastifyReply) {
    try {
      const todayStart = new Date();
      todayStart.setDate(todayStart.getDate() - 1);
      todayStart.setHours(17, 0, 0, 0);
      const todayEnd = new Date();
      todayEnd.setHours(16, 59, 59, 999);

      await this.User.aggregate([
        {
          $match: {
            $expr: {
              $eq: ['$_id', { $toObjectId: id }],
            },
            isDeleted: false,
          },
        },
        // lookup the transactions collection and filter by 'Paid' status
        {
          $lookup: {
            from: 'transactions',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      {
                        $eq: ['$transactionType', TransactionType.Transaction],
                      },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'transaction',
          },
        },
        {
          $unwind: {
            path: '$transaction',
            preserveNullAndEmptyArrays: true,
          },
        },
        // lookup the withdraw collection and filter by 'Paid' and 'Pending' status
        {
          $lookup: {
            from: 'withdraws',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$user', '$$userId'] },
                      { $eq: ['$process', WithdrawProcess.Process] },
                      { $eq: ['$withdrawType', WithdrawType.Client] },
                    ],
                  },
                },
              },
              {
                $facet: {
                  all: [
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                  today: [
                    {
                      $match: {
                        createdAt: {
                          $gte: todayStart,
                          $lt: todayEnd,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: '$status',
                        totalAmount: { $sum: '$amount' },
                        total: {
                          $sum: 1,
                        },
                      },
                    },
                    {
                      $group: {
                        _id: null,
                        objects: {
                          $push: {
                            k: '$_id',
                            v: {
                              totalAmount: '$totalAmount',
                              total: '$total',
                            },
                          },
                        },
                      },
                    },
                    {
                      $replaceRoot: {
                        newRoot: { $arrayToObject: '$objects' },
                      },
                    },
                  ],
                },
              },
              {
                $project: {
                  all: { $arrayElemAt: ['$all', 0] },
                  today: { $arrayElemAt: ['$today', 0] },
                },
              },
            ],
            as: 'withdraw',
          },
        },
        {
          $unwind: {
            path: '$withdraw',
            preserveNullAndEmptyArrays: true,
          },
        },
        // lookup the balance collection and filter by user
        {
          $lookup: {
            from: 'clients',
            let: { userId: '$_id' },
            pipeline: [{ $match: { $expr: { $eq: ['$user', '$$userId'] } } }],
            as: 'client',
          },
        },
        {
          $unwind: {
            path: '$client',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 1,
            username: 1,
            email: 1,
            isBlocked: 1,
            isVerified: 1,
            createdAt: 1,
            updatedAt: 1,
            transaction: {
              $let: {
                vars: {
                  transactionData: {
                    $ifNull: ['$transaction', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$transactionData', null] },
                    then: null,
                    else: '$$transactionData',
                  },
                },
              },
            },
            withdraw: {
              $let: {
                vars: {
                  withdrawData: {
                    $ifNull: ['$withdraw', null],
                  },
                },
                in: {
                  $cond: {
                    if: { $eq: ['$$withdrawData', null] },
                    then: null,
                    else: '$$withdrawData',
                  },
                },
              },
            },
            client: {
              clientName: 1,
            },
          },
        },
      ]).then((user) => {
        if (user.length) {
          const success = response.initSuccess(200, true, user[0]);
          return res.send(success);
        } else {
          const error = response.initError(
            404,
            false,
            new ErrorMessage('Client not found'),
          );
          return res.send(error);
        }
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientTransaction(query: QueryDto, id: string, res: FastifyReply) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        transactionId: { transactionId: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const transactionQuery: any = {
        user: new Types.ObjectId(id),
        transactionType: TransactionType.Transaction,
        $or: [
          { transactionId: { $regex: query.search.trim(), $options: 'i' } },
        ],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        transactionQuery.status = query.filter.trim();
      }
      await this.Transaction.find(transactionQuery)
        .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
        .skip(skip)
        .limit(query.limit)
        .populate({
          path: 'method',
          select: '-_id name',
        })
        .select('_id transactionId amount status createdAt')
        .then(async (transactions) => {
          const total = await this.Transaction.countDocuments(transactionQuery);
          const success = response.initSuccess(200, true, {
            transactions,
            total,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getClientWithdraw(query: QueryDto, id: string, res: FastifyReply) {
    try {
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        withdrawId: { withdrawId: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        status: { status: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const withdrawQuery: any = {
        user: new Types.ObjectId(id),
        process: WithdrawProcess.Process,
        withdrawType: WithdrawType.Client,
        $or: [{ withdrawId: { $regex: query.search.trim(), $options: 'i' } }],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        withdrawQuery.status = query.filter.trim();
      }
      await this.Withdraw.find(withdrawQuery)
        .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
        .skip(skip)
        .limit(query.limit)
        .populate({
          path: 'bank',
          select: '-_id name',
        })
        .select('_id withdrawId amount status createdAt')
        .then(async (withdraws) => {
          const total = await this.Withdraw.countDocuments(withdrawQuery);
          const success = response.initSuccess(200, true, {
            withdraws,
            total,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getTeam(query: QueryDto, req: FastifyUserRequest, res: FastifyReply) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        username: { username: query.sortOrder === 'asc' ? 1 : -1 },
        amountTrx: { amountTrx: query.sortOrder === 'asc' ? 1 : -1 },
        amountWd: { amountWd: query.sortOrder === 'asc' ? 1 : -1 },
        status: { status: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      await this.User.aggregate([
        {
          $match: {
            $and: [
              {
                $expr: {
                  $eq: ['$upline', { $toObjectId: user.id }],
                },
              },
              { role: Role.Partner },
              { isDeleted: false },
              query.search
                ? {
                    username: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  }
                : {},
            ],
          },
        },
        {
          $facet: {
            data: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.username,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $lookup: {
                  from: 'commissions',
                  let: { userId: '$_id' },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $and: [
                            {
                              $eq: ['$downline', '$$userId'],
                            },
                            {
                              $eq: ['$upline', { $toObjectId: user.id }],
                            },
                          ],
                        },
                      },
                    },
                    {
                      $project: {
                        _id: 0,
                        amountTrx: 1,
                        amountTrxQty: 1,
                        amountWd: 1,
                        amountWdQty: 1,
                      },
                    },
                  ],
                  as: 'commission',
                },
              },
              {
                $unwind: {
                  path: '$commission',
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $project: {
                  _id: 0,
                  id: '$_id',
                  username: 1,
                  isBlocked: 1,
                  createdAt: 1,
                  amountTrx: '$commission.amountTrx',
                  amountTrxQty: '$commission.amountTrxQty',
                  amountWd: '$commission.amountWd',
                  amountWdQty: '$commission.amountWdQty',
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            data: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((users) => {
        const success = response.initSuccess(200, true, users[0]);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getWithdraw(
    query: QueryDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        withdrawId: { withdrawId: query.sortOrder === 'asc' ? 1 : -1 },
        name: { name: query.sortOrder === 'asc' ? 1 : -1 },
        accNumber: { accNumber: query.sortOrder === 'asc' ? 1 : -1 },
        amount: { amount: query.sortOrder === 'asc' ? 1 : -1 },
        status: { status: query.sortOrder === 'asc' ? 1 : -1 },
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };
      const withdrawQuery: any = {
        user: user.id,
        process: WithdrawProcess.Process,
        withdrawType: WithdrawType.Partner,
        $or: [
          { withdrawId: { $regex: query.search.trim(), $options: 'i' } },
          { name: { $regex: query.search.trim(), $options: 'i' } },
          { accNumber: { $regex: query.search.trim(), $options: 'i' } },
        ],
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };

      if (query.filter.trim() !== 'all') {
        withdrawQuery.status = query.filter.trim();
      }

      await this.Withdraw.find(withdrawQuery)
        .sort(sortOptions[query.sortBy] || sortOptions.createdAt)
        .skip(skip)
        .limit(query.limit)
        .populate({
          path: 'bank',
          select: '-_id name',
        })
        .select(
          '_id withdrawId name accNumber amount feeAdmin status createdAt',
        )
        .then(async (withdraws) => {
          const total = await this.Withdraw.countDocuments(withdrawQuery);
          const success = response.initSuccess(200, true, {
            withdraws,
            total,
          });
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getCommission(
    query: QueryDto,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const queryData: any = {
        user: user.id,
        createdAt: {
          $gte: new Date(Number(query.dateStart)),
          $lte: new Date(Number(query.dateEnd)),
        },
      };
      await this.Commission.find(queryData)
        .select('-isActive -updatedAt -__v -user')
        .then((commission) => {
          const success = response.initSuccess(200, true, commission);
          return res.send(success);
        });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getLogType(res: FastifyReply) {
    try {
      await this.LogType.find({
        type: { $in: [LogTypes.Login, LogTypes.Logout] },
      }).then((logTypes) => {
        const success = response.initSuccess(200, true, logTypes);
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getBalanceLogType(res: FastifyReply) {
    try {
      const success = response.initSuccess(
        200,
        true,
        Object.values(BalanceLogType),
      );
      return res.send(success);
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getLogs(
    query: QueryDto,
    logId: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      const skip = (query.page - 1) * query.limit;
      const sortOptions = {
        createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
      };

      const logQuery: any = {
        $match: {
          user: new Types.ObjectId(user.id),
          admin: { $exists: false },
          createdAt: {
            $gte: new Date(Number(query.dateStart)),
            $lte: new Date(Number(query.dateEnd)),
          },
        },
      };
      if (logId !== 'all') {
        await this.LogType.findById(logId).then(async (logType) => {
          if (logType) {
            if (
              [LogTypes.Login, LogTypes.Logout].includes(
                logType.type as LogTypes,
              )
            ) {
              logQuery.$match.type = new Types.ObjectId(logType.id);
            } else {
              const error = response.initError(
                404,
                false,
                new ErrorMessage('Log type not valid'),
              );
              return res.send(error);
            }
          } else {
            const error = response.initError(
              404,
              false,
              new ErrorMessage('Log type not found'),
            );
            return res.send(error);
          }
        });
      }

      await this.Log.aggregate([
        logQuery,
        {
          $lookup: {
            from: 'users',
            localField: 'user',
            foreignField: '_id',
            as: 'user',
          },
        },
        {
          $unwind: {
            path: '$user',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: 'logtypes',
            localField: 'type',
            foreignField: '_id',
            as: 'type',
          },
        },
        {
          $unwind: {
            path: '$type',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: query.search
            ? {
                $or: [
                  {
                    'user.username': {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    message: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                  {
                    ip: {
                      $regex: new RegExp(query.search.trim(), 'i'),
                    },
                  },
                ],
              }
            : {},
        },
        {
          $facet: {
            results: [
              {
                $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
              },
              { $skip: skip },
              { $limit: parseInt(query.limit.toString()) },
              {
                $project: {
                  _id: 0,
                  id: '$_id',
                  message: 1,
                  ip: 1,
                  type: 1,
                  createdAt: 1,
                },
              },
            ],
            count: [{ $count: 'total' }],
          },
        },
        {
          $project: {
            results: 1,
            total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
          },
        },
      ]).then((logs) => {
        const success = response.initSuccess(
          200,
          true,
          logs.length ? logs[0] : [],
        );
        return res.send(success);
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }

  async getBalanceLogs(
    query: QueryDto,
    logTypeName: string,
    req: FastifyUserRequest,
    res: FastifyReply,
  ) {
    try {
      const { user } = req.user;
      await this.Balance.findOne({ user: user.id }).then(async (balance) => {
        const skip = (query.page - 1) * query.limit;
        const sortOptions = {
          createdAt: { createdAt: query.sortOrder === 'asc' ? 1 : -1 },
        };

        const balanceLogQuery: any = {
          $match: {
            balance: new Types.ObjectId(balance.id),
            createdAt: {
              $gte: new Date(Number(query.dateStart)),
              $lte: new Date(Number(query.dateEnd)),
            },
          },
        };

        if (logTypeName !== 'all') {
          balanceLogQuery.$match.type = logTypeName;
        }
        await this.BalanceLog.aggregate([
          balanceLogQuery,
          {
            $lookup: {
              from: 'users',
              localField: 'user',
              foreignField: '_id',
              as: 'user',
            },
          },
          {
            $unwind: {
              path: '$user',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: 'transactions',
              localField: 'transaction',
              foreignField: '_id',
              as: 'transaction',
            },
          },
          {
            $unwind: {
              path: '$transaction',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: 'withdraws',
              localField: 'withdraw',
              foreignField: '_id',
              as: 'withdraw',
            },
          },
          {
            $unwind: {
              path: '$withdraw',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $match: query.search
              ? {
                  $or: [
                    {
                      name: {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'transaction.transactionId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                    {
                      'withdraw.withdrawId': {
                        $regex: new RegExp(query.search.trim(), 'i'),
                      },
                    },
                  ],
                }
              : {},
          },
          {
            $facet: {
              results: [
                {
                  $sort: sortOptions[query.sortBy] || sortOptions.createdAt,
                },
                { $skip: skip },
                { $limit: parseInt(query.limit.toString()) },
                {
                  $project: {
                    _id: 0,
                    id: '$_id',
                    name: 1,
                    balanceAmount: 1,
                    balanceCredit: 1,
                    type: 1,
                    transaction: {
                      id: '$transaction._id',
                    },
                    withdraw: {
                      id: '$withdraw._id',
                    },
                    createdAt: 1,
                  },
                },
              ],
              count: [{ $count: 'total' }],
            },
          },
          {
            $project: {
              results: 1,
              total: { $ifNull: [{ $arrayElemAt: ['$count.total', 0] }, 0] }, // extract total from $count stage
            },
          },
        ]).then((logs) => {
          const success = response.initSuccess(
            200,
            true,
            logs.length ? logs[0] : [],
          );
          return res.send(success);
        });
      });
    } catch (err) {
      console.log(err);
      const error = response.initError(
        500,
        false,
        new ErrorMessage("There's an error on the server, please wait :)"),
      );
      return res.send(error);
    }
  }
}
