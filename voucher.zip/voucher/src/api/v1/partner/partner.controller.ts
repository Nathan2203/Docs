import {
  Controller,
  Get,
  UseGuards,
  Req,
  Res,
  Query,
  Param,
  Post,
  Body,
  ValidationPipe,
} from '@nestjs/common';
import { PartnerService } from './partner.service';
import { ApiTags, ApiBearerAuth, ApiSecurity } from '@nestjs/swagger';
import { Role } from 'src/common/config/enum';
import { UserGuard } from 'src/common/middleware/user/user.guard';
import { Roles } from 'src/core/decorators/role.decorator';
import { FastifyReply } from 'fastify';
import { FastifyUserRequest } from 'src/common/interface/fastify-user.interface';
import { QueryDto } from '../admin/dto/query.dto';
import { ChangePasswordDto } from '../admin/dto/change-password.dto';

@ApiTags('Partner')
@Controller({ path: 'partner', version: '1' })
@ApiBearerAuth()
@ApiSecurity('session')
@ApiSecurity('browserId')
@Roles(Role.Partner)
@UseGuards(UserGuard)
export class PartnerController {
  constructor(private readonly partnerService: PartnerService) {}

  @Get('/logout')
  doLogout(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.partnerService.doLogout(req, res);
  }

  @Post('/change/password')
  changePassword(
    @Body(new ValidationPipe()) payload: ChangePasswordDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.partnerService.changePassword(payload, req, res);
  }

  @Get('/overview')
  getOverview(@Req() req: FastifyUserRequest, @Res() res: FastifyReply) {
    this.partnerService.getOverview(req, res);
  }

  @Get('/client')
  getClient(
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.partnerService.getClient(query, req, res);
  }

  @Get('/client/overview/:id')
  getClientOverview(@Param('id') id: string, @Res() res: FastifyReply) {
    this.partnerService.getClientOverview(id, res);
  }

  @Get('/client/transaction/:id')
  getClientTransaction(
    @Query() query: QueryDto,
    @Param('id') id: string,
    @Res() res: FastifyReply,
  ) {
    this.partnerService.getClientTransaction(query, id, res);
  }

  @Get('/client/withdraw/:id')
  getClientWithdraw(
    @Query() query: QueryDto,
    @Param('id') id: string,
    @Res() res: FastifyReply,
  ) {
    this.partnerService.getClientWithdraw(query, id, res);
  }

  @Get('/team')
  getTeam(
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.partnerService.getTeam(query, req, res);
  }

  @Get('/withdraw')
  getWithdraw(
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.partnerService.getWithdraw(query, req, res);
  }

  @Get('/commission')
  getCommission(
    @Query() query: QueryDto,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.partnerService.getCommission(query, req, res);
  }

  @Get('/log/activity/type')
  getLogType(@Res() res: FastifyReply) {
    this.partnerService.getLogType(res);
  }

  @Get('/log/balance/type')
  getBalanveLogType(@Res() res: FastifyReply) {
    this.partnerService.getBalanceLogType(res);
  }

  @Get('/log/balance/:logTypeName')
  getBalanceLogs(
    @Query() query: QueryDto,
    @Param('logTypeName') logTypeName: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.partnerService.getBalanceLogs(query, logTypeName, req, res);
  }

  @Get('/log/activity/:logTypeId')
  getLogs(
    @Query() query: QueryDto,
    @Param('logTypeId') logTypeId: string,
    @Req() req: FastifyUserRequest,
    @Res() res: FastifyReply,
  ) {
    this.partnerService.getLogs(query, logTypeId, req, res);
  }
}
