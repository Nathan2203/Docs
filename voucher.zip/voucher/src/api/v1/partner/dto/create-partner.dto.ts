export class CreatePartnerDto {}
