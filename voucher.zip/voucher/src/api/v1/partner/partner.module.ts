import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';

import { PartnerService } from './partner.service';
import { PartnerController } from './partner.controller';
import { UserStrategy } from 'src/common/middleware/user/user.strategy';
import { UserGuard } from 'src/common/middleware/user/user.guard';

import { User, UserSchema } from '../user/entities/user.entity';
import { Browser, BrowserSchema } from '../user/entities/browser.entity';
import { Session, SessionSchema } from '../user/entities/session.entity';
import { Withdraw, WithdrawSchema } from '../user/entities/withdraw.entity';
import { Commission, CommissionSchema } from './entities/commission.entity';
import {
  Transaction,
  TransactionSchema,
} from '../user/entities/transaction.entity';
import {
  BalanceLog,
  BalanceLogSchema,
} from '../user/entities/balance-log.entity';
import { Log, LogSchema } from '../admin/entities/log.entity';
import { LogType, LogTypeSchema } from '../admin/entities/log-type.entity';
import { Balance, BalanceSchema } from '../user/entities/balance.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Session.name, schema: SessionSchema },
      { name: Browser.name, schema: BrowserSchema },
      { name: Transaction.name, schema: TransactionSchema },
      { name: Withdraw.name, schema: WithdrawSchema },
      { name: Commission.name, schema: CommissionSchema },
      { name: Balance.name, schema: BalanceSchema },
      { name: BalanceLog.name, schema: BalanceLogSchema },
      { name: Log.name, schema: LogSchema },
      { name: LogType.name, schema: LogTypeSchema },
    ]),
  ],
  controllers: [PartnerController],
  providers: [PartnerService, UserStrategy, UserGuard],
})
export class PartnerModule {}
