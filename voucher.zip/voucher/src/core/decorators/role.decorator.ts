import { SetMetadata } from '@nestjs/common';
import { ACCESS } from 'src/common/config/constants';
import { Role } from 'src/common/config/enum';

export const ACCESS_METADATA_KEY = ACCESS;
export const Access = (isPublic: boolean, roles: Role[]) =>
  SetMetadata(ACCESS_METADATA_KEY, { isPublic, roles });

export const Public = () => Access(true, []);
export const Roles = (...roles: Role[]) => Access(false, roles);
