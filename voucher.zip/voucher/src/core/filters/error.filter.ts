import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  ForbiddenException,
  HttpException,
  InternalServerErrorException,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { FastifyReply } from 'fastify';
import { SOPResponse, SOPErrorMessage as ErrorMessage } from 'src/common/api';
const sopResponse = new SOPResponse();

@Catch()
export class ErrorFilter implements ExceptionFilter {
  catch(exception: Error, host: ArgumentsHost) {
    const req = host.switchToHttp().getRequest();
    const res = host.switchToHttp().getResponse<FastifyReply>();

    if (exception instanceof HttpException) {
      if (
        req.url.includes('api') ||
        !(exception instanceof NotFoundException)
      ) {
        const status = exception.getStatus();
        if (
          exception instanceof UnauthorizedException ||
          exception instanceof ForbiddenException
        ) {
          res
            .status(status)
            .send(
              sopResponse.initError(
                status,
                false,
                new ErrorMessage(
                  status == 429
                    ? exception.message.replace('ThrottlerException: ', '')
                    : exception.getResponse()['errorMessage'] ??
                      exception.message,
                  exception.getResponse()['errors'],
                ),
              ),
            );
        } else if (exception instanceof InternalServerErrorException) {
          res
            .status(500)
            .send(
              sopResponse.initError(
                500,
                false,
                new ErrorMessage('Wrong domain'),
              ),
            );
        } else {
          res.send(
            sopResponse.initError(
              status,
              false,
              new ErrorMessage(
                status == 429
                  ? exception.message.replace('ThrottlerException: ', '')
                  : exception.getResponse()['errorMessage'] ??
                    exception.message,
                exception.getResponse()['errors'],
              ),
            ),
          );
        }
      } else {
        res
          .status(404)
          .send(
            sopResponse.initError(404, false, new ErrorMessage('Not found')),
          );
      }
    } else {
      res
        .status(500)
        .send(
          sopResponse.initError(
            500,
            false,
            new ErrorMessage(exception.message),
          ),
        );
    }
  }
}
