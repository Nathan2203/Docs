import { Injectable } from '@nestjs/common';
import { SharpService } from 'nestjs-sharp/dist/sharp.service';
import fetch from 'node-fetch';
import * as FormData from 'form-data';
import * as fs from 'fs';

import { CT_APP_JSON } from 'src/common/config/constants';
import { primePrivKey } from 'src/common/config/secret';
import { encryptRsa } from 'src/common/helper/rsa';
import { getFormattedTime } from 'src/common/helper/formattedTime';
import { generateRandomNumber } from 'src/common/helper/generateRandomNumber';
import { hash } from 'src/common/helper/hash';
import { minifyJson } from 'src/common/helper/minifyJson';

import { MerchantRegisterBncDto } from 'src/api/v1/admin/dto/merchant-register-bnc.dto';
import { encryptHmac } from 'src/common/helper/encryptKey';

@Injectable()
export class ProviderService {
  constructor(private sharpService: SharpService) {}
  async getBncAccessToken(clientId: string): Promise<string | null> {
    try {
      const timestamp = getFormattedTime();
      const sig = encryptRsa(primePrivKey, clientId + '|' + timestamp);
      const header = {
        'Content-Type': CT_APP_JSON,
        'X-CLIENT-KEY': clientId,
        'X-TIMESTAMP': timestamp,
        'X-SIGNATURE': sig,
      };

      const responseToken = await fetch(
        process.env.BNC_BASE_TOKEN + 'get/token',
        {
          method: 'POST',
          headers: header,
          body: JSON.stringify({
            grant_type: 'client_credentials',
          }),
        },
      );
      const responseJson = await responseToken.json();

      if (responseJson.responseCode === '2007300' && responseJson.accessToken) {
        return `${responseJson.tokenType} ${responseJson.accessToken}`;
      } else {
        return null;
      }
    } catch (err) {
      return null;
    }
  }

  async getBncProvince(clientId: string, token: string): Promise<any | null> {
    try {
      const timestamp = getFormattedTime();
      const payload = {};
      const stringToSign = `POST:/open/bi/private/1.0.0/qr/query-province:${hash(
        'sha256',
        minifyJson(payload),
      ).toLowerCase()}:${timestamp}`;
      const sig = encryptRsa(primePrivKey, stringToSign);
      const header = {
        'Content-Type': CT_APP_JSON,
        Authorization: token,
        'X-TIMESTAMP': timestamp,
        'X-SIGNATURE': sig,
        ORIGIN: 'primevoucher.store',
        'X-PARTNER-ID': clientId,
        'X-EXTERNAL-ID': new Date().getTime() + generateRandomNumber(10),
        'CHANNEL-ID': '95221',
      };

      const responseProvince = await fetch(
        process.env.BNC_BASE_V1 + 'qr/query-province',
        {
          method: 'POST',
          headers: header,
          body: JSON.stringify(payload),
        },
      );
      const responseJson = await responseProvince.json();
      if (responseJson.responseCode === '200Q500') {
        return responseJson.provinceList;
      } else {
        return null;
      }
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  async getBncCity(
    clientId: string,
    token: string,
    provinceId: string,
  ): Promise<any | null> {
    try {
      const timestamp = getFormattedTime();
      const payload = {
        provinceId,
      };
      const stringToSign = `POST:/open/bi/private/1.0.0/qr/query-city:${hash(
        'sha256',
        minifyJson(payload),
      ).toLowerCase()}:${timestamp}`;
      const sig = encryptRsa(primePrivKey, stringToSign);
      const header = {
        'Content-Type': CT_APP_JSON,
        Authorization: token,
        'X-TIMESTAMP': timestamp,
        'X-SIGNATURE': sig,
        ORIGIN: 'primevoucher.store',
        'X-PARTNER-ID': clientId,
        'X-EXTERNAL-ID': new Date().getTime() + generateRandomNumber(10),
        'CHANNEL-ID': '95221',
      };

      const responseCity = await fetch(
        process.env.BNC_BASE_V1 + 'qr/query-city',
        {
          method: 'POST',
          headers: header,
          body: JSON.stringify(payload),
        },
      );
      const responseJson = await responseCity.json();
      if (responseJson.responseCode === '200Q500') {
        return responseJson.cityList;
      } else {
        return null;
      }
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  async getBncDistrict(
    clientId: string,
    token: string,
    cityId: string,
  ): Promise<any | null> {
    try {
      const timestamp = getFormattedTime();
      const payload = {
        cityId,
      };
      const stringToSign = `POST:/open/bi/private/1.0.0/query-district:${hash(
        'sha256',
        minifyJson(payload),
      ).toLowerCase()}:${timestamp}`;
      const sig = encryptRsa(primePrivKey, stringToSign);
      const header = {
        'Content-Type': CT_APP_JSON,
        Authorization: token,
        'X-TIMESTAMP': timestamp,
        'X-SIGNATURE': sig,
        ORIGIN: 'primevoucher.store',
        'X-PARTNER-ID': clientId,
        'X-EXTERNAL-ID': new Date().getTime() + generateRandomNumber(10),
        'CHANNEL-ID': '95221',
      };

      const responseDistrict = await fetch(
        process.env.BNC_BASE_V1 + 'query-district',
        {
          method: 'POST',
          headers: header,
          body: JSON.stringify(payload),
        },
      );
      const responseJson = await responseDistrict.json();
      if (responseJson.responseCode === '200Q500') {
        return responseJson.districtList;
      } else {
        return null;
      }
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  async getBncPostal(
    clientId: string,
    token: string,
    districtId: string,
  ): Promise<any | null> {
    try {
      const timestamp = getFormattedTime();
      const payload = {
        districtId,
      };
      const stringToSign = `POST:/open/bi/private/1.0.0/qr/query-postcode:${hash(
        'sha256',
        minifyJson(payload),
      ).toLowerCase()}:${timestamp}`;
      const sig = encryptRsa(primePrivKey, stringToSign);
      const header = {
        'Content-Type': CT_APP_JSON,
        Authorization: token,
        'X-TIMESTAMP': timestamp,
        'X-SIGNATURE': sig,
        ORIGIN: 'primevoucher.store',
        'X-PARTNER-ID': clientId,
        'X-EXTERNAL-ID': new Date().getTime() + generateRandomNumber(10),
        'CHANNEL-ID': '95221',
      };

      const responsePostal = await fetch(
        process.env.BNC_BASE_V1 + 'qr/query-postcode',
        {
          method: 'POST',
          headers: header,
          body: JSON.stringify(payload),
        },
      );
      const responseJson = await responsePostal.json();
      if (responseJson.responseCode === '200Q500') {
        return responseJson.postCodeList;
      } else {
        return null;
      }
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  async uploadBncImg(
    imgPath: string,
    clientId: string,
    token: string,
  ): Promise<any | null> {
    try {
      const timestamp = getFormattedTime();
      const fileName = new Date().getTime() + generateRandomNumber(10);

      const payload = new FormData();
      payload.append('file', fs.createReadStream(imgPath));
      payload.append('fileName', fileName);

      const stringToSign = `POST:/open/bi/private/1.0.0/qr/upload-image:${hash(
        'sha256',
        minifyJson(payload),
      ).toLowerCase()}:${timestamp}`;
      const sig = encryptRsa(primePrivKey, stringToSign);
      const header = {
        Authorization: token,
        'X-TIMESTAMP': timestamp,
        'X-SIGNATURE': sig,
        ORIGIN: 'primevoucher.store',
        'X-PARTNER-ID': clientId,
        'X-EXTERNAL-ID': new Date().getTime() + generateRandomNumber(10),
        'CHANNEL-ID': '95221',
      };

      const responseUp = await fetch(
        process.env.BNC_BASE_V1 + 'qr/upload-image',
        {
          method: 'POST',
          headers: {
            ...header,
            ...payload.getHeaders(),
          },
          body: payload,
        },
      );
      const responseJson = await responseUp.json();
      if (responseJson.responseCode === '200Q400') {
        return responseJson.mediaId;
      } else {
        return null;
      }
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  async registerMerchantBnc(
    clientId: string,
    token: string,
    payload: any,
  ): Promise<any | null> {
    try {
      const timestamp = getFormattedTime();
      const stringToSign = `POST:/open/bi/private/1.0.0/qr/add-merchant2:${hash(
        'sha256',
        minifyJson(payload),
      ).toLowerCase()}:${timestamp}`;
      const sig = encryptRsa(primePrivKey, stringToSign);
      const header = {
        'Content-Type': CT_APP_JSON,
        Authorization: token,
        'X-TIMESTAMP': timestamp,
        'X-SIGNATURE': sig,
        ORIGIN: 'primevoucher.store',
        'X-PARTNER-ID': clientId,
        'X-EXTERNAL-ID': new Date().getTime() + generateRandomNumber(10),
        'CHANNEL-ID': '95221',
      };

      const responseRegister = await fetch(
        process.env.BNC_BASE_V1 + 'qr/add-merchant2',
        {
          method: 'POST',
          headers: header,
          body: JSON.stringify(payload),
        },
      );
      const responseJson = await responseRegister.json();
      console.log(responseJson, payload);
      if (responseJson.responseCode === '200Q100') {
        return responseJson;
      } else {
        return null;
      }
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  async generateQrisBnc(
    clientId: string,
    token: string,
    payload: any,
  ): Promise<any | null> {
    try {
      const timestamp = getFormattedTime();
      const stringToSign = `POST:/open/bi/private/1.0.0/qr/qr-mpm-generate:${hash(
        'sha256',
        minifyJson(payload),
      ).toLowerCase()}:${timestamp}`;
      const sig = encryptRsa(primePrivKey, stringToSign);
      const header = {
        'Content-Type': CT_APP_JSON,
        Authorization: token,
        'X-TIMESTAMP': timestamp,
        'X-SIGNATURE': sig,
        ORIGIN: 'primevoucher.store',
        'X-PARTNER-ID': clientId,
        'X-EXTERNAL-ID': new Date().getTime() + generateRandomNumber(10),
        'CHANNEL-ID': '95221',
      };

      const responseRegister = await fetch(
        process.env.BNC_BASE_V1 + 'qr/qr-mpm-generate',
        {
          method: 'POST',
          headers: header,
          body: JSON.stringify(payload),
        },
      );
      const responseJson = await responseRegister.json();
      console.log(responseJson, payload);
      if (responseJson.responseCode === '2004700') {
        return responseJson;
      } else {
        return null;
      }
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  async generateBcaVaMpi(
    jwt: string,
    payload: any,
    pin: string,
  ): Promise<any | null> {
    try {
      const timestamp = getFormattedTime();
      const stringToSign = `POST:/api/h2h/prod/bcava:${jwt}:${hash(
        'sha256',
        minifyJson(payload),
      ).toLowerCase()}:${timestamp}`;
      const sig = encryptHmac('sha512', pin, stringToSign, 'base64');
      const header = {
        'Content-Type': CT_APP_JSON,
        Authorization: `Basic ${jwt}`,
        Timestamp: timestamp,
        Signature: sig,
      };

      // console.time('MPIFetch');
      const responseRegister = await fetch(process.env.MPI_BASE_URL + 'bcava', {
        method: 'POST',
        headers: header,
        body: JSON.stringify(payload),
        timeout: 180000,
      });
      // console.timeEnd('MPIFetch');
      // console.time('MPIJson');
      const responseJson = await responseRegister.json();
      // console.timeEnd('MPIJson');
      console.log(
        'response generate: ',
        process.env.MPI_BASE_URL + 'bcava',
        JSON.stringify(responseJson.values.message),
        payload,
        // header,
      );
      const searchParams = new URLSearchParams(
        responseJson.values.message.responseData.endpointUrl.split('?')[1],
      );
      const orderId = searchParams.get('orderId');
      console.time('FBFetch');
      const getVa = await fetch('https://payment-vuvtrvmj3q-et.a.run.app', {
        method: 'POST',
        body: JSON.stringify({
          url: `https://qris.ottopay.id/payment-services/v2.0.0/api/payment-detail/${orderId}`,
        }),
        headers: {
          'Content-Type': CT_APP_JSON,
        },
      });
      // console.timeEnd('FBFetch');

      // console.time('FBJson');
      const getVaJson = await getVa.json();
      // console.timeEnd('FBJson');
      // console.log(getVaJson);
      // const responseCheck = await this.checkStatusBcaVaMpi(
      //   jwt,
      //   payload.idtrx,
      //   pin,
      // );
      // console.log('response check: ', responseCheck);
      return {
        va: getVaJson.transactionDetails.vabca,
        refId: orderId,
        url: responseJson.values.message.responseData.endpointUrl,
      };
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  async checkStatusBcaVaMpi(
    jwt: string,
    idTrx: string,
    pin: string,
  ): Promise<any | null> {
    try {
      const timestamp = getFormattedTime();
      const stringToSign = `GET:/api/h2h/prod/bcava/check-status?idtrx=${idTrx}:${jwt}:${hash(
        'sha256',
        '',
      ).toLowerCase()}:${timestamp}`;
      const sig = encryptHmac('sha512', pin, stringToSign, 'base64');
      const header = {
        'Content-Type': CT_APP_JSON,
        Authorization: `Basic ${jwt}`,
        Timestamp: timestamp,
        Signature: sig,
      };

      const responseRegister = await fetch(
        process.env.MPI_BASE_URL + `bcava/check-status?idtrx=${idTrx}`,
        {
          method: 'GET',
          headers: header,
          timeout: 180000,
        },
      );
      const responseJson = await responseRegister.json();
      console.log('check status: ', responseJson, header);
      return responseJson;
      // if (responseJson.status === '200' && responseJson.values) {
      //   return responseJson.values;
      // } else {
      //   return null;
      // }
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  async generateBcaVaOy(
    username: string,
    apiKey: string,
    payload: any,
  ): Promise<any | null> {
    try {
      const header = {
        'Content-Type': CT_APP_JSON,
        'X-Oy-Username': username,
        'X-Api-Key': apiKey,
      };

      const responseVa = await fetch(
        process.env.OY_BASE_URL + 'generate-static-va',
        {
          method: 'POST',
          headers: header,
          body: JSON.stringify(payload),
        },
      );
      const responseJson = await responseVa.text();
      console.log(responseJson, payload, header);
      if (responseJson) {
        return responseJson;
      } else {
        return null;
      }
    } catch (err) {
      console.log(err);
      return null;
    }
  }
}
