import { Module } from '@nestjs/common';
import { ProviderService } from './provider.service';
import { SharpModule } from 'nestjs-sharp/dist/sharp.module';

@Module({
  imports: [SharpModule],
  providers: [ProviderService],
  exports: [ProviderService],
})
export class ProviderModule {}
