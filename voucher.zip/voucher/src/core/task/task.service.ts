import { Injectable, Logger } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Cron, CronExpression, Interval, Timeout } from '@nestjs/schedule';
import { Model, Types } from 'mongoose';
import {
  Callback,
  CallbackDocument,
} from 'src/api/v1/callback/entities/callback.entity';
import { Client, ClientDocument } from 'src/api/v1/open/entities/client.entity';
import {
  Commission,
  CommissionDocument,
} from 'src/api/v1/partner/entities/commission.entity';
import {
  BalanceLog,
  BalanceLogDocument,
} from 'src/api/v1/user/entities/balance-log.entity';
import {
  Balance,
  BalanceDocument,
} from 'src/api/v1/user/entities/balance.entity';

import {
  Transaction,
  TransactionDocument,
} from 'src/api/v1/user/entities/transaction.entity';
import { User, UserDocument } from 'src/api/v1/user/entities/user.entity';
import {
  AccessFrom,
  BalanceLogType,
  CallbackType,
  MethodType,
  Role,
  TransactionStatusType,
  TransactionType,
} from 'src/common/config/enum';
import { decrypt } from 'src/common/helper/decryptKeyIv';
import { encryptHmac } from 'src/common/helper/encryptKey';
import { hash } from 'src/common/helper/hash';
import { minifyJson } from 'src/common/helper/minifyJson';
import sendCallback from 'src/common/util/sendCallback';

@Injectable()
export class TaskService {
  constructor(
    @InjectModel(Transaction.name)
    private readonly Transaction: Model<TransactionDocument>,
    @InjectModel(Client.name)
    private readonly Client: Model<ClientDocument>,
    @InjectModel(Balance.name)
    private readonly Balance: Model<BalanceDocument>,
    @InjectModel(BalanceLog.name)
    private readonly BalanceLog: Model<BalanceLogDocument>,
    @InjectModel(Commission.name)
    private readonly Commission: Model<CommissionDocument>,
    @InjectModel(User.name)
    private readonly User: Model<UserDocument>,
    @InjectModel(Callback.name)
    private readonly Callback: Model<CallbackDocument>,
  ) {}

  @Cron(CronExpression.EVERY_DAY_AT_11AM, {
    timeZone: 'Asia/Jakarta',
  })
  async handleCronClientSettle() {
    const today = new Date();
    await this.Transaction.find({
      status: TransactionStatusType.Paid,
      pgSettled: true,
      clientSettled: false,
      clientSettleDate: { $lte: today },
    })
      .populate('method')
      .then(async (transactions: any) => {
        for (const transaction of transactions) {
          const balanceCredit =
            transaction.amount - transaction.fee - (transaction.debt ?? 0);
          const balance = await this.Balance.findOneAndUpdate(
            {
              user: transaction.user,
            },
            {
              $inc: {
                balance: Number(balanceCredit),
                pending: -Number(balanceCredit),
              },
            },
            { new: true },
          );

          if (
            transaction.transactionType === TransactionType.Transaction ||
            (transaction.transactionType === TransactionType.Topup &&
              transaction.accessFrom === AccessFrom.Api)
          ) {
            await this.Client.findOne({
              user: transaction.user.id,
            }).then(async (client) => {
              if (client) {
                const resObj: any = {
                  amount: transaction.amount,
                  fee: transaction.fee,
                  expired: new Date(transaction.exp).getTime(),
                  method: transaction.method.code,
                  methodName: transaction.method.name,
                  customerName: transaction.clientCustName,
                  ref1: transaction.clientRef,
                  ref2: transaction.transactionId,
                  status: TransactionStatusType.Settled,
                  desc: `Your ${
                    transaction.method.type === MethodType.Va
                      ? 'Virtual Account'
                      : transaction.method.type === MethodType.Retail
                      ? 'Retail'
                      : transaction.method.type === MethodType.Qris
                      ? 'QRIS'
                      : transaction.method.type === MethodType.Ewallet
                      ? 'Ewallet'
                      : ''
                  } ${
                    transaction.transactionType === TransactionType.Transaction
                      ? 'Transaction'
                      : 'Topup'
                  } is Settled to your balance`,
                  paidTime: new Date(transaction.paidTime).getTime(),
                  serialNumber: transaction.serialNumber.replace(
                    new RegExp('linkqu', 'ig'),
                    '',
                  ),
                  settleTime: today.getTime(),
                };

                if (transaction.method.type === MethodType.Ewallet) {
                  resObj.phone = transaction.phone;
                }

                const callbackKey = decrypt(
                  process.env.ENCRYPT_ALG,
                  hash('sha256', client.id).substring(0, 32),
                  hash(
                    'sha256',
                    transaction.user.id + client.clientId,
                  ).substring(0, 16),
                  client.callbackKey,
                );

                const sig = encryptHmac(
                  'sha512',
                  callbackKey,
                  minifyJson(resObj).toLowerCase(),
                  'hex',
                );

                const cbQuery: any = {
                  user: transaction.user.id,
                };

                if (
                  transaction.transactionType === TransactionType.Transaction
                ) {
                  cbQuery.transaction = transaction.id;
                } else {
                  cbQuery.topup = transaction.id;
                }
                await this.Callback.findOne(cbQuery).then(
                  async (transactionCb) => {
                    var res: string, sent: boolean;
                    await sendCallback(
                      transaction.transactionType ===
                        TransactionType.Transaction
                        ? client.callbackTrx
                        : client.callbackWd,
                      resObj,
                      sig,
                    )
                      .then((responseData) => {
                        res = responseData;
                        sent = true;
                      })
                      .catch((error) => {
                        res = error;
                        sent = false;
                      });

                    if (transactionCb) {
                      transactionCb.isSent = sent;
                      transactionCb.payload = JSON.stringify(resObj);
                      transactionCb.callbackUrl =
                        transaction.transactionType ===
                        TransactionType.Transaction
                          ? client.callbackTrx
                          : client.callbackWd;
                      if (sent) {
                        transactionCb.res = res;
                      } else {
                        transactionCb.error = res;
                      }
                      transactionCb.attempt = transactionCb.attempt + 1;
                      transactionCb.last = new Date();

                      await transactionCb.save();
                    } else {
                      const newCallback = new this.Callback({
                        isSent: sent,
                        payload: JSON.stringify(resObj),
                        callbackUrl:
                          transaction.transactionType ===
                          TransactionType.Transaction
                            ? client.callbackTrx
                            : client.callbackWd,
                        last: new Date(),
                        type:
                          transaction.transactionType ===
                          TransactionType.Transaction
                            ? CallbackType.Transaction
                            : CallbackType.Topup,
                        user: transaction.user.id,
                      });

                      if (
                        transaction.transactionType ===
                        TransactionType.Transaction
                      ) {
                        newCallback.transaction = transaction.id;
                      } else {
                        newCallback.topup = transaction.id;
                      }

                      if (sent) {
                        newCallback.res = res;
                      } else {
                        newCallback.error = res;
                      }

                      await newCallback.save();
                    }
                  },
                );
              }
            });
          }

          const newBalanceLog = new this.BalanceLog({
            name:
              transaction.clientRef + transaction.transactionType ===
              TransactionType.Topup
                ? "'s Topup"
                : '',
            balanceAmount: balance.balance,
            balanceCredit: Number(balanceCredit),
            type: BalanceLogType.In,
            balance: balance.id,
            transaction: transaction.id,
          });

          await newBalanceLog.save();

          await this.Transaction.findByIdAndUpdate(transaction.id, {
            status: TransactionStatusType.Settled,
            clientSettled: true,
          });
        }
      });
  }

  @Cron(CronExpression.EVERY_5_SECONDS)
  async handleCronCallback() {
    const today = new Date();
    today.setTime(today.getTime() - 30 * 60000);

    await this.Callback.find({
      isSent: false,
      attempt: { $lt: 5 },
      last: { $lte: today },
    }).then(async (callbacks) => {
      for (const callback of callbacks) {
        await this.Client.findOne({
          user: callback.user,
        }).then(async (client) => {
          if (client) {
            const callbackKey = decrypt(
              process.env.ENCRYPT_ALG,
              hash('sha256', client.id).substring(0, 32),
              hash('sha256', callback.user + client.clientId).substring(0, 16),
              client.callbackKey,
            );

            const sig = encryptHmac(
              'sha512',
              callbackKey,
              minifyJson(JSON.parse(callback.payload)).toLowerCase(),
              'hex',
            );

            var res: string, sent: boolean;
            await sendCallback(
              callback.callbackUrl,
              JSON.parse(callback.payload),
              sig,
            )
              .then((responseData) => {
                res = responseData;
                sent = true;
              })
              .catch((error) => {
                res = error;
                sent = false;
              });

            callback.isSent = sent;
            if (sent) {
              callback.res = res;
            } else {
              callback.error = res;
            }
            callback.attempt = callback.attempt + 1;
            callback.last = new Date();

            await callback.save();
          }
        });
      }
    });
  }

  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT, {
    timeZone: 'Asia/Jakarta',
  })
  async handleCronNewCommission() {
    // const todayStart = new Date();
    // todayStart.setDate(todayStart.getDate() - 1);
    // todayStart.setHours(0, 0, 0, 0);
    // const todayEnd = new Date();
    // todayEnd.setDate(todayEnd.getDate() - 1);
    // todayEnd.setHours(23, 59, 59, 999);

    const user = await this.User.findOne({ role: Role.Root }).exec();
    const balance = await this.Balance.findOne({ user: user.id }).exec();
    await this.Commission.aggregate([
      {
        $lookup: {
          from: 'users',
          localField: 'user',
          foreignField: '_id',
          as: 'user',
        },
      },
      {
        $unwind: {
          path: '$user',
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          user: { $exists: true },
          isActive: true,
          'user.role': { $in: [Role.Partner, Role.Root] },
          'user.isBlocked': false,
          'user.isDeleted': false,
        },
      },
    ]).then(async (commissions) => {
      for (const commission of commissions) {
        const newCommission = new this.Commission({
          user: new Types.ObjectId(commission.user._id),
          cutoff: commission.user.role === Role.Root ? 0 : undefined,
          clientTrx: commission.user.role === Role.Root ? undefined : 0,
          clientTrxQty: commission.user.role === Role.Root ? undefined : 0,
          partnerTrx: commission.user.role === Role.Root ? undefined : 0,
          partnerTrxQty: commission.user.role === Role.Root ? undefined : 0,
          clientWd: commission.user.role === Role.Root ? undefined : 0,
          clientWdQty: commission.user.role === Role.Root ? undefined : 0,
          partnerWd: commission.user.role === Role.Root ? undefined : 0,
          partnerWdQty: commission.user.role === Role.Root ? undefined : 0,
        });
        await newCommission.save();

        const update: any = {
          isActive: false,
        };

        if (commission.user.role === Role.Root) {
          var nominal = balance.balance;
          await this.Commission.aggregate([
            {
              $match: {
                user: new Types.ObjectId(user.id),
                isActive: false,
                isDisbursed: false,
              },
            },
            {
              $group: {
                _id: null,
                totalCutoff: { $sum: '$cutoff' },
              },
            },
          ]).then((rootCommission) => {
            if (rootCommission.length) {
              nominal -= rootCommission[0].totalCutoff;
            }
          });
          update.cutoff = nominal;
        }

        await this.Commission.findByIdAndUpdate(commission._id, update);
      }
    });

    // await this.Commission.updateMany(
    //   {
    //     $and: [
    //       { user: { $exists: true } },
    //       {
    //         createdAt: {
    //           $gte: todayStart,
    //           $lt: todayEnd,
    //         },
    //       },
    //     ],
    //   },
    //   { isActive: false },
    // );
  }

  @Cron(CronExpression.EVERY_5_SECONDS)
  async handleIntervalExpire() {
    const today = new Date();
    await this.Transaction.find({
      status: TransactionStatusType.Pending,
      exp: { $lte: today },
    })
      .populate('user')
      .populate('product')
      .then(async (transactions: any) => {
        for (const transaction of transactions) {
          await this.Transaction.findByIdAndUpdate(transaction.id, {
            status: TransactionStatusType.Expired,
          });
          if (transaction.user.role === Role.Client) {
            await this.Client.findOne({
              user: transaction.user.id,
            }).then((client) => {
              //TODO SEND CALLBACK EXPIRED TO CLIENT
            });
          } else if (
            transaction.user.role === Role.User &&
            transaction.usedBalance > 0
          ) {
            const balance = await this.Balance.findOneAndUpdate(
              {
                user: transaction.user.id,
              },
              {
                $inc: {
                  balance: Number(transaction.usedBalance),
                },
              },
              { new: true },
            );

            const newBalanceLog3 = new this.BalanceLog({
              name: 'Refund ' + transaction.product.name,
              balanceAmount: balance.balance - transaction.usedBalance,
              balanceCredit: Number(transaction.usedBalance),
              type: BalanceLogType.Refund,
              balance: balance.id,
              transaction: transaction.id,
            });

            await newBalanceLog3.save();
          }
        }
      });
  }

  //   @Timeout(5000)
  //   handleTimeout() {
  //     this.logger.debug('Called once after 5 seconds');
  //   }
}
