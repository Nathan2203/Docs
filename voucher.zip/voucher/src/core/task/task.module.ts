import { Module } from '@nestjs/common';

import { TaskService } from './task.service';
import { MongooseModule } from '@nestjs/mongoose';
import {
  Transaction,
  TransactionSchema,
} from 'src/api/v1/user/entities/transaction.entity';
import { Client, ClientSchema } from 'src/api/v1/open/entities/client.entity';
import {
  Balance,
  BalanceSchema,
} from 'src/api/v1/user/entities/balance.entity';
import {
  BalanceLog,
  BalanceLogSchema,
} from 'src/api/v1/user/entities/balance-log.entity';
import {
  Commission,
  CommissionSchema,
} from 'src/api/v1/partner/entities/commission.entity';
import { User, UserSchema } from 'src/api/v1/user/entities/user.entity';
import {
  Callback,
  CallbackSchema,
} from 'src/api/v1/callback/entities/callback.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Transaction.name, schema: TransactionSchema },
      { name: Client.name, schema: ClientSchema },
      { name: Balance.name, schema: BalanceSchema },
      { name: BalanceLog.name, schema: BalanceLogSchema },
      { name: Commission.name, schema: CommissionSchema },
      { name: User.name, schema: UserSchema },
      { name: Callback.name, schema: CallbackSchema },
    ]),
  ],
  providers: [TaskService],
})
export class TaskModule {}
