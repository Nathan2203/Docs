export const HOSTNAME = 'niagapay.click';
export const API_HOSTNAME = 'api.niagapay.click';
export const APIDEV_HOSTNAME = 'apidev.niagapay.click';
export const CT_APP_JSON = 'application/json';
export const IS_PUBLIC = 'isPublic';
export const ROLES = 'roles';
export const ACCESS = 'openAccess';

export const JWT_ALG = 'EdDSA';
export const JWT_EXPIRED_ERR_CODE = 'ERR_JWT_EXPIRED';
export const JWT_SIGNATURE_INVALID_ERR_CODE =
  'ERR_JWS_SIGNATURE_VERIFICATION_FAILED';

export const EMAIL_NOT_PROVIDED = 'not@provided.com';

export const CLIENT_CALLBACK_SIGNATURE = 'X-CALLBACK-SIGNATURE';

export const WA_URL =
  'https://nest.messagebird.com/workspaces/96b798a8-c3d6-45b4-ab25-8ef6e5209d70/channels/94b38d80-4b3f-40dd-9471-467798ea8091/messages';
