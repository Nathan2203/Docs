export enum Role {
  User = 'user',
  Admin = 'admin',
  Super = 'super',
  Client = 'client',
  Root = 'root',
  Partner = 'partner',
}

export enum ValueType {
  Percentage = 'percentage',
  Fixed = 'fixed',
  Both = 'both',
}

export enum FeeType {
  Bank = 'bank',
  Va = 'va',
  CC = 'cc',
  Ewallet = 'ewallet',
  Cash = 'cash',
  Transaction = 'transaction',
}

export enum BalanceLogType {
  In = 'in',
  Out = 'out',
  Refund = 'refund',
  Issue = 'issue',
  Pay = 'payDebt',
}

export enum ActionClientType {
  SetUpline = 'setUpline',
  SetLimit = 'setLimit',
  SetPaymentName = 'setPaymentName',
  FreezeBalance = 'freezeBalance',
  ReturnBalance = 'returnBalance',
  Reset2Fa = 'reset2Fa',
  Block = 'block',
  Unblock = 'unBlock',
  Delete = 'delete',
}

export enum MethodType {
  Va = 'va',
  Retail = 'retail',
  Qris = 'qris',
  Ewallet = 'paymentewallet',
}

export enum MethodApiType {
  Va = 'va',
  Retail = 'retail',
  Qris = 'qris',
  Ewallet = 'ewallet',
}

export enum MethodApi2Type {
  Payment = 'payment',
  Transfer = 'transfer',
  Topup = 'topup',
}

export enum BankType {
  Bank = 'bank',
  Va = 'va',
  CC = 'cc',
  Ewallet = 'ewallet',
  Cash = 'cash',
}

export enum BankActionType {
  VA = 'va',
  CC = 'cc',
}

export enum TransactionType {
  Transaction = 'transaction',
  Topup = 'topup',
}

export enum TransactionStatusType {
  Settled = 'settled',
  Paid = 'paid',
  Processing = 'processing',
  Pending = 'pending',
  Failed = 'failed',
  Expired = 'expired',
  Assist = 'assist',
}

export enum WithdrawProcess {
  Inquiry = 'inquiry',
  Process = 'process',
}

export enum WithdrawStatus {
  Pending = 'pending',
  Processing = 'processing',
  Failed = 'failed',
  Success = 'success',
  Rejected = 'rejected',
}

export enum WithdrawType {
  Client = 'client',
  Partner = 'partner',
  Deposit = 'deposit',
  Cair = 'cair',
}

export enum AccessFrom {
  Dashboard = 'dashboard',
  Api = 'api',
}

export enum LogType {
  Login = 'login',
  Logout = 'logout',
  AdminDisburse = 'admin disburse',
  ClientDisburse = 'client disburse',
  ClientTopup = 'client topup',
  AdminUpdate = 'admin update',
  ClientUpdate = 'client update',
}

export enum CallbackType {
  Transaction = 'transaction',
  Topup = 'topup',
  Withdraw = 'withdraw',
}

export enum PgType {
  Success = 'SUCCESS',
  SuccessCode = '00',
  Failed = 'FAILED',
  Pending = 'PENDING',
  Pay = 'pay',
  Settle = 'settle',
}

export enum ProviderCodeType {
  Linkqu = 'linkqu',
  Bnc = 'bnc',
  Mpi = 'mpi',
  Oy = 'oy',
}

export enum ProviderImgType {
  Ktp = 'ktp',
  Npwp = 'npwp',
  License = 'license',
  Nib = 'nib',
  CertInc = 'certInc',
  Cert40 = 'cert40',
  CertLA = 'certLA',
  CertDA = 'certDA',
  CertAA = 'certAA',
  CertEst = 'certEst',
  Sppkp = 'sppkp',
  Env = 'env',
}

export enum ClientResponse {
  ServerError = 500,
  Success = 200,
  InvalidSignature = 201,
  InvalidData = 202,
  MethodNotAllowed = 203,
  MethodNotFound = 204,
}
