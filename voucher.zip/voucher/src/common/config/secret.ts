import * as fs from 'fs';
import { join } from 'path';

export const privKey = fs.readFileSync(
  join(__dirname, '../../../secrets/voucher.pem'),
  'utf8',
);

export const pubKey = fs.readFileSync(
  join(__dirname, '../../../secrets/voucher.pub.pem'),
  'utf8',
);

export const sslKey = fs.readFileSync(
  join(__dirname, '../../../secrets/ssl/private.key'),
  'utf8',
);

export const sslCrt = fs.readFileSync(
  join(__dirname, '../../../secrets/ssl/niagapay_click.crt'),
  'utf8',
);

export const sslCa = fs.readFileSync(
  join(__dirname, '../../../secrets/ssl/niagapay_click.ca-bundle'),
  'utf8',
);

export const primePrivKey = fs.readFileSync(
  join(__dirname, '../../../secrets/prime.pem'),
  'utf8',
);

export const bncPrivKey = fs.readFileSync(
  join(__dirname, '../../../secrets/bnc.pem'),
  'utf8',
);

export const bncPubKey = fs.readFileSync(
  join(__dirname, '../../../secrets/bnc.pub.pem'),
  'utf8',
);
