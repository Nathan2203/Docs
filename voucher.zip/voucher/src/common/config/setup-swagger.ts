import { NestFastifyApplication } from '@nestjs/platform-fastify';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { FastifyInstance } from 'fastify';
import { createReadStream } from 'fs';
import * as jose from 'jose';
import { join } from 'path';

const alg = 'HS256';
const DOC_ENDPOINT = 'docs/api-v1.0';
const DOC_LOGIN_ENDPOINT = `/${DOC_ENDPOINT}/login`;
const DOC_LOGIN_HTML_PATH = join(
  __dirname,
  '../../../src/common/view/doc-login.html',
);

const COOKIE_NAME = 'ms::api-front-doc';

export default function setUpSwagger(
  app: NestFastifyApplication,
  server: FastifyInstance,
  appView: NestFastifyApplication,
) {
  server.after(() => {
    server.addHook('onRoute', (opts) => {
      const url = opts.url;
      if (url !== DOC_LOGIN_ENDPOINT && url.indexOf(`/${DOC_ENDPOINT}`) === 0) {
        opts.onRequest = (request, reply, next) => {
          const keys = [process.env.SWAGGER_KEY as string];
          const cookie = request.cookies[COOKIE_NAME];
          if (cookie) {
            try {
              jose.jwtVerify(cookie, new TextEncoder().encode(keys[0]));
              next();
              return;
            } catch {
              reply.redirect(DOC_LOGIN_ENDPOINT);
            }
          } else {
            reply.redirect(DOC_LOGIN_ENDPOINT);
          }
        };
      }
    });

    // login routes

    server.route({
      method: 'GET',
      url: DOC_LOGIN_ENDPOINT,
      handler: (request, reply) => {
        const cookie = request.cookies[COOKIE_NAME];
        if (cookie) {
          reply.redirect(`/${DOC_ENDPOINT}`);
        } else {
          reply
            .header('Content-Type', 'text/html; charset=UTF-8')
            .send(createReadStream(DOC_LOGIN_HTML_PATH, 'utf8'));
        }
      },
    });

    server.route({
      method: 'POST',
      url: DOC_LOGIN_ENDPOINT,
      handler: async (request, reply) => {
        const keys = process.env.SWAGGER_KEY;
        const pw = process.env.SWAGGER_PASS;
        const password = request.body['swagger_password'];
        if (password !== pw) {
          reply.redirect(DOC_LOGIN_ENDPOINT);
          return;
        }

        const token = await new jose.SignJWT({ id: new Date().getTime() })
          .setProtectedHeader({ alg })
          .sign(new TextEncoder().encode(keys));

        reply.setCookie(COOKIE_NAME, token).redirect(`/${DOC_ENDPOINT}`);
      },
    });
  });

  const config = new DocumentBuilder()
    .setTitle('Voucher API Documentation')
    .setDescription('This is some description for you')
    .addBasicAuth()
    .addBearerAuth()
    .addSecurity('session', {
      type: 'apiKey',
      in: 'header',
      name: 'session',
      description: 'Your session ID',
    })
    .addSecurity('browserId', {
      type: 'apiKey',
      in: 'header',
      name: 'x-browser-id',
      description: 'Your browser ID',
    })
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup(DOC_ENDPOINT, appView, document, {
    swaggerOptions: {
      docExpansion: 'none',
      persistAuthorization: true,
    },
  });
}
