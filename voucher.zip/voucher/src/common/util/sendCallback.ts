import fetch from 'node-fetch';

import {
  CLIENT_CALLBACK_SIGNATURE,
  CT_APP_JSON,
} from 'src/common/config/constants';

export default async function sendCallback(
  url: string,
  payload: any,
  signature: string,
): Promise<any> {
  try {
    const response = await fetch(url, {
      method: 'POST',
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': CT_APP_JSON,
        [CLIENT_CALLBACK_SIGNATURE]: signature,
      },
    });
    const responseData = await response.json();
    if (responseData && responseData.message) {
      if (responseData.message.toLowerCase() === 'ok') {
        return Promise.resolve(JSON.stringify(responseData));
      } else {
        return Promise.reject(
          `Invalid response ${JSON.stringify(responseData)}`,
        );
      }
    } else {
      return Promise.reject(`Error sending callback to ${url}`);
    }
  } catch (error) {
    return Promise.reject(`Error sending callback to ${url}: ${error}`);
  }
}
