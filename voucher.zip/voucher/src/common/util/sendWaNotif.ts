import fetch from 'node-fetch';

import { CT_APP_JSON, WA_URL } from 'src/common/config/constants';

export default async function sendWaNotif(
  withdrawId: string,
  username: string,
  amount: string,
): Promise<any> {
  try {
    const list = [
      '+6285782401874',
      '+6287883859045',
      '+6289523484658',
      '+62895353026000',
    ];
    for (const number of list) {
      const response = await fetch(WA_URL, {
        method: 'POST',
        body: JSON.stringify({
          receiver: {
            contacts: [
              {
                identifierValue: number,
              },
            ],
          },
          template: {
            projectId: '7ac93ac6-aa2a-4c63-b2ff-4d226e49aa77',
            version: 'latest',
            locale: 'en',
            variables: {
              withdrawId,
              username,
              amount,
            },
          },
        }),
        headers: {
          'Content-Type': CT_APP_JSON,
          Authorization: process.env.MB_JWT,
        },
      });
      const responseData = await response.json();
      if (!responseData || responseData.status !== 'accepted') {
        console.log(
          `Error sending whatsapp notification to ${number} for ${withdrawId}`,
        );
      }
    }
    return Promise.resolve('OK');
  } catch (error) {
    return Promise.reject(`Error sending whatsapp notification`);
  }
}
