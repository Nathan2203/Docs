import { FastifyRequest } from 'fastify';
import { UserDocument } from 'src/api/v1/user/entities/user.entity';
import { ClientDocument } from 'src/api/v1/open/entities/client.entity';
import { DevClientDocument } from 'src/api/v1/open/entities/dev-client.entity';

export interface FastifyOpenRequest extends FastifyRequest {
  user: {
    user: UserDocument;
    client: ClientDocument | DevClientDocument;
  };
}
