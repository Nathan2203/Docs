import { FastifyRequest } from 'fastify';
import { BrowserDocument } from 'src/api/v1/user/entities/browser.entity';
import { UserDocument } from 'src/api/v1/user/entities/user.entity';

export interface FastifyUserRequest extends FastifyRequest {
  user: {
    user: UserDocument;
    browser: BrowserDocument;
  };
}
