import { FastifyRequest } from 'fastify';
import { BrowserDocument } from 'src/api/v1/user/entities/browser.entity';

export interface FastifyBrowserRequest extends FastifyRequest {
  user: BrowserDocument;
}
