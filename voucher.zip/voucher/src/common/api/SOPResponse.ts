import { SOPErrorMessage } from "./SOPErrorMessage";

export class SOPResponse {
    status!: number;
    success!: boolean;
    data!: any;
    error!: SOPErrorMessage;
  
    initSuccess(status: number, success: boolean, data: any): any {
          this.status = status;
          this.success = success;
          this.data = data;
          return {
              status,
              success,
              data
          };
      }
  
      initError(status: number, success: boolean, error: SOPErrorMessage): any {
          this.status = status;
          this.success = success;
          this.error = error;
          return {
              status,
              success,
              error
          };
      }
  }