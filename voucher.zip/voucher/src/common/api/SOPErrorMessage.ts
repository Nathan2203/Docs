export class SOPErrorMessage {
  errorMessage: string;
  errors?: string[];
  constructor(error: string, errors?: string[]) {
    this.errorMessage = error;
    this.errors = errors;
  }
}
