import { Injectable, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuthGuard } from '@nestjs/passport';
import { ACCESS } from '../../config/constants';

@Injectable()
export class UserGuard extends AuthGuard('user-strategy') {
  constructor(private readonly reflector: Reflector) {
    super();
  }

  async canActivate(context: ExecutionContext) {
    const access = this.reflector.getAllAndOverride<{
      isPublic: boolean;
      roles: string[];
    }>(ACCESS, [context.getHandler(), context.getClass()]);
    const { roles } = access || { isPublic: false, roles: [] };
    if (await super.canActivate(context)) {
      const { user } = context.switchToHttp().getRequest();
      return roles.some((role) => user.user.role?.includes(role));
    } else {
      return false;
    }
  }
}
