import {
  ForbiddenException,
  Injectable,
  InternalServerErrorException,
  UnauthorizedException,
} from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-custom';
import { jwtVerify, importSPKI, JWTPayload } from 'jose';
import { FastifyRequest } from 'fastify';
import {
  API_HOSTNAME,
  JWT_ALG,
  JWT_EXPIRED_ERR_CODE,
  JWT_SIGNATURE_INVALID_ERR_CODE,
} from '../../config/constants';
import { InjectModel } from '@nestjs/mongoose';
import { User, UserDocument } from 'src/api/v1/user/entities/user.entity';
import { Model } from 'mongoose';
import { searchArray } from 'src/common/helper/searchArray';
import { pubKey } from 'src/common/config/secret';

import {
  Session,
  SessionDocument,
} from 'src/api/v1/user/entities/session.entity';
import {
  Browser,
  BrowserDocument,
} from 'src/api/v1/user/entities/browser.entity';

@Injectable()
export class UserStrategy extends PassportStrategy(Strategy, 'user-strategy') {
  constructor(
    @InjectModel(User.name) private User: Model<UserDocument>,
    @InjectModel(Session.name) private Session: Model<SessionDocument>,
    @InjectModel(Browser.name) private Browser: Model<BrowserDocument>,
  ) {
    super();
  }

  async validate(req: FastifyRequest): Promise<any> {
    try {
      if (
        req.headers['hostname'] !== API_HOSTNAME &&
        process.env.APP_ENV !== 'dev'
      ) {
        throw new InternalServerErrorException('Wrong Domain');
      }
    } catch (err) {
      throw new InternalServerErrorException('Wrong Domain');
    }

    const alg = JWT_ALG;
    var key = await importSPKI(pubKey, alg);

    let payloadData: JWTPayload;
    try {
      const jwt = req.headers.authorization.replace('Bearer ', '');
      const { payload } = await jwtVerify(jwt, key, {
        algorithms: [alg],
      });
      payloadData = payload;
    } catch (err) {
      if (err.code === JWT_EXPIRED_ERR_CODE) {
        throw new UnauthorizedException('Unauthorized Access - Token expired');
      } else if (err.code === JWT_SIGNATURE_INVALID_ERR_CODE) {
        throw new UnauthorizedException(
          'Unauthorized Access - Signature invalid',
        );
      } else {
        throw new UnauthorizedException('Unauthorized Access - JWT invalid');
      }
    }

    let user: UserDocument;
    try {
      user = await this.User.findById(payloadData.id).exec();
    } catch (_err) {
      throw new UnauthorizedException(
        'Unauthorized Access - Invalid token data',
      );
    }

    if (user) {
      if (user.isBlocked) {
        throw new ForbiddenException('Sorry, Your account is blocked');
      } else if (user.isDeleted) {
        throw new ForbiddenException('Sorry, Your account is deleted');
      } else {
        let sessionData: Session;
        try {
          const session = req.headers.session;
          sessionData = await this.Session.findOne({
            sessionToken: session,
          })
            .lean()
            .exec();
        } catch (_err) {
          throw new UnauthorizedException(
            'Unauthorized Access - Invalid session data',
          );
        }

        if (sessionData) {
          if (sessionData.sessionExpires.getTime() < Date.now()) {
            throw new UnauthorizedException(
              'Unauthorized Access - Session expired!',
            );
          } else {
            let browserData: Browser[];
            try {
              const browserId = req.headers['x-browser-id'];
              browserData = await this.Browser.find({
                browserId: browserId,
              }).exec();
            } catch (_err) {
              throw new UnauthorizedException(
                'Unauthorized Access - Invalid session data',
              );
            }

            if (browserData && browserData.length) {
              const found = searchArray(
                browserData,
                null,
                null,
                'user',
                user.id,
              );
              if (found.length > 0) {
                const browserFound = found[0];
                return {
                  user,
                  browser: browserFound,
                };
              } else {
                throw new UnauthorizedException(
                  'Unauthorized Access - Browser ID not match!',
                );
              }
            } else {
              throw new UnauthorizedException(
                'Unauthorized Access - Invalid Browser ID',
              );
            }
          }
        } else {
          throw new UnauthorizedException(
            'Unauthorized Access - Invalid Session',
          );
        }
      }
    } else {
      throw new UnauthorizedException(
        'Unauthorized Access - No user found with that token',
      );
    }
  }
}
