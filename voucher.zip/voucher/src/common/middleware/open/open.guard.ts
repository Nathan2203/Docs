import { Injectable, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuthGuard } from '@nestjs/passport';

import { ACCESS } from '../../config/constants';

@Injectable()
export class OpenGuard extends AuthGuard('open-strategy') {
  constructor(private readonly reflector: Reflector) {
    super();
  }

  async canActivate(context: ExecutionContext) {
    const access = this.reflector.getAllAndOverride<{
      isPublic: boolean;
      roles: string[];
    }>(ACCESS, [context.getHandler(), context.getClass()]);
    const { isPublic, roles } = access || { isPublic: false, roles: [] };

    if (isPublic) {
      return true;
    } else {
      if (await super.canActivate(context)) {
        const { user } = context.switchToHttp().getRequest();
        return roles.some((role) => user.user.role?.includes(role));
      } else {
        return false;
      }
    }
  }
}
