import {
  ForbiddenException,
  Injectable,
  InternalServerErrorException,
  UnauthorizedException,
} from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-custom';
import { FastifyRequest } from 'fastify';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import * as crypto from 'crypto';

import { decrypt } from '../../helper/decryptKeyIv';

import { User, UserDocument } from 'src/api/v1/user/entities/user.entity';
import { Client, ClientDocument } from 'src/api/v1/open/entities/client.entity';
import {
  DevClient,
  DevClientDocument,
} from 'src/api/v1/open/entities/dev-client.entity';
import { APIDEV_HOSTNAME, API_HOSTNAME } from 'src/common/config/constants';

@Injectable()
export class OpenStrategy extends PassportStrategy(Strategy, 'open-strategy') {
  constructor(
    @InjectModel(User.name) private User: Model<UserDocument>,
    @InjectModel(Client.name) private Client: Model<ClientDocument>,
    @InjectModel(DevClient.name) private DevClient: Model<DevClientDocument>,
  ) {
    super();
  }

  //e3V2ByEfKacPcr8uGJLPGiEqL13SNcfaX3vrXzUxAWY=

  //Z8vGyXLckidzmg+hOr6lkwF9vKm9vPK81fMZNpZOckA=

  async validate(req: FastifyRequest): Promise<any> {
    if (process.env.APP_ENV === 'prod') {
      try {
        if (
          req.headers['hostname'] !== API_HOSTNAME &&
          req.headers['hostname'] !== APIDEV_HOSTNAME
        ) {
          throw new InternalServerErrorException('Wrong Domain');
        }
      } catch (err) {
        throw new InternalServerErrorException('Wrong Domain');
      }
    }

    let authorizationHeader: string;
    try {
      authorizationHeader = req.headers.authorization;
      if (!authorizationHeader || !authorizationHeader.startsWith('Basic ')) {
        throw new UnauthorizedException(
          'Unauthorized Access - Authorization invalid',
        );
      }
    } catch (err) {
      throw new UnauthorizedException(
        'Unauthorized Access - Authorization invalid',
      );
    }

    if (req.url.toLowerCase().includes('/signature')) {
      const xMethod = req.headers['x-method'];
      const xUrl = req.headers['x-url'];

      if (!xMethod) {
        throw new UnauthorizedException(
          'Unauthorized Access - X-METHOD is empty',
        );
      }

      if (!xUrl) {
        throw new UnauthorizedException('Unauthorized Access - X-URL is empty');
      }
    } else if (
      !req.url.toLowerCase().includes('/utility/') &&
      !req.url.toLowerCase().includes('/status/')
    ) {
      const xSig = req.headers['x-signature'];

      if (!xSig) {
        throw new UnauthorizedException(
          'Unauthorized Access - X-SIGNATURE is empty',
        );
      }
    }

    const encodedCredentials = authorizationHeader.slice(6);
    const decodedCredentials = Buffer.from(
      encodedCredentials,
      'base64',
    ).toString('utf-8');
    const [clientId, clientSecret] = decodedCredentials.split(':');

    let client: ClientDocument | DevClientDocument;
    try {
      if (req.headers['hostname'] === API_HOSTNAME) {
        client = await this.Client.findOne({
          clientId: clientId,
        }).exec();
      } else {
        client = await this.DevClient.findOne({
          clientId: clientId,
        }).exec();
      }
    } catch (_err) {
      throw new UnauthorizedException('Unauthorized Access - ClientId invalid');
    }

    if (client) {
      if (client.ip && client.ip.length) {
        const ipList: string[] = client.ip.split(',');
        if (ipList.includes(req.ip)) {
          if (
            client.callbackTrx &&
            client.callbackWd &&
            client.callbackTopup &&
            client.callbackKey
          ) {
            const alg = process.env.ENCRYPT_ALG;

            const secret = decrypt(
              alg,
              crypto
                .createHash('sha256')
                .update(client.id)
                .digest('hex')
                .substring(0, 32),
              crypto
                .createHash('sha256')
                .update(client.user + clientId)
                .digest('hex')
                .substring(0, 16),
              client.clientSecret,
            );

            if (secret !== clientSecret) {
              throw new UnauthorizedException(
                'Unauthorized Access - Client Secret not match',
              );
            } else {
              let user: UserDocument;
              try {
                user = await this.User.findById(client.user).exec();
              } catch (_err) {
                throw new UnauthorizedException(
                  'Unauthorized Access - User invalid',
                );
              }

              if (user) {
                if (user.isBlocked) {
                  throw new ForbiddenException(
                    'Sorry, Your account is blocked',
                  );
                } else if (user.isDeleted) {
                  throw new ForbiddenException(
                    'Sorry, Your account is deleted',
                  );
                } else {
                  const key = decrypt(
                    alg,
                    crypto
                      .createHash('sha256')
                      .update(client.clientSecret)
                      .digest('hex')
                      .substring(0, 32),
                    crypto
                      .createHash('sha256')
                      .update(client.id + clientId + client.user)
                      .digest('hex')
                      .substring(0, 16),
                    client.signatureKey,
                  );
                  client.clientSecret = secret;
                  client.signatureKey = key;

                  return {
                    user,
                    client,
                  };
                }
              } else {
                throw new UnauthorizedException(
                  'Unauthorized Access - No user found with that clientId',
                );
              }
            }
          } else {
            throw new ForbiddenException(
              'Please set all of the callback URL and generate the callback key first!',
            );
          }
        } else {
          throw new ForbiddenException(
            `Your IP Address: ${req.ip} is not whitelisted!`,
          );
        }
      } else {
        throw new ForbiddenException('Please set the whitelist IP first!');
      }
    } else {
      throw new UnauthorizedException(
        'Unauthorized Access - ClientId not found',
      );
    }
  }
}
