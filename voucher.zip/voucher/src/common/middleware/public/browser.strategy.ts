import {
  Injectable,
  InternalServerErrorException,
  UnauthorizedException,
} from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-custom';
import { FastifyRequest } from 'fastify';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

import {
  Browser,
  BrowserDocument,
} from 'src/api/v1/user/entities/browser.entity';
import { API_HOSTNAME } from 'src/common/config/constants';

@Injectable()
export class BrowserStrategy extends PassportStrategy(
  Strategy,
  'browser-strategy',
) {
  constructor(
    @InjectModel(Browser.name) private Browser: Model<BrowserDocument>,
  ) {
    super();
  }

  async validate(req: FastifyRequest): Promise<any> {
    if (process.env.APP_ENV === 'prod') {
      try {
        if (req.headers['hostname'] !== API_HOSTNAME) {
          throw new InternalServerErrorException('Wrong Domain');
        }
      } catch (err) {
        throw new InternalServerErrorException('Wrong Domain');
      }
    }

    let browser: BrowserDocument;
    try {
      const browserId = req.headers['x-browser-id'];
      browser = await this.Browser.findOne({ browserId: browserId }).exec();
    } catch (_err) {
      throw new UnauthorizedException(
        'Unauthorized Access - Invalid browser id',
      );
    }

    if (browser) {
      return browser;
    } else {
      throw new UnauthorizedException(
        'Unauthorized Access - No data found with that id',
      );
    }
  }
}
