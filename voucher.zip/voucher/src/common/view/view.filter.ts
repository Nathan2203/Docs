import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
} from '@nestjs/common';
import { FastifyReply } from 'fastify';
import { ViewService } from './view.service';

@Catch(HttpException)
export class ViewFilter implements ExceptionFilter {
  constructor(readonly viewService: ViewService) {}

  catch(_exception: HttpException, host: ArgumentsHost) {
    const req = host.switchToHttp().getRequest();
    const res = host.switchToHttp().getResponse<FastifyReply>();

    this.viewService.getHandler(req, res);
  }
}
