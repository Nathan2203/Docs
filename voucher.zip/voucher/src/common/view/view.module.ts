import { Module } from '@nestjs/common';
import { ViewController } from './view.controller';
import { ViewService } from './view.service';
import { ViewFilter } from './view.filter';
import { APP_FILTER } from '@nestjs/core';

@Module({
  controllers: [ViewController],
  providers: [
    ViewService,
    {
      useClass: ViewFilter,
      provide: APP_FILTER,
    },
  ],
})
export class ViewModule {}
