import * as crypto from 'crypto';

export const encrypt = (
  algo: string,
  key: string,
  iv: string,
  plaintext: string,
): string => {
  const cipher = crypto.createCipheriv(algo, key, iv);
  // Hint: Larger inputs (it's GCM, after all!) should use the stream API
  let res = cipher.update(plaintext, 'utf8', 'base64');
  res += cipher.final('base64');
  return res;
};
