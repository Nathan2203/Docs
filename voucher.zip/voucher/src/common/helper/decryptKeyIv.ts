import * as crypto from 'crypto';

export const decrypt = (
  algo: string,
  key: string,
  iv: string,
  enc: string,
): string => {
  const decipher = crypto.createDecipheriv(algo, key, iv);

  let str = decipher.update(enc, 'base64', 'utf8');
  str += decipher.final('utf8');
  return str;
};
