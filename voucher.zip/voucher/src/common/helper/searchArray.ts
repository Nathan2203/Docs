export function searchArray(
  data: any[],
  field: string = null,
  val: string = null,
  field2: string = null,
  val2: string = null,
): any[] {
  const filteredArray: any[] = data.filter((element: any) =>
    field != null && val != null && field2 != null && val2 != null
      ? element[field].includes(val) && element[field2].equals(val2)
      : field2 != null && val2 != null
      ? element[field2] == val2
      : element[field].includes(val),
  );

  return filteredArray;
}
