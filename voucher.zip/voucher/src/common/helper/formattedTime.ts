export function getFormattedTime(): string {
  const now = new Date();
  const isoString = now.toISOString();
  const timezoneOffset = getTimezoneOffset(now);

  const dateString = isoString.substring(0, 19);
  const formattedDate = `${dateString}${timezoneOffset}`;

  return formattedDate;
}

function getTimezoneOffset(now: Date): string {
  const timezoneOffsetMinutes = now.getTimezoneOffset();
  const timezoneOffsetSign = timezoneOffsetMinutes <= 0 ? '+' : '-';
  const timezoneOffsetHours = Math.floor(Math.abs(timezoneOffsetMinutes) / 60);
  const timezoneOffsetMinutesRemainder = Math.abs(timezoneOffsetMinutes) % 60;
  return `${timezoneOffsetSign}${timezoneOffsetHours
    .toString()
    .padStart(2, '0')}:${timezoneOffsetMinutesRemainder
    .toString()
    .padStart(2, '0')}`;
}
