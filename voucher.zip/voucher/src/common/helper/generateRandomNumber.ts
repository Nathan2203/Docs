import * as crypto from 'crypto';

export function generateRandomNumber(length: number): string {
  const max = Math.pow(10, length) - 1;
  let randomNumber = '';
  let numIterations = Math.floor(length / 17);

  // Generate random numbers for each 17-digit segment
  for (let i = 0; i < numIterations; i++) {
    const randomBytes = crypto.randomBytes(Math.ceil(Math.log2(max) / 8));
    const segment =
      parseInt(randomBytes.toString('hex'), 16) % Math.pow(10, 17);
    randomNumber += segment.toString();
  }

  // Generate a random number for the remaining digits
  const remainingDigits = length % 17;
  if (remainingDigits > 0) {
    const randomBytes = crypto.randomBytes(Math.ceil(Math.log2(max) / 8));
    const segment =
      parseInt(randomBytes.toString('hex'), 16) % Math.pow(10, remainingDigits);
    randomNumber += segment.toString();
  }

  return randomNumber;
}
