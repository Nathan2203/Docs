import * as crypto from 'crypto';

export const encryptRsa = (priv: string, data: string): string => {
  const privKey = crypto.createPrivateKey(priv);
  return crypto
    .sign('RSA-SHA256', Buffer.from(data), privKey)
    .toString('base64');
};

export const verifyRsa = (pub: string, data: string, sig: string): boolean => {
  const pubKey = crypto.createPublicKey(pub);
  return crypto.verify(
    'RSA-SHA256',
    Buffer.from(data),
    pubKey,
    Buffer.from(sig, 'base64'),
  );
};
