import * as bcrypt from 'bcrypt';

export const encryptPass = async (pass: string): Promise<string> => {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(pass, salt);
};
