import * as crypto from 'crypto';

export const hash = (alg: string, data: string): string => {
  return crypto.createHash(alg).update(data).digest('hex');
};
