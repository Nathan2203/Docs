import * as crypto from 'crypto';

export const encryptHmac = (
  alg: string,
  secret: string,
  data: string,
  dig: crypto.BinaryToTextEncoding,
): string => {
  return crypto.createHmac(alg, secret).update(data).digest(dig);
};
