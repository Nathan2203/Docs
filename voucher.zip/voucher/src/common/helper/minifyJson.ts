export function minifyJson(json: any): string {
  return JSON.stringify(json, (_key, value) => {
    if (typeof value === 'string') {
      return value.trim();
    }
    return value;
  });
}
