export function removeSpace(val: string): string {
  return val.replace(/[^\w-]+/g, '');
}
